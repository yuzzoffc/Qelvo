import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

/// Seksi datar di Pengaturan dan Akun: judul kecil, lalu baris-baris yang
/// dipisah garis tipis, tanpa kartu pembungkus.
class SettingSection extends StatelessWidget {
  const SettingSection({super.key, required this.title, required this.children});

  final String title;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(2, 26, 2, 4),
          child: Text(
            title,
            style: t.body(14.5, weight: FontWeight.w700, color: t.muted),
          ),
        ),
        for (var i = 0; i < children.length; i++) ...[
          if (i > 0) Container(height: 1, color: t.border),
          children[i],
        ],
      ],
    );
  }
}

class SettingRow extends StatelessWidget {
  const SettingRow({
    super.key,
    required this.label,
    this.value,
    this.subtitle,
    this.leading,
    this.trailing,
    this.onTap,
    this.chevron = false,
    this.danger = false,
  });

  final String label;
  final String? value;
  final String? subtitle;

  /// Widget di kiri teks, misalnya avatar di baris akun.
  final Widget? leading;

  /// Widget di kanan, misalnya sakelar. Tampil sebelum panah.
  final Widget? trailing;
  final VoidCallback? onTap;
  final bool chevron;

  /// Warna peringatan untuk aksi yang menghapus.
  final bool danger;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final content = Padding(
      padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 12),
      child: Row(
        children: [
          if (leading != null) ...[leading!, const SizedBox(width: 14)],
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: t.body(
                    17,
                    weight: leading != null ? FontWeight.w600 : FontWeight.w400,
                    color: danger ? t.warn : t.text,
                  ),
                ),
                if (subtitle != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 3),
                    child: Text(
                      subtitle!,
                      style: t.body(14, color: t.muted, height: 1.35),
                    ),
                  ),
              ],
            ),
          ),
          if (value != null) ...[
            const SizedBox(width: 12),
            Flexible(
              child: Text(
                value!,
                textAlign: TextAlign.end,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: t.body(16, color: t.muted),
              ),
            ),
          ],
          if (trailing != null) ...[const SizedBox(width: 12), trailing!],
          if (chevron) ...[
            const SizedBox(width: 4),
            Icon(Icons.chevron_right_rounded, size: 24, color: t.muted),
          ],
        ],
      ),
    );
    if (onTap == null) return content;
    return Tappable(
      onTap: onTap,
      borderRadius: BorderRadius.circular(QelvoRadius.sm),
      minSize: 56,
      child: content,
    );
  }
}
