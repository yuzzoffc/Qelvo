import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/state/update_controller.dart';
import 'package:qelvo_ai/ui/markdown/markdown_view.dart';
import 'package:qelvo_ai/ui/widgets/buttons.dart';
import 'package:qelvo_ai/ui/widgets/choice_sheet.dart';

/// Ukuran berkas dalam MB dengan koma desimal, misalnya "24,6 MB".
String megabytes(int bytes) {
  final value = bytes / (1024 * 1024);
  return '${value.toStringAsFixed(1).replaceAll('.', ',')} MB';
}

/// Lembar pembaruan: tawaran, kemajuan unduhan, dan pemasangan. Satu-satunya
/// tempat pembaruan tampil; tidak ada pemberitahuan sistem untuk ini.
Future<void> showUpdateSheet(BuildContext context, UpdateController updates) {
  final t = context.q;
  updates.markPrompted();
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: t.surface,
    shape: kSheetShape,
    builder: (_) => _UpdateSheet(updates: updates),
  );
}

class _UpdateSheet extends StatelessWidget {
  const _UpdateSheet({required this.updates});

  final UpdateController updates;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final bottom = MediaQuery.viewPaddingOf(context).bottom;
    return ListenableBuilder(
      listenable: updates,
      builder: (context, _) {
        final release = updates.release;
        final status = updates.status;
        // Tanpa rilis (sudah ditutup atau dilewati): lembar menutup dirinya.
        if (release == null) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (context.mounted && Navigator.of(context).canPop()) {
              Navigator.of(context).pop();
            }
          });
          return const SizedBox(height: 1);
        }
        final downloading = status == UpdateStatus.downloading;
        return PopScope(
          // Unduhan yang sedang jalan tidak ikut tertutup tanpa sengaja.
          canPop: !downloading,
          child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(20, 10, 20, 20 + bottom),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SheetHandle(),
                const SizedBox(height: 14),
                Text(_title(status), style: t.display(22)),
                const SizedBox(height: 4),
                Text(
                  'QELVO ${release.version}'
                  '${release.apkSize > 0 ? ' · ${megabytes(release.apkSize)}' : ''}'
                  ' · kamu memakai ${updates.versionLabel}',
                  style: t.body(14.5, color: t.muted, height: 1.4),
                ),
                if (release.notes.isNotEmpty) ...[
                  const SizedBox(height: 16),
                  ConstrainedBox(
                    constraints: const BoxConstraints(maxHeight: 220),
                    child: SingleChildScrollView(
                      child: MarkdownView(text: release.notes),
                    ),
                  ),
                ],
                const SizedBox(height: 18),
                if (downloading) _Progress(updates: updates),
                if (updates.needsPermission)
                  _Note(
                    'Android meminta izin dulu. Di layar pengaturan yang terbuka, '
                    'izinkan QELVO memasang aplikasi, lalu kembali ke sini dan '
                    'ketuk Pasang.',
                  ),
                if (updates.error != null)
                  _Note(updates.error!, danger: true),
                const SizedBox(height: 4),
                ..._actions(context, status),
              ],
            ),
          ),
        );
      },
    );
  }

  String _title(UpdateStatus status) => switch (status) {
        UpdateStatus.downloading => 'Mengunduh pembaruan',
        UpdateStatus.ready => 'Siap dipasang',
        UpdateStatus.failed => 'Pembaruan gagal',
        _ => 'Pembaruan tersedia',
      };

  List<Widget> _actions(BuildContext context, UpdateStatus status) {
    switch (status) {
      case UpdateStatus.downloading:
        return [
          OutlineActionButton(
            label: 'Batalkan unduhan',
            onPressed: updates.cancelDownload,
          ),
        ];
      case UpdateStatus.ready:
        return [
          PrimaryButton(label: 'Pasang', onPressed: updates.install),
          const SizedBox(height: 10),
          _later(context),
        ];
      case UpdateStatus.failed:
        return [
          PrimaryButton(label: 'Coba lagi', onPressed: updates.download),
          const SizedBox(height: 10),
          _later(context),
        ];
      default:
        return [
          PrimaryButton(label: 'Perbarui', onPressed: updates.download),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SmallButton(
                label: 'Nanti',
                onPressed: () {
                  updates.dismiss();
                },
              ),
              const SizedBox(width: 10),
              SmallButton(
                label: 'Lewati versi ini',
                onPressed: () {
                  updates.skip();
                },
              ),
            ],
          ),
        ];
    }
  }

  Widget _later(BuildContext context) {
    return Center(
      child: SmallButton(
        label: 'Nanti',
        onPressed: () {
          updates.dismiss();
        },
      ),
    );
  }
}

class _Progress extends StatelessWidget {
  const _Progress({required this.updates});

  final UpdateController updates;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final total = updates.totalBytes;
    final label = total > 0
        ? '${megabytes(updates.receivedBytes)} dari ${megabytes(total)}'
        : megabytes(updates.receivedBytes);
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Semantics(
        label: 'Mengunduh pembaruan, $label',
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Garis kemajuan netral: cyan hanya untuk momen kunci (tombol utama,
            // sakelar menyala, ekor logo).
            ClipRRect(
              borderRadius: BorderRadius.circular(3),
              child: LinearProgressIndicator(
                value: total > 0 ? updates.progress : null,
                minHeight: 6,
                backgroundColor: t.border,
                color: t.text,
              ),
            ),
            const SizedBox(height: 8),
            Text(label, style: t.body(13.5, color: t.muted)),
          ],
        ),
      ),
    );
  }
}

class _Note extends StatelessWidget {
  const _Note(this.text, {this.danger = false});

  final String text;
  final bool danger;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Text(
        text,
        style: t.body(14, color: danger ? t.warn : t.muted, height: 1.45),
      ),
    );
  }
}
