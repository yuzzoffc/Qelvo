import 'dart:async';

import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/core/time_format.dart';
import 'package:qelvo_ai/data/api_client.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/state/app_state.dart';
import 'package:qelvo_ai/state/chat_controller.dart';
import 'package:qelvo_ai/state/session.dart';
import 'package:qelvo_ai/ui/widgets/dialogs.dart';
import 'package:qelvo_ai/ui/widgets/profile_avatar.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_spinner.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

/// Session dan app dikirim eksplisit karena dialog berada di luar pohon
/// widget tempat SessionScope dipasang.
Future<void> showHistoryDrawer(
  BuildContext context, {
  required Session session,
  required ChatController chat,
  required VoidCallback onOpenSettings,
  required VoidCallback onOpenAccount,
}) {
  final app = AppScope.of(context);
  return showGeneralDialog<void>(
    context: context,
    barrierDismissible: true,
    barrierLabel: 'Tutup riwayat',
    barrierColor: const Color(0x99000000),
    transitionDuration: const Duration(milliseconds: 220),
    pageBuilder: (dialogContext, _, __) => _DrawerPage(
      app: app,
      session: session,
      chat: chat,
      onOpenSettings: onOpenSettings,
      onOpenAccount: onOpenAccount,
    ),
    transitionBuilder: (context, animation, _, child) {
      final curved = CurvedAnimation(
        parent: animation,
        curve: Curves.easeOutCubic,
      );
      return SlideTransition(
        position: Tween<Offset>(begin: const Offset(-1, 0), end: Offset.zero)
            .animate(curved),
        child: child,
      );
    },
  );
}

class _DrawerPage extends StatefulWidget {
  const _DrawerPage({
    required this.app,
    required this.session,
    required this.chat,
    required this.onOpenSettings,
    required this.onOpenAccount,
  });

  final AppState app;
  final Session session;
  final ChatController chat;
  final VoidCallback onOpenSettings;
  final VoidCallback onOpenAccount;

  @override
  State<_DrawerPage> createState() => _DrawerPageState();
}

class _DrawerPageState extends State<_DrawerPage> {
  final TextEditingController _search = TextEditingController();
  String _query = '';

  @override
  void initState() {
    super.initState();
    // Daftar yang sudah ada tampil dulu; data terbaru menyusul dari server.
    unawaited(widget.session.history.refresh());
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  void _close() => Navigator.of(context).pop();

  void _startNewChat() {
    _close();
    widget.chat.reset();
  }

  void _openConversation(Conversation conversation) {
    _close();
    widget.chat.open(conversation);
  }

  void _openSettings() {
    _close();
    widget.onOpenSettings();
  }

  void _openAccount() {
    _close();
    widget.onOpenAccount();
  }

  Future<void> _confirmDelete(Conversation conversation) async {
    final ok = await confirmDialog(
      context,
      title: 'Hapus percakapan?',
      message: '"${conversation.title}" akan dihapus dari akunmu.',
      confirmLabel: 'Hapus',
      destructive: true,
    );
    if (!ok || !mounted) return;
    // Kalau percakapan ini sedang terbuka, layarnya dikosongkan lebih dulu tanpa
    // menyimpan jawaban setengah jadi, supaya percakapannya tidak hidup lagi.
    if (widget.chat.conversationId == conversation.id) {
      widget.chat.reset(persistPartial: false);
    }
    try {
      await widget.session.enqueue(
        () => widget.session.repository.deleteConversation(conversation.id),
      );
      unawaited(widget.session.history.refresh());
    } catch (error) {
      if (mounted) {
        showNotice(
          context,
          error is ApiException
              ? error.message
              : 'Gagal menghapus. Periksa koneksi lalu coba lagi.',
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final media = MediaQuery.of(context);
    final width = (media.size.width * 0.82).clamp(280.0, 380.0).toDouble();

    return Stack(
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: SizedBox(
            width: width,
            height: double.infinity,
            child: Material(
              color: t.panel,
              child: Container(
                decoration: BoxDecoration(
                  border: Border(right: BorderSide(color: t.border)),
                ),
                child: SafeArea(
                  child: Column(
                    children: [
                      _searchField(t),
                      _newChatRow(t),
                      Expanded(child: _list(t)),
                      _footer(t),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
        Positioned(
          top: media.padding.top + 8,
          right: 8,
          child: Tappable(
            label: 'Tutup riwayat',
            onTap: _close,
            borderRadius: BorderRadius.circular(22),
            child: const Padding(
              padding: EdgeInsets.all(10),
              child: Icon(Icons.close_rounded, size: 26, color: Colors.white),
            ),
          ),
        ),
      ],
    );
  }

  Widget _searchField(QelvoTheme t) {
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 12, 14, 4),
      padding: const EdgeInsets.symmetric(horizontal: 14),
      height: 50,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(25),
        border: Border.all(color: t.border),
      ),
      child: Row(
        children: [
          Icon(Icons.search_rounded, size: 22, color: t.muted),
          const SizedBox(width: 10),
          Expanded(
            child: TextField(
              controller: _search,
              onChanged: (value) => setState(() => _query = value),
              style: t.body(16),
              cursorColor: t.accentText,
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                isCollapsed: true,
                border: InputBorder.none,
                hintText: 'Cari percakapan',
                hintStyle: t.body(16, color: t.muted),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _newChatRow(QelvoTheme t) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 4, 8, 4),
      child: Tappable(
        onTap: _startNewChat,
        minSize: 52,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(
            children: [
              Icon(Icons.edit_outlined, size: 22, color: t.accentText),
              const SizedBox(width: 14),
              Text('Percakapan baru', style: t.body(17, weight: FontWeight.w600)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _list(QelvoTheme t) {
    final history = widget.session.history;
    return ListenableBuilder(
      listenable: history,
      builder: (context, _) {
        if (history.loading && history.items.isEmpty) {
          return const Center(child: QelvoSpinner());
        }
        if (history.error != null && history.items.isEmpty) {
          return _message(
            t,
            history.error!,
            actionLabel: 'Coba lagi',
            onAction: history.refresh,
          );
        }
        final items = history.search(_query);
        if (items.isEmpty) {
          final searching = _query.trim().isNotEmpty;
          final saving = widget.app.settings.saveHistory;
          return _message(
            t,
            searching
                ? 'Tidak ada percakapan yang cocok dengan "${_query.trim()}".'
                : saving
                    ? 'Belum ada percakapan. Pertanyaan yang kamu kirim akan tersimpan di akunmu.'
                    : 'Penyimpanan riwayat sedang mati. Nyalakan di Pengaturan agar percakapan baru tersimpan.',
          );
        }

        final now = DateTime.now();
        final children = <Widget>[];
        String? lastLabel;
        for (final conversation in items) {
          final label = groupLabel(now, conversation.updatedAt);
          if (label != lastLabel) {
            children.add(_GroupLabel(label));
            lastLabel = label;
          }
          children.add(
            _ConversationRow(
              conversation: conversation,
              selected: conversation.id == widget.chat.conversationId,
              onTap: () => _openConversation(conversation),
              onLongPress: () => _confirmDelete(conversation),
            ),
          );
        }
        children.add(
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 16, 14, 8),
            child: Text(
              'Tekan lama untuk menghapus percakapan.',
              style: t.body(13.5, color: t.muted),
            ),
          ),
        );
        return ListView(
          padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
          children: children,
        );
      },
    );
  }

  Widget _message(
    QelvoTheme t,
    String text, {
    String? actionLabel,
    VoidCallback? onAction,
  }) {
    return Padding(
      padding: const EdgeInsets.all(22),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            text,
            textAlign: TextAlign.center,
            style: t.body(15, color: t.muted, height: 1.5),
          ),
          if (actionLabel != null) ...[
            const SizedBox(height: 10),
            Tappable(
              onTap: onAction,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                child: Text(
                  actionLabel,
                  style: t.body(15, weight: FontWeight.w700, color: t.accentText),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _footer(QelvoTheme t) {
    final session = widget.session;
    final guest = session.isGuest;
    final hasName = session.displayName.isNotEmpty;
    final name = guest
        ? 'Tamu'
        : hasName
            ? session.displayName
            : session.email;
    final detail = guest
        ? 'Masuk atau daftar'
        : hasName
            ? session.email
            : '';
    return Container(
      padding: const EdgeInsets.fromLTRB(6, 8, 6, 8),
      decoration: BoxDecoration(
        border: Border(top: BorderSide(color: t.border)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Tappable(
              label: guest ? 'Masuk atau daftar' : 'Akun, $name',
              onTap: _openAccount,
              borderRadius: BorderRadius.circular(QelvoRadius.md),
              minSize: 56,
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Row(
                  children: [
                    ProfileAvatar(session: session, size: 44),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: t.body(16, weight: FontWeight.w600),
                          ),
                          if (detail.isNotEmpty)
                            Text(
                              detail,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: t.body(14, color: t.muted),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Tappable(
            label: 'Pengaturan',
            onTap: _openSettings,
            borderRadius: BorderRadius.circular(22),
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Icon(Icons.tune_rounded, size: 24, color: t.muted),
            ),
          ),
        ],
      ),
    );
  }
}

class _GroupLabel extends StatelessWidget {
  const _GroupLabel(this.label);

  final String label;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 18, 14, 6),
      child: Text(
        label,
        style: t.body(14.5, weight: FontWeight.w700, color: t.muted),
      ),
    );
  }
}

class _ConversationRow extends StatelessWidget {
  const _ConversationRow({
    required this.conversation,
    required this.selected,
    required this.onTap,
    required this.onLongPress,
  });

  final Conversation conversation;
  final bool selected;
  final VoidCallback onTap;
  final VoidCallback onLongPress;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Tappable(
      onTap: onTap,
      onLongPress: onLongPress,
      selected: selected,
      label: conversation.title,
      minSize: 48,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        decoration: BoxDecoration(
          color: selected ? t.bubble : Colors.transparent,
          borderRadius: BorderRadius.circular(QelvoRadius.md),
        ),
        child: Text(
          conversation.title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: t.body(16.5),
        ),
      ),
    );
  }
}
