import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';
import 'package:url_launcher/url_launcher.dart';

/// Sumber yang dikutip jawaban hasil pencarian web, sebagai tombol kecil yang
/// membuka halamannya di peramban. Dipasang di dalam kartu jawaban, di bawah
/// teksnya, dan hanya setelah jawabannya selesai supaya tata letaknya tidak
/// bergeser saat teks masih mengalir.
class SourceChips extends StatelessWidget {
  const SourceChips({super.key, required this.sources});

  final List<ChatSource> sources;

  /// Membuka [url] di peramban. Hanya http dan https; selain itu diabaikan.
  /// Gagal membuka (tidak ada peramban) juga diabaikan: tidak ada yang bisa
  /// dilakukan pengguna dari sini selain mencoba lagi.
  static Future<void> open(String url) async {
    final uri = Uri.tryParse(url);
    if (uri == null || (uri.scheme != 'http' && uri.scheme != 'https')) return;
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      // Lihat catatan di atas.
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Sumber',
          style: t.body(13, weight: FontWeight.w600, color: t.muted),
        ),
        const SizedBox(height: 8),
        // Antarbaris tanpa jarak: area sentuh tiap tombol setinggi 44 dp, jadi
        // ruang di antara tampilan tombolnya sudah ada.
        Wrap(
          spacing: 8,
          children: [
            for (var i = 0; i < sources.length; i++)
              _SourceChip(number: i + 1, source: sources[i]),
          ],
        ),
      ],
    );
  }
}

class _SourceChip extends StatelessWidget {
  const _SourceChip({required this.number, required this.source});

  final int number;
  final ChatSource source;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final radius = BorderRadius.circular(18);
    return ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 220),
      child: Tappable(
        label: 'Sumber $number: ${source.label}. Buka di peramban.',
        onTap: () => SourceChips.open(source.url),
        borderRadius: radius,
        // Tampilan tombol 32 dp, area sentuhnya 44 dp (Tappable bawaan).
        child: Center(
          widthFactor: 1,
          child: Container(
            padding: const EdgeInsets.fromLTRB(11, 8, 13, 8),
            decoration: BoxDecoration(
              borderRadius: radius,
              border: Border.all(color: t.aiBubbleLine),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  '$number',
                  style: t.body(12.5, weight: FontWeight.w700, color: t.muted),
                ),
                const SizedBox(width: 8),
                Flexible(
                  child: Text(
                    source.label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: t.body(13.5, height: 1.2),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
