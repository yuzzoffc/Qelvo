import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_spinner.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

/// Baris gambar kecil foto yang akan dikirim, di atas kolom tulis di komposer.
/// Tiap foto punya tombol silang untuk dilepas. Foto yang baru dipilih dan
/// masih diolah tampil sebagai kotak berputar di ujung baris.
class AttachmentStrip extends StatelessWidget {
  const AttachmentStrip({
    super.key,
    required this.attachments,
    required this.onRemove,
    this.pending = 0,
  });

  final List<ChatAttachment> attachments;

  /// Jumlah foto yang sedang diolah.
  final int pending;

  /// Dipanggil dengan nomor urut foto (mulai dari 0).
  final ValueChanged<int> onRemove;

  static const double thumbSize = 72;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          for (var i = 0; i < attachments.length; i++) ...[
            if (i > 0) const SizedBox(width: 10),
            _Thumb(
              attachment: attachments[i],
              number: i + 1,
              onRemove: () => onRemove(i),
            ),
          ],
          for (var j = 0; j < pending; j++) ...[
            if (attachments.isNotEmpty || j > 0) const SizedBox(width: 10),
            const _PendingThumb(),
          ],
        ],
      ),
    );
  }
}

class _PendingThumb extends StatelessWidget {
  const _PendingThumb();

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Semantics(
      label: 'Foto sedang disiapkan',
      excludeSemantics: true,
      child: Container(
        width: AttachmentStrip.thumbSize,
        height: AttachmentStrip.thumbSize,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: t.bubble,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: t.border),
        ),
        child: const QelvoSpinner(size: 24),
      ),
    );
  }
}

class _Thumb extends StatelessWidget {
  const _Thumb({
    required this.attachment,
    required this.number,
    required this.onRemove,
  });

  final ChatAttachment attachment;
  final int number;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return SizedBox(
      width: AttachmentStrip.thumbSize,
      height: AttachmentStrip.thumbSize,
      child: Stack(
        children: [
          Positioned.fill(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: Semantics(
                image: true,
                label: 'Foto $number',
                child: Image.memory(
                  attachment.thumb,
                  fit: BoxFit.cover,
                  gaplessPlayback: true,
                  excludeFromSemantics: true,
                ),
              ),
            ),
          ),
          // Area sentuh 44dp di pojok kanan atas; yang terlihat hanya lingkaran kecil.
          Positioned(
            top: 0,
            right: 0,
            child: Tappable(
              label: 'Hapus foto $number',
              onTap: onRemove,
              borderRadius: BorderRadius.circular(22),
              child: Center(
                child: Container(
                  width: 22,
                  height: 22,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: t.text),
                  child: Icon(Icons.close_rounded, size: 15, color: t.bg),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
