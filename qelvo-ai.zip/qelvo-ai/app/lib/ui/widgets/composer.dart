import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/ui/widgets/attachment_strip.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

/// Kolom tulis pesan: kartu dengan foto terlampir (bila ada) dan isian di atas,
/// lalu tombol + di kiri bawah dan tombol kirim di kanan bawah. Foto, Cari web,
/// dan Berpikir ada di lembar yang dibuka tombol + ([onAdd]), jadi di sini tidak
/// ada chip. Bentuknya sama di beranda dan di dalam percakapan.
class Composer extends StatefulWidget {
  const Composer({
    super.key,
    required this.controller,
    required this.focusNode,
    required this.hint,
    required this.busy,
    required this.onSend,
    required this.onStop,
    this.onAdd,
    this.attachments = const [],
    this.pendingAttachments = 0,
    this.onRemoveAttachment,
  });

  final TextEditingController controller;
  final FocusNode focusNode;
  final String hint;

  /// True saat jawaban sedang dialirkan; tombol kirim berubah jadi berhenti.
  final bool busy;
  final VoidCallback onSend;
  final VoidCallback onStop;

  /// Membuka lembar Tambahkan ke chat. Tanpa ini tombol + tidak tampil.
  final VoidCallback? onAdd;

  /// Foto yang akan dikirim bersama pesan, dan aksinya.
  final List<ChatAttachment> attachments;

  /// Foto yang baru dipilih dan masih diolah. Selama ada, tombol kirim belum aktif.
  final int pendingAttachments;
  final ValueChanged<int>? onRemoveAttachment;

  @override
  State<Composer> createState() => _ComposerState();
}

class _ComposerState extends State<Composer> {
  late bool _hasText = widget.controller.text.trim().isNotEmpty;

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_onTextChanged);
  }

  @override
  void didUpdateWidget(Composer oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.controller != widget.controller) {
      oldWidget.controller.removeListener(_onTextChanged);
      widget.controller.addListener(_onTextChanged);
      _hasText = widget.controller.text.trim().isNotEmpty;
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onTextChanged);
    super.dispose();
  }

  void _onTextChanged() {
    final hasText = widget.controller.text.trim().isNotEmpty;
    if (hasText != _hasText) setState(() => _hasText = hasText);
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final hasPhotos =
        widget.attachments.isNotEmpty || widget.pendingAttachments > 0;

    return Container(
      padding: const EdgeInsets.fromLTRB(10, 14, 10, 10),
      decoration: BoxDecoration(
        color: t.surface,
        borderRadius: BorderRadius.circular(QelvoRadius.xl),
        border: Border.all(color: t.border),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (hasPhotos) ...[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: AttachmentStrip(
                attachments: widget.attachments,
                pending: widget.pendingAttachments,
                onRemove: widget.onRemoveAttachment ?? (_) {},
              ),
            ),
            const SizedBox(height: 14),
          ],
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: TextField(
              controller: widget.controller,
              focusNode: widget.focusNode,
              minLines: 1,
              maxLines: 6,
              keyboardType: TextInputType.multiline,
              textInputAction: TextInputAction.newline,
              textCapitalization: TextCapitalization.sentences,
              style: t.body(17, height: 1.3),
              cursorColor: t.text,
              decoration: InputDecoration(
                isCollapsed: true,
                border: InputBorder.none,
                hintText: widget.hint,
                hintStyle: t.body(17, color: t.muted, height: 1.3),
                contentPadding: const EdgeInsets.symmetric(vertical: 4),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              if (widget.onAdd != null)
                _AddButton(
                  count: widget.attachments.length,
                  onTap: widget.onAdd!,
                ),
              const Spacer(),
              _SendButton(
                busy: widget.busy,
                enabled: _hasText && widget.pendingAttachments == 0,
                onSend: widget.onSend,
                onStop: widget.onStop,
                size: 46,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// Tombol + yang membuka lembar Tambahkan ke chat. Dibuat paling mencolok
/// setelah tombol kirim: isi lebih terang dari kartu, garis tepi tegas (3:1),
/// dan tanda + tebal berwarna teks utama.
class _AddButton extends StatelessWidget {
  const _AddButton({required this.count, required this.onTap});

  final int count;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Tappable(
      label: count == 0
          ? 'Tambahkan ke chat'
          : 'Tambahkan ke chat, $count foto terlampir',
      onTap: onTap,
      borderRadius: BorderRadius.circular(23),
      minSize: 46,
      child: Container(
        width: 46,
        height: 46,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: t.bubble,
          border: Border.all(color: t.outline, width: 1.4),
        ),
        child: Icon(Icons.add_rounded, size: 28, color: t.text),
      ),
    );
  }
}

class _SendButton extends StatelessWidget {
  const _SendButton({
    required this.busy,
    required this.enabled,
    required this.onSend,
    required this.onStop,
    required this.size,
  });

  final bool busy;
  final bool enabled;
  final VoidCallback onSend;
  final VoidCallback onStop;
  final double size;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final active = busy || enabled;
    final VoidCallback? action = busy ? onStop : (enabled ? onSend : null);
    return Semantics(
      button: true,
      enabled: active,
      label: busy ? 'Hentikan jawaban' : 'Kirim pesan',
      onTap: action,
      excludeSemantics: true,
      child: Material(
        color: active ? t.accent : t.bubble,
        shape: const CircleBorder(),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: action,
          child: SizedBox.square(
            dimension: size,
            child: Center(
              child: busy
                  ? Container(
                      width: 14,
                      height: 14,
                      decoration: BoxDecoration(
                        color: t.onAccent,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    )
                  : Icon(
                      Icons.arrow_upward_rounded,
                      size: 24,
                      color: enabled ? t.onAccent : t.muted,
                    ),
            ),
          ),
        ),
      ),
    );
  }
}
