import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/ui/widgets/attachment_strip.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

/// Kolom tulis pesan: kartu dengan foto terlampir (bila ada) dan isian di atas,
/// lalu tombol lampir, chip Berpikir dan Cari web di bawahnya, dan tombol kirim
/// di kanan. Bentuknya sama di beranda dan di dalam percakapan.
class Composer extends StatefulWidget {
  const Composer({
    super.key,
    required this.controller,
    required this.focusNode,
    required this.hint,
    required this.busy,
    required this.onSend,
    required this.onStop,
    this.thinking = false,
    this.onToggleThinking,
    this.onWebSearch,
    this.attachments = const [],
    this.onAttach,
    this.onRemoveAttachment,
  });

  final TextEditingController controller;
  final FocusNode focusNode;
  final String hint;

  /// True saat jawaban sedang dialirkan; tombol kirim berubah jadi berhenti.
  final bool busy;
  final VoidCallback onSend;
  final VoidCallback onStop;
  final bool thinking;
  final VoidCallback? onToggleThinking;
  final VoidCallback? onWebSearch;

  /// Foto yang akan dikirim bersama pesan, dan aksinya.
  final List<ChatAttachment> attachments;
  final VoidCallback? onAttach;
  final ValueChanged<int>? onRemoveAttachment;

  @override
  State<Composer> createState() => _ComposerState();
}

class _ComposerState extends State<Composer> {
  late bool _hasText = widget.controller.text.trim().isNotEmpty;

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_onTextChanged);
  }

  @override
  void didUpdateWidget(Composer oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.controller != widget.controller) {
      oldWidget.controller.removeListener(_onTextChanged);
      widget.controller.addListener(_onTextChanged);
      _hasText = widget.controller.text.trim().isNotEmpty;
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onTextChanged);
    super.dispose();
  }

  void _onTextChanged() {
    final hasText = widget.controller.text.trim().isNotEmpty;
    if (hasText != _hasText) setState(() => _hasText = hasText);
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;

    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 10, 10),
      decoration: BoxDecoration(
        color: t.surface,
        borderRadius: BorderRadius.circular(QelvoRadius.xl),
        border: Border.all(color: t.border),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (widget.attachments.isNotEmpty) ...[
            AttachmentStrip(
              attachments: widget.attachments,
              onRemove: widget.onRemoveAttachment ?? (_) {},
            ),
            const SizedBox(height: 14),
          ],
          TextField(
            controller: widget.controller,
            focusNode: widget.focusNode,
            minLines: 1,
            maxLines: 6,
            keyboardType: TextInputType.multiline,
            textInputAction: TextInputAction.newline,
            textCapitalization: TextCapitalization.sentences,
            style: t.body(17, height: 1.3),
            cursorColor: t.accentText,
            decoration: InputDecoration(
              isCollapsed: true,
              border: InputBorder.none,
              hintText: widget.hint,
              hintStyle: t.body(17, color: t.muted, height: 1.3),
              contentPadding: const EdgeInsets.symmetric(vertical: 4),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Expanded(
                child: Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    if (widget.onAttach != null)
                      _AttachButton(
                        count: widget.attachments.length,
                        onTap: widget.onAttach!,
                      ),
                    _ToggleChip(
                      icon: Icons.psychology_outlined,
                      label: 'Berpikir',
                      active: widget.thinking,
                      onTap: widget.onToggleThinking,
                    ),
                    // TODO(web-search): aktifkan setelah backend punya pencarian web.
                    _ToggleChip(
                      icon: Icons.language_rounded,
                      label: 'Cari web',
                      note: 'Segera',
                      active: false,
                      onTap: widget.onWebSearch,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              _SendButton(
                busy: widget.busy,
                enabled: _hasText,
                onSend: widget.onSend,
                onStop: widget.onStop,
                size: 46,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _AttachButton extends StatelessWidget {
  const _AttachButton({required this.count, required this.onTap});

  final int count;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Tappable(
      label: count == 0 ? 'Lampirkan foto' : 'Tambah foto, $count terlampir',
      onTap: onTap,
      borderRadius: BorderRadius.circular(22),
      child: Container(
        width: 44,
        height: 44,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: t.border),
        ),
        child: Icon(Icons.add_rounded, size: 24, color: t.text),
      ),
    );
  }
}

class _ToggleChip extends StatelessWidget {
  const _ToggleChip({
    required this.icon,
    required this.label,
    required this.active,
    required this.onTap,
    this.note,
  });

  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback? onTap;
  final String? note;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final foreground = active ? t.accentText : t.muted;
    return Tappable(
      onTap: onTap,
      selected: active,
      borderRadius: BorderRadius.circular(22),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        decoration: BoxDecoration(
          color: active ? t.accentSoft : Colors.transparent,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: active ? t.accentLine : t.border),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 19, color: foreground),
            const SizedBox(width: 6),
            Text(
              label,
              style: t.body(15, weight: FontWeight.w600, color: foreground),
            ),
            if (note != null) ...[
              const SizedBox(width: 6),
              Text(note!, style: t.mono(10.5, color: t.muted)),
            ],
          ],
        ),
      ),
    );
  }
}

class _SendButton extends StatelessWidget {
  const _SendButton({
    required this.busy,
    required this.enabled,
    required this.onSend,
    required this.onStop,
    required this.size,
  });

  final bool busy;
  final bool enabled;
  final VoidCallback onSend;
  final VoidCallback onStop;
  final double size;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final active = busy || enabled;
    final VoidCallback? action = busy ? onStop : (enabled ? onSend : null);
    return Semantics(
      button: true,
      enabled: active,
      label: busy ? 'Hentikan jawaban' : 'Kirim pesan',
      onTap: action,
      excludeSemantics: true,
      child: Material(
        color: active ? t.accent : t.bubble,
        shape: const CircleBorder(),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: action,
          child: SizedBox.square(
            dimension: size,
            child: Center(
              child: busy
                  ? Container(
                      width: 14,
                      height: 14,
                      decoration: BoxDecoration(
                        color: t.onAccent,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    )
                  : Icon(
                      Icons.arrow_upward_rounded,
                      size: 24,
                      color: enabled ? t.onAccent : t.muted,
                    ),
            ),
          ),
        ),
      ),
    );
  }
}
