import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';

/// Mengembalikan true hanya kalau pengguna menekan tombol konfirmasi.
Future<bool> confirmDialog(
  BuildContext context, {
  required String title,
  required String message,
  required String confirmLabel,
  bool destructive = false,
}) async {
  final t = context.q;
  final result = await showDialog<bool>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      backgroundColor: t.surface,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(QelvoRadius.lg),
        side: BorderSide(color: t.border),
      ),
      title: Text(title, style: t.display(19)),
      content: Text(message, style: t.body(15.5, color: t.muted, height: 1.45)),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(dialogContext).pop(false),
          child: Text(
            'Batal',
            style: t.body(15.5, weight: FontWeight.w600, color: t.muted),
          ),
        ),
        TextButton(
          onPressed: () => Navigator.of(dialogContext).pop(true),
          child: Text(
            confirmLabel,
            style: t.body(
              15.5,
              weight: FontWeight.w700,
              color: destructive ? t.warn : t.accentText,
            ),
          ),
        ),
      ],
    ),
  );
  return result ?? false;
}

void showNotice(BuildContext context, String message) {
  final messenger = ScaffoldMessenger.of(context);
  messenger.hideCurrentSnackBar();
  messenger.showSnackBar(
    SnackBar(content: Text(message), duration: const Duration(seconds: 3)),
  );
}
