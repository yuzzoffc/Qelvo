import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';

/// Mengembalikan true hanya kalau pengguna menekan tombol konfirmasi.
Future<bool> confirmDialog(
  BuildContext context, {
  required String title,
  required String message,
  required String confirmLabel,
  bool destructive = false,
}) async {
  final t = context.q;
  final result = await showDialog<bool>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      backgroundColor: t.surface,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(QelvoRadius.lg),
        side: BorderSide(color: t.border),
      ),
      title: Text(title, style: t.display(19)),
      content: Text(message, style: t.body(15.5, color: t.muted, height: 1.45)),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(dialogContext).pop(false),
          child: Text(
            'Batal',
            style: t.body(15.5, weight: FontWeight.w600, color: t.muted),
          ),
        ),
        TextButton(
          onPressed: () => Navigator.of(dialogContext).pop(true),
          child: Text(
            confirmLabel,
            style: t.body(
              15.5,
              weight: FontWeight.w700,
              color: destructive ? t.warn : t.text,
            ),
          ),
        ),
      ],
    ),
  );
  return result ?? false;
}

void showNotice(BuildContext context, String message) {
  final messenger = ScaffoldMessenger.of(context);
  messenger.hideCurrentSnackBar();
  messenger.showSnackBar(
    SnackBar(content: Text(message), duration: const Duration(seconds: 3)),
  );
}

/// Dialog dengan satu kolom isian. Mengembalikan teks yang disimpan, atau null
/// kalau dibatalkan. Dengan [allowEmpty], teks kosong juga boleh disimpan
/// (untuk menghapus isian).
Future<String?> promptDialog(
  BuildContext context, {
  required String title,
  required String confirmLabel,
  String initial = '',
  String? hint,
  String? helper,
  int maxLength = 100,
  int maxLines = 1,
  bool allowEmpty = false,
}) {
  return showDialog<String>(
    context: context,
    builder: (_) => _PromptDialog(
      title: title,
      confirmLabel: confirmLabel,
      initial: initial,
      hint: hint,
      helper: helper,
      maxLength: maxLength,
      maxLines: maxLines,
      allowEmpty: allowEmpty,
    ),
  );
}

class _PromptDialog extends StatefulWidget {
  const _PromptDialog({
    required this.title,
    required this.confirmLabel,
    required this.initial,
    required this.hint,
    required this.helper,
    required this.maxLength,
    required this.maxLines,
    required this.allowEmpty,
  });

  final String title;
  final String confirmLabel;
  final String initial;
  final String? hint;
  final String? helper;
  final int maxLength;
  final int maxLines;
  final bool allowEmpty;

  @override
  State<_PromptDialog> createState() => _PromptDialogState();
}

class _PromptDialogState extends State<_PromptDialog> {
  late final TextEditingController _controller =
      TextEditingController(text: widget.initial);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _submit() {
    final text = _controller.text.trim();
    if (text.isEmpty && !widget.allowEmpty) return;
    Navigator.of(context).pop(text);
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    OutlineInputBorder border(Color color, [double width = 1]) =>
        OutlineInputBorder(
          borderRadius: BorderRadius.circular(QelvoRadius.md),
          borderSide: BorderSide(color: color, width: width),
        );
    final single = widget.maxLines == 1;
    return AlertDialog(
      backgroundColor: t.surface,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(QelvoRadius.lg),
        side: BorderSide(color: t.border),
      ),
      title: Text(widget.title, style: t.display(19)),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (widget.helper != null) ...[
              Text(
                widget.helper!,
                style: t.body(15, color: t.muted, height: 1.45),
              ),
              const SizedBox(height: 14),
            ],
            TextField(
              controller: _controller,
              autofocus: true,
              maxLength: widget.maxLength,
              maxLines: widget.maxLines,
              minLines: 1,
              textCapitalization: TextCapitalization.sentences,
              textInputAction:
                  single ? TextInputAction.done : TextInputAction.newline,
              onSubmitted: single ? (_) => _submit() : null,
              style: t.body(16),
              cursorColor: t.text,
              decoration: InputDecoration(
                hintText: widget.hint,
                hintStyle: t.body(16, color: t.muted),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 14,
                ),
                border: border(t.outline),
                enabledBorder: border(t.outline),
                focusedBorder: border(t.text, 2),
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: Text(
            'Batal',
            style: t.body(15.5, weight: FontWeight.w600, color: t.muted),
          ),
        ),
        TextButton(
          onPressed: _submit,
          child: Text(
            widget.confirmLabel,
            style: t.body(15.5, weight: FontWeight.w700),
          ),
        ),
      ],
    );
  }
}
