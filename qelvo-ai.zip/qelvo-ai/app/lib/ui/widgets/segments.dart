import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

/// Kontrol segmen satu pilihan: Gelap, Terang, Sistem di Pengaturan, dan
/// Masuk, Daftar di layar login. Segmen terpilih berisi cyan dan bertulisan
/// tebal, jadi statusnya tidak hanya terbaca dari warna.
class QelvoSegments<T> extends StatelessWidget {
  const QelvoSegments({
    super.key,
    required this.options,
    required this.value,
    required this.onChanged,
  });

  final List<(T, String)> options;
  final T value;
  final ValueChanged<T> onChanged;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: t.surface,
        borderRadius: BorderRadius.circular(QelvoRadius.md + 2),
        border: Border.all(color: t.border),
      ),
      child: Row(
        children: [
          for (final (option, label) in options)
            Expanded(
              child: Tappable(
                label: label,
                selected: value == option,
                onTap: () => onChanged(option),
                borderRadius: BorderRadius.circular(QelvoRadius.md),
                child: Container(
                  height: 44,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: value == option ? t.accent : Colors.transparent,
                    borderRadius: BorderRadius.circular(QelvoRadius.md),
                  ),
                  child: Text(
                    label,
                    style: t.body(
                      16,
                      weight: value == option ? FontWeight.w700 : FontWeight.w500,
                      color: value == option ? t.onAccent : t.muted,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
