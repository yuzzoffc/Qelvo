import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

/// Satu pilihan di menu tekan-lama.
class QelvoMenuItem<T> {
  const QelvoMenuItem({
    required this.value,
    required this.label,
    required this.icon,
    this.destructive = false,
  });

  final T value;
  final String label;
  final IconData icon;

  /// Aksi yang menghapus: ikon dan tulisannya merah ([QelvoTheme.danger]).
  final bool destructive;
}

/// Menu mengambang di dekat titik sentuh, seperti menu tekan-lama di app Claude:
/// kartu bersudut bulat, tiap baris berikon dan berlabel. [anchor] adalah titik
/// sentuh (koordinat layar). Mengembalikan nilai pilihan, atau null kalau menu
/// ditutup tanpa memilih (ketuk di luar menu atau tombol kembali).
Future<T?> showQelvoMenu<T>(
  BuildContext context, {
  required Offset anchor,
  required List<QelvoMenuItem<T>> items,
}) {
  return showGeneralDialog<T>(
    context: context,
    barrierDismissible: true,
    barrierLabel: 'Tutup menu',
    barrierColor: Colors.transparent,
    transitionDuration: const Duration(milliseconds: 140),
    pageBuilder: (dialogContext, animation, secondaryAnimation) {
      return _MenuLayer<T>(anchor: anchor, items: items, animation: animation);
    },
    // Geraknya dipasang di kartu menu (_MenuLayer), bukan di seluruh layar.
    transitionBuilder: (context, animation, secondaryAnimation, child) => child,
  );
}

class _MenuLayer<T> extends StatelessWidget {
  const _MenuLayer({
    required this.anchor,
    required this.items,
    required this.animation,
  });

  final Offset anchor;
  final List<QelvoMenuItem<T>> items;
  final Animation<double> animation;

  @override
  Widget build(BuildContext context) {
    Widget card = QelvoMenuCard(
      children: [
        for (final item in items)
          QelvoMenuRow(
            icon: item.icon,
            label: item.label,
            destructive: item.destructive,
            onTap: () => Navigator.of(context).pop(item.value),
          ),
      ],
    );
    // Muncul dari titik sentuh: memudar dan membesar sedikit. Berhenti total
    // kalau pengguna mengurangi animasi.
    if (!MediaQuery.disableAnimationsOf(context)) {
      final curved = animation.drive(CurveTween(curve: Curves.easeOutCubic));
      card = FadeTransition(
        opacity: curved,
        child: ScaleTransition(
          scale: curved.drive(Tween<double>(begin: 0.94, end: 1)),
          alignment: Alignment.topLeft,
          child: card,
        ),
      );
    }
    return CustomSingleChildLayout(
      delegate: _MenuLayout(
        anchor: anchor,
        safe: MediaQuery.paddingOf(context),
      ),
      child: card,
    );
  }
}

/// Kartu menu: isi `bubble` dengan garis tepi tipis, tanpa bayangan (aturan
/// desain proyek: tidak ada glow atau bayangan).
class QelvoMenuCard extends StatelessWidget {
  const QelvoMenuCard({super.key, required this.children, this.width = 236});

  final List<Widget> children;
  final double width;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Container(
      width: width,
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: t.bubble,
        borderRadius: BorderRadius.circular(QelvoRadius.lg),
        border: Border.all(color: t.aiBubbleLine),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: children,
      ),
    );
  }
}

/// Satu baris menu: ikon di kiri, tulisan di kanannya.
class QelvoMenuRow extends StatelessWidget {
  const QelvoMenuRow({
    super.key,
    required this.icon,
    required this.label,
    required this.onTap,
    this.destructive = false,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool destructive;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Tappable(
      onTap: onTap,
      label: label,
      minSize: 48,
      borderRadius: BorderRadius.circular(QelvoRadius.md),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Row(
          children: [
            Icon(icon, size: 22, color: destructive ? t.danger : t.muted),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: t.body(16.5, color: destructive ? t.danger : t.text),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Menu teks terpilih (Salin, Pilih semua, ...) untuk kolom tulis dan kolom
/// pencarian. Isinya tetap dari Flutter, hanya tampilannya yang mengikuti menu
/// tekan-lama.
Widget qelvoEditableMenu(BuildContext context, EditableTextState state) {
  return _SelectionMenu(
    anchors: state.contextMenuAnchors,
    items: state.contextMenuButtonItems,
  );
}

/// Menu teks terpilih untuk teks pesan (SelectableText dan SelectionArea).
Widget qelvoSelectableMenu(BuildContext context, SelectableRegionState state) {
  return _SelectionMenu(
    anchors: state.contextMenuAnchors,
    items: state.contextMenuButtonItems,
  );
}

class _SelectionMenu extends StatelessWidget {
  const _SelectionMenu({required this.anchors, required this.items});

  final TextSelectionToolbarAnchors anchors;
  final List<ContextMenuButtonItem> items;

  @override
  Widget build(BuildContext context) {
    final rows = <Widget>[];
    for (final item in items) {
      final onPressed = item.onPressed;
      final label = _selectionLabel(item);
      if (onPressed == null || label == null) continue;
      rows.add(QelvoMenuRow(
        icon: _selectionIcon(item.type),
        label: label,
        onTap: onPressed,
      ));
    }
    if (rows.isEmpty) return const SizedBox.shrink();
    return CustomSingleChildLayout(
      delegate: _MenuLayout(
        // Di bawah teks terpilih; kalau tidak muat, di atasnya.
        anchor: anchors.secondaryAnchor ?? anchors.primaryAnchor,
        above: anchors.primaryAnchor,
        safe: MediaQuery.paddingOf(context),
        centered: true,
      ),
      child: QelvoMenuCard(width: 208, children: rows),
    );
  }
}

String? _selectionLabel(ContextMenuButtonItem item) {
  switch (item.type) {
    case ContextMenuButtonType.copy:
      return 'Salin';
    case ContextMenuButtonType.cut:
      return 'Potong';
    case ContextMenuButtonType.paste:
      return 'Tempel';
    case ContextMenuButtonType.selectAll:
      return 'Pilih semua';
    case ContextMenuButtonType.share:
      return 'Bagikan';
    case ContextMenuButtonType.lookUp:
      return 'Cari';
    case ContextMenuButtonType.searchWeb:
      return 'Cari di web';
    default:
      return item.label;
  }
}

IconData _selectionIcon(ContextMenuButtonType type) {
  switch (type) {
    case ContextMenuButtonType.copy:
      return Icons.content_copy_outlined;
    case ContextMenuButtonType.cut:
      return Icons.content_cut;
    case ContextMenuButtonType.paste:
      return Icons.content_paste;
    case ContextMenuButtonType.selectAll:
      return Icons.select_all;
    case ContextMenuButtonType.share:
      return Icons.ios_share_rounded;
    case ContextMenuButtonType.lookUp:
    case ContextMenuButtonType.searchWeb:
      return Icons.search_rounded;
    default:
      return Icons.more_horiz;
  }
}

/// Menaruh menu di dekat [anchor] dan menjaganya tetap di dalam layar.
///
/// Secara bawaan sudut kiri atas menu ada di [anchor] (menu tekan-lama).
/// Dengan [centered], menu ditengahkan pada [anchor] (menu teks terpilih). Kalau
/// menu tidak muat di bawah dan [above] ada, sisi bawah menu ditaruh di [above].
class _MenuLayout extends SingleChildLayoutDelegate {
  const _MenuLayout({
    required this.anchor,
    required this.safe,
    this.above,
    this.centered = false,
  });

  final Offset anchor;
  final Offset? above;
  final EdgeInsets safe;
  final bool centered;

  static const double _margin = 12;

  @override
  BoxConstraints getConstraintsForChild(BoxConstraints constraints) {
    return constraints.loosen();
  }

  @override
  Offset getPositionForChild(Size size, Size childSize) {
    final minX = safe.left + _margin;
    final maxX = math.max(
      minX,
      size.width - safe.right - _margin - childSize.width,
    );
    final minY = safe.top + _margin;
    final maxY = math.max(
      minY,
      size.height - safe.bottom - _margin - childSize.height,
    );
    final wantedX = centered ? anchor.dx - childSize.width / 2 : anchor.dx;
    var wantedY = anchor.dy;
    final flipTo = above;
    if (wantedY > maxY && flipTo != null) {
      wantedY = flipTo.dy - childSize.height;
    }
    return Offset(
      wantedX.clamp(minX, maxX).toDouble(),
      wantedY.clamp(minY, maxY).toDouble(),
    );
  }

  @override
  bool shouldRelayout(_MenuLayout oldDelegate) {
    return anchor != oldDelegate.anchor ||
        above != oldDelegate.above ||
        safe != oldDelegate.safe ||
        centered != oldDelegate.centered;
  }
}
