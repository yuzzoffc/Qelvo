import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';

class QelvoSpinner extends StatefulWidget {
  const QelvoSpinner({
    super.key,
    this.size = 22,
    this.strokeWidth = 2.6,
    this.color,
  });

  final double size;
  final double strokeWidth;

  /// Warna busur. Kalau kosong, memakai warna aksen tema.
  final Color? color;

  @override
  State<QelvoSpinner> createState() => _QelvoSpinnerState();
}

class _QelvoSpinnerState extends State<QelvoSpinner>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  );

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Saat pengguna meminta animasi dikurangi, busur dibiarkan diam.
    if (MediaQuery.disableAnimationsOf(context)) {
      _controller.stop();
    } else if (!_controller.isAnimating) {
      _controller.repeat();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Semantics(
      label: 'Memuat',
      child: SizedBox.square(
        dimension: widget.size,
        child: RotationTransition(
          turns: _controller,
          child: CustomPaint(
            painter: _ArcPainter(
              track: widget.color?.withAlpha(60) ?? t.border,
              arc: widget.color ?? t.accentText,
              width: widget.strokeWidth,
            ),
          ),
        ),
      ),
    );
  }
}

class _ArcPainter extends CustomPainter {
  _ArcPainter({required this.track, required this.arc, required this.width});

  final Color track;
  final Color arc;
  final double width;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = (Offset.zero & size).deflate(width / 2);
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = width
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(rect, 0, 2 * math.pi, false, paint..color = track);
    canvas.drawArc(rect, -math.pi / 2, math.pi / 2, false, paint..color = arc);
  }

  @override
  bool shouldRepaint(_ArcPainter oldDelegate) =>
      oldDelegate.track != track ||
      oldDelegate.arc != arc ||
      oldDelegate.width != width;
}
