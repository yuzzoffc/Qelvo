import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/state/attachment_policy.dart';
import 'package:qelvo_ai/ui/widgets/buttons.dart';
import 'package:qelvo_ai/ui/widgets/choice_sheet.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_spinner.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

/// Membuka lembar "Pilih foto". Hasilnya foto yang sudah diperkecil dan siap
/// dikirim, atau null kalau lembar ditutup tanpa memilih.
Future<List<ChatAttachment>?> showPhotoPicker(
  BuildContext context, {
  required int maxSelect,
}) {
  final t = context.q;
  return showModalBottomSheet<List<ChatAttachment>>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: t.bg,
    shape: kSheetShape,
    builder: (_) => _PhotoPickerSheet(maxSelect: maxSelect),
  );
}

enum _Stage { loading, ready, denied, failed }

class _PhotoPickerSheet extends StatefulWidget {
  const _PhotoPickerSheet({required this.maxSelect});

  final int maxSelect;

  @override
  State<_PhotoPickerSheet> createState() => _PhotoPickerSheetState();
}

class _PhotoPickerSheetState extends State<_PhotoPickerSheet> {
  static const int _pageSize = 60;

  final ScrollController _scroll = ScrollController();
  final List<AssetEntity> _selected = [];
  final List<AssetEntity> _assets = [];
  List<AssetPathEntity> _albums = const [];
  AssetPathEntity? _album;
  _Stage _stage = _Stage.loading;
  int _page = 0;
  bool _hasMore = true;
  bool _loadingMore = false;
  bool _processing = false;
  String? _problem;

  /// Naik setiap kali folder berganti, supaya hasil pemuatan folder lama yang
  /// terlambat tiba tidak tercampur ke daftar folder baru.
  int _generation = 0;

  @override
  void initState() {
    super.initState();
    _scroll.addListener(_onScroll);
    unawaited(_start());
  }

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (!_scroll.hasClients) return;
    final position = _scroll.position;
    if (position.pixels > position.maxScrollExtent - 600) {
      unawaited(_loadMore());
    }
  }

  Future<void> _start() async {
    // Dipanggil dari initState (tahap sudah loading) dan dari tombol Coba lagi.
    if (_stage != _Stage.loading) setState(() => _stage = _Stage.loading);
    try {
      final permission = await PhotoManager.requestPermissionExtend();
      if (!mounted) return;
      final granted = permission == PermissionState.authorized ||
          permission == PermissionState.limited;
      if (!granted) {
        setState(() => _stage = _Stage.denied);
        return;
      }
      final albums = await PhotoManager.getAssetPathList(type: RequestType.image);
      if (!mounted) return;
      _albums = _ordered(albums);
      if (_albums.isEmpty) {
        setState(() => _stage = _Stage.ready);
        return;
      }
      await _select(_albums.first);
    } catch (_) {
      if (mounted) setState(() => _stage = _Stage.failed);
    }
  }

  /// Terbaru dulu, lalu Kamera, Screenshot, dan Unduhan, baru folder lainnya.
  static int _rank(AssetPathEntity album) {
    if (album.isAll) return 0;
    switch (album.name.toLowerCase()) {
      case 'camera':
        return 1;
      case 'screenshots':
        return 2;
      case 'download':
      case 'downloads':
        return 3;
      default:
        return 4;
    }
  }

  static List<AssetPathEntity> _ordered(List<AssetPathEntity> albums) {
    final sorted = List<AssetPathEntity>.of(albums);
    sorted.sort((a, b) {
      final byRank = _rank(a).compareTo(_rank(b));
      if (byRank != 0) return byRank;
      return a.name.toLowerCase().compareTo(b.name.toLowerCase());
    });
    return sorted;
  }

  static String _albumLabel(AssetPathEntity album) {
    if (album.isAll) return 'Terbaru';
    switch (album.name.toLowerCase()) {
      case 'camera':
        return 'Kamera';
      case 'screenshots':
        return 'Screenshot';
      case 'download':
      case 'downloads':
        return 'Unduhan';
      default:
        return album.name;
    }
  }

  Future<void> _select(AssetPathEntity album) async {
    _generation++;
    _loadingMore = false;
    setState(() {
      _album = album;
      _assets.clear();
      _page = 0;
      _hasMore = true;
      _stage = _Stage.loading;
    });
    await _loadMore();
  }

  Future<void> _loadMore() async {
    final album = _album;
    if (album == null || _loadingMore || !_hasMore) return;
    _loadingMore = true;
    final generation = _generation;
    try {
      final batch = await album.getAssetListPaged(page: _page, size: _pageSize);
      if (!mounted || generation != _generation) return;
      setState(() {
        _assets.addAll(batch);
        _page++;
        _hasMore = batch.length == _pageSize;
        _stage = _Stage.ready;
      });
    } catch (_) {
      if (mounted && generation == _generation) {
        setState(() {
          _hasMore = false;
          _stage = _assets.isEmpty ? _Stage.failed : _Stage.ready;
        });
      }
    } finally {
      if (generation == _generation) _loadingMore = false;
    }
  }

  void _toggle(AssetEntity asset) {
    final index = _selected.indexWhere((item) => item.id == asset.id);
    setState(() {
      _problem = null;
      if (index >= 0) {
        _selected.removeAt(index);
      } else if (_selected.length < widget.maxSelect) {
        _selected.add(asset);
      }
    });
  }

  /// Foto yang dikirim ke model dan gambar kecilnya dibuat oleh Android lewat
  /// photo_manager, jadi tidak ada pengolahan gambar di Dart. Kalau hasilnya
  /// terlalu besar, ukuran dan mutunya diturunkan bertahap.
  Future<ChatAttachment?> _prepare(AssetEntity asset) async {
    Uint8List? full;
    for (final (side, quality) in const [(1280, 82), (1024, 72), (768, 62)]) {
      final bytes = await asset.thumbnailDataWithSize(
        ThumbnailSize(side, side),
        quality: quality,
      );
      if (bytes == null) continue;
      full = bytes;
      if (bytes.length <= AttachmentRules.maxPhotoBytes) break;
    }
    if (full == null || full.length > AttachmentRules.maxPhotoBytes) return null;

    Uint8List? thumb;
    for (final (side, quality) in const [(256, 62), (192, 55), (128, 50)]) {
      final bytes = await asset.thumbnailDataWithSize(
        ThumbnailSize(side, side),
        quality: quality,
      );
      if (bytes == null) continue;
      thumb = bytes;
      if (bytes.length <= AttachmentRules.maxThumbBytes) break;
    }
    if (thumb == null || thumb.length > AttachmentRules.maxThumbBytes) return null;

    return ChatAttachment(thumb: thumb, full: full);
  }

  Future<void> _confirm() async {
    if (_selected.isEmpty || _processing) return;
    setState(() {
      _processing = true;
      _problem = null;
    });
    final result = <ChatAttachment>[];
    for (final asset in List<AssetEntity>.of(_selected)) {
      final attachment = await _prepare(asset);
      if (!mounted) return;
      if (attachment != null) result.add(attachment);
    }
    if (result.isEmpty) {
      setState(() {
        _processing = false;
        _problem = 'Foto yang dipilih tidak bisa dibuka. Coba foto lain.';
      });
      return;
    }
    Navigator.of(context).pop(result);
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return SizedBox(
      height: MediaQuery.sizeOf(context).height * 0.9,
      child: Column(
        children: [
          const Padding(
            padding: EdgeInsets.only(top: 10),
            child: SheetHandle(),
          ),
          _header(t),
          _albumChips(t),
          Expanded(child: _body(t)),
          _footer(t),
        ],
      ),
    );
  }

  Widget _header(QelvoTheme t) {
    final album = _album;
    final count = _selected.length;
    final reached = count >= widget.maxSelect;
    final subtitle = album == null
        ? 'Pilih sampai ${widget.maxSelect} foto'
        : 'Folder ${_albumLabel(album)} · $count dipilih${reached ? ' (maksimal)' : ''}';
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 6, 8, 6),
      child: Row(
        children: [
          Tappable(
            label: 'Tutup',
            onTap: () => Navigator.of(context).pop(),
            borderRadius: BorderRadius.circular(24),
            minSize: 48,
            child: Center(child: Icon(Icons.close_rounded, size: 26, color: t.text)),
          ),
          Expanded(
            child: Column(
              children: [
                Text('Pilih foto', style: t.display(18)),
                const SizedBox(height: 2),
                Semantics(
                  liveRegion: true,
                  child: Text(
                    subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: t.body(14, color: t.muted),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 48),
        ],
      ),
    );
  }

  Widget _albumChips(QelvoTheme t) {
    if (_albums.length < 2) return const SizedBox.shrink();
    return SizedBox(
      height: 56,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        itemCount: _albums.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final album = _albums[index];
          final selected = album.id == _album?.id;
          return Tappable(
            label: 'Folder ${_albumLabel(album)}',
            selected: selected,
            onTap: () => _select(album),
            borderRadius: BorderRadius.circular(22),
            child: Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: selected ? t.accentSoft : Colors.transparent,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: selected ? t.accentLine : t.border),
              ),
              child: Text(
                _albumLabel(album),
                style: t.body(
                  15,
                  weight: FontWeight.w600,
                  color: selected ? t.accentText : t.muted,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _body(QelvoTheme t) {
    switch (_stage) {
      case _Stage.loading:
        return const Center(child: QelvoSpinner(size: 28));
      case _Stage.denied:
        return _message(
          t,
          icon: Icons.photo_library_outlined,
          text: 'QELVO belum boleh membuka foto. Izinkan akses foto di pengaturan, lalu coba lagi.',
          actions: [
            SmallButton(
              label: 'Buka pengaturan',
              filled: true,
              onPressed: () => PhotoManager.openSetting(),
            ),
            SmallButton(label: 'Coba lagi', onPressed: _start),
          ],
        );
      case _Stage.failed:
        return _message(
          t,
          icon: Icons.error_outline_rounded,
          text: 'Foto tidak bisa dimuat.',
          actions: [SmallButton(label: 'Coba lagi', onPressed: _start)],
        );
      case _Stage.ready:
        if (_assets.isEmpty) {
          return _message(
            t,
            icon: Icons.image_not_supported_outlined,
            text: 'Tidak ada foto di folder ini.',
          );
        }
        return GridView.builder(
          controller: _scroll,
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            mainAxisSpacing: 6,
            crossAxisSpacing: 6,
          ),
          itemCount: _assets.length,
          itemBuilder: (context, index) {
            final asset = _assets[index];
            final order = _selected.indexWhere((item) => item.id == asset.id);
            final selected = order >= 0;
            return _AssetTile(
              key: ValueKey(asset.id),
              asset: asset,
              order: selected ? order + 1 : 0,
              dimmed: !selected && _selected.length >= widget.maxSelect,
              onTap: () => _toggle(asset),
            );
          },
        );
    }
  }

  Widget _message(
    QelvoTheme t, {
    required IconData icon,
    required String text,
    List<Widget> actions = const [],
  }) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 36, color: t.muted),
            const SizedBox(height: 14),
            Text(
              text,
              textAlign: TextAlign.center,
              style: t.body(16, color: t.muted, height: 1.5),
            ),
            if (actions.isNotEmpty) ...[
              const SizedBox(height: 18),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                alignment: WrapAlignment.center,
                children: actions,
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _footer(QelvoTheme t) {
    final count = _selected.length;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (_problem != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Semantics(
                liveRegion: true,
                child: Text(
                  _problem!,
                  textAlign: TextAlign.center,
                  style: t.body(14, color: t.warn),
                ),
              ),
            ),
          PrimaryButton(
            label: count == 0 ? 'Tambahkan foto' : 'Tambahkan $count foto',
            busy: _processing,
            onPressed: count == 0 ? null : _confirm,
          ),
        ],
      ),
    );
  }
}

/// Satu kotak foto di grid. Gambar kecilnya dimuat sendiri; kalau terpilih,
/// tampil bergaris cyan dengan nomor urut pilihan.
class _AssetTile extends StatefulWidget {
  const _AssetTile({
    super.key,
    required this.asset,
    required this.order,
    required this.dimmed,
    required this.onTap,
  });

  final AssetEntity asset;

  /// Nomor urut pilihan mulai dari 1, atau 0 kalau belum dipilih.
  final int order;
  final bool dimmed;
  final VoidCallback onTap;

  @override
  State<_AssetTile> createState() => _AssetTileState();
}

class _AssetTileState extends State<_AssetTile> {
  late final Future<Uint8List?> _thumb = widget.asset.thumbnailDataWithSize(
    const ThumbnailSize(300, 300),
    quality: 80,
  );

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final selected = widget.order > 0;
    final radius = BorderRadius.circular(10);
    return Tappable(
      label: selected ? 'Foto, dipilih nomor ${widget.order}' : 'Foto',
      selected: selected,
      onTap: widget.dimmed ? null : widget.onTap,
      borderRadius: radius,
      child: ClipRRect(
        borderRadius: radius,
        child: Stack(
          fit: StackFit.expand,
          children: [
            FutureBuilder<Uint8List?>(
              future: _thumb,
              builder: (context, snapshot) {
                final data = snapshot.data;
                if (data == null) return ColoredBox(color: t.surface);
                return Image.memory(
                  data,
                  fit: BoxFit.cover,
                  gaplessPlayback: true,
                  excludeFromSemantics: true,
                );
              },
            ),
            if (widget.dimmed) ColoredBox(color: t.bg.withAlpha(150)),
            if (selected) ...[
              DecoratedBox(
                decoration: BoxDecoration(
                  border: Border.all(color: t.accent, width: 3),
                  borderRadius: radius,
                ),
              ),
              Positioned(
                top: 6,
                right: 6,
                child: Container(
                  width: 24,
                  height: 24,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: t.accent),
                  child: Text(
                    '${widget.order}',
                    style: t.display(13, color: t.onAccent),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
