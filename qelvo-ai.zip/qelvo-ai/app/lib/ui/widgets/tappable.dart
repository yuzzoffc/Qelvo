import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';

/// Area sentuh dengan umpan balik saat ditekan, fokus keyboard, dan semantik
/// tombol. Dibuat di atas InkWell supaya bisa dipakai lewat keyboard dan
/// pembaca layar. Beri [label] kalau isinya hanya ikon.
class Tappable extends StatelessWidget {
  const Tappable({
    super.key,
    required this.onTap,
    required this.child,
    this.label,
    this.onLongPress,
    this.borderRadius = const BorderRadius.all(Radius.circular(QelvoRadius.md)),
    this.minSize = 44,
    this.selected,
  });

  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final Widget child;
  final String? label;
  final BorderRadius borderRadius;
  final double minSize;
  final bool? selected;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final hasLabel = label != null;
    return Semantics(
      button: true,
      enabled: onTap != null,
      selected: selected,
      label: label,
      onTap: hasLabel ? onTap : null,
      onLongPress: hasLabel ? onLongPress : null,
      excludeSemantics: hasLabel,
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(
          onTap: onTap,
          onLongPress: onLongPress,
          borderRadius: borderRadius,
          splashFactory: NoSplash.splashFactory,
          highlightColor: t.text.withAlpha(18),
          focusColor: t.text.withAlpha(40),
          hoverColor: t.text.withAlpha(12),
          child: ConstrainedBox(
            constraints: BoxConstraints(minWidth: minSize, minHeight: minSize),
            child: child,
          ),
        ),
      ),
    );
  }
}
