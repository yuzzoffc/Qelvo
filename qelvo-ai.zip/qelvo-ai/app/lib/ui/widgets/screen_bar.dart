import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

class ScreenBar extends StatelessWidget {
  const ScreenBar({super.key, required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 4),
      child: Row(
        children: [
          Tappable(
            label: 'Kembali',
            onTap: () => Navigator.of(context).maybePop(),
            borderRadius: BorderRadius.circular(24),
            minSize: 48,
            child: Icon(Icons.chevron_left_rounded, size: 32, color: t.text),
          ),
          Expanded(
            child: Text(
              title,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: t.display(18),
            ),
          ),
          // Penyeimbang agar judul tepat di tengah.
          const SizedBox(width: 48),
        ],
      ),
    );
  }
}
