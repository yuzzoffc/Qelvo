import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';

class QelvoToggle extends StatelessWidget {
  const QelvoToggle({
    super.key,
    required this.value,
    required this.onChanged,
    required this.label,
    this.enabled = true,
  });

  final bool value;
  final ValueChanged<bool> onChanged;

  /// Dibacakan pembaca layar, misalnya "Mode berpikir".
  final String label;

  /// Kalau false, saklar tampil redup dan tidak bisa disentuh, misalnya untuk
  /// fitur yang belum tersedia.
  final bool enabled;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final VoidCallback? action = enabled ? () => onChanged(!value) : null;
    return Semantics(
      label: label,
      toggled: value,
      enabled: enabled,
      onTap: action,
      excludeSemantics: true,
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(
          customBorder: const StadiumBorder(),
          splashFactory: NoSplash.splashFactory,
          highlightColor: t.text.withAlpha(18),
          focusColor: t.text.withAlpha(40),
          onTap: action,
          child: Opacity(
            opacity: enabled ? 1 : 0.5,
            child: Padding(
              // Padding memperluas area sentuh ke sekitar 44dp.
              padding: const EdgeInsets.all(7),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 160),
                width: 52,
                height: 30,
                padding: const EdgeInsets.all(3),
                alignment: value ? Alignment.centerRight : Alignment.centerLeft,
                decoration: BoxDecoration(
                  color: value ? t.accent : t.bubble,
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: value ? t.accent : t.outline),
                ),
                child: Container(
                  width: 22,
                  height: 22,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: value ? t.onAccent : t.muted,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
