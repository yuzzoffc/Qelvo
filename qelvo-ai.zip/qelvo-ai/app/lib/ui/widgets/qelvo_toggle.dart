import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';

class QelvoToggle extends StatelessWidget {
  const QelvoToggle({
    super.key,
    required this.value,
    required this.onChanged,
    required this.label,
  });

  final bool value;
  final ValueChanged<bool> onChanged;

  /// Dibacakan pembaca layar, misalnya "Mode berpikir".
  final String label;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Semantics(
      label: label,
      toggled: value,
      onTap: () => onChanged(!value),
      excludeSemantics: true,
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(
          customBorder: const StadiumBorder(),
          splashFactory: NoSplash.splashFactory,
          highlightColor: t.accent.withAlpha(30),
          focusColor: t.accent.withAlpha(48),
          onTap: () => onChanged(!value),
          child: Padding(
            // Padding memperluas area sentuh ke sekitar 44dp.
            padding: const EdgeInsets.all(7),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 160),
              width: 52,
              height: 30,
              padding: const EdgeInsets.all(3),
              alignment: value ? Alignment.centerRight : Alignment.centerLeft,
              decoration: BoxDecoration(
                color: value ? t.accent : t.bubble,
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: value ? t.accent : t.outline),
              ),
              child: Container(
                width: 22,
                height: 22,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: value ? t.onAccent : t.muted,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
