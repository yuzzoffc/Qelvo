import 'dart:async';

import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/state/app_state.dart';
import 'package:qelvo_ai/state/model_catalog.dart';
import 'package:qelvo_ai/ui/widgets/choice_sheet.dart';
import 'package:qelvo_ai/ui/widgets/notice.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_spinner.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

Future<void> showModelSheet(BuildContext context) {
  final app = AppScope.of(context);
  final t = context.q;
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: t.surface,
    shape: kSheetShape,
    builder: (_) => _ModelSheet(app: app),
  );
}

/// Lembar "Pilih model", bergaya lembar pilih model di app Claude: tombol tutup
/// di kiri dan judul di tengah, satu kartu berisi daftar model dengan tanda
/// centang di model yang dipakai, lalu catatan kecil di bawahnya. Menyentuh
/// sebuah model langsung memilihnya dan menutup lembar. Penyedia mengikuti model
/// yang dipilih, jadi tidak ada pilihan penyedia terpisah.
class _ModelSheet extends StatelessWidget {
  const _ModelSheet({required this.app});

  final AppState app;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final bottom = MediaQuery.viewPaddingOf(context).bottom;
    return ListenableBuilder(
      listenable: app.catalog,
      builder: (context, _) {
        return SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(16, 10, 16, 20 + bottom),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SheetHandle(),
              const SizedBox(height: 8),
              const SheetHeader(title: 'Pilih model'),
              const SizedBox(height: 12),
              _models(context, t, app.catalog),
              Padding(
                padding: const EdgeInsets.fromLTRB(6, 14, 6, 0),
                child: Text(
                  'Layanan AI di baliknya ikut menyesuaikan sendiri. Kuota gratis bisa berubah sewaktu-waktu, jadi cek ketentuan dari layanan AI-nya.',
                  style: t.body(13.5, color: t.muted, height: 1.45),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _models(BuildContext context, QelvoTheme t, ModelCatalog catalog) {
    if (catalog.providers.isEmpty) {
      if (catalog.status == CatalogStatus.failed) {
        return InlineNotice(
          message: catalog.error ?? 'Daftar model gagal dimuat.',
          actionLabel: 'Coba lagi',
          onAction: catalog.load,
        );
      }
      if (catalog.status == CatalogStatus.ready) {
        return const InlineNotice(
          message:
              'Server belum punya penyedia AI. Isi GEMINI_API_KEY atau OPENROUTER_API_KEY di backend.',
        );
      }
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 24),
        child: Center(child: QelvoSpinner()),
      );
    }

    final rows = <Widget>[];
    for (final provider in catalog.providers) {
      for (final ModelOption model in provider.models) {
        if (rows.isNotEmpty) {
          rows.add(Divider(height: 1, thickness: 1, color: t.aiBubbleLine));
        }
        rows.add(
          _ModelRow(
            title: model.label,
            subtitle: provider.tagline,
            selected: catalog.isActive(provider, model),
            webSearch: model.webSearch,
            onTap: () {
              unawaited(catalog.selectModel(provider, model));
              Navigator.of(context).pop();
            },
          ),
        );
      }
    }
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: t.bubble,
        borderRadius: BorderRadius.circular(QelvoRadius.lg),
        border: Border.all(color: t.aiBubbleLine),
      ),
      child: Column(children: rows),
    );
  }
}

/// Satu baris model: nama dan keterangan di kiri, tanda centang di kanan kalau
/// model ini yang dipakai. Penanda "Cari web" menunjukkan model yang bisa mencari
/// di web, seperti penanda paket di lembar model app Claude.
class _ModelRow extends StatelessWidget {
  const _ModelRow({
    required this.title,
    required this.subtitle,
    required this.selected,
    required this.webSearch,
    required this.onTap,
  });

  final String title;
  final String subtitle;
  final bool selected;
  final bool webSearch;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Tappable(
      onTap: onTap,
      selected: selected,
      borderRadius: BorderRadius.zero,
      minSize: 72,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 14, 14, 14),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Flexible(child: Text(title, style: t.display(18))),
                      if (webSearch) ...[
                        const SizedBox(width: 10),
                        const _CapabilityPill(label: 'Cari web'),
                      ],
                    ],
                  ),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    style: t.body(14.5, color: t.muted, height: 1.35),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            // Lebar tetap, jadi teks tidak bergeser saat pilihan berpindah.
            SizedBox(
              width: 28,
              child: selected
                  ? Icon(Icons.check_rounded, size: 24, color: t.text)
                  : null,
            ),
          ],
        ),
      ),
    );
  }
}

/// Penanda kecil berbingkai di samping nama model.
class _CapabilityPill extends StatelessWidget {
  const _CapabilityPill({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: t.outline),
      ),
      child: Text(
        label,
        style: t.body(12, weight: FontWeight.w600, color: t.muted, height: 1.2),
      ),
    );
  }
}
