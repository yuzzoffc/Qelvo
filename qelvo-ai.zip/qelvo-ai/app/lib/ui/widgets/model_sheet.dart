import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/state/app_state.dart';
import 'package:qelvo_ai/state/model_catalog.dart';
import 'package:qelvo_ai/ui/widgets/buttons.dart';
import 'package:qelvo_ai/ui/widgets/choice_sheet.dart';
import 'package:qelvo_ai/ui/widgets/notice.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_spinner.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

Future<void> showModelSheet(BuildContext context) {
  final app = AppScope.of(context);
  final t = context.q;
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: t.surface,
    shape: kSheetShape,
    builder: (_) => _ModelSheet(app: app),
  );
}

/// Satu daftar model. Penyedia mengikuti model yang dipilih, jadi tidak ada
/// pilihan penyedia terpisah.
class _ModelSheet extends StatelessWidget {
  const _ModelSheet({required this.app});

  final AppState app;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return ListenableBuilder(
      listenable: Listenable.merge([app.catalog, app.settings]),
      builder: (context, _) {
        return SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 10, 20, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SheetHandle(),
              const SizedBox(height: 18),
              Text('Pilih model', style: t.display(26)),
              const SizedBox(height: 8),
              Text(
                'Penyedia API mengikuti model yang kamu pilih.',
                style: t.body(15.5, color: t.muted, height: 1.45),
              ),
              const SizedBox(height: 18),
              _models(t, app.catalog),
              const SizedBox(height: 6),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 2),
                      child: Icon(
                        Icons.lock_outline_rounded,
                        size: 16,
                        color: t.muted,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Penyedia tidak bisa diganti terpisah, hanya lewat pilihan model. Kuota gratis dapat berubah, jadi cek ketentuan penyedia.',
                        style: t.body(13.5, color: t.muted, height: 1.45),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              PrimaryButton(
                label: 'Selesai',
                onPressed: () => Navigator.of(context).pop(),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _models(QelvoTheme t, ModelCatalog catalog) {
    if (catalog.providers.isEmpty) {
      if (catalog.status == CatalogStatus.failed) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: InlineNotice(
            message: catalog.error ?? 'Daftar model gagal dimuat.',
            actionLabel: 'Coba lagi',
            onAction: catalog.load,
          ),
        );
      }
      if (catalog.status == CatalogStatus.ready) {
        return const Padding(
          padding: EdgeInsets.only(bottom: 12),
          child: InlineNotice(
            message:
                'Server belum punya penyedia AI. Isi GEMINI_API_KEY atau OPENROUTER_API_KEY di backend.',
          ),
        );
      }
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 24),
        child: Center(child: QelvoSpinner()),
      );
    }
    return Column(
      children: [
        for (final provider in catalog.providers)
          for (final ModelOption model in provider.models)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _ModelCard(
                title: model.label,
                subtitle: provider.tagline,
                selected: catalog.isActive(provider, model),
                onTap: () => catalog.selectModel(provider, model),
              ),
            ),
      ],
    );
  }
}

class _ModelCard extends StatelessWidget {
  const _ModelCard({
    required this.title,
    required this.subtitle,
    required this.selected,
    required this.onTap,
  });

  final String title;
  final String subtitle;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final radius = BorderRadius.circular(QelvoRadius.lg);
    return Tappable(
      onTap: onTap,
      selected: selected,
      borderRadius: radius,
      minSize: 68,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(16, 14, 14, 14),
        decoration: BoxDecoration(
          color: selected ? t.accentSoft : Colors.transparent,
          borderRadius: radius,
          border: Border.all(
            color: selected ? t.accentLine : t.border,
            width: selected ? 1.4 : 1,
          ),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: t.display(17.5)),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    style: t.body(14.5, color: t.muted, height: 1.35),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            _RadioMark(selected: selected),
          ],
        ),
      ),
    );
  }
}

class _RadioMark extends StatelessWidget {
  const _RadioMark({required this.selected});

  final bool selected;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Container(
      width: 28,
      height: 28,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: selected ? t.accent : Colors.transparent,
        border: Border.all(color: selected ? t.accent : t.outline, width: 1.6),
      ),
      child: selected
          ? Icon(Icons.check_rounded, size: 18, color: t.onAccent)
          : null,
    );
  }
}
