import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/state/app_state.dart';
import 'package:qelvo_ai/state/model_catalog.dart';
import 'package:qelvo_ai/ui/widgets/choice_sheet.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_logo.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_spinner.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

Future<void> showModelSheet(BuildContext context) {
  final app = AppScope.of(context);
  final t = context.q;
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: t.surface,
    shape: kSheetShape,
    builder: (_) => _ModelSheet(app: app),
  );
}

class _ModelSheet extends StatelessWidget {
  const _ModelSheet({required this.app});

  final AppState app;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return ListenableBuilder(
      listenable: Listenable.merge([app.catalog, app.settings]),
      builder: (context, _) {
        final catalog = app.catalog;
        final active = catalog.activeProvider;
        final models = active?.models ?? const <ModelOption>[];
        return SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 10, 20, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SheetHandle(),
              const SizedBox(height: 18),
              Text('Pilih model', style: t.display(26)),
              const SizedBox(height: 8),
              Text(
                'Jawaban dibuat oleh model dari penyedia API yang dipilih.',
                style: t.body(15.5, color: t.muted, height: 1.45),
              ),
              const SizedBox(height: 18),
              _providers(t, catalog, active),
              const _ProviderCard(
                providerId: 'qelvo',
                title: 'QELVO Intelligence',
                subtitle: 'Pilih model otomatis sesuai pertanyaan',
                selected: false,
                pill: 'Segera',
                onTap: null,
              ),
              if (models.length > 1 && active != null) ...[
                const SizedBox(height: 22),
                Text(
                  'Model ${active.name}',
                  style: t.body(15, weight: FontWeight.w600, color: t.muted),
                ),
                const SizedBox(height: 6),
                for (final model in models)
                  _ModelRow(
                    label: model.label,
                    selected: model.id == catalog.activeModel?.id,
                    onTap: () => catalog.selectModel(model),
                  ),
              ],
              const SizedBox(height: 18),
              Text(
                'Kuota gratis dapat berubah. Cek ketentuan penyedia.',
                style: t.body(14, color: t.muted, height: 1.4),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _providers(QelvoTheme t, ModelCatalog catalog, ProviderInfo? active) {
    if (catalog.providers.isEmpty) {
      if (catalog.status == CatalogStatus.failed) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: _Notice(
            message: catalog.error ?? 'Daftar penyedia gagal dimuat.',
            actionLabel: 'Coba lagi',
            onAction: catalog.load,
          ),
        );
      }
      if (catalog.status == CatalogStatus.ready) {
        return const Padding(
          padding: EdgeInsets.only(bottom: 12),
          child: _Notice(
            message:
                'Server belum punya penyedia AI. Isi GEMINI_API_KEY atau OPENROUTER_API_KEY di backend.',
          ),
        );
      }
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 24),
        child: Center(child: QelvoSpinner()),
      );
    }
    return Column(
      children: [
        for (final provider in catalog.providers)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _ProviderCard(
              providerId: provider.id,
              title: provider.name,
              subtitle: provider.tagline,
              selected: provider.id == active?.id,
              onTap: () => catalog.selectProvider(provider),
            ),
          ),
      ],
    );
  }
}

class _ProviderIcon extends StatelessWidget {
  const _ProviderIcon(this.providerId);

  final String providerId;

  @override
  Widget build(BuildContext context) {
    final color = context.q.accentText;
    return switch (providerId) {
      'gemini' => GeminiMark(size: 22, color: color),
      'qelvo' => QelvoLogo(size: 24, color: color),
      'openrouter' => Icon(Icons.language_rounded, size: 24, color: color),
      _ => Icon(Icons.dns_outlined, size: 24, color: color),
    };
  }
}

class _ProviderCard extends StatelessWidget {
  const _ProviderCard({
    required this.providerId,
    required this.title,
    required this.subtitle,
    required this.selected,
    required this.onTap,
    this.pill,
  });

  final String providerId;
  final String title;
  final String subtitle;
  final bool selected;
  final VoidCallback? onTap;

  /// Label status di kanan, misalnya "Segera" untuk fitur yang belum ada.
  final String? pill;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final radius = BorderRadius.circular(QelvoRadius.lg);
    return Tappable(
      onTap: onTap,
      selected: selected,
      borderRadius: radius,
      minSize: 72,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: selected ? t.accentSoft : Colors.transparent,
          borderRadius: radius,
          border: Border.all(
            color: selected ? t.accentLine : t.border,
            width: selected ? 1.4 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: t.bubble,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Center(child: _ProviderIcon(providerId)),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: t.display(18)),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    style: t.body(14.5, color: t.muted, height: 1.35),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            if (pill != null)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: t.border),
                ),
                child: Text(pill!, style: t.body(13.5, color: t.muted)),
              )
            else
              _RadioMark(selected: selected),
          ],
        ),
      ),
    );
  }
}

class _RadioMark extends StatelessWidget {
  const _RadioMark({required this.selected});

  final bool selected;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Container(
      width: 28,
      height: 28,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: selected ? t.accent : Colors.transparent,
        border: Border.all(color: selected ? t.accent : t.outline, width: 1.6),
      ),
      child: selected
          ? Icon(Icons.check_rounded, size: 18, color: t.onAccent)
          : null,
    );
  }
}

class _ModelRow extends StatelessWidget {
  const _ModelRow({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Tappable(
      onTap: onTap,
      selected: selected,
      minSize: 52,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
        child: Row(
          children: [
            Expanded(child: Text(label, style: t.body(16.5))),
            if (selected) Icon(Icons.check_rounded, size: 22, color: t.accentText),
          ],
        ),
      ),
    );
  }
}

class _Notice extends StatelessWidget {
  const _Notice({required this.message, this.actionLabel, this.onAction});

  final String message;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(QelvoRadius.md),
        border: Border.all(color: t.warn.withAlpha(120)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(message, style: t.body(15, color: t.text, height: 1.45)),
          if (actionLabel != null) ...[
            const SizedBox(height: 8),
            Tappable(
              onTap: onAction,
              borderRadius: BorderRadius.circular(QelvoRadius.sm),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
                child: Text(
                  actionLabel!,
                  style: t.body(15, weight: FontWeight.w700, color: t.accentText),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
