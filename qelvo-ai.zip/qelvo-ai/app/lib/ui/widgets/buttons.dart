import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/ui/widgets/google_mark.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_spinner.dart';

/// Tombol utama: isi cyan, teks gelap. Nonaktif saat [onPressed] null atau [busy].
class PrimaryButton extends StatelessWidget {
  const PrimaryButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.busy = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final bool busy;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final enabled = onPressed != null && !busy;
    return Semantics(
      button: true,
      enabled: enabled,
      label: label,
      onTap: enabled ? onPressed : null,
      excludeSemantics: true,
      child: SizedBox(
        width: double.infinity,
        height: 56,
        child: Material(
          color: enabled || busy ? t.accent : t.bubble,
          shape: const StadiumBorder(),
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: enabled ? onPressed : null,
            child: Center(
              child: busy
                  ? QelvoSpinner(size: 24, color: t.onAccent)
                  : Text(
                      label,
                      style: t.display(
                        17,
                        color: enabled ? t.onAccent : t.muted,
                      ),
                    ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Tombol dengan garis tepi untuk aksi kedua, misalnya Keluar.
class OutlineActionButton extends StatelessWidget {
  const OutlineActionButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.busy = false,
  });

  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  final bool busy;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final enabled = onPressed != null && !busy;
    return Semantics(
      button: true,
      enabled: enabled,
      label: label,
      onTap: enabled ? onPressed : null,
      excludeSemantics: true,
      child: SizedBox(
        width: double.infinity,
        height: 56,
        child: Material(
          color: Colors.transparent,
          shape: StadiumBorder(side: BorderSide(color: t.outline)),
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: enabled ? onPressed : null,
            child: Center(
              child: busy
                  ? const QelvoSpinner(size: 24)
                  : Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (icon != null) ...[
                          Icon(icon, size: 22, color: t.text),
                          const SizedBox(width: 10),
                        ],
                        Text(
                          label,
                          style: t.body(16.5, weight: FontWeight.w600),
                        ),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Tombol "Lanjutkan dengan Google": warna dan logo mengikuti pedoman merek
/// Google, jadi tidak ikut warna aksen QELVO.
class GoogleButton extends StatelessWidget {
  const GoogleButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.busy = false,
  });

  static const Color _ink = Color(0xFF1F1F1F);

  final String label;
  final VoidCallback? onPressed;
  final bool busy;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final enabled = onPressed != null && !busy;
    final fill = dark ? const Color(0xFFF2F2F2) : Colors.white;
    return Semantics(
      button: true,
      enabled: enabled,
      label: label,
      onTap: enabled ? onPressed : null,
      excludeSemantics: true,
      child: SizedBox(
        width: double.infinity,
        height: 56,
        child: Material(
          color: enabled || busy ? fill : fill.withAlpha(120),
          shape: StadiumBorder(
            side: dark ? BorderSide.none : BorderSide(color: t.outline),
          ),
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: enabled ? onPressed : null,
            child: Center(
              child: busy
                  ? const QelvoSpinner(size: 22, color: _ink)
                  : Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const GoogleMark(size: 22),
                        const SizedBox(width: 12),
                        Text(
                          label,
                          style: t.body(16.5, weight: FontWeight.w600, color: _ink),
                        ),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Tombol pil ringkas untuk aksi di dalam konten, misalnya Coba lagi dan
/// Ganti model pada pesan error. [filled] memberi isi cyan.
class SmallButton extends StatelessWidget {
  const SmallButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.filled = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final bool filled;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Semantics(
      button: true,
      enabled: onPressed != null,
      label: label,
      onTap: onPressed,
      excludeSemantics: true,
      child: Material(
        color: filled ? t.accent : Colors.transparent,
        shape: StadiumBorder(
          side: filled ? BorderSide.none : BorderSide(color: t.outline),
        ),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onPressed,
          child: ConstrainedBox(
            constraints: const BoxConstraints(minHeight: 44, minWidth: 44),
            child: Center(
              widthFactor: 1,
              heightFactor: 1,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 22),
                child: Text(
                  label,
                  style: t.body(
                    15.5,
                    weight: FontWeight.w700,
                    color: filled ? t.onAccent : t.text,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
