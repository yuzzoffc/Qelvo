import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_spinner.dart';

/// Tombol utama: isi cyan, teks gelap. Nonaktif saat [onPressed] null atau [busy].
class PrimaryButton extends StatelessWidget {
  const PrimaryButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.busy = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final bool busy;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final enabled = onPressed != null && !busy;
    return Semantics(
      button: true,
      enabled: enabled,
      label: label,
      onTap: enabled ? onPressed : null,
      excludeSemantics: true,
      child: SizedBox(
        width: double.infinity,
        height: 56,
        child: Material(
          color: enabled || busy ? t.accent : t.bubble,
          shape: const StadiumBorder(),
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: enabled ? onPressed : null,
            child: Center(
              child: busy
                  ? QelvoSpinner(size: 24, color: t.onAccent)
                  : Text(
                      label,
                      style: t.display(
                        17,
                        color: enabled ? t.onAccent : t.muted,
                      ),
                    ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Tombol dengan garis tepi untuk aksi kedua, misalnya masuk dengan Google.
class OutlineActionButton extends StatelessWidget {
  const OutlineActionButton({
    super.key,
    required this.label,
    required this.icon,
    required this.onPressed,
    this.busy = false,
  });

  final String label;
  final IconData icon;
  final VoidCallback? onPressed;
  final bool busy;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final enabled = onPressed != null && !busy;
    return Semantics(
      button: true,
      enabled: enabled,
      label: label,
      onTap: enabled ? onPressed : null,
      excludeSemantics: true,
      child: SizedBox(
        width: double.infinity,
        height: 56,
        child: Material(
          color: Colors.transparent,
          shape: StadiumBorder(side: BorderSide(color: t.outline)),
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: enabled ? onPressed : null,
            child: Center(
              child: busy
                  ? const QelvoSpinner(size: 24)
                  : Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(icon, size: 22, color: t.text),
                        const SizedBox(width: 10),
                        Text(
                          label,
                          style: t.body(16.5, weight: FontWeight.w600),
                        ),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }
}
