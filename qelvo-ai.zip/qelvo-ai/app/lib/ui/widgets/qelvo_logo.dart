import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';

/// Logo Q dari desain: cincin dengan celah di kanan bawah dan ekor diagonal.
class QelvoLogo extends StatelessWidget {
  const QelvoLogo({super.key, this.size = 24, this.color});

  final double size;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return SizedBox.square(
      dimension: size,
      child: CustomPaint(painter: _LogoPainter(color ?? context.q.accentText)),
    );
  }
}

class _LogoPainter extends CustomPainter {
  _LogoPainter(this.color);

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    // Kotak logo termasuk ekor yang menjulur, jadi cincin sedikit lebih kecil
    // dari separuh sisi kotak.
    final side = size.shortestSide;
    final outer = side * 0.488;
    final stroke = outer * 0.30;
    final center = Offset(outer, outer);
    final arcRect = Rect.fromCircle(center: center, radius: outer - stroke / 2);
    const gap = 22 * math.pi / 180;
    const diagonal = math.pi / 4;

    final ring = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke;
    canvas.drawArc(arcRect, diagonal + gap, 2 * math.pi - 2 * gap, false, ring);

    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(diagonal);
    canvas.drawRect(
      Rect.fromLTRB(outer * 0.12, -stroke / 2, outer * 1.335, stroke / 2),
      Paint()..color = color,
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(_LogoPainter oldDelegate) => oldDelegate.color != color;
}

/// Bintang empat sudut, tanda Gemini di pilihan penyedia.
class GeminiMark extends StatelessWidget {
  const GeminiMark({super.key, this.size = 22, this.color});

  final double size;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return SizedBox.square(
      dimension: size,
      child: CustomPaint(painter: _StarPainter(color ?? context.q.accentText)),
    );
  }
}

class _StarPainter extends CustomPainter {
  _StarPainter(this.color);

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final cx = w / 2;
    final cy = h / 2;
    const k = 0.08;
    final path = Path()
      ..moveTo(cx, 0)
      ..quadraticBezierTo(cx + k * w, cy - k * h, w, cy)
      ..quadraticBezierTo(cx + k * w, cy + k * h, cx, h)
      ..quadraticBezierTo(cx - k * w, cy + k * h, 0, cy)
      ..quadraticBezierTo(cx - k * w, cy - k * h, cx, 0)
      ..close();
    canvas.drawPath(path, Paint()..color = color);
  }

  @override
  bool shouldRepaint(_StarPainter oldDelegate) => oldDelegate.color != color;
}

/// Ikon menu dua garis: panjang di atas, pendek di bawah.
class MenuGlyph extends StatelessWidget {
  const MenuGlyph({super.key, this.size = 24, this.color});

  final double size;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return SizedBox.square(
      dimension: size,
      child: CustomPaint(painter: _MenuPainter(color ?? context.q.text)),
    );
  }
}

class _MenuPainter extends CustomPainter {
  _MenuPainter(this.color);

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round;
    final w = size.width;
    final h = size.height;
    canvas.drawLine(Offset(w * 0.12, h * 0.36), Offset(w * 0.88, h * 0.36), paint);
    canvas.drawLine(Offset(w * 0.12, h * 0.64), Offset(w * 0.56, h * 0.64), paint);
  }

  @override
  bool shouldRepaint(_MenuPainter oldDelegate) => oldDelegate.color != color;
}
