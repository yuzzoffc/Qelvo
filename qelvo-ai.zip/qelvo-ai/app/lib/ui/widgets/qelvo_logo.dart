import 'dart:math' as math;

import 'package:flutter/foundation.dart' show visibleForTesting;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:qelvo_ai/core/theme.dart';

// Geometri logo QELVO versi 3.0, dalam satuan desain: lebar cincin Q = 100.
// Angkanya diukur dari vektor di PDF identitas visual, bukan digambar ulang:
// cincin luar berpusat di (50, 50); cincin dalam bergeser 4,17 satuan ke kanan
// atas, jadi cincin menebal di kiri bawah dan menipis di kanan atas. Ekor
// bersumbu 45 derajat dan menembus kotak sampai 118,75.

const Offset _outerCenter = Offset(50, 50);
const double _outerRadius = 50;
const Offset _innerCenter = Offset(52.949, 47.049);
const double _innerRadius = 35.417;

// Celah tempat ekor lewat: dua tepi lurus sejajar sisi ekor.
const Offset _outerStart = Offset(76.361, 92.486);
const Offset _outerEnd = Offset(92.486, 76.361);
const Offset _innerStart = Offset(83.625, 64.749);
const Offset _innerEnd = Offset(61.778, 81.348);

/// Sisi kotak yang memuat cincin dan ujung ekor.
const double _symbolExtent = 118.75;

const List<Offset> _letterE = [
  Offset(120.834, 0),
  Offset(169.446, 0),
  Offset(177.777, 8.333),
  Offset(177.777, 13.89),
  Offset(134.723, 13.89),
  Offset(134.723, 43.056),
  Offset(170.833, 43.056),
  Offset(170.833, 56.944),
  Offset(134.723, 56.944),
  Offset(134.723, 86.11),
  Offset(177.777, 86.11),
  Offset(177.777, 100),
  Offset(120.834, 100),
];

const List<Offset> _letterL = [
  Offset(195.832, 0),
  Offset(201.389, 0),
  Offset(209.721, 8.333),
  Offset(209.721, 86.11),
  Offset(252.779, 86.11),
  Offset(252.779, 100),
  Offset(195.832, 100),
];

const List<Offset> _letterV = [
  Offset(233.333, 0),
  Offset(248.098, 0),
  Offset(277.778, 82.223),
  Offset(307.459, 0),
  Offset(310.877, 0),
  Offset(319.209, 8.333),
  Offset(286.11, 100),
  Offset(269.447, 100),
];

const Offset _letterOCenter = Offset(366.668, 50);
const Offset _letterOHole = Offset(369.612, 47.056);

/// Lebar logotype Q E L V O, dan posisi slogan di bawahnya.
const double _wordmarkWidth = 416.667;
const double _taglineLeft = 134.72;
const double _taglineBaseline = 125;
const double _taglineSize = 17.4;
const double _taglineSpan = 200;

Path _buildRing() {
  const outerRect = Rect.fromLTRB(0, 0, 100, 100);
  final innerRect = Rect.fromCircle(center: _innerCenter, radius: _innerRadius);
  double angle(Offset point, Offset center) =>
      math.atan2(point.dy - center.dy, point.dx - center.dx);
  const turn = 2 * math.pi;
  final outerFrom = angle(_outerStart, _outerCenter);
  final outerTo = angle(_outerEnd, _outerCenter);
  final innerFrom = angle(_innerStart, _innerCenter);
  final innerTo = angle(_innerEnd, _innerCenter);
  // Busur luar searah jarum jam dari satu sisi celah ke sisi lainnya, lalu
  // busur dalam kembali berlawanan arah.
  final outerSweep = (outerTo - outerFrom) % turn;
  final innerSweep = (innerFrom - innerTo) % turn;
  return Path()
    ..moveTo(_outerStart.dx, _outerStart.dy)
    ..arcTo(outerRect, outerFrom, outerSweep, false)
    ..lineTo(_innerStart.dx, _innerStart.dy)
    ..arcTo(innerRect, innerFrom, -innerSweep, false)
    ..close();
}

Path _buildTail() => Path()
  ..moveTo(71.111, 56.39)
  ..lineTo(118.75, 118.75)
  ..lineTo(56.39, 71.111)
  ..close();

Path _buildLetters() => Path()
  ..addPolygon(_letterE, true)
  ..addPolygon(_letterL, true)
  ..addPolygon(_letterV, true);

Path _buildLetterO() => Path()
  ..fillType = PathFillType.evenOdd
  ..addOval(Rect.fromCircle(center: _letterOCenter, radius: _outerRadius))
  ..addOval(Rect.fromCircle(center: _letterOHole, radius: _innerRadius));

final Path _ringPath = _buildRing();
final Path _tailPath = _buildTail();
final Path _lettersPath = _buildLetters();
final Path _letterOPath = _buildLetterO();

/// Hanya untuk uji geometri: cincin dan ekor simbol Q.
@visibleForTesting
Path get debugRingPath => _ringPath;

@visibleForTesting
Path get debugTailPath => _tailPath;

/// Simbol Q dari desain. [size] adalah sisi kotak yang memuat cincin dan
/// ujung ekor. Warna bawaan mengikuti tema (cincin terang, ekor cyan);
/// [color] membuat versi satu warna.
class QelvoLogo extends StatelessWidget {
  const QelvoLogo({super.key, this.size = 24, this.color});

  final double size;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return SizedBox.square(
      dimension: size,
      child: CustomPaint(
        painter: _SymbolPainter(
          ring: color ?? t.logoRing,
          tail: color ?? t.logoTail,
        ),
      ),
    );
  }
}

class _SymbolPainter extends CustomPainter {
  const _SymbolPainter({required this.ring, required this.tail});

  final Color ring;
  final Color tail;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.shortestSide / _symbolExtent);
    canvas.drawPath(_ringPath, Paint()..color = ring);
    canvas.drawPath(_tailPath, Paint()..color = tail);
    canvas.restore();
  }

  @override
  bool shouldRepaint(_SymbolPainter oldDelegate) =>
      oldDelegate.ring != ring || oldDelegate.tail != tail;
}

/// Logotype QELVO. Dengan [tagline], slogan "THINK BEYOND." ikut tampil di
/// bawah huruf E sampai O, seperti di PDF identitas. Slogan masih teks hidup
/// (Sora); ubah ke outline sebelum produksi.
class QelvoWordmark extends StatelessWidget {
  const QelvoWordmark({
    super.key,
    this.width = 120,
    this.tagline = false,
    this.color,
  });

  final double width;
  final bool tagline;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final scale = width / _wordmarkWidth;
    final mark = CustomPaint(
      painter: _WordmarkPainter(
        ring: color ?? t.logoRing,
        tail: color ?? t.logoTail,
      ),
    );

    if (!tagline) {
      return Semantics(
        label: 'QELVO',
        child: ExcludeSemantics(
          child: SizedBox(
            width: width,
            height: _symbolExtent * scale,
            child: mark,
          ),
        ),
      );
    }

    final fontSize = _taglineSize * scale;
    return Semantics(
      label: 'QELVO, Think Beyond.',
      child: ExcludeSemantics(
        child: SizedBox(
          width: width,
          height: (_taglineBaseline + 5) * scale,
          child: Stack(
            children: [
              Positioned.fill(child: mark),
              Positioned(
                left: _taglineLeft * scale,
                top: (_taglineBaseline - _taglineSize * 0.8) * scale,
                width: _taglineSpan * scale,
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'THINK BEYOND.',
                    maxLines: 1,
                    style: GoogleFonts.sora(
                      fontSize: fontSize,
                      height: 1.0,
                      letterSpacing: fontSize * 0.3,
                      color: t.muted,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _WordmarkPainter extends CustomPainter {
  const _WordmarkPainter({required this.ring, required this.tail});

  final Color ring;
  final Color tail;

  @override
  void paint(Canvas canvas, Size size) {
    final body = Paint()..color = ring;
    canvas.save();
    canvas.scale(size.width / _wordmarkWidth);
    canvas.drawPath(_ringPath, body);
    canvas.drawPath(_lettersPath, body);
    canvas.drawPath(_letterOPath, body);
    canvas.drawPath(_tailPath, Paint()..color = tail);
    canvas.restore();
  }

  @override
  bool shouldRepaint(_WordmarkPainter oldDelegate) =>
      oldDelegate.ring != ring || oldDelegate.tail != tail;
}

/// Ikon menu dua garis: panjang di atas, pendek di bawah.
class MenuGlyph extends StatelessWidget {
  const MenuGlyph({super.key, this.size = 24, this.color});

  final double size;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return SizedBox.square(
      dimension: size,
      child: CustomPaint(painter: _MenuPainter(color ?? context.q.text)),
    );
  }
}

class _MenuPainter extends CustomPainter {
  _MenuPainter(this.color);

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round;
    final w = size.width;
    final h = size.height;
    canvas.drawLine(Offset(w * 0.12, h * 0.36), Offset(w * 0.88, h * 0.36), paint);
    canvas.drawLine(Offset(w * 0.12, h * 0.64), Offset(w * 0.56, h * 0.64), paint);
  }

  @override
  bool shouldRepaint(_MenuPainter oldDelegate) => oldDelegate.color != color;
}
