import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/state/chat_controller.dart';
import 'package:qelvo_ai/ui/widgets/buttons.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_logo.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

/// Pita di bawah bilah atas saat pesan gagal terkirim karena tidak ada
/// sambungan internet.
class OfflineBanner extends StatelessWidget {
  const OfflineBanner({super.key});

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Semantics(
      liveRegion: true,
      child: Container(
        width: double.infinity,
        color: t.surface,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        child: Row(
          children: [
            Icon(Icons.wifi_off_rounded, size: 18, color: t.muted),
            const SizedBox(width: 10),
            Text('Tidak ada koneksi internet', style: t.body(14.5)),
          ],
        ),
      ),
    );
  }
}

/// Tanda di bawah gelembung pesan yang belum sampai ke server.
class UnsentNotice extends StatelessWidget {
  const UnsentNotice({super.key, required this.onRetry});

  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Align(
      alignment: Alignment.centerRight,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.error_outline_rounded, size: 16, color: t.warn),
          const SizedBox(width: 6),
          Text('Tidak terkirim', style: t.body(13.5, color: t.warn)),
          if (onRetry != null)
            Tappable(
              onTap: onRetry,
              borderRadius: BorderRadius.circular(QelvoRadius.sm),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                child: Text(
                  'Coba lagi',
                  style: t.body(
                    13.5,
                    weight: FontWeight.w700,
                    color: t.accentText,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// Pengganti jawaban yang gagal diperoleh: judul, penjelasan, dan dua aksi.
class ErrorBlock extends StatelessWidget {
  const ErrorBlock({
    super.key,
    required this.failure,
    required this.onRetry,
    required this.onChangeModel,
  });

  final ChatFailure failure;
  final VoidCallback onRetry;
  final VoidCallback onChangeModel;

  /// Pesan dari server, lalu kode status kalau ada, lalu kabar bahwa pesan
  /// pengguna masih ada di percakapan.
  String _detail() {
    var text = failure.message.trim();
    if (text.endsWith('.')) text = text.substring(0, text.length - 1);
    final code = failure.statusCode;
    if (code != null) text = '$text (kode $code)';
    return '$text. Pesanmu tetap ada, jadi tidak perlu mengetik ulang.';
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const QelvoLogo(size: 28),
        const SizedBox(height: 14),
        Semantics(
          liveRegion: true,
          child: Row(
            children: [
              Icon(Icons.warning_amber_rounded, size: 22, color: t.warn),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Tidak dapat memperoleh jawaban',
                  style: t.display(17),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Text(_detail(), style: t.body(15.5, color: t.muted, height: 1.5)),
        const SizedBox(height: 16),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            SmallButton(label: 'Coba lagi', filled: true, onPressed: onRetry),
            SmallButton(label: 'Ganti model', onPressed: onChangeModel),
          ],
        ),
      ],
    );
  }
}

/// Tiga garis kerangka sebelum potongan jawaban pertama tiba. Berdenyut pelan,
/// dan diam kalau pengguna meminta animasi dikurangi.
class ThinkingSkeleton extends StatefulWidget {
  const ThinkingSkeleton({super.key});

  @override
  State<ThinkingSkeleton> createState() => _ThinkingSkeletonState();
}

class _ThinkingSkeletonState extends State<ThinkingSkeleton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1400),
  );
  late final Animation<double> _opacity = Tween<double>(begin: 0.45, end: 1)
      .animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (MediaQuery.disableAnimationsOf(context)) {
      _controller.stop();
      _controller.value = 1;
    } else if (!_controller.isAnimating) {
      _controller.repeat(reverse: true);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    Widget bar(double fraction) => FractionallySizedBox(
          alignment: Alignment.centerLeft,
          widthFactor: fraction,
          child: Container(
            height: 12,
            decoration: BoxDecoration(
              color: t.surface,
              borderRadius: BorderRadius.circular(6),
            ),
          ),
        );
    return ExcludeSemantics(
      child: FadeTransition(
        opacity: _opacity,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Berpikir…', style: t.body(15, color: t.muted)),
            const SizedBox(height: 14),
            bar(1),
            const SizedBox(height: 10),
            bar(0.78),
            const SizedBox(height: 10),
            bar(0.52),
          ],
        ),
      ),
    );
  }
}
