import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/state/chat_controller.dart';
import 'package:qelvo_ai/ui/widgets/buttons.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_logo.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

/// Pita di bawah bilah atas saat pesan gagal terkirim karena tidak ada
/// sambungan internet.
class OfflineBanner extends StatelessWidget {
  const OfflineBanner({super.key});

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Semantics(
      liveRegion: true,
      child: Container(
        width: double.infinity,
        color: t.surface,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        child: Row(
          children: [
            Icon(Icons.wifi_off_rounded, size: 18, color: t.muted),
            const SizedBox(width: 10),
            Text('Tidak ada koneksi internet', style: t.body(14.5)),
          ],
        ),
      ),
    );
  }
}

/// Tanda di bawah gelembung pesan yang belum sampai ke server.
class UnsentNotice extends StatelessWidget {
  const UnsentNotice({super.key, required this.onRetry});

  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Align(
      alignment: Alignment.centerRight,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.error_outline_rounded, size: 16, color: t.warn),
          const SizedBox(width: 6),
          Text('Tidak terkirim', style: t.body(13.5, color: t.warn)),
          if (onRetry != null)
            Tappable(
              onTap: onRetry,
              borderRadius: BorderRadius.circular(QelvoRadius.sm),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                child: Text(
                  'Coba lagi',
                  style: t.body(13.5, weight: FontWeight.w700),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// Pengganti jawaban yang gagal diperoleh: judul, penjelasan, dan dua aksi.
class ErrorBlock extends StatelessWidget {
  const ErrorBlock({
    super.key,
    required this.failure,
    required this.onRetry,
    required this.onChangeModel,
  });

  final ChatFailure failure;
  final VoidCallback onRetry;
  final VoidCallback onChangeModel;

  /// Pesan dari server, lalu kode status kalau ada, lalu kabar bahwa pesan
  /// pengguna masih ada di percakapan.
  String _detail() {
    var text = failure.message.trim();
    if (text.endsWith('.')) text = text.substring(0, text.length - 1);
    final code = failure.statusCode;
    if (code != null) text = '$text (kode $code)';
    return '$text. Pesanmu tetap ada, jadi tidak perlu mengetik ulang.';
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const QelvoLogo(size: 28),
        const SizedBox(height: 14),
        Semantics(
          liveRegion: true,
          child: Row(
            children: [
              Icon(Icons.warning_amber_rounded, size: 22, color: t.warn),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Tidak dapat memperoleh jawaban',
                  style: t.display(17),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Text(_detail(), style: t.body(15.5, color: t.muted, height: 1.5)),
        const SizedBox(height: 16),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            SmallButton(label: 'Coba lagi', filled: true, onPressed: onRetry),
            SmallButton(label: 'Ganti model', onPressed: onChangeModel),
          ],
        ),
      ],
    );
  }
}

/// Penanda bahwa QELVO sedang bekerja sebelum potongan jawaban pertama tiba:
/// tiga titik putih yang bergelombang, kalimat status, dan tiga garis kerangka
/// yang disapu cahaya abu-biru. Menonjolnya lewat gerak dan kontras teks, bukan
/// lewat cyan. Semua gerak berhenti kalau pengguna meminta animasi dikurangi;
/// titik tetap menyala penuh supaya penandanya masih terlihat.
class ThinkingIndicator extends StatefulWidget {
  const ThinkingIndicator({super.key, this.thinking = true});

  /// Mode berpikir menyala. Kalau mati, kalimat status berbunyi "sedang
  /// menjawab", karena server memang tidak diminta berpikir lebih dalam.
  final bool thinking;

  @override
  State<ThinkingIndicator> createState() => _ThinkingIndicatorState();
}

class _ThinkingIndicatorState extends State<ThinkingIndicator>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1500),
  );

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (MediaQuery.disableAnimationsOf(context)) {
      _controller.stop();
    } else if (!_controller.isAnimating) {
      _controller.repeat();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  /// Tinggi gelombang titik ke-[index], dari 0 sampai 1. Tiap titik tertinggal
  /// sedikit dari titik sebelumnya, jadi gelombangnya merambat ke kanan.
  static double _wave(double progress, int index) {
    final phase = (progress - index * 0.16) % 1.0;
    return phase < 0.5 ? phase * 2 : (1 - phase) * 2;
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final still = MediaQuery.disableAnimationsOf(context);
    final status =
        widget.thinking ? 'QELVO sedang berpikir' : 'QELVO sedang menjawab';
    final base = t.aiBubbleLine;
    final glow = Color.lerp(t.outline, t.muted, 0.35)!;

    return Semantics(
      label: status,
      excludeSemantics: true,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) {
          final progress = _controller.value;

          // Pita cahaya bergerak dari kiri ke kanan; tiap garis mulai sedikit
          // terlambat dari garis di atasnya.
          Widget bar(double fraction, double delay) {
            final center = -1.5 + 3 * ((progress + delay) % 1.0);
            return FractionallySizedBox(
              alignment: Alignment.centerLeft,
              widthFactor: fraction,
              child: Container(
                height: 12,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  color: still ? base : null,
                  gradient: still
                      ? null
                      : LinearGradient(
                          begin: Alignment(center - 0.5, 0),
                          end: Alignment(center + 0.5, 0),
                          colors: [base, glow, base],
                        ),
                ),
              ),
            );
          }

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  for (var i = 0; i < 3; i++) ...[
                    if (i > 0) const SizedBox(width: 6),
                    _PulseDot(
                      color: t.text,
                      level: still ? 1 : _wave(progress, i),
                    ),
                  ],
                  const SizedBox(width: 12),
                  Flexible(
                    child: Text(
                      '$status…',
                      style: t.body(15.5, weight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              bar(1, 0),
              const SizedBox(height: 10),
              bar(0.78, 0.12),
              const SizedBox(height: 10),
              bar(0.52, 0.24),
            ],
          );
        },
      ),
    );
  }
}

/// Satu titik penanda. Ukuran dan kepekatannya naik bersama [level] (0 sampai
/// 1), di dalam kotak 10 px yang tetap supaya tata letak tidak bergoyang.
class _PulseDot extends StatelessWidget {
  const _PulseDot({required this.color, required this.level});

  final Color color;
  final double level;

  @override
  Widget build(BuildContext context) {
    final size = 7 + 3 * level;
    return SizedBox(
      width: 10,
      height: 10,
      child: Center(
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: color.withAlpha((90 + 165 * level).round()),
          ),
        ),
      ),
    );
  }
}

/// Garis tipis di bawah bilah atas selama jawaban berjalan, dari menunggu
/// potongan pertama sampai selesai. Penanda cepat bahwa aplikasi sedang bekerja
/// dan tidak macet. Tingginya tetap, jadi isi layar tidak bergeser saat garis
/// muncul. Kalau pengguna mengurangi animasi, garisnya diam.
class ActivityLine extends StatefulWidget {
  const ActivityLine({super.key, required this.active});

  final bool active;

  @override
  State<ActivityLine> createState() => _ActivityLineState();
}

class _ActivityLineState extends State<ActivityLine>
    with SingleTickerProviderStateMixin {
  static const double _height = 3;

  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1300),
  );

  void _sync() {
    final still = MediaQuery.disableAnimationsOf(context);
    if (widget.active && !still) {
      if (!_controller.isAnimating) _controller.repeat();
    } else {
      _controller.stop();
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _sync();
  }

  @override
  void didUpdateWidget(ActivityLine oldWidget) {
    super.didUpdateWidget(oldWidget);
    _sync();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    if (!widget.active) return const SizedBox(height: _height);
    if (MediaQuery.disableAnimationsOf(context)) {
      return SizedBox(height: _height, child: ColoredBox(color: t.outline));
    }
    return ExcludeSemantics(
      child: SizedBox(
        height: _height,
        width: double.infinity,
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, _) => CustomPaint(
            painter: _SweepPainter(
              progress: _controller.value,
              track: t.border,
              bar: t.muted,
            ),
          ),
        ),
      ),
    );
  }
}

class _SweepPainter extends CustomPainter {
  _SweepPainter({
    required this.progress,
    required this.track,
    required this.bar,
  });

  final double progress;
  final Color track;
  final Color bar;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = track);
    final width = size.width * 0.4;
    final left = -width + (size.width + width) * progress;
    final rect = Rect.fromLTWH(left, 0, width, size.height)
        .intersect(Offset.zero & size);
    if (rect.width > 0) canvas.drawRect(rect, Paint()..color = bar);
  }

  @override
  bool shouldRepaint(_SweepPainter oldDelegate) =>
      oldDelegate.progress != progress ||
      oldDelegate.track != track ||
      oldDelegate.bar != bar;
}
