import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/state/session.dart';

/// Lingkaran avatar: dua huruf awal nama, atau ikon orang untuk tamu dan akun
/// tanpa nama maupun email.
class ProfileAvatar extends StatelessWidget {
  const ProfileAvatar({super.key, required this.session, this.size = 44});

  final Session session;
  final double size;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final initials = session.isGuest ? '' : session.initials;
    return ExcludeSemantics(
      child: Container(
        width: size,
        height: size,
        alignment: Alignment.center,
        decoration: BoxDecoration(shape: BoxShape.circle, color: t.bubble),
        child: initials.isEmpty
            ? Icon(Icons.person_outline_rounded, size: size * 0.5, color: t.muted)
            : Text(
                initials,
                style: t.display(size * 0.34, weight: FontWeight.w700),
              ),
      ),
    );
  }
}
