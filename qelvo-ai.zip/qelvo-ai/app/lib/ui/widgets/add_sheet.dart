import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/data/settings_store.dart';
import 'package:qelvo_ai/ui/widgets/choice_sheet.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_toggle.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

/// Hasil lembar Tambahkan ke chat. Hanya Foto yang menutup lembar: Berpikir
/// dan Cari web langsung berlaku saat sakelarnya diubah.
enum AddChoice { photo }

/// Keadaan baris Cari web: bisa dinyalakan, belum ada di server ("Segera
/// hadir"), atau tidak bisa dipakai dengan model yang dipilih. Ditentukan layar
/// obrolan dari daftar model server.
class WebSearchStatus {
  const WebSearchStatus.ready()
      : enabled = true,
        soon = false,
        note = '';

  const WebSearchStatus.soon()
      : enabled = false,
        soon = true,
        note = 'Segera hadir';

  /// Tidak bisa dipakai sekarang; [note] menjelaskan alasannya.
  const WebSearchStatus.unavailable(this.note)
      : enabled = false,
        soon = false;

  /// Sakelarnya bisa diubah.
  final bool enabled;

  /// Server belum punya fiturnya, jadi barisnya berlabel penanda "Segera hadir".
  final bool soon;

  /// Keterangan baris saat [enabled] false.
  final String note;
}

/// Lembar yang dibuka tombol + di komposer. Isinya tiga hal saja: Foto, Cari
/// web, dan Berpikir. Tidak ada tombol File, Kamera, atau Konektor. Foto dibuka
/// lewat pemilih foto bawaan HP, bukan daftar foto buatan aplikasi.
///
/// [photoEnabled] dan [photoNote] datang dari layar obrolan: catatan itu
/// menjelaskan sisa jatah foto, atau alasan Foto tidak bisa dipakai (model tidak
/// membaca foto, daftar model belum dimuat, jatah foto penuh). [webSearch]
/// menjelaskan keadaan baris Cari web dengan cara yang sama.
Future<AddChoice?> showAddSheet(
  BuildContext context, {
  required SettingsStore settings,
  required bool photoEnabled,
  required String photoNote,
  required WebSearchStatus webSearch,
}) {
  final t = context.q;
  return showModalBottomSheet<AddChoice>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: t.surface,
    shape: kSheetShape,
    builder: (_) => _AddSheet(
      settings: settings,
      photoEnabled: photoEnabled,
      photoNote: photoNote,
      webSearch: webSearch,
    ),
  );
}

class _AddSheet extends StatelessWidget {
  const _AddSheet({
    required this.settings,
    required this.photoEnabled,
    required this.photoNote,
    required this.webSearch,
  });

  final SettingsStore settings;
  final bool photoEnabled;
  final String photoNote;
  final WebSearchStatus webSearch;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final bottom = MediaQuery.viewPaddingOf(context).bottom;
    return SingleChildScrollView(
      padding: EdgeInsets.fromLTRB(16, 10, 16, 20 + bottom),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SheetHandle(),
          const SizedBox(height: 8),
          Row(
            children: [
              Tappable(
                label: 'Tutup',
                onTap: () => Navigator.of(context).pop(),
                borderRadius: BorderRadius.circular(24),
                minSize: 48,
                child: Center(
                  child: Icon(Icons.close_rounded, size: 24, color: t.text),
                ),
              ),
              Expanded(
                child: Text(
                  'Tambahkan ke chat',
                  textAlign: TextAlign.center,
                  style: t.display(18),
                ),
              ),
              const SizedBox(width: 48),
            ],
          ),
          const SizedBox(height: 12),
          _PhotoTile(
            enabled: photoEnabled,
            note: photoNote,
            onTap: () => Navigator.of(context).pop(AddChoice.photo),
          ),
          const SizedBox(height: 12),
          ListenableBuilder(
            listenable: settings,
            builder: (context, _) {
              final thinking = settings.thinking;
              final search = settings.webSearch;
              return _ToolGroup(
                thinking: thinking,
                onToggleThinking: () => settings.setThinking(!thinking),
                // Pilihan pengguna tetap tersimpan, tapi baris yang tidak bisa
                // dipakai selalu tampil mati.
                search: search && webSearch.enabled,
                webSearch: webSearch,
                onToggleSearch: () => settings.setWebSearch(!search),
              );
            },
          ),
        ],
      ),
    );
  }
}

/// Satu-satunya tombol aksi di lembar: membuka pemilih foto bawaan HP.
class _PhotoTile extends StatelessWidget {
  const _PhotoTile({
    required this.enabled,
    required this.note,
    required this.onTap,
  });

  final bool enabled;
  final String note;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final radius = BorderRadius.circular(QelvoRadius.lg);
    return Tappable(
      label: 'Foto. $note',
      onTap: enabled ? onTap : null,
      borderRadius: radius,
      minSize: 72,
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 14, 16, 14),
        decoration: BoxDecoration(
          color: t.bubble,
          borderRadius: radius,
          border: Border.all(color: t.aiBubbleLine),
        ),
        child: Row(
          children: [
            _IconDisc(icon: Icons.image_outlined, lit: false, dim: !enabled),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Foto',
                    style: t.display(17.5, color: enabled ? t.text : t.outline),
                  ),
                  const SizedBox(height: 2),
                  Text(note, style: t.body(14.5, color: t.muted, height: 1.35)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Cari web dan Berpikir, dua baris dengan sakelar dalam satu kartu.
class _ToolGroup extends StatelessWidget {
  const _ToolGroup({
    required this.thinking,
    required this.onToggleThinking,
    required this.search,
    required this.webSearch,
    required this.onToggleSearch,
  });

  final bool thinking;
  final VoidCallback onToggleThinking;
  final bool search;
  final WebSearchStatus webSearch;
  final VoidCallback onToggleSearch;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: t.bubble,
        borderRadius: BorderRadius.circular(QelvoRadius.lg),
        border: Border.all(color: t.aiBubbleLine),
      ),
      child: Column(
        children: [
          // Aktif kalau server menandai modelnya `web_search: true`
          // (docs/WEB_SEARCH.md). Selama server belum punya fiturnya, baris ini
          // berlabel "Segera hadir"; judul dan ikonnya diredupkan dan sakelarnya
          // mati setiap kali barisnya tidak bisa dipakai.
          _ToolRow(
            icon: Icons.language_rounded,
            title: 'Cari web',
            note: !webSearch.enabled
                ? webSearch.note
                : search
                    ? 'Menyala. QELVO mencari di web saat pertanyaanmu butuh info terbaru, lengkap dengan sumber.'
                    : 'Mati. Jawaban dari pengetahuan model saja.',
            badge: webSearch.soon,
            on: search,
            enabled: webSearch.enabled,
            onTap: onToggleSearch,
          ),
          Divider(height: 1, thickness: 1, color: t.aiBubbleLine),
          _ToolRow(
            icon: Icons.psychology_outlined,
            title: 'Berpikir',
            note: thinking
                ? 'Menyala. Jawaban lebih teliti, tapi lebih lama.'
                : 'Mati. Jawaban lebih cepat.',
            on: thinking,
            enabled: true,
            onTap: onToggleThinking,
          ),
        ],
      ),
    );
  }
}

/// Satu baris: ikon, judul, keterangan, dan sakelar. Seluruh baris bisa
/// disentuh. Saat menyala, ikonnya berlatar biru navy terang dan sakelarnya
/// terisi cyan; saat mati keduanya redup, dan keterangannya juga menyebut
/// keadaannya supaya tidak hanya bergantung pada warna.
///
/// Baris yang belum bisa dipakai ([enabled] false) tampil jelas berbeda dari
/// baris yang hanya sedang mati: judul dan ikonnya jauh lebih redup, tidak ada
/// efek sentuh, dan sakelarnya memudar.
class _ToolRow extends StatelessWidget {
  const _ToolRow({
    required this.icon,
    required this.title,
    required this.note,
    required this.on,
    required this.enabled,
    required this.onTap,
    this.badge = false,
  });

  final IconData icon;
  final String title;
  final String note;
  final bool on;
  final bool enabled;
  final VoidCallback onTap;

  /// Tampilkan [note] sebagai penanda status berbingkai, bukan kalimat
  /// keterangan. Dipakai untuk "Segera hadir". Pembaca layar tetap membacanya
  /// sebagai bagian dari keterangan baris.
  final bool badge;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Semantics(
      container: true,
      toggled: on,
      enabled: enabled,
      label: '$title. $note',
      onTap: enabled ? onTap : null,
      excludeSemantics: true,
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(
          onTap: enabled ? onTap : null,
          splashFactory: NoSplash.splashFactory,
          highlightColor: t.text.withAlpha(18),
          child: ConstrainedBox(
            constraints: const BoxConstraints(minHeight: 72),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 8, 12),
              child: Row(
                children: [
                  _IconDisc(icon: icon, lit: on, dim: !enabled),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          title,
                          style: t.display(
                            17.5,
                            color: enabled ? t.text : t.outline,
                          ),
                        ),
                        SizedBox(height: badge ? 6 : 2),
                        if (badge)
                          _StatusBadge(label: note)
                        else
                          Text(
                            note,
                            style: t.body(14.5, color: t.muted, height: 1.35),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  ExcludeSemantics(
                    child: QelvoToggle(
                      value: on,
                      enabled: enabled,
                      label: title,
                      onChanged: (_) => onTap(),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Penanda status kecil di bawah judul, misalnya "Segera hadir". Teksnya tetap
/// terbaca (muted) walau barisnya diredupkan, supaya orang tahu kenapa baris
/// itu tidak bisa disentuh.
class _StatusBadge extends StatelessWidget {
  const _StatusBadge({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: t.aiBubbleLine),
      ),
      child: Text(
        label,
        style: t.body(
          12.5,
          weight: FontWeight.w600,
          color: t.muted,
          height: 1.2,
        ),
      ),
    );
  }
}

/// Lingkaran berisi ikon. [lit] true memberinya latar biru navy yang lebih
/// terang dan ikon putih, tanda bahwa fiturnya menyala. [dim] true berarti
/// fiturnya belum bisa dipakai: ikon dan tepinya lebih redup dari keadaan mati
/// biasa.
class _IconDisc extends StatelessWidget {
  const _IconDisc({required this.icon, required this.lit, this.dim = false});

  final IconData icon;
  final bool lit;
  final bool dim;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 160),
      width: 44,
      height: 44,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: lit ? t.raised : t.surface,
        border: Border.all(
          color: lit ? t.raisedLine : (dim ? t.border : t.aiBubbleLine),
          width: lit ? 1.4 : 1,
        ),
      ),
      child: Icon(
        icon,
        size: 22,
        color: lit ? t.text : (dim ? t.outline : t.muted),
      ),
    );
  }
}
