import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/data/settings_store.dart';
import 'package:qelvo_ai/ui/widgets/choice_sheet.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_toggle.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

/// Hasil lembar Tambahkan ke chat. Hanya Foto yang menutup lembar: Berpikir
/// langsung berlaku saat sakelarnya diubah, dan Cari web belum tersedia.
enum AddChoice { photo }

/// Lembar yang dibuka tombol + di komposer. Isinya tiga hal saja: Foto, Cari
/// web, dan Berpikir. Tidak ada tombol File, Kamera, atau Konektor. Foto dibuka
/// lewat pemilih foto bawaan HP, bukan daftar foto buatan aplikasi.
///
/// [photoEnabled] dan [photoNote] datang dari layar obrolan: catatan itu
/// menjelaskan sisa jatah foto, atau alasan Foto tidak bisa dipakai (model tidak
/// membaca foto, daftar model belum dimuat, jatah foto penuh).
Future<AddChoice?> showAddSheet(
  BuildContext context, {
  required SettingsStore settings,
  required bool photoEnabled,
  required String photoNote,
}) {
  final t = context.q;
  return showModalBottomSheet<AddChoice>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: t.surface,
    shape: kSheetShape,
    builder: (_) => _AddSheet(
      settings: settings,
      photoEnabled: photoEnabled,
      photoNote: photoNote,
    ),
  );
}

class _AddSheet extends StatelessWidget {
  const _AddSheet({
    required this.settings,
    required this.photoEnabled,
    required this.photoNote,
  });

  final SettingsStore settings;
  final bool photoEnabled;
  final String photoNote;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final bottom = MediaQuery.viewPaddingOf(context).bottom;
    return SingleChildScrollView(
      padding: EdgeInsets.fromLTRB(16, 10, 16, 20 + bottom),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SheetHandle(),
          const SizedBox(height: 8),
          Row(
            children: [
              Tappable(
                label: 'Tutup',
                onTap: () => Navigator.of(context).pop(),
                borderRadius: BorderRadius.circular(24),
                minSize: 48,
                child: Center(
                  child: Icon(Icons.close_rounded, size: 24, color: t.text),
                ),
              ),
              Expanded(
                child: Text(
                  'Tambahkan ke chat',
                  textAlign: TextAlign.center,
                  style: t.display(18),
                ),
              ),
              const SizedBox(width: 48),
            ],
          ),
          const SizedBox(height: 12),
          _PhotoTile(
            enabled: photoEnabled,
            note: photoNote,
            onTap: () => Navigator.of(context).pop(AddChoice.photo),
          ),
          const SizedBox(height: 12),
          ListenableBuilder(
            listenable: settings,
            builder: (context, _) {
              final thinking = settings.thinking;
              return _ToolGroup(
                thinking: thinking,
                onToggleThinking: () => settings.setThinking(!thinking),
              );
            },
          ),
        ],
      ),
    );
  }
}

/// Satu-satunya tombol aksi di lembar: membuka pemilih foto bawaan HP.
class _PhotoTile extends StatelessWidget {
  const _PhotoTile({
    required this.enabled,
    required this.note,
    required this.onTap,
  });

  final bool enabled;
  final String note;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final radius = BorderRadius.circular(QelvoRadius.lg);
    return Tappable(
      label: 'Foto. $note',
      onTap: enabled ? onTap : null,
      borderRadius: radius,
      minSize: 72,
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 14, 16, 14),
        decoration: BoxDecoration(
          color: t.bubble,
          borderRadius: radius,
          border: Border.all(color: t.aiBubbleLine),
        ),
        child: Row(
          children: [
            const _IconDisc(icon: Icons.image_outlined, lit: false),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Foto',
                    style: t.display(17.5, color: enabled ? t.text : t.muted),
                  ),
                  const SizedBox(height: 2),
                  Text(note, style: t.body(14.5, color: t.muted, height: 1.35)),
                ],
              ),
            ),
            if (enabled) ...[
              const SizedBox(width: 8),
              Icon(Icons.chevron_right_rounded, size: 24, color: t.muted),
            ],
          ],
        ),
      ),
    );
  }
}

/// Cari web dan Berpikir, dua baris dengan sakelar dalam satu kartu.
class _ToolGroup extends StatelessWidget {
  const _ToolGroup({required this.thinking, required this.onToggleThinking});

  final bool thinking;
  final VoidCallback onToggleThinking;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: t.bubble,
        borderRadius: BorderRadius.circular(QelvoRadius.lg),
        border: Border.all(color: t.aiBubbleLine),
      ),
      child: Column(
        children: [
          // TODO(web-search): aktifkan saat backend menyediakan pencarian web.
          // Selama itu baris ini berlabel "Segera hadir" dan sakelarnya mati.
          _ToolRow(
            icon: Icons.language_rounded,
            title: 'Cari web',
            note: 'Segera hadir',
            on: false,
            enabled: false,
            onTap: () {},
          ),
          Divider(height: 1, thickness: 1, color: t.aiBubbleLine),
          _ToolRow(
            icon: Icons.psychology_outlined,
            title: 'Berpikir',
            note: thinking
                ? 'Menyala. Jawaban lebih teliti, tapi lebih lama.'
                : 'Mati. Jawaban lebih cepat.',
            on: thinking,
            enabled: true,
            onTap: onToggleThinking,
          ),
        ],
      ),
    );
  }
}

/// Satu baris: ikon, judul, keterangan, dan sakelar. Seluruh baris bisa
/// disentuh. Saat menyala, ikonnya berlatar cyan dan sakelarnya terisi; saat
/// mati keduanya redup, dan keterangannya juga menyebut keadaannya supaya tidak
/// hanya bergantung pada warna.
class _ToolRow extends StatelessWidget {
  const _ToolRow({
    required this.icon,
    required this.title,
    required this.note,
    required this.on,
    required this.enabled,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String note;
  final bool on;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Semantics(
      container: true,
      toggled: on,
      enabled: enabled,
      label: '$title. $note',
      onTap: enabled ? onTap : null,
      excludeSemantics: true,
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(
          onTap: enabled ? onTap : null,
          splashFactory: NoSplash.splashFactory,
          highlightColor: t.accent.withAlpha(30),
          child: ConstrainedBox(
            constraints: const BoxConstraints(minHeight: 72),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 8, 12),
              child: Row(
                children: [
                  _IconDisc(icon: icon, lit: on),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          title,
                          style: t.display(
                            17.5,
                            color: enabled ? t.text : t.muted,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          note,
                          style: t.body(14.5, color: t.muted, height: 1.35),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  ExcludeSemantics(
                    child: QelvoToggle(
                      value: on,
                      enabled: enabled,
                      label: title,
                      onChanged: (_) => onTap(),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Lingkaran berisi ikon. [lit] true memberinya latar dan garis cyan, tanda
/// bahwa fiturnya menyala.
class _IconDisc extends StatelessWidget {
  const _IconDisc({required this.icon, required this.lit});

  final IconData icon;
  final bool lit;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 160),
      width: 44,
      height: 44,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: lit ? t.accentSoft : t.surface,
        border: Border.all(
          color: lit ? t.accentLine : t.aiBubbleLine,
          width: lit ? 1.4 : 1,
        ),
      ),
      child: Icon(icon, size: 22, color: lit ? t.accentText : t.muted),
    );
  }
}
