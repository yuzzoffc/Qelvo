import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qelvo_ai/core/config.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/data/settings_store.dart';
import 'package:qelvo_ai/state/app_state.dart';
import 'package:qelvo_ai/state/model_catalog.dart';
import 'package:qelvo_ai/state/session.dart';
import 'package:qelvo_ai/ui/screens/legal_screen.dart';
import 'package:qelvo_ai/ui/widgets/choice_sheet.dart';
import 'package:qelvo_ai/ui/widgets/dialogs.dart';
import 'package:qelvo_ai/ui/widgets/model_sheet.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_logo.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_spinner.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_toggle.dart';
import 'package:qelvo_ai/ui/widgets/screen_bar.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key, required this.onHistoryCleared});

  /// Dipanggil setelah semua riwayat dihapus, agar chat yang terbuka ditutup.
  final VoidCallback onHistoryCleared;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _exporting = false;

  Future<void> _pickTextScale(AppState app) async {
    final picked = await showChoiceSheet<TextScaleOption>(
      context,
      title: 'Ukuran teks',
      message: 'Berlaku di seluruh aplikasi, di atas ukuran teks dari sistem.',
      selected: app.settings.textScale,
      options: [
        for (final option in TextScaleOption.values)
          ChoiceOption<TextScaleOption>(value: option, title: option.label),
      ],
    );
    if (picked != null) await app.settings.setTextScale(picked);
  }

  Future<void> _pickInstruction(AppState app) async {
    final picked = await showChoiceSheet<InstructionPreset>(
      context,
      title: 'Instruksi sistem',
      message: 'Gaya jawaban QELVO. Aturan dasar QELVO tetap berlaku.',
      selected: app.settings.instruction,
      options: [
        for (final preset in InstructionPreset.values)
          ChoiceOption<InstructionPreset>(
            value: preset,
            title: preset.label,
            subtitle: preset.description,
          ),
      ],
    );
    if (picked != null) await app.settings.setInstruction(picked);
  }

  Future<void> _editServer(AppState app) async {
    final url = await showDialog<String>(
      context: context,
      builder: (_) => _ServerDialog(initial: app.settings.serverUrl),
    );
    if (url == null) return;
    await app.settings.setServerUrl(url);
    app.catalog.reset();
    unawaited(app.catalog.load());
  }

  Future<void> _export(Session session) async {
    setState(() => _exporting = true);
    try {
      final result = await session.repository.exportMarkdown();
      if (!mounted) return;
      if (result.included == 0) {
        showNotice(context, 'Belum ada percakapan untuk diekspor.');
        return;
      }
      await Clipboard.setData(ClipboardData(text: result.markdown));
      if (!mounted) return;
      final partial = result.included < result.total
          ? ' (${result.included} dari ${result.total}, sisanya terlalu besar untuk clipboard)'
          : '';
      showNotice(
        context,
        '${result.included} percakapan disalin sebagai Markdown$partial.',
      );
    } catch (_) {
      if (mounted) {
        showNotice(context, 'Ekspor gagal. Periksa koneksi lalu coba lagi.');
      }
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  Future<void> _deleteAll(Session session) async {
    final ok = await confirmDialog(
      context,
      title: 'Hapus semua riwayat?',
      message: 'Semua percakapan di akunmu akan dihapus dan tidak bisa dikembalikan.',
      confirmLabel: 'Hapus semua',
      destructive: true,
    );
    if (!ok || !mounted) return;
    try {
      await session.repository.deleteEverything();
      widget.onHistoryCleared();
      if (mounted) showNotice(context, 'Riwayat dihapus.');
    } catch (_) {
      if (mounted) showNotice(context, 'Gagal menghapus riwayat. Coba lagi.');
    }
  }

  Future<void> _signOut(AppState app) async {
    // Tutup layar ini lebih dulu; AuthGate akan menampilkan layar masuk.
    Navigator.of(context).popUntil((route) => route.isFirst);
    app.catalog.reset();
    await app.auth.signOut();
  }

  void _openLegal(LegalKind kind) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => LegalScreen(kind: kind)),
    );
  }

  String _providerValue(ModelCatalog catalog) {
    final active = catalog.activeProvider;
    if (active != null) return active.name;
    return catalog.status == CatalogStatus.failed
        ? 'Tidak terhubung'
        : 'Memuat...';
  }

  String? _serverStatus(ModelCatalog catalog) {
    return switch (catalog.status) {
      CatalogStatus.ready => 'Terhubung',
      CatalogStatus.loading => 'Memeriksa...',
      CatalogStatus.failed => 'Tidak terhubung',
      CatalogStatus.idle => null,
    };
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final session = SessionScope.of(context);
    final t = context.q;
    return Scaffold(
      backgroundColor: t.bg,
      body: SafeArea(
        child: Column(
          children: [
            const ScreenBar(title: 'Pengaturan'),
            Expanded(
              child: ListenableBuilder(
                listenable: Listenable.merge([app.settings, app.catalog]),
                builder: (context, _) {
                  final settings = app.settings;
                  final catalog = app.catalog;
                  final name = session.user.displayName;
                  final account = session.email.isNotEmpty
                      ? session.email
                      : (name != null && name.isNotEmpty ? name : 'Akun Google');
                  return ListView(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
                    children: [
                      _Group(
                        title: 'Akun',
                        children: [
                          _SettingRow(label: 'Masuk sebagai', value: account),
                          _SettingRow(
                            label: 'Keluar',
                            onTap: () => _signOut(app),
                          ),
                        ],
                      ),
                      _Group(
                        title: 'Tampilan',
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(18, 16, 18, 14),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Tema', style: t.body(17)),
                                const SizedBox(height: 12),
                                _ThemeSegments(
                                  value: settings.themeMode,
                                  onChanged: settings.setThemeMode,
                                ),
                              ],
                            ),
                          ),
                          _SettingRow(
                            label: 'Ukuran teks',
                            value: settings.textScale.label,
                            chevron: true,
                            onTap: () => _pickTextScale(app),
                          ),
                        ],
                      ),
                      _Group(
                        title: 'Model',
                        children: [
                          _SettingRow(
                            label: 'Penyedia API',
                            value: _providerValue(catalog),
                            chevron: true,
                            onTap: () => showModelSheet(context),
                          ),
                          _SettingRow(
                            label: 'Instruksi sistem',
                            value: settings.instruction.label,
                            chevron: true,
                            onTap: () => _pickInstruction(app),
                          ),
                          _SettingRow(
                            label: 'Mode berpikir',
                            subtitle: 'Jawaban lebih teliti, tetapi bisa lebih lambat.',
                            trailing: QelvoToggle(
                              label: 'Mode berpikir',
                              value: settings.thinking,
                              onChanged: settings.setThinking,
                            ),
                          ),
                        ],
                      ),
                      _Group(
                        title: 'Data',
                        children: [
                          _SettingRow(
                            label: 'Simpan riwayat',
                            subtitle: 'Percakapan disimpan di akunmu lewat Firebase.',
                            trailing: QelvoToggle(
                              label: 'Simpan riwayat',
                              value: settings.saveHistory,
                              onChanged: settings.setSaveHistory,
                            ),
                          ),
                          _SettingRow(
                            label: 'Ekspor percakapan',
                            chevron: !_exporting,
                            trailing: _exporting
                                ? const QelvoSpinner(size: 20)
                                : null,
                            onTap: _exporting ? null : () => _export(session),
                          ),
                          _SettingRow(
                            label: 'Hapus semua riwayat',
                            danger: true,
                            onTap: () => _deleteAll(session),
                          ),
                        ],
                      ),
                      _Group(
                        title: 'Tentang',
                        children: [
                          _SettingRow(
                            label: 'Ketentuan',
                            chevron: true,
                            onTap: () => _openLegal(LegalKind.terms),
                          ),
                          _SettingRow(
                            label: 'Kebijakan Privasi',
                            chevron: true,
                            onTap: () => _openLegal(LegalKind.privacy),
                          ),
                        ],
                      ),
                      _Group(
                        title: 'Lanjutan',
                        children: [
                          _SettingRow(
                            label: 'Alamat server',
                            value: Uri.tryParse(settings.serverUrl)?.authority ??
                                settings.serverUrl,
                            subtitle: _serverStatus(catalog),
                            chevron: true,
                            onTap: () => _editServer(app),
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 32),
                        child: Column(
                          children: [
                            const QelvoLogo(size: 36),
                            const SizedBox(height: 12),
                            Text(
                              'QELVO AI v${AppConfig.version} · Think Beyond.',
                              style: t.body(14.5, color: t.muted),
                            ),
                          ],
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Group extends StatelessWidget {
  const _Group({required this.title, required this.children});

  final String title;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(8, 22, 8, 10),
          child: Text(
            title,
            style: t.body(15, weight: FontWeight.w700, color: t.muted),
          ),
        ),
        Container(
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
            color: t.surface,
            borderRadius: BorderRadius.circular(QelvoRadius.lg + 2),
            border: Border.all(color: t.border),
          ),
          child: Column(
            children: [
              for (var i = 0; i < children.length; i++) ...[
                if (i > 0) Container(height: 1, color: t.border),
                children[i],
              ],
            ],
          ),
        ),
      ],
    );
  }
}

class _SettingRow extends StatelessWidget {
  const _SettingRow({
    required this.label,
    this.value,
    this.subtitle,
    this.trailing,
    this.onTap,
    this.chevron = false,
    this.danger = false,
  });

  final String label;
  final String? value;
  final String? subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;
  final bool chevron;
  final bool danger;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final content = Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: t.body(17, color: danger ? t.warn : t.text),
                ),
                if (subtitle != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 3),
                    child: Text(
                      subtitle!,
                      style: t.body(14, color: t.muted, height: 1.35),
                    ),
                  ),
              ],
            ),
          ),
          if (value != null) ...[
            const SizedBox(width: 12),
            Flexible(
              child: Text(
                value!,
                textAlign: TextAlign.end,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: t.body(16, color: t.muted),
              ),
            ),
          ],
          if (trailing != null) ...[const SizedBox(width: 12), trailing!],
          if (chevron) ...[
            const SizedBox(width: 4),
            Icon(Icons.chevron_right_rounded, size: 24, color: t.muted),
          ],
        ],
      ),
    );
    if (onTap == null) return content;
    return Tappable(
      onTap: onTap,
      borderRadius: BorderRadius.zero,
      minSize: 54,
      child: content,
    );
  }
}

class _ThemeSegments extends StatelessWidget {
  const _ThemeSegments({required this.value, required this.onChanged});

  final ThemeMode value;
  final ValueChanged<ThemeMode> onChanged;

  static const List<(ThemeMode, String)> _options = [
    (ThemeMode.dark, 'Gelap'),
    (ThemeMode.light, 'Terang'),
    (ThemeMode.system, 'Sistem'),
  ];

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: t.bg,
        borderRadius: BorderRadius.circular(QelvoRadius.md + 2),
        border: Border.all(color: t.border),
      ),
      child: Row(
        children: [
          for (final (mode, label) in _options)
            Expanded(
              child: Tappable(
                label: label,
                selected: value == mode,
                onTap: () => onChanged(mode),
                borderRadius: BorderRadius.circular(QelvoRadius.md),
                child: Container(
                  height: 44,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: value == mode ? t.accent : Colors.transparent,
                    borderRadius: BorderRadius.circular(QelvoRadius.md),
                  ),
                  child: Text(
                    label,
                    style: t.body(
                      16,
                      weight: value == mode ? FontWeight.w700 : FontWeight.w500,
                      color: value == mode ? t.onAccent : t.muted,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _ServerDialog extends StatefulWidget {
  const _ServerDialog({required this.initial});

  final String initial;

  @override
  State<_ServerDialog> createState() => _ServerDialogState();
}

class _ServerDialogState extends State<_ServerDialog> {
  late final TextEditingController _controller =
      TextEditingController(text: widget.initial);
  String? _error;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _save() {
    final url = _controller.text.trim();
    final uri = Uri.tryParse(url);
    final valid = uri != null &&
        (uri.scheme == 'http' || uri.scheme == 'https') &&
        uri.host.isNotEmpty;
    if (!valid) {
      setState(() => _error = 'Alamat harus diawali http:// atau https://');
      return;
    }
    Navigator.of(context).pop(url);
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    OutlineInputBorder border(Color color, [double width = 1]) =>
        OutlineInputBorder(
          borderRadius: BorderRadius.circular(QelvoRadius.md),
          borderSide: BorderSide(color: color, width: width),
        );
    return AlertDialog(
      backgroundColor: t.surface,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(QelvoRadius.lg),
        side: BorderSide(color: t.border),
      ),
      title: Text('Alamat server', style: t.display(19)),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Alamat backend QELVO yang dipakai aplikasi ini.',
              style: t.body(15, color: t.muted, height: 1.45),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _controller,
              keyboardType: TextInputType.url,
              autocorrect: false,
              style: t.body(16),
              cursorColor: t.accentText,
              decoration: InputDecoration(
                hintText: 'https://alamat-server-kamu',
                hintStyle: t.body(16, color: t.muted),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 14,
                ),
                border: border(t.outline),
                enabledBorder: border(t.outline),
                focusedBorder: border(t.accentText, 2),
              ),
            ),
            if (_error != null) ...[
              const SizedBox(height: 10),
              Text(_error!, style: t.body(14, color: t.warn)),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: Text(
            'Batal',
            style: t.body(15.5, weight: FontWeight.w600, color: t.muted),
          ),
        ),
        TextButton(
          onPressed: _save,
          child: Text(
            'Simpan',
            style: t.body(15.5, weight: FontWeight.w700, color: t.accentText),
          ),
        ),
      ],
    );
  }
}
