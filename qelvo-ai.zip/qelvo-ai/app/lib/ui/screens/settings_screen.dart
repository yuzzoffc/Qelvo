import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qelvo_ai/core/config.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/data/api_client.dart';
import 'package:qelvo_ai/data/settings_store.dart';
import 'package:qelvo_ai/state/app_state.dart';
import 'package:qelvo_ai/state/model_catalog.dart';
import 'package:qelvo_ai/state/session.dart';
import 'package:qelvo_ai/ui/flows/session_flows.dart';
import 'package:qelvo_ai/ui/screens/account_screen.dart';
import 'package:qelvo_ai/ui/screens/legal_screen.dart';
import 'package:qelvo_ai/ui/widgets/buttons.dart';
import 'package:qelvo_ai/ui/widgets/choice_sheet.dart';
import 'package:qelvo_ai/ui/widgets/dialogs.dart';
import 'package:qelvo_ai/ui/widgets/model_sheet.dart';
import 'package:qelvo_ai/ui/widgets/profile_avatar.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_logo.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_spinner.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_toggle.dart';
import 'package:qelvo_ai/ui/widgets/screen_bar.dart';
import 'package:qelvo_ai/ui/widgets/segments.dart';
import 'package:qelvo_ai/ui/widgets/setting_row.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key, required this.onHistoryCleared});

  /// Dipanggil setelah semua riwayat dihapus, agar chat yang terbuka ditutup.
  final VoidCallback onHistoryCleared;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _exporting = false;

  Future<void> _pickTextScale(AppState app) async {
    final picked = await showChoiceSheet<TextScaleOption>(
      context,
      title: 'Ukuran teks',
      message: 'Berlaku di seluruh aplikasi, di atas ukuran teks dari sistem.',
      selected: app.settings.textScale,
      options: [
        for (final option in TextScaleOption.values)
          ChoiceOption<TextScaleOption>(value: option, title: option.label),
      ],
    );
    if (picked != null) await app.settings.setTextScale(picked);
  }

  Future<void> _pickInstruction(AppState app) async {
    final picked = await showChoiceSheet<InstructionPreset>(
      context,
      title: 'Instruksi sistem',
      message: 'Gaya jawaban QELVO. Aturan dasar QELVO tetap berlaku.',
      selected: app.settings.instruction,
      options: [
        for (final preset in InstructionPreset.values)
          ChoiceOption<InstructionPreset>(
            value: preset,
            title: preset.label,
            subtitle: preset.description,
          ),
      ],
    );
    if (picked != null) await app.settings.setInstruction(picked);
  }

  Future<void> _export(Session session) async {
    setState(() => _exporting = true);
    try {
      final result = await session.repository.exportMarkdown();
      if (!mounted) return;
      if (result.included == 0) {
        showNotice(context, 'Belum ada percakapan untuk diekspor.');
        return;
      }
      await Clipboard.setData(ClipboardData(text: result.markdown));
      if (!mounted) return;
      final partial = result.included < result.total
          ? ' (${result.included} dari ${result.total}, sisanya terlalu besar untuk clipboard)'
          : '';
      showNotice(
        context,
        '${result.included} percakapan disalin sebagai Markdown$partial.',
      );
    } catch (error) {
      if (mounted) {
        showNotice(context, _failure(error, 'Ekspor gagal. Periksa koneksi lalu coba lagi.'));
      }
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  /// Pesan dari server kalau ada (misalnya riwayat belum aktif), selain itu cadangan.
  String _failure(Object error, String fallback) =>
      error is ApiException ? error.message : fallback;

  Future<void> _deleteAll(Session session) async {
    final ok = await confirmDialog(
      context,
      title: 'Hapus semua riwayat?',
      message: 'Semua percakapan di akunmu akan dihapus dan tidak bisa dikembalikan.',
      confirmLabel: 'Hapus semua',
      destructive: true,
    );
    if (!ok || !mounted) return;
    // Chat yang terbuka ditutup lebih dulu tanpa menyimpannya, lalu penghapusan
    // masuk antrean sesi supaya tidak ada pesan lama yang menyusul sesudahnya.
    widget.onHistoryCleared();
    try {
      await session.enqueue(session.repository.deleteEverything);
      unawaited(session.history.refresh());
      if (mounted) showNotice(context, 'Riwayat dihapus.');
    } catch (error) {
      if (mounted) {
        showNotice(context, _failure(error, 'Gagal menghapus riwayat. Coba lagi.'));
      }
    }
  }

  Future<void> _leave(AppState app, Session session) => leaveSession(
        context,
        app: app,
        session: session,
        onHistoryCleared: widget.onHistoryCleared,
        toSignIn: session.isGuest,
      );

  /// Baris akun membuka layar Akun. Tamu tidak punya akun untuk dibuka, jadi
  /// barisnya menjadi jalan menuju masuk.
  Future<void> _openAccount(AppState app, Session session) async {
    if (session.isGuest) {
      await _leave(app, session);
      return;
    }
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => SessionScope(
          session: session,
          child: AccountScreen(onHistoryCleared: widget.onHistoryCleared),
        ),
      ),
    );
    if (mounted) setState(() {});
  }

  void _openLegal(LegalKind kind) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => LegalScreen(kind: kind)),
    );
  }

  String _modelValue(ModelCatalog catalog) {
    final model = catalog.activeModel;
    if (model != null) return model.label;
    return catalog.status == CatalogStatus.failed ? 'Tidak terhubung' : 'Memuat…';
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final session = SessionScope.of(context);
    final t = context.q;
    return Scaffold(
      backgroundColor: t.bg,
      body: SafeArea(
        child: Column(
          children: [
            const ScreenBar(title: 'Pengaturan'),
            Expanded(
              child: ListenableBuilder(
                listenable: Listenable.merge([app.settings, app.catalog]),
                builder: (context, _) {
                  final settings = app.settings;
                  final catalog = app.catalog;
                  final guest = session.isGuest;
                  final hasName = session.displayName.isNotEmpty;
                  final accountName = guest
                      ? 'Tamu'
                      : hasName
                          ? session.displayName
                          : session.email.isNotEmpty
                              ? session.email
                              : 'Akun Google';
                  final accountDetail = guest
                      ? 'Masuk atau daftar'
                      : hasName
                          ? session.email
                          : null;
                  return ListView(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 32),
                    children: [
                      SettingSection(
                        title: 'Akun',
                        children: [
                          SettingRow(
                            leading: ProfileAvatar(session: session, size: 48),
                            label: accountName,
                            subtitle: accountDetail,
                            chevron: true,
                            onTap: () => _openAccount(app, session),
                          ),
                        ],
                      ),
                      SettingSection(
                        title: 'Tampilan',
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            child: QelvoSegments<ThemeMode>(
                              options: const [
                                (ThemeMode.dark, 'Gelap'),
                                (ThemeMode.light, 'Terang'),
                                (ThemeMode.system, 'Sistem'),
                              ],
                              value: settings.themeMode,
                              onChanged: settings.setThemeMode,
                            ),
                          ),
                          SettingRow(
                            label: 'Ukuran teks',
                            value: settings.textScale.label,
                            chevron: true,
                            onTap: () => _pickTextScale(app),
                          ),
                        ],
                      ),
                      SettingSection(
                        title: 'Model',
                        children: [
                          SettingRow(
                            label: 'Model aktif',
                            value: _modelValue(catalog),
                            chevron: true,
                            onTap: () => showModelSheet(context),
                          ),
                          SettingRow(
                            label: 'Instruksi sistem',
                            value: settings.instruction.label,
                            chevron: true,
                            onTap: () => _pickInstruction(app),
                          ),
                          SettingRow(
                            label: 'Mode berpikir',
                            subtitle: 'Jawaban lebih teliti, tetapi bisa lebih lambat.',
                            trailing: QelvoToggle(
                              label: 'Mode berpikir',
                              value: settings.thinking,
                              onChanged: settings.setThinking,
                            ),
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(2, 4, 2, 0),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(top: 2),
                              child: Icon(
                                Icons.lock_outline_rounded,
                                size: 16,
                                color: t.muted,
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                'Penyedia API tidak bisa diganti terpisah. Penyedia berubah hanya saat kamu memilih model.',
                                style: t.body(13.5, color: t.muted, height: 1.45),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SettingSection(
                        title: 'Data',
                        children: [
                          SettingRow(
                            label: 'Simpan riwayat',
                            subtitle:
                                'Percakapan, termasuk gambar kecil dari foto yang kamu lampirkan, disimpan di akunmu lewat Firebase.',
                            trailing: QelvoToggle(
                              label: 'Simpan riwayat',
                              value: settings.saveHistory,
                              onChanged: settings.setSaveHistory,
                            ),
                          ),
                          SettingRow(
                            label: 'Ekspor percakapan',
                            chevron: !_exporting,
                            trailing: _exporting
                                ? const QelvoSpinner(size: 20)
                                : null,
                            onTap: _exporting ? null : () => _export(session),
                          ),
                          SettingRow(
                            label: 'Hapus semua riwayat',
                            danger: true,
                            onTap: () => _deleteAll(session),
                          ),
                        ],
                      ),
                      SettingSection(
                        title: 'Tentang',
                        children: [
                          SettingRow(
                            label: 'Ketentuan Layanan',
                            chevron: true,
                            onTap: () => _openLegal(LegalKind.terms),
                          ),
                          SettingRow(
                            label: 'Kebijakan Privasi',
                            chevron: true,
                            onTap: () => _openLegal(LegalKind.privacy),
                          ),
                        ],
                      ),
                      const SizedBox(height: 28),
                      OutlineActionButton(
                        label: guest ? 'Masuk atau daftar' : 'Keluar',
                        icon: guest ? null : Icons.logout_rounded,
                        onPressed: () => _leave(app, session),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 22),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const QelvoLogo(size: 22),
                            const SizedBox(width: 10),
                            Text(
                              'QELVO AI v${AppConfig.version} · Think Beyond.',
                              style: t.body(14, color: t.muted),
                            ),
                          ],
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
