import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/state/app_state.dart';
import 'package:qelvo_ai/state/chat_controller.dart';
import 'package:qelvo_ai/state/session.dart';
import 'package:qelvo_ai/ui/markdown/markdown_view.dart';
import 'package:qelvo_ai/ui/screens/settings_screen.dart';
import 'package:qelvo_ai/ui/widgets/composer.dart';
import 'package:qelvo_ai/ui/widgets/dialogs.dart';
import 'package:qelvo_ai/ui/widgets/history_drawer.dart';
import 'package:qelvo_ai/ui/widgets/model_sheet.dart';
import 'package:qelvo_ai/ui/widgets/notice.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_logo.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_spinner.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

/// Layar utama. Kosong = sapaan dengan kartu saran; ada pesan = percakapan.
class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  late final AppState _app;
  late final Session _session;
  late final ChatController _chat;
  final TextEditingController _composer = TextEditingController();
  final FocusNode _focus = FocusNode();
  final ScrollController _scroll = ScrollController();
  bool _forceStick = false;

  @override
  void initState() {
    super.initState();
    _app = AppScope.of(context);
    _session = SessionScope.of(context);
    _chat = ChatController(app: _app, session: _session)..addListener(_onChat);
    unawaited(_app.catalog.load());
  }

  @override
  void dispose() {
    _chat.removeListener(_onChat);
    _chat.dispose();
    _composer.dispose();
    _focus.dispose();
    _scroll.dispose();
    super.dispose();
  }

  /// Menjaga daftar tetap di bawah saat jawaban mengalir, kecuali pengguna
  /// sedang menggulir ke atas untuk membaca.
  void _onChat() {
    final nearBottom = !_scroll.hasClients ||
        _scroll.position.maxScrollExtent - _scroll.position.pixels < 160;
    if (!nearBottom && !_forceStick) return;
    _forceStick = false;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && _scroll.hasClients) {
        _scroll.jumpTo(_scroll.position.maxScrollExtent);
      }
    });
  }

  void _send() {
    final text = _composer.text;
    if (text.trim().isEmpty || _chat.isLoading) return;
    _composer.clear();
    _forceStick = true;
    _chat.send(text);
  }

  void _fill(String prompt) {
    _composer.text = prompt;
    _composer.selection = TextSelection.collapsed(offset: prompt.length);
    _focus.requestFocus();
  }

  void _compose() {
    _composer.clear();
    _focus.requestFocus();
  }

  Future<void> _export() async {
    await Clipboard.setData(ClipboardData(text: _chat.toMarkdown()));
    if (mounted) showNotice(context, 'Percakapan disalin sebagai Markdown.');
  }

  void _openSettings() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => SessionScope(
          session: _session,
          child: SettingsScreen(onHistoryCleared: _chat.reset),
        ),
      ),
    );
  }

  void _openDrawer() {
    _focus.unfocus();
    showHistoryDrawer(
      context,
      session: _session,
      chat: _chat,
      onOpenSettings: _openSettings,
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Scaffold(
      backgroundColor: t.bg,
      body: SafeArea(
        child: ListenableBuilder(
          listenable: Listenable.merge([_chat, _app.settings]),
          builder: (context, _) {
            final landing = _chat.isEmpty && !_chat.isLoading;
            return Column(
              children: [
                _TopBar(
                  landing: landing,
                  onMenu: _openDrawer,
                  onModel: () => showModelSheet(context),
                  onTrailing: landing ? _compose : _export,
                ),
                Expanded(
                  child: landing
                      ? _Landing(onPick: _fill)
                      : _Conversation(chat: _chat, scroll: _scroll),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 6, 12, 12),
                  child: Composer(
                    controller: _composer,
                    focusNode: _focus,
                    hint: landing ? 'Tanya QELVO...' : 'Balas QELVO...',
                    busy: _chat.isStreaming,
                    landing: landing,
                    thinking: _app.settings.thinking,
                    onToggleThinking: () =>
                        _app.settings.setThinking(!_app.settings.thinking),
                    onWebSearch: () => showNotice(
                      context,
                      'Pencarian web belum tersedia. Segera hadir.',
                    ),
                    onSend: _send,
                    onStop: _chat.stop,
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar({
    required this.landing,
    required this.onMenu,
    required this.onModel,
    required this.onTrailing,
  });

  final bool landing;
  final VoidCallback onMenu;
  final VoidCallback onModel;
  final VoidCallback onTrailing;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 4),
      child: Row(
        children: [
          Tappable(
            label: 'Buka riwayat',
            onTap: onMenu,
            borderRadius: BorderRadius.circular(24),
            minSize: 48,
            child: Center(child: MenuGlyph(size: 26, color: t.text)),
          ),
          Expanded(
            child: Center(
              child: Tappable(
                label: 'Pilih model',
                onTap: onModel,
                borderRadius: BorderRadius.circular(24),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                  decoration: BoxDecoration(
                    color: t.surface,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: t.border),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const QelvoLogo(size: 20),
                      const SizedBox(width: 8),
                      Text('QELVO', style: t.display(15, spacing: 3)),
                      const SizedBox(width: 4),
                      Icon(
                        Icons.keyboard_arrow_down_rounded,
                        size: 20,
                        color: t.muted,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Tappable(
            label: landing ? 'Mulai menulis' : 'Salin percakapan sebagai Markdown',
            onTap: onTrailing,
            borderRadius: BorderRadius.circular(24),
            minSize: 48,
            child: Center(
              child: Icon(
                landing ? Icons.edit_outlined : Icons.ios_share_rounded,
                size: 24,
                color: t.text,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Suggestion {
  const _Suggestion(this.icon, this.title, this.subtitle, this.prompt);

  final IconData icon;
  final String title;
  final String subtitle;

  /// Teks yang diisikan ke kolom pesan. Pengguna bisa mengubahnya dulu.
  final String prompt;
}

class _Landing extends StatelessWidget {
  const _Landing({required this.onPick});

  final ValueChanged<String> onPick;

  static const List<_Suggestion> _suggestions = [
    _Suggestion(
      Icons.menu_book_outlined,
      'Jelaskan konsep',
      'Fotosintesis dalam dua kalimat',
      'Jelaskan konsep fotosintesis dalam dua kalimat.',
    ),
    _Suggestion(
      Icons.code_rounded,
      'Bantu tulis kode',
      'Fungsi Dart untuk luas lingkaran',
      'Buatkan fungsi Dart untuk menghitung luas lingkaran.',
    ),
    _Suggestion(
      Icons.lightbulb_outline_rounded,
      'Cari ide',
      'Nama untuk toko kopi baru',
      'Beri 10 ide nama untuk toko kopi baru yang singkat dan mudah diingat.',
    ),
    _Suggestion(
      Icons.edit_outlined,
      'Rapikan tulisan',
      'Email ke dosen yang lebih sopan',
      'Rapikan email ini agar lebih sopan dan ringkas:\n\n',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return LayoutBuilder(
      builder: (context, box) {
        return SingleChildScrollView(
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          padding: const EdgeInsets.fromLTRB(20, 24, 20, 8),
          child: ConstrainedBox(
            constraints:
                BoxConstraints(minHeight: math.max(0.0, box.maxHeight - 32)),
            child: IntrinsicHeight(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Halo.',
                    style: t.display(40, weight: FontWeight.w800, height: 1.1),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Apa yang ingin kamu pikirkan hari ini?',
                    style: t.display(
                      36,
                      weight: FontWeight.w500,
                      color: t.muted,
                      height: 1.18,
                    ),
                  ),
                  const Spacer(),
                  const SizedBox(height: 24),
                  for (var i = 0; i < _suggestions.length; i += 2)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: IntrinsicHeight(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Expanded(
                              child: _SuggestionCard(
                                item: _suggestions[i],
                                onTap: () => onPick(_suggestions[i].prompt),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: _SuggestionCard(
                                item: _suggestions[i + 1],
                                onTap: () => onPick(_suggestions[i + 1].prompt),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _SuggestionCard extends StatelessWidget {
  const _SuggestionCard({required this.item, required this.onTap});

  final _Suggestion item;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final radius = BorderRadius.circular(QelvoRadius.lg);
    return Tappable(
      onTap: onTap,
      borderRadius: radius,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: t.surface,
          borderRadius: radius,
          border: Border.all(color: t.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: t.accentSoft,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(item.icon, size: 20, color: t.accentText),
            ),
            const SizedBox(height: 16),
            Text(item.title, style: t.display(16.5)),
            const SizedBox(height: 4),
            Text(
              item.subtitle,
              style: t.body(14.5, color: t.muted, height: 1.35),
            ),
          ],
        ),
      ),
    );
  }
}

class _Conversation extends StatelessWidget {
  const _Conversation({required this.chat, required this.scroll});

  final ChatController chat;
  final ScrollController scroll;

  @override
  Widget build(BuildContext context) {
    if (chat.isLoading) {
      return const Center(child: QelvoSpinner(size: 28));
    }
    final messages = chat.messages;
    final hasError = chat.error != null;
    return ListView.builder(
      controller: scroll,
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      itemCount: messages.length + (hasError ? 1 : 0),
      itemBuilder: (context, index) {
        if (index >= messages.length) {
          return InlineNotice(
            message: chat.error!,
            actionLabel: chat.canRetry ? 'Coba lagi' : null,
            onAction: chat.canRetry ? chat.retry : null,
          );
        }
        final message = messages[index];
        final isLast = index == messages.length - 1;
        return Padding(
          key: ValueKey(message.id),
          padding: const EdgeInsets.only(bottom: 22),
          child: message.role == ChatRole.user
              ? _UserBubble(text: message.content)
              : _AssistantMessage(
                  message: message,
                  chat: chat,
                  streaming: chat.isStreaming && isLast,
                  canRegenerate: isLast && !chat.isStreaming,
                ),
        );
      },
    );
  }
}

class _UserBubble extends StatelessWidget {
  const _UserBubble({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final maxWidth = MediaQuery.sizeOf(context).width * 0.84;
    return Align(
      alignment: Alignment.centerRight,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: maxWidth),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
          decoration: BoxDecoration(
            color: t.bubble,
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(24),
              topRight: Radius.circular(24),
              bottomLeft: Radius.circular(24),
              bottomRight: Radius.circular(6),
            ),
          ),
          child: SelectableText(text, style: t.body(16.5, height: 1.4)),
        ),
      ),
    );
  }
}

class _AssistantMessage extends StatelessWidget {
  const _AssistantMessage({
    required this.message,
    required this.chat,
    required this.streaming,
    required this.canRegenerate,
  });

  final ChatMessage message;
  final ChatController chat;
  final bool streaming;
  final bool canRegenerate;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Semantics(
          liveRegion: streaming,
          label: streaming ? 'QELVO sedang menjawab' : null,
          child: const QelvoLogo(size: 26),
        ),
        const SizedBox(height: 12),
        SelectionArea(
          child: MarkdownView(text: message.content, streaming: streaming),
        ),
        if (!streaming && message.content.isNotEmpty) ...[
          const SizedBox(height: 6),
          _Actions(
            message: message,
            chat: chat,
            canRegenerate: canRegenerate,
          ),
        ],
      ],
    );
  }
}

class _Actions extends StatelessWidget {
  const _Actions({
    required this.message,
    required this.chat,
    required this.canRegenerate,
  });

  final ChatMessage message;
  final ChatController chat;
  final bool canRegenerate;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _CopyAction(text: message.content),
        _IconAction(
          icon: message.rating == 1
              ? Icons.thumb_up_rounded
              : Icons.thumb_up_outlined,
          label: 'Jawaban membantu',
          active: message.rating == 1,
          onTap: () => chat.rate(message, 1),
        ),
        _IconAction(
          icon: message.rating == -1
              ? Icons.thumb_down_rounded
              : Icons.thumb_down_outlined,
          label: 'Jawaban kurang membantu',
          active: message.rating == -1,
          onTap: () => chat.rate(message, -1),
        ),
        if (canRegenerate)
          _IconAction(
            icon: Icons.refresh_rounded,
            label: 'Buat ulang jawaban',
            onTap: chat.regenerate,
          ),
      ],
    );
  }
}

class _IconAction extends StatelessWidget {
  const _IconAction({
    required this.icon,
    required this.label,
    required this.onTap,
    this.active = false,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool active;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Tappable(
      label: label,
      onTap: onTap,
      selected: active,
      borderRadius: BorderRadius.circular(22),
      child: Center(
        child: Icon(icon, size: 22, color: active ? t.accentText : t.muted),
      ),
    );
  }
}

class _CopyAction extends StatefulWidget {
  const _CopyAction({required this.text});

  final String text;

  @override
  State<_CopyAction> createState() => _CopyActionState();
}

class _CopyActionState extends State<_CopyAction> {
  bool _copied = false;
  Timer? _timer;

  Future<void> _copy() async {
    await Clipboard.setData(ClipboardData(text: widget.text));
    if (!mounted) return;
    setState(() => _copied = true);
    _timer?.cancel();
    _timer = Timer(const Duration(milliseconds: 1600), () {
      if (mounted) setState(() => _copied = false);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _IconAction(
      icon: _copied ? Icons.check_rounded : Icons.content_copy_outlined,
      label: _copied ? 'Tersalin' : 'Salin jawaban',
      active: _copied,
      onTap: _copy,
    );
  }
}
