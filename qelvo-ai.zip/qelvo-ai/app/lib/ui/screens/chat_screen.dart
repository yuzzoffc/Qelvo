import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/data/photo_source.dart';
import 'package:qelvo_ai/state/app_state.dart';
import 'package:qelvo_ai/state/attachment_policy.dart';
import 'package:qelvo_ai/state/chat_controller.dart';
import 'package:qelvo_ai/state/photo_prep.dart';
import 'package:qelvo_ai/state/session.dart';
import 'package:qelvo_ai/ui/flows/session_flows.dart';
import 'package:qelvo_ai/ui/markdown/markdown_view.dart';
import 'package:qelvo_ai/ui/screens/account_screen.dart';
import 'package:qelvo_ai/ui/screens/settings_screen.dart';
import 'package:qelvo_ai/ui/widgets/add_sheet.dart';
import 'package:qelvo_ai/ui/widgets/chat_notices.dart';
import 'package:qelvo_ai/ui/widgets/composer.dart';
import 'package:qelvo_ai/ui/widgets/dialogs.dart';
import 'package:qelvo_ai/ui/widgets/history_drawer.dart';
import 'package:qelvo_ai/ui/widgets/model_sheet.dart';
import 'package:qelvo_ai/ui/widgets/notice.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_logo.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_spinner.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

/// Layar utama. Kosong = sapaan dengan kartu saran; ada pesan = percakapan.
class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  late final AppState _app;
  late final Session _session;
  late final ChatController _chat;
  final TextEditingController _composer = TextEditingController();
  final FocusNode _focus = FocusNode();
  final ScrollController _scroll = ScrollController();
  final List<ChatAttachment> _attachments = [];

  /// Foto yang baru dipilih dan masih diolah.
  int _preparing = 0;

  /// Naik tiap kali lampiran dikosongkan, supaya foto yang selesai diolah
  /// setelah itu tidak muncul di percakapan baru.
  int _attachEpoch = 0;
  bool _forceStick = false;

  @override
  void initState() {
    super.initState();
    _app = AppScope.of(context);
    _session = SessionScope.of(context);
    _chat = ChatController(app: _app, session: _session)..addListener(_onChat);
    unawaited(_app.catalog.load());
  }

  @override
  void dispose() {
    _chat.removeListener(_onChat);
    _chat.dispose();
    _composer.dispose();
    _focus.dispose();
    _scroll.dispose();
    super.dispose();
  }

  /// Menjaga daftar tetap di bawah saat jawaban mengalir, kecuali pengguna
  /// sedang menggulir ke atas untuk membaca.
  void _onChat() {
    final nearBottom = !_scroll.hasClients ||
        _scroll.position.maxScrollExtent - _scroll.position.pixels < 160;
    if (!nearBottom && !_forceStick) return;
    _forceStick = false;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && _scroll.hasClients) {
        _scroll.jumpTo(_scroll.position.maxScrollExtent);
      }
    });
  }

  void _send() {
    final text = _composer.text;
    if (text.trim().isEmpty || _chat.isLoading || _preparing > 0) return;
    final attachments = List<ChatAttachment>.of(_attachments);
    _composer.clear();
    setState(_attachments.clear);
    _forceStick = true;
    _chat.send(text, attachments: attachments);
  }

  void _fill(String prompt) {
    _composer.text = prompt;
    _composer.selection = TextSelection.collapsed(offset: prompt.length);
    _focus.requestFocus();
  }

  void _compose() {
    _composer.clear();
    _attachEpoch++;
    setState(() {
      _attachments.clear();
      _preparing = 0;
    });
    _focus.requestFocus();
  }

  /// Keadaan Foto di lembar Tambahkan ke chat. Tombol selalu menjawab: kalau
  /// model belum bisa membaca foto atau jatahnya penuh, alasannya ditulis di
  /// lembar, bukan lewat pemberitahuan yang tertutup lembar itu sendiri.
  ({bool enabled, String note}) _photoStatus() {
    final model = _app.catalog.activeModel;
    if (model == null) {
      return (
        enabled: false,
        note: 'Daftar model belum dimuat. Tunggu sebentar lalu coba lagi.',
      );
    }
    if (!model.vision) {
      return (
        enabled: false,
        note: 'Model ini belum bisa membaca foto. Pilih model lain di bilah atas.',
      );
    }
    final room =
        AttachmentRules.maxPerMessage - _attachments.length - _preparing;
    if (room <= 0) {
      return (
        enabled: false,
        note:
            'Satu pesan maksimal ${AttachmentRules.maxPerMessage} foto. Hapus satu untuk menambah.',
      );
    }
    return (enabled: true, note: 'Pilih dari galeri HP, sampai $room foto');
  }

  /// Membuka lembar Tambahkan ke chat. Berpikir langsung berlaku di dalam
  /// lembar; hanya Foto yang menutupnya, lalu pemilih foto bawaan HP dibuka.
  Future<void> _openAddSheet() async {
    _focus.unfocus();
    final status = _photoStatus();
    final choice = await showAddSheet(
      context,
      settings: _app.settings,
      photoEnabled: status.enabled,
      photoNote: status.note,
    );
    if (!mounted || choice != AddChoice.photo) return;
    await _pickPhotos();
  }

  /// Membuka pemilih foto bawaan HP, lalu menyiapkan foto yang dipilih (gambar
  /// penuh dan gambar kecil). Selama disiapkan, komposer menampilkan kotak
  /// berputar di tempat fotonya dan tombol kirim belum aktif.
  Future<void> _pickPhotos() async {
    final room =
        AttachmentRules.maxPerMessage - _attachments.length - _preparing;
    if (room <= 0) return;

    final PickedPhotos picked;
    try {
      picked = await pickPhotosFromDevice(limit: room);
    } catch (_) {
      if (mounted) {
        showNotice(
          context,
          'Pemilih foto bawaan HP tidak bisa dibuka. Coba lagi.',
        );
      }
      return;
    }
    if (!mounted || picked.photos.isEmpty) return;
    if (picked.skipped > 0) {
      showNotice(
        context,
        'Satu pesan maksimal ${AttachmentRules.maxPerMessage} foto. ${picked.skipped} foto tidak ikut.',
      );
    }

    final epoch = _attachEpoch;
    final count = picked.photos.length;
    setState(() => _preparing += count);
    final results = await Future.wait(picked.photos.map(attachmentFromBytes));
    if (!mounted || epoch != _attachEpoch) return;

    final ready = [
      for (final item in results)
        if (item != null) item,
    ];
    setState(() {
      _preparing -= count;
      _attachments.addAll(ready);
    });
    if (ready.length < count) {
      showNotice(
        context,
        ready.isEmpty
            ? 'Foto yang dipilih tidak bisa dibuka. Coba foto lain.'
            : 'Sebagian foto tidak bisa dibuka dan dilewati.',
      );
    }
    // Kolom kosong diisi permintaan awal supaya foto langsung bisa dikirim.
    if (ready.isNotEmpty && _composer.text.trim().isEmpty) {
      _fill('Jelaskan isi foto ini');
    }
  }

  Future<void> _export() async {
    await Clipboard.setData(ClipboardData(text: _chat.toMarkdown()));
    if (mounted) showNotice(context, 'Percakapan disalin sebagai Markdown.');
  }

  void _clearOpenChat() => _chat.reset(persistPartial: false);

  /// Setelah kembali dari layar lain, sapaan dibaca ulang (nama bisa berubah).
  Future<void> _push(Widget screen) async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => SessionScope(session: _session, child: screen),
      ),
    );
    if (mounted) setState(() {});
  }

  void _openSettings() => _push(SettingsScreen(onHistoryCleared: _clearOpenChat));

  void _openAccount() {
    if (_session.isGuest) {
      _signIn();
    } else {
      _push(AccountScreen(onHistoryCleared: _clearOpenChat));
    }
  }

  Future<void> _signIn() => leaveSession(
        context,
        app: _app,
        session: _session,
        onHistoryCleared: _clearOpenChat,
        toSignIn: true,
      );

  void _openDrawer() {
    _focus.unfocus();
    showHistoryDrawer(
      context,
      session: _session,
      chat: _chat,
      onOpenSettings: _openSettings,
      onOpenAccount: _openAccount,
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Scaffold(
      backgroundColor: t.bg,
      body: SafeArea(
        child: ListenableBuilder(
          listenable: Listenable.merge([_chat, _app.settings, _app.catalog]),
          builder: (context, _) {
            final failure = _chat.failure;
            final landing = _chat.isEmpty && !_chat.isLoading && failure == null;
            // Selama jawaban mengalir, tombol kembali menyembunyikan aplikasi
            // alih-alih menutupnya, supaya jawaban tetap berjalan di latar
            // belakang. Begitu selesai, kembali menutup aplikasi seperti biasa.
            return PopScope(
              canPop: !_chat.isStreaming,
              onPopInvokedWithResult: (didPop, result) {
                if (!didPop) unawaited(_chat.background.moveToBack());
              },
              child: Column(
                children: [
                  _TopBar(
                    landing: landing,
                    modelLabel: _app.catalog.shortLabel,
                    onMenu: _openDrawer,
                    onModel: () => showModelSheet(context),
                    onTrailing: landing ? _compose : _export,
                  ),
                  ActivityLine(active: _chat.isStreaming),
                  if (failure != null && failure.offline) const OfflineBanner(),
                  Expanded(
                    child: landing
                        ? _Landing(
                            name: _session.firstName,
                            onPick: _fill,
                          )
                        : _Conversation(
                            chat: _chat,
                            scroll: _scroll,
                            thinking: _app.settings.thinking,
                            onChangeModel: () => showModelSheet(context),
                          ),
                  ),
                  if (landing && _session.isGuest)
                    _GuestStrip(onSignIn: _signIn),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(
                      QelvoLayout.cardMargin,
                      6,
                      QelvoLayout.cardMargin,
                      12,
                    ),
                    child: Composer(
                      controller: _composer,
                      focusNode: _focus,
                      hint: landing ? 'Tanya QELVO…' : 'Balas QELVO…',
                      busy: _chat.isStreaming,
                      attachments: _attachments,
                      pendingAttachments: _preparing,
                      onAdd: _openAddSheet,
                      onRemoveAttachment: (index) =>
                          setState(() => _attachments.removeAt(index)),
                      onSend: _send,
                      onStop: _chat.stop,
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar({
    required this.landing,
    required this.modelLabel,
    required this.onMenu,
    required this.onModel,
    required this.onTrailing,
  });

  final bool landing;
  final String modelLabel;
  final VoidCallback onMenu;
  final VoidCallback onModel;
  final VoidCallback onTrailing;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 4),
      child: Row(
        children: [
          Tappable(
            label: 'Buka riwayat',
            onTap: onMenu,
            borderRadius: BorderRadius.circular(24),
            minSize: 48,
            child: Center(child: MenuGlyph(size: 26, color: t.text)),
          ),
          Expanded(
            child: Center(
              child: Tappable(
                label: modelLabel.isEmpty
                    ? 'Pilih model'
                    : 'Pilih model, sekarang $modelLabel',
                onTap: onModel,
                borderRadius: BorderRadius.circular(24),
                child: Container(
                  padding: const EdgeInsets.fromLTRB(14, 9, 10, 9),
                  decoration: BoxDecoration(
                    color: t.surface,
                    borderRadius: BorderRadius.circular(24),
                    // Tepi sedikit lebih tegas dari garis biasa supaya pil ini
                    // tidak larut ke latar layar.
                    border: Border.all(color: t.aiBubbleLine),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const QelvoWordmark(width: 66),
                      if (modelLabel.isNotEmpty) ...[
                        const SizedBox(width: 9),
                        // Titik warna merek: penanda model aktif dan petunjuk
                        // bahwa pil ini bisa diketuk. Tampil setelah daftar
                        // model dimuat, bersama nama modelnya.
                        Container(
                          width: 7,
                          height: 7,
                          decoration: BoxDecoration(
                            color: t.logoTail,
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Flexible(
                          child: Text(
                            modelLabel,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: t.body(14.5, color: t.muted),
                          ),
                        ),
                      ],
                      const SizedBox(width: 2),
                      Icon(
                        Icons.keyboard_arrow_down_rounded,
                        size: 20,
                        color: t.text,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Tappable(
            label: landing ? 'Mulai menulis' : 'Salin percakapan sebagai Markdown',
            onTap: onTrailing,
            borderRadius: BorderRadius.circular(24),
            minSize: 48,
            child: Center(
              child: Icon(
                landing ? Icons.edit_outlined : Icons.ios_share_rounded,
                size: 24,
                // Di beranda belum ada yang ditulis, jadi pensil sengaja redup
                // supaya perhatian tetap di sapaan dan kolom tulis. Ikon bagikan
                // di percakapan tetap penuh.
                color: landing ? t.quietIcon : t.text,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Pita untuk tamu di beranda: pengingat singkat dan jalan menuju masuk.
class _GuestStrip extends StatelessWidget {
  const _GuestStrip({required this.onSignIn});

  final VoidCallback onSignIn;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Padding(
      padding: const EdgeInsets.fromLTRB(QelvoLayout.textStart, 0, 12, 0),
      child: Row(
        children: [
          Expanded(
            child: Text(
              'Mode tamu · riwayat hilang saat keluar',
              style: t.body(13.5, color: t.muted),
            ),
          ),
          Tappable(
            label: 'Masuk dengan akun',
            onTap: onSignIn,
            borderRadius: BorderRadius.circular(QelvoRadius.sm),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              child: Text(
                'Masuk',
                style: t.body(14.5, weight: FontWeight.w700),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Suggestion {
  const _Suggestion(this.title, this.subtitle, this.prompt);

  final String title;
  final String subtitle;

  /// Teks yang diisikan ke kolom pesan. Pengguna bisa mengubahnya dulu.
  final String prompt;
}

class _Landing extends StatelessWidget {
  const _Landing({required this.name, required this.onPick});

  /// Nama depan untuk sapaan. Kosong untuk tamu atau akun tanpa nama.
  final String name;
  final ValueChanged<String> onPick;

  /// Tiga saran, bukan empat: beranda sengaja dibiarkan lebih lapang. "Rapikan
  /// tulisan" dilepas karena kalimat awalnya berakhir di kolom kosong untuk
  /// ditempel, tidak sesiap tiga yang lain.
  static const List<_Suggestion> _suggestions = [
    _Suggestion(
      'Jelaskan konsep',
      'Fotosintesis dalam dua kalimat',
      'Jelaskan konsep fotosintesis dalam dua kalimat.',
    ),
    _Suggestion(
      'Bantu tulis kode',
      'Fungsi Dart untuk luas lingkaran',
      'Buatkan fungsi Dart untuk menghitung luas lingkaran.',
    ),
    _Suggestion(
      'Cari ide',
      'Nama untuk toko kopi baru',
      'Beri 10 ide nama untuk toko kopi baru yang singkat dan mudah diingat.',
    ),
  ];

  /// Ruang di atas sapaan dan di bawah saran terakhir. Bagian bawah sengaja
  /// lega supaya baris saran tidak menempel ke kolom tulis.
  static const double _top = 24;
  static const double _bottom = 24;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return LayoutBuilder(
      builder: (context, box) {
        return SingleChildScrollView(
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          // Selebar kartu kolom tulis: garis pemisah saran sejajar dengan tepi
          // kartu itu, sedangkan teks sapaan dan saran mulai dari awal teks
          // isian (QelvoLayout.textStart).
          padding: const EdgeInsets.fromLTRB(
            QelvoLayout.cardMargin,
            _top,
            QelvoLayout.cardMargin,
            _bottom,
          ),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minHeight: math.max(0.0, box.maxHeight - _top - _bottom),
            ),
            child: IntrinsicHeight(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: QelvoLayout.cardTextInset,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          name.isEmpty ? 'Hai!' : 'Hai, $name!',
                          style: t.display(
                            40,
                            weight: FontWeight.w800,
                            height: 1.1,
                          ),
                        ),
                        const SizedBox(height: 4),
                        // Lebar dibatasi agar kalimat patah jadi dua baris yang
                        // seimbang: "Mau ngobrolin" dan "apa sekarang?".
                        ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 300),
                          child: Text(
                            'Mau ngobrolin apa sekarang?',
                            style: t.display(
                              36,
                              weight: FontWeight.w500,
                              color: t.muted,
                              height: 1.18,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Spacer(),
                  const SizedBox(height: 28),
                  for (var i = 0; i < _suggestions.length; i++)
                    _SuggestionRow(
                      item: _suggestions[i],
                      first: i == 0,
                      onTap: () => onPick(_suggestions[i].prompt),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

/// Satu saran sebagai baris teks dengan garis pemisah. Sebelumnya empat kartu
/// identik berikon di atas kotak berwarna: pola bawaan AI (antislop R-14, R-04)
/// yang juga memakai cyan di empat tempat sekaligus. Isinya tetap kalimat awal
/// yang bisa diubah dulu sebelum dikirim. Barisnya selebar kartu kolom tulis
/// dan teksnya mulai dari awal teks isian, jadi sapaan, saran, dan isian pesan
/// berada di garis kiri yang sama.
class _SuggestionRow extends StatelessWidget {
  const _SuggestionRow({
    required this.item,
    required this.first,
    required this.onTap,
  });

  final _Suggestion item;

  /// Baris pertama juga diberi garis di atasnya.
  final bool first;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Tappable(
      onTap: onTap,
      minSize: 64,
      borderRadius: BorderRadius.circular(QelvoRadius.sm),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(
          horizontal: QelvoLayout.cardTextInset,
          vertical: 18,
        ),
        decoration: BoxDecoration(
          border: Border(
            top: first ? BorderSide(color: t.border) : BorderSide.none,
            bottom: BorderSide(color: t.border),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(item.title, style: t.display(17)),
            const SizedBox(height: 2),
            Text(
              item.subtitle,
              style: t.body(15, color: t.muted, height: 1.35),
            ),
          ],
        ),
      ),
    );
  }
}

class _Conversation extends StatelessWidget {
  const _Conversation({
    required this.chat,
    required this.scroll,
    required this.thinking,
    required this.onChangeModel,
  });

  final ChatController chat;
  final ScrollController scroll;

  /// Mode berpikir menyala; menentukan bunyi penanda saat menunggu jawaban.
  final bool thinking;
  final VoidCallback onChangeModel;

  Widget _failure(ChatFailure failure) {
    if (!chat.canRetry) return InlineNotice(message: failure.message);
    if (failure.offline) return UnsentNotice(onRetry: chat.retry);
    return ErrorBlock(
      failure: failure,
      onRetry: chat.retry,
      onChangeModel: onChangeModel,
    );
  }

  @override
  Widget build(BuildContext context) {
    if (chat.isLoading) {
      return const Center(child: QelvoSpinner(size: 28));
    }
    final messages = chat.messages;
    final failure = chat.failure;
    return ListView.builder(
      controller: scroll,
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      itemCount: messages.length + (failure != null ? 1 : 0),
      itemBuilder: (context, index) {
        if (index >= messages.length) return _failure(failure!);
        final message = messages[index];
        final isLast = index == messages.length - 1;
        return Padding(
          key: ValueKey(message.id),
          padding: const EdgeInsets.only(bottom: 22),
          child: message.role == ChatRole.user
              ? _UserBubble(
                  text: message.content,
                  attachments: message.attachments,
                )
              : _AssistantMessage(
                  message: message,
                  chat: chat,
                  streaming: chat.isStreaming && isLast,
                  thinking: thinking,
                  canRegenerate: isLast && !chat.isStreaming,
                ),
        );
      },
    );
  }
}

class _UserBubble extends StatelessWidget {
  const _UserBubble({required this.text, required this.attachments});

  final String text;
  final List<ChatAttachment> attachments;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final maxWidth = MediaQuery.sizeOf(context).width * 0.84;
    return Align(
      alignment: Alignment.centerRight,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: maxWidth),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
          // Biru navy yang lebih terang dan bergaris tepi: jelas beda dari kartu
          // netral jawaban AI, tanpa memakai cyan.
          decoration: BoxDecoration(
            color: t.raised,
            border: Border.all(color: t.raisedLine),
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(24),
              topRight: Radius.circular(24),
              bottomLeft: Radius.circular(24),
              bottomRight: Radius.circular(6),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              if (attachments.isNotEmpty) ...[
                _BubblePhotos(attachments: attachments),
                const SizedBox(height: 10),
              ],
              SelectableText(text, style: t.body(16.5, height: 1.4)),
            ],
          ),
        ),
      ),
    );
  }
}

/// Gambar kecil foto yang dilampirkan, di atas teks pesan. Satu foto tampil
/// lebih besar; beberapa foto tersusun dua per baris.
class _BubblePhotos extends StatelessWidget {
  const _BubblePhotos({required this.attachments});

  final List<ChatAttachment> attachments;

  @override
  Widget build(BuildContext context) {
    final size = attachments.length == 1 ? 168.0 : 96.0;
    return Semantics(
      label: '${attachments.length} foto dilampirkan',
      child: Wrap(
        spacing: 6,
        runSpacing: 6,
        children: [
          for (final attachment in attachments)
            ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: Image.memory(
                attachment.thumb,
                width: size,
                height: size,
                fit: BoxFit.cover,
                gaplessPlayback: true,
                excludeFromSemantics: true,
              ),
            ),
        ],
      ),
    );
  }
}

class _AssistantMessage extends StatelessWidget {
  const _AssistantMessage({
    required this.message,
    required this.chat,
    required this.streaming,
    required this.thinking,
    required this.canRegenerate,
  });

  final ChatMessage message;
  final ChatController chat;
  final bool streaming;
  final bool thinking;
  final bool canRegenerate;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    // Sebelum potongan pertama tiba, penanda berpikir menggantikan teks.
    final waiting = streaming && message.content.isEmpty;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Semantics(
          liveRegion: streaming,
          label: streaming ? 'QELVO sedang menjawab' : null,
          child: const QelvoLogo(size: 28),
        ),
        const SizedBox(height: 12),
        // Kartu netral dengan garis tepi, rata kiri, dan sudut kiri atas yang
        // runcing ke arah logo. Pesan pengguna berwarna biru navy terang dan rata
        // kanan, jadi keduanya langsung terbedakan.
        Container(
          width: double.infinity,
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
          decoration: BoxDecoration(
            color: t.surface,
            border: Border.all(color: t.aiBubbleLine),
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(6),
              topRight: Radius.circular(24),
              bottomLeft: Radius.circular(24),
              bottomRight: Radius.circular(24),
            ),
          ),
          child: waiting
              ? ThinkingIndicator(thinking: thinking)
              : SelectionArea(
                  child: MarkdownView(
                    text: message.content,
                    streaming: streaming,
                  ),
                ),
        ),
        if (!streaming && message.content.isNotEmpty) ...[
          const SizedBox(height: 6),
          _Actions(
            message: message,
            chat: chat,
            canRegenerate: canRegenerate,
          ),
        ],
      ],
    );
  }
}

class _Actions extends StatelessWidget {
  const _Actions({
    required this.message,
    required this.chat,
    required this.canRegenerate,
  });

  final ChatMessage message;
  final ChatController chat;
  final bool canRegenerate;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _CopyAction(text: message.content),
        _IconAction(
          icon: message.rating == 1
              ? Icons.thumb_up_rounded
              : Icons.thumb_up_outlined,
          label: 'Jawaban membantu',
          active: message.rating == 1,
          onTap: () => chat.rate(message, 1),
        ),
        _IconAction(
          icon: message.rating == -1
              ? Icons.thumb_down_rounded
              : Icons.thumb_down_outlined,
          label: 'Jawaban kurang membantu',
          active: message.rating == -1,
          onTap: () => chat.rate(message, -1),
        ),
        if (canRegenerate)
          _IconAction(
            icon: Icons.refresh_rounded,
            label: 'Buat ulang jawaban',
            onTap: chat.regenerate,
          ),
      ],
    );
  }
}

class _IconAction extends StatelessWidget {
  const _IconAction({
    required this.icon,
    required this.label,
    required this.onTap,
    this.active = false,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool active;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Tappable(
      label: label,
      onTap: onTap,
      selected: active,
      borderRadius: BorderRadius.circular(22),
      child: Center(
        child: Icon(icon, size: 22, color: active ? t.text : t.muted),
      ),
    );
  }
}

class _CopyAction extends StatefulWidget {
  const _CopyAction({required this.text});

  final String text;

  @override
  State<_CopyAction> createState() => _CopyActionState();
}

class _CopyActionState extends State<_CopyAction> {
  bool _copied = false;
  Timer? _timer;

  Future<void> _copy() async {
    await Clipboard.setData(ClipboardData(text: widget.text));
    if (!mounted) return;
    setState(() => _copied = true);
    _timer?.cancel();
    _timer = Timer(const Duration(milliseconds: 1600), () {
      if (mounted) setState(() => _copied = false);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _IconAction(
      icon: _copied ? Icons.check_rounded : Icons.content_copy_outlined,
      label: _copied ? 'Tersalin' : 'Salin jawaban',
      active: _copied,
      onTap: _copy,
    );
  }
}
