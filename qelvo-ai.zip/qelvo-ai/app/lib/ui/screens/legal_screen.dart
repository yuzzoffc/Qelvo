import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/config.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/ui/widgets/screen_bar.dart';

enum LegalKind { terms, privacy }

class _Section {
  const _Section(this.title, this.body);

  final String title;
  final String body;
}

const List<_Section> _terms = [
  _Section(
    'Tentang layanan',
    'QELVO adalah aplikasi asisten AI untuk bertanya, belajar, menulis, dan coding. Jawaban dibuat oleh model milik penyedia API yang kamu pilih (Google AI Studio atau OpenRouter), bukan oleh model buatan QELVO.',
  ),
  _Section(
    'Akun',
    'Kamu harus masuk sebelum memakai fitur AI, dengan akun Google atau sebagai tamu. Jaga akses ke akunmu. Aktivitas lewat akunmu menjadi tanggung jawabmu. Riwayat chat tamu hanya bisa dibuka di perangkat yang sama dan dihapus saat kamu keluar dari mode tamu.',
  ),
  _Section(
    'Pemakaian yang wajar',
    'Jangan memakai QELVO untuk melanggar hukum, menyerang atau melecehkan orang lain, atau membebani layanan secara berlebihan. Kami membatasi jumlah permintaan per menit dan dapat menutup akses yang menyalahgunakan layanan.',
  ),
  _Section(
    'Jawaban bisa keliru',
    'Model AI dapat membuat kesalahan. Periksa ulang hal yang penting, terutama soal kesehatan, hukum, dan keuangan. Jangan mengirim kata sandi, nomor kartu, atau data rahasia.',
  ),
  _Section(
    'Layanan gratis',
    'Kuota dan ketentuan penyedia AI dapat berubah. Layanan bisa terhenti atau melambat tanpa pemberitahuan lebih dulu.',
  ),
  _Section(
    'Perubahan ketentuan',
    'Ketentuan ini dapat diperbarui. Versi yang berlaku adalah yang tampil di dalam aplikasi.',
  ),
  _Section(
    'Kontak',
    '[Isi alamat kontak pemilik layanan sebelum rilis.]',
  ),
];

const List<_Section> _privacy = [
  _Section(
    'Data yang diproses',
    'Email dan nama profil dari akun Google yang kamu pakai untuk masuk. Tamu tidak memberi email atau nama; Firebase hanya membuat ID akun anonim. Isi percakapan: pesan, waktu, dan penilaian suka atau tidak suka pada jawaban. Pengaturan tampilan di perangkat.',
  ),
  _Section(
    'Tempat penyimpanan',
    'Akun dikelola oleh Firebase Authentication. Riwayat percakapan disimpan di Cloud Firestore (layanan Google) lewat server QELVO dan terhubung ke akunmu; aplikasi tidak mengakses database itu secara langsung. Pengaturan tampilan hanya tersimpan di perangkat.',
  ),
  _Section(
    'Ke mana pesan dikirim',
    'Saat kamu mengirim pesan, aplikasi mengirim beberapa pesan terakhir ke server QELVO. Server meneruskannya ke penyedia AI yang kamu pilih untuk membuat jawaban. Server QELVO hanya menyimpan percakapan ke riwayat akunmu (bila "Simpan riwayat" menyala) dan tidak mencatatnya di tempat lain, tetapi penyedia hosting dapat mencatat data teknis permintaan seperti waktu dan alamat IP.',
  ),
  _Section(
    'Penyedia AI',
    'Pada tingkat gratis, penyedia AI dapat memakai isi percakapan untuk meningkatkan produk mereka, dan sebagian model gratis di OpenRouter dapat menyimpan prompt. Baca ketentuan penyedia sebelum mengirim data yang sensitif.',
  ),
  if (AppConfig.emailLogin)
    _Section(
      'Kode verifikasi email',
      'Kode dikirim ke emailmu dan hanya berlaku 10 menit. Server menyimpan hasil hash dari kode, bukan kodenya, sampai kode dipakai atau kedaluwarsa.',
    ),
  _Section(
    'Menghapus data',
    'Di Pengaturan, "Hapus semua riwayat" menghapus seluruh percakapan dari akunmu. Tekan lama sebuah percakapan di daftar riwayat untuk menghapusnya satu per satu. Keluar dari mode tamu menghapus seluruh riwayat tamu. Penghapusan akun belum tersedia di aplikasi. [Isi kontak untuk permintaan penghapusan akun.]',
  ),
  _Section(
    'Usia dan wilayah',
    '[Isi batas usia pengguna dan ketentuan wilayah sebelum rilis.]',
  ),
];

class LegalScreen extends StatelessWidget {
  const LegalScreen({super.key, required this.kind});

  final LegalKind kind;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final isTerms = kind == LegalKind.terms;
    final sections = isTerms ? _terms : _privacy;
    return Scaffold(
      backgroundColor: t.bg,
      body: SafeArea(
        child: Column(
          children: [
            ScreenBar(title: isTerms ? 'Ketentuan' : 'Kebijakan Privasi'),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(QelvoRadius.md),
                      border: Border.all(color: t.warn.withAlpha(140)),
                    ),
                    child: Text(
                      'Draf versi 0.1. Belum ditinjau ahli hukum. Lengkapi bagian bertanda [ ] sebelum rilis publik.',
                      style: t.body(14.5, height: 1.45),
                    ),
                  ),
                  for (final section in sections) ...[
                    const SizedBox(height: 22),
                    Text(section.title, style: t.display(18)),
                    const SizedBox(height: 6),
                    Text(
                      section.body,
                      style: t.body(15.5, color: t.muted, height: 1.55),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
