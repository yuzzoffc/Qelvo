import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/config.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/ui/widgets/screen_bar.dart';

enum LegalKind { terms, privacy }

class _Section {
  const _Section(this.title, this.body);

  final String title;
  final String body;
}

const List<_Section> _terms = [
  _Section(
    'Tentang layanan',
    'QELVO adalah aplikasi asisten AI untuk bertanya, belajar, menulis, dan coding. Jawaban dibuat oleh model milik penyedia API yang kamu pilih (Google AI Studio atau OpenRouter), bukan oleh model buatan QELVO.',
  ),
  _Section(
    'Akun',
    'Kamu harus masuk sebelum memakai fitur AI, dengan akun Google atau kode yang dikirim ke emailmu. Jaga akses ke akunmu. Aktivitas lewat akunmu menjadi tanggung jawabmu. Kamu bisa menghapus akunmu kapan saja di Pengaturan, Akun, Hapus akun.',
  ),
  _Section(
    'Pemakaian yang wajar',
    'Jangan memakai QELVO untuk melanggar hukum, menyerang atau melecehkan orang lain, atau membebani layanan secara berlebihan. Kami membatasi jumlah permintaan per menit dan dapat menutup akses yang menyalahgunakan layanan.',
  ),
  _Section(
    'Jawaban bisa keliru',
    'Model AI dapat membuat kesalahan. Periksa ulang hal yang penting, terutama soal kesehatan, hukum, dan keuangan. Jangan mengirim kata sandi, nomor kartu, data rahasia, atau foto dokumen pribadi.',
  ),
  _Section(
    'Layanan gratis',
    'Kuota dan ketentuan penyedia AI dapat berubah. Layanan bisa terhenti atau melambat tanpa pemberitahuan lebih dulu.',
  ),
  _Section(
    'Perubahan ketentuan',
    'Ketentuan ini dapat diperbarui. Versi yang berlaku adalah yang tampil di dalam aplikasi.',
  ),
  _Section(
    'Kontak',
    '[Isi alamat kontak pemilik layanan sebelum rilis.]',
  ),
];

const List<_Section> _privacy = [
  _Section(
    'Data yang diproses',
    'Email dan nama profil dari akun Google yang kamu pakai untuk masuk, atau email yang kamu pakai untuk masuk dengan kode (kode hanya disimpan sebagai hash dan kedaluwarsa dalam 10 menit). Isi percakapan: pesan, waktu, penilaian suka atau tidak suka pada jawaban, dan foto yang kamu lampirkan. Aplikasi hanya membuka galeri foto saat kamu menekan tombol lampir, dan hanya membaca foto yang kamu pilih. Pengaturan tampilan di perangkat. Catatan "Tentang kamu" dikirim bersama pesan ke penyedia AI supaya jawaban sesuai, dan hanya tersimpan di perangkatmu. Jumlah pesan per hari dihitung per akun untuk menjaga kuota. Laporan crash (pesan error, jejak teknis, versi aplikasi, dan jenis perangkat, tanpa isi percakapan, nama, atau email) dikirim ke server QELVO; kamu bisa mematikannya di Pengaturan.',
  ),
  _Section(
    'Tempat penyimpanan',
    'Akun dikelola oleh Firebase Authentication. Riwayat percakapan disimpan di Cloud Firestore (layanan Google) lewat server QELVO dan terhubung ke akunmu; aplikasi tidak mengakses database itu secara langsung. Foto yang kamu lampirkan tidak disimpan di server; yang ikut tersimpan di riwayat hanyalah gambar kecil dari foto itu (sekitar 256 piksel), dan hanya bila "Simpan riwayat" menyala. Pengaturan tampilan hanya tersimpan di perangkat.',
  ),
  _Section(
    'Ke mana pesan dikirim',
    'Saat kamu mengirim pesan, aplikasi mengirim beberapa pesan terakhir ke server QELVO. Server meneruskannya ke penyedia AI yang kamu pilih untuk membuat jawaban. Foto yang kamu lampirkan ikut dikirim ke penyedia itu bersama pesannya. Server QELVO hanya menyimpan percakapan ke riwayat akunmu (bila "Simpan riwayat" menyala) dan tidak mencatatnya di tempat lain, tetapi penyedia hosting dapat mencatat data teknis permintaan seperti waktu dan alamat IP.',
  ),
  _Section(
    'Penyedia AI',
    'Pada tingkat gratis, penyedia AI dapat memakai isi percakapan untuk meningkatkan produk mereka, dan sebagian model gratis di OpenRouter dapat menyimpan prompt. Baca ketentuan penyedia sebelum mengirim data yang sensitif.',
  ),
  if (AppConfig.emailLogin)
    _Section(
      'Kode verifikasi email',
      'Kode dikirim ke emailmu dan hanya berlaku 10 menit. Server menyimpan hasil hash dari kode, bukan kodenya, sampai kode dipakai atau kedaluwarsa.',
    ),
  _Section(
    'Menghapus data',
    'Di Pengaturan, "Hapus semua riwayat" menghapus seluruh percakapan dari akunmu, termasuk gambar kecil di dalamnya. Tekan lama sebuah percakapan di daftar riwayat untuk mengganti nama, menyematkan, atau menghapusnya. Di Pengaturan, Akun, "Hapus akun" menghapus akunmu beserta seluruh riwayatnya setelah kamu memasukkan kode 6 digit yang dikirim ke emailmu. Tanpa aplikasi, buka halaman /hapus-akun di alamat server QELVO. [Isi alamat lengkap halaman itu dan kontak bantuan.]',
  ),
  _Section(
    'Usia dan wilayah',
    '[Isi batas usia pengguna dan ketentuan wilayah sebelum rilis.]',
  ),
];

class LegalScreen extends StatelessWidget {
  const LegalScreen({super.key, required this.kind});

  final LegalKind kind;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final isTerms = kind == LegalKind.terms;
    final sections = isTerms ? _terms : _privacy;
    return Scaffold(
      backgroundColor: t.bg,
      body: SafeArea(
        child: Column(
          children: [
            ScreenBar(title: isTerms ? 'Ketentuan Layanan' : 'Kebijakan Privasi'),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(QelvoRadius.md),
                      border: Border.all(color: t.warn.withAlpha(140)),
                    ),
                    child: Text(
                      'Draf versi 0.1. Belum ditinjau ahli hukum. Lengkapi bagian bertanda [ ] sebelum rilis publik.',
                      style: t.body(14.5, height: 1.45),
                    ),
                  ),
                  for (final section in sections) ...[
                    const SizedBox(height: 22),
                    Text(section.title, style: t.display(18)),
                    const SizedBox(height: 6),
                    Text(
                      section.body,
                      style: t.body(15.5, color: t.muted, height: 1.55),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
