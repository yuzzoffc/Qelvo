import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/data/api_client.dart';
import 'package:qelvo_ai/data/auth_service.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/state/app_state.dart';
import 'package:qelvo_ai/ui/widgets/buttons.dart';
import 'package:qelvo_ai/ui/widgets/dialogs.dart';
import 'package:qelvo_ai/ui/widgets/notice.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_logo.dart';
import 'package:qelvo_ai/ui/widgets/screen_bar.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

class EmailCodeScreen extends StatefulWidget {
  const EmailCodeScreen({super.key, required this.email, required this.info});

  final String email;
  final EmailCodeInfo info;

  @override
  State<EmailCodeScreen> createState() => _EmailCodeScreenState();
}

class _EmailCodeScreenState extends State<EmailCodeScreen> {
  static const int _length = 6;

  final TextEditingController _code = TextEditingController();
  final FocusNode _focus = FocusNode();
  Timer? _timer;
  late int _resendIn = widget.info.resendIn;
  late int _expiresIn = widget.info.expiresIn;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _focus.addListener(_onFocus);
    _startTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _focus.removeListener(_onFocus);
    _code.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _onFocus() {
    if (mounted) setState(() {});
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return;
      setState(() {
        if (_resendIn > 0) _resendIn--;
      });
      if (_resendIn == 0) timer.cancel();
    });
  }

  Future<void> _submit() async {
    final code = _code.text.trim();
    if (code.length != _length || _busy) return;
    final app = AppScope.of(context);
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final token = await app.api.verifyEmailCode(widget.email, code);
      await app.auth.signInWithCustomToken(token);
      if (!mounted) return;
      // AuthGate sudah berganti ke layar chat; tutup layar kode di atasnya.
      Navigator.of(context).popUntil((route) => route.isFirst);
    } on ApiException catch (error) {
      _showError(error.message);
    } on AuthFailure catch (error) {
      _showError(error.message);
    } finally {
      if (mounted) {
        setState(() => _busy = false);
        // Kolom isian baru aktif lagi setelah pembangunan ulang ini, jadi
        // fokus dikembalikan sesudahnya supaya papan ketik tidak hilang.
        if (_error != null) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) _focus.requestFocus();
          });
        }
      }
    }
  }

  void _showError(String message) {
    if (!mounted) return;
    setState(() => _error = message);
    _code.clear();
  }

  Future<void> _resend() async {
    final app = AppScope.of(context);
    setState(() => _error = null);
    try {
      final info = await app.api.startEmailCode(widget.email);
      if (!mounted) return;
      setState(() {
        _resendIn = info.resendIn;
        _expiresIn = info.expiresIn;
      });
      _startTimer();
      showNotice(context, 'Kode baru dikirim.');
    } on ApiException catch (error) {
      if (mounted) setState(() => _error = error.message);
    }
  }

  /// 45 detik jadi 0:45, supaya hitungan mundur terbaca seperti jam.
  String _clock(int seconds) =>
      '${seconds ~/ 60}:${(seconds % 60).toString().padLeft(2, '0')}';

  Widget _boxes() {
    final digits = _code.text;
    final activeIndex = math.min(digits.length, _length - 1);
    return SizedBox(
      height: 60,
      child: Stack(
        children: [
          Row(
            children: [
              for (var i = 0; i < _length; i++) ...[
                if (i > 0) const SizedBox(width: 8),
                Expanded(
                  child: _DigitBox(
                    digit: i < digits.length ? digits[i] : '',
                    active: _focus.hasFocus && !_busy && i == activeIndex,
                    failed: _error != null,
                  ),
                ),
              ],
            ],
          ),
          // Kolom isian asli ada di atas kotak, dengan teks transparan. Satu
          // kolom ini yang menerima ketikan, isi otomatis dari SMS,
          // dan tempel, jadi kotak di bawahnya hanya tampilan.
          Positioned.fill(
            child: AutofillGroup(
              child: TextField(
                controller: _code,
                focusNode: _focus,
                autofocus: true,
                enabled: !_busy,
                expands: true,
                maxLines: null,
                minLines: null,
                showCursor: false,
                keyboardType: TextInputType.number,
                textInputAction: TextInputAction.done,
                autofillHints: const [AutofillHints.oneTimeCode],
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(_length),
                ],
                style: const TextStyle(color: Colors.transparent, fontSize: 24),
                decoration: const InputDecoration(
                  // Tidak terlihat, tetapi dibacakan pembaca layar.
                  hintText: 'Kode verifikasi 6 digit',
                  hintStyle: TextStyle(color: Colors.transparent),
                  border: InputBorder.none,
                  counterText: '',
                  contentPadding: EdgeInsets.zero,
                ),
                onChanged: (value) {
                  setState(() {});
                  if (value.length == _length) _submit();
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final minutes = (_expiresIn / 60).ceil();
    final complete = _code.text.trim().length == _length;

    return Scaffold(
      backgroundColor: t.bg,
      body: SafeArea(
        child: Column(
          children: [
            const ScreenBar(title: ''),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(24, 8, 24, 16),
                child: Align(
                  alignment: Alignment.topCenter,
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 440),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const QelvoLogo(size: 48),
                        const SizedBox(height: 22),
                        Text(
                          'Cek email kamu',
                          style: t.display(28, weight: FontWeight.w800),
                        ),
                        const SizedBox(height: 10),
                        Text.rich(
                          TextSpan(
                            style: t.body(16, color: t.muted, height: 1.5),
                            children: [
                              const TextSpan(text: 'Kami mengirim kode 6 digit ke '),
                              TextSpan(
                                text: widget.email,
                                style: TextStyle(color: t.text),
                              ),
                              TextSpan(text: '. Kode berlaku $minutes menit.'),
                            ],
                          ),
                        ),
                        const SizedBox(height: 28),
                        _boxes(),
                        const SizedBox(height: 10),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 2),
                          child: Text(
                            'Diverifikasi otomatis saat 6 digit terisi.',
                            style: t.body(14, color: t.muted),
                          ),
                        ),
                        const SizedBox(height: 22),
                        PrimaryButton(
                          label: 'Verifikasi',
                          busy: _busy,
                          onPressed: complete ? _submit : null,
                        ),
                        if (_error != null) ...[
                          const SizedBox(height: 16),
                          InlineNotice(message: _error!),
                        ],
                        const SizedBox(height: 22),
                        Center(
                          child: _resendIn > 0
                              ? Text(
                                  'Kirim ulang kode dalam ${_clock(_resendIn)}',
                                  style: t.body(15, color: t.muted),
                                )
                              : Tappable(
                                  onTap: _busy ? null : _resend,
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 14,
                                      vertical: 10,
                                    ),
                                    child: Text(
                                      'Kirim ulang kode',
                                      style: t.body(
                                        15.5,
                                        weight: FontWeight.w700,
                                      ),
                                    ),
                                  ),
                                ),
                        ),
                        Center(
                          child: Tappable(
                            onTap: _busy ? null : () => Navigator.of(context).maybePop(),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 14,
                                vertical: 10,
                              ),
                              child: Text(
                                'Ganti email',
                                style: t.body(
                                  15.5,
                                  weight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(32, 4, 32, 18),
              child: Text(
                'Tidak menemukan emailnya? Periksa folder spam.',
                textAlign: TextAlign.center,
                style: t.body(13.5, color: t.muted, height: 1.5),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Satu kotak digit. Kotak aktif bergaris tebal berwarna teks dan memperlihatkan
/// garis kursor diam (tanpa kedip) saat masih kosong.
class _DigitBox extends StatelessWidget {
  const _DigitBox({
    required this.digit,
    required this.active,
    required this.failed,
  });

  final String digit;
  final bool active;
  final bool failed;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final Color edge = failed
        ? t.warn
        : active
            ? t.text
            : t.outline;
    return ExcludeSemantics(
      child: Container(
        height: 60,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: t.surface,
          borderRadius: BorderRadius.circular(QelvoRadius.md - 2),
          border: Border.all(color: edge, width: active ? 2 : 1),
        ),
        child: digit.isNotEmpty
            ? Text(digit, style: t.mono(26, weight: FontWeight.w600))
            : active
                ? Container(width: 2, height: 26, color: t.text)
                : null,
      ),
    );
  }
}
