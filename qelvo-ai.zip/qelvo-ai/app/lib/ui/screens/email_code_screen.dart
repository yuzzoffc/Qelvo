import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/data/api_client.dart';
import 'package:qelvo_ai/data/auth_service.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/state/app_state.dart';
import 'package:qelvo_ai/ui/widgets/buttons.dart';
import 'package:qelvo_ai/ui/widgets/dialogs.dart';
import 'package:qelvo_ai/ui/widgets/notice.dart';
import 'package:qelvo_ai/ui/widgets/screen_bar.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

class EmailCodeScreen extends StatefulWidget {
  const EmailCodeScreen({super.key, required this.email, required this.info});

  final String email;
  final EmailCodeInfo info;

  @override
  State<EmailCodeScreen> createState() => _EmailCodeScreenState();
}

class _EmailCodeScreenState extends State<EmailCodeScreen> {
  final TextEditingController _code = TextEditingController();
  final FocusNode _focus = FocusNode();
  Timer? _timer;
  late int _resendIn = widget.info.resendIn;
  late int _expiresIn = widget.info.expiresIn;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _code.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return;
      setState(() {
        if (_resendIn > 0) _resendIn--;
      });
      if (_resendIn == 0) timer.cancel();
    });
  }

  Future<void> _submit() async {
    final code = _code.text.trim();
    if (code.length != 6 || _busy) return;
    final app = AppScope.of(context);
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final token = await app.api.verifyEmailCode(widget.email, code);
      await app.auth.signInWithCustomToken(token);
      if (!mounted) return;
      // AuthGate sudah berganti ke layar chat; tutup layar kode di atasnya.
      Navigator.of(context).popUntil((route) => route.isFirst);
    } on ApiException catch (error) {
      _showError(error.message);
    } on AuthFailure catch (error) {
      _showError(error.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _showError(String message) {
    if (!mounted) return;
    setState(() => _error = message);
    _code.clear();
    _focus.requestFocus();
  }

  Future<void> _resend() async {
    final app = AppScope.of(context);
    setState(() => _error = null);
    try {
      final info = await app.api.startEmailCode(widget.email);
      if (!mounted) return;
      setState(() {
        _resendIn = info.resendIn;
        _expiresIn = info.expiresIn;
      });
      _startTimer();
      showNotice(context, 'Kode baru dikirim.');
    } on ApiException catch (error) {
      if (mounted) setState(() => _error = error.message);
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final minutes = (_expiresIn / 60).ceil();
    final complete = _code.text.trim().length == 6;

    OutlineInputBorder border(Color color, [double width = 1]) =>
        OutlineInputBorder(
          borderRadius: BorderRadius.circular(QelvoRadius.md),
          borderSide: BorderSide(color: color, width: width),
        );

    return Scaffold(
      backgroundColor: t.bg,
      body: SafeArea(
        child: Column(
          children: [
            const ScreenBar(title: 'Verifikasi email'),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 440),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Masukkan kode',
                          style: t.display(28, weight: FontWeight.w800),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          'Kami mengirim kode 6 digit ke ${widget.email}. Kode berlaku $minutes menit.',
                          style: t.body(16, color: t.muted, height: 1.5),
                        ),
                        const SizedBox(height: 28),
                        AutofillGroup(
                          child: TextField(
                            controller: _code,
                            focusNode: _focus,
                            autofocus: true,
                            enabled: !_busy,
                            textAlign: TextAlign.center,
                            keyboardType: TextInputType.number,
                            autofillHints: const [AutofillHints.oneTimeCode],
                            inputFormatters: [
                              FilteringTextInputFormatter.digitsOnly,
                              LengthLimitingTextInputFormatter(6),
                            ],
                            onChanged: (value) {
                              setState(() {});
                              if (value.length == 6) _submit();
                            },
                            style: t.mono(30, weight: FontWeight.w600, spacing: 12),
                            cursorColor: t.accentText,
                            decoration: InputDecoration(
                              hintText: '000000',
                              hintStyle: t.mono(
                                30,
                                weight: FontWeight.w600,
                                color: t.outline,
                                spacing: 12,
                              ),
                              contentPadding: const EdgeInsets.symmetric(
                                vertical: 18,
                              ),
                              border: border(t.outline),
                              enabledBorder: border(t.outline),
                              disabledBorder: border(t.border),
                              focusedBorder: border(t.accentText, 2),
                            ),
                          ),
                        ),
                        const SizedBox(height: 18),
                        PrimaryButton(
                          label: 'Masuk',
                          busy: _busy,
                          onPressed: complete ? _submit : null,
                        ),
                        if (_error != null) ...[
                          const SizedBox(height: 16),
                          InlineNotice(message: _error!),
                        ],
                        const SizedBox(height: 22),
                        Center(
                          child: _resendIn > 0
                              ? Text(
                                  'Kirim ulang kode dalam $_resendIn detik',
                                  style: t.body(15, color: t.muted),
                                )
                              : Tappable(
                                  onTap: _busy ? null : _resend,
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 14,
                                      vertical: 10,
                                    ),
                                    child: Text(
                                      'Kirim ulang kode',
                                      style: t.body(
                                        15.5,
                                        weight: FontWeight.w700,
                                        color: t.accentText,
                                      ),
                                    ),
                                  ),
                                ),
                        ),
                        Center(
                          child: Tappable(
                            onTap: _busy ? null : () => Navigator.of(context).maybePop(),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 14,
                                vertical: 10,
                              ),
                              child: Text(
                                'Ganti email',
                                style: t.body(15, color: t.muted),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
