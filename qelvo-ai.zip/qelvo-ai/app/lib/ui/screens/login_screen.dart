import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/data/api_client.dart';
import 'package:qelvo_ai/data/auth_service.dart';
import 'package:qelvo_ai/state/app_state.dart';
import 'package:qelvo_ai/ui/screens/email_code_screen.dart';
import 'package:qelvo_ai/ui/screens/legal_screen.dart';
import 'package:qelvo_ai/ui/widgets/buttons.dart';
import 'package:qelvo_ai/ui/widgets/notice.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_logo.dart';

final RegExp _emailPattern = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _email = TextEditingController();
  late final TapGestureRecognizer _termsTap = TapGestureRecognizer()
    ..onTap = () => _open(LegalKind.terms);
  late final TapGestureRecognizer _privacyTap = TapGestureRecognizer()
    ..onTap = () => _open(LegalKind.privacy);

  bool _googleBusy = false;
  bool _emailBusy = false;
  String? _error;

  bool get _busy => _googleBusy || _emailBusy;

  @override
  void dispose() {
    _email.dispose();
    _termsTap.dispose();
    _privacyTap.dispose();
    super.dispose();
  }

  void _open(LegalKind kind) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => LegalScreen(kind: kind)),
    );
  }

  Future<void> _signInWithGoogle() async {
    final app = AppScope.of(context);
    setState(() {
      _googleBusy = true;
      _error = null;
    });
    try {
      await app.auth.signInWithGoogle();
    } on AuthFailure catch (error) {
      if (mounted) setState(() => _error = error.message);
    } finally {
      if (mounted) setState(() => _googleBusy = false);
    }
  }

  Future<void> _sendCode() async {
    final email = _email.text.trim().toLowerCase();
    if (!_emailPattern.hasMatch(email)) {
      setState(() => _error = 'Alamat email belum valid. Contoh: nama@email.com');
      return;
    }
    final app = AppScope.of(context);
    setState(() {
      _emailBusy = true;
      _error = null;
    });
    try {
      final info = await app.api.startEmailCode(email);
      if (!mounted) return;
      await Navigator.of(context).push(
        MaterialPageRoute<void>(
          builder: (_) => EmailCodeScreen(email: email, info: info),
        ),
      );
    } on ApiException catch (error) {
      if (mounted) setState(() => _error = error.message);
    } finally {
      if (mounted) setState(() => _emailBusy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final link = TextStyle(
      decoration: TextDecoration.underline,
      decorationColor: t.muted,
      color: t.text,
    );

    return Scaffold(
      backgroundColor: t.bg,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(24, 24, 24, 24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const QelvoLogo(size: 48),
                  const SizedBox(height: 24),
                  Text(
                    'Masuk ke QELVO',
                    style: t.display(30, weight: FontWeight.w800, height: 1.15),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Riwayat chatmu tersimpan di akun dan bisa dibuka lagi di perangkat lain.',
                    style: t.body(16, color: t.muted, height: 1.5),
                  ),
                  const SizedBox(height: 32),
                  OutlineActionButton(
                    label: 'Lanjutkan dengan Google',
                    icon: Icons.account_circle_outlined,
                    busy: _googleBusy,
                    onPressed: _busy ? null : _signInWithGoogle,
                  ),
                  const SizedBox(height: 22),
                  Row(
                    children: [
                      Expanded(child: Container(height: 1, color: t.border)),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 14),
                        child: Text('atau', style: t.body(14.5, color: t.muted)),
                      ),
                      Expanded(child: Container(height: 1, color: t.border)),
                    ],
                  ),
                  const SizedBox(height: 22),
                  Text(
                    'Email',
                    style: t.body(15, weight: FontWeight.w600, color: t.muted),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _email,
                    enabled: !_busy,
                    keyboardType: TextInputType.emailAddress,
                    textInputAction: TextInputAction.done,
                    autocorrect: false,
                    autofillHints: const [AutofillHints.email],
                    onSubmitted: (_) => _sendCode(),
                    style: t.body(17),
                    cursorColor: t.accentText,
                    decoration: InputDecoration(
                      hintText: 'nama@email.com',
                      hintStyle: t.body(17, color: t.muted),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 18,
                        vertical: 16,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(QelvoRadius.md),
                        borderSide: BorderSide(color: t.outline),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(QelvoRadius.md),
                        borderSide: BorderSide(color: t.outline),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(QelvoRadius.md),
                        borderSide: BorderSide(color: t.accentText, width: 2),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  PrimaryButton(
                    label: 'Kirim kode ke email',
                    busy: _emailBusy,
                    onPressed: _busy ? null : _sendCode,
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 16),
                    InlineNotice(message: _error!),
                  ],
                  const SizedBox(height: 28),
                  Text.rich(
                    TextSpan(
                      style: t.body(13.5, color: t.muted, height: 1.5),
                      children: [
                        const TextSpan(text: 'Dengan masuk, kamu menyetujui '),
                        TextSpan(
                          text: 'Ketentuan',
                          style: link,
                          recognizer: _termsTap,
                        ),
                        const TextSpan(text: ' dan '),
                        TextSpan(
                          text: 'Kebijakan Privasi',
                          style: link,
                          recognizer: _privacyTap,
                        ),
                        const TextSpan(text: '.'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
