import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/config.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/data/api_client.dart';
import 'package:qelvo_ai/data/auth_service.dart';
import 'package:qelvo_ai/state/app_state.dart';
import 'package:qelvo_ai/ui/screens/email_code_screen.dart';
import 'package:qelvo_ai/ui/screens/legal_screen.dart';
import 'package:qelvo_ai/ui/widgets/buttons.dart';
import 'package:qelvo_ai/ui/widgets/notice.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_logo.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_spinner.dart';
import 'package:qelvo_ai/ui/widgets/segments.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

final RegExp _emailPattern = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _email = TextEditingController();
  late final TapGestureRecognizer _termsTap = TapGestureRecognizer()
    ..onTap = () => _open(LegalKind.terms);
  late final TapGestureRecognizer _privacyTap = TapGestureRecognizer()
    ..onTap = () => _open(LegalKind.privacy);

  /// Masuk dan Daftar memakai alur yang sama: akun dibuat otomatis kalau belum
  /// ada. Pilihan ini hanya mengubah judul.
  bool _signUp = false;
  bool _googleBusy = false;
  bool _guestBusy = false;
  bool _emailBusy = false;
  String? _error;

  bool get _busy => _googleBusy || _guestBusy || _emailBusy;

  @override
  void dispose() {
    _email.dispose();
    _termsTap.dispose();
    _privacyTap.dispose();
    super.dispose();
  }

  void _open(LegalKind kind) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => LegalScreen(kind: kind)),
    );
  }

  Future<void> _signInWithGoogle() async {
    final app = AppScope.of(context);
    setState(() {
      _googleBusy = true;
      _error = null;
    });
    try {
      await app.auth.signInWithGoogle();
    } on AuthFailure catch (error) {
      if (mounted) setState(() => _error = error.message);
    } finally {
      if (mounted) setState(() => _googleBusy = false);
    }
  }

  Future<void> _signInAsGuest() async {
    final app = AppScope.of(context);
    setState(() {
      _guestBusy = true;
      _error = null;
    });
    try {
      await app.auth.signInAsGuest();
    } on AuthFailure catch (error) {
      if (mounted) setState(() => _error = error.message);
    } finally {
      if (mounted) setState(() => _guestBusy = false);
    }
  }

  Future<void> _sendCode() async {
    final email = _email.text.trim().toLowerCase();
    if (!_emailPattern.hasMatch(email)) {
      setState(() => _error = 'Alamat email belum valid. Contoh: nama@email.com');
      return;
    }
    final app = AppScope.of(context);
    setState(() {
      _emailBusy = true;
      _error = null;
    });
    try {
      final info = await app.api.startEmailCode(email);
      if (!mounted) return;
      await Navigator.of(context).push(
        MaterialPageRoute<void>(
          builder: (_) => EmailCodeScreen(email: email, info: info),
        ),
      );
    } on ApiException catch (error) {
      if (mounted) setState(() => _error = error.message);
    } finally {
      if (mounted) setState(() => _emailBusy = false);
    }
  }

  List<Widget> _emailForm() {
    final t = context.q;
    OutlineInputBorder border(Color color, [double width = 1]) =>
        OutlineInputBorder(
          borderRadius: BorderRadius.circular(QelvoRadius.md),
          borderSide: BorderSide(color: color, width: width),
        );
    return [
      const _OrDivider(),
      Text(
        'Email',
        style: t.body(15, weight: FontWeight.w600, color: t.muted),
      ),
      const SizedBox(height: 8),
      TextField(
        controller: _email,
        enabled: !_busy,
        keyboardType: TextInputType.emailAddress,
        textInputAction: TextInputAction.done,
        autocorrect: false,
        autofillHints: const [AutofillHints.email],
        onSubmitted: (_) => _sendCode(),
        style: t.body(17),
        cursorColor: t.text,
        decoration: InputDecoration(
          hintText: 'nama@email.com',
          hintStyle: t.body(17, color: t.muted),
          filled: true,
          fillColor: t.surface,
          prefixIcon: Icon(Icons.mail_outline_rounded, size: 22, color: t.muted),
          contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 17),
          border: border(t.outline),
          enabledBorder: border(t.outline),
          disabledBorder: border(t.border),
          focusedBorder: border(t.text, 2),
        ),
      ),
      const SizedBox(height: 8),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: Text(
          'Kode verifikasi 6 digit langsung dikirim ke email ini.',
          style: t.body(13.5, color: t.muted, height: 1.4),
        ),
      ),
      const SizedBox(height: 16),
      PrimaryButton(
        label: 'Lanjutkan',
        busy: _emailBusy,
        onPressed: _busy ? null : _sendCode,
      ),
    ];
  }

  Widget _guestOption() {
    final t = context.q;
    return Column(
      children: [
        Tappable(
          onTap: _busy ? null : _signInAsGuest,
          minSize: 48,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: _guestBusy
                ? const QelvoSpinner(size: 20)
                : Text(
                    'Lanjutkan sebagai tamu',
                    style: t.body(16, weight: FontWeight.w600),
                  ),
          ),
        ),
        Text(
          'Tanpa akun, riwayat hanya bisa dibuka di perangkat ini dan hilang saat kamu keluar.',
          textAlign: TextAlign.center,
          style: t.body(13.5, color: t.muted, height: 1.5),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final link = TextStyle(
      decoration: TextDecoration.underline,
      decorationColor: t.muted,
      color: t.text,
    );

    return Scaffold(
      backgroundColor: t.bg,
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                padding: const EdgeInsets.fromLTRB(24, 28, 24, 16),
                child: Align(
                  alignment: Alignment.topCenter,
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 440),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const QelvoLogo(size: 56),
                        const SizedBox(height: 22),
                        Text(
                          _signUp ? 'Buat akun QELVO' : 'Masuk ke QELVO',
                          style: t.display(30, weight: FontWeight.w800, height: 1.15),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Akun dibuat otomatis jika kamu belum punya.',
                          style: t.body(16, color: t.muted, height: 1.5),
                        ),
                        const SizedBox(height: 22),
                        QelvoSegments<bool>(
                          options: const [(false, 'Masuk'), (true, 'Daftar')],
                          value: _signUp,
                          onChanged: (value) => setState(() => _signUp = value),
                        ),
                        const SizedBox(height: 18),
                        GoogleButton(
                          label: 'Lanjutkan dengan Google',
                          busy: _googleBusy,
                          onPressed: _busy ? null : _signInWithGoogle,
                        ),
                        if (AppConfig.emailLogin) ..._emailForm(),
                        const SizedBox(height: 10),
                        Center(child: _guestOption()),
                        if (_error != null) ...[
                          const SizedBox(height: 16),
                          InlineNotice(message: _error!),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(32, 4, 32, 18),
              child: Text.rich(
                TextSpan(
                  style: t.body(13.5, color: t.muted, height: 1.5),
                  children: [
                    const TextSpan(text: 'Dengan melanjutkan, kamu menyetujui '),
                    TextSpan(
                      text: 'Ketentuan Layanan',
                      style: link,
                      recognizer: _termsTap,
                    ),
                    const TextSpan(text: ' dan '),
                    TextSpan(
                      text: 'Kebijakan Privasi',
                      style: link,
                      recognizer: _privacyTap,
                    ),
                    const TextSpan(text: '.'),
                  ],
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OrDivider extends StatelessWidget {
  const _OrDivider();

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 20),
      child: Row(
        children: [
          Expanded(child: Container(height: 1, color: t.border)),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Text('atau', style: t.body(14.5, color: t.muted)),
          ),
          Expanded(child: Container(height: 1, color: t.border)),
        ],
      ),
    );
  }
}
