import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/state/app_state.dart';
import 'package:qelvo_ai/state/session.dart';
import 'package:qelvo_ai/ui/screens/chat_screen.dart';
import 'package:qelvo_ai/ui/screens/login_screen.dart';
import 'package:qelvo_ai/ui/screens/splash_screen.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_logo.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_spinner.dart';

/// Layar AI hanya bisa dicapai setelah login. Server juga memeriksa token,
/// jadi gerbang ini bukan satu-satunya penjaga.
class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  StreamSubscription<User?>? _subscription;
  Session? _session;
  bool _resolved = false;

  @override
  void initState() {
    super.initState();
    _subscription = AppScope.of(context).auth.authState.listen(_onUser);
  }

  @override
  void dispose() {
    _subscription?.cancel();
    _session?.dispose();
    super.dispose();
  }

  void _onUser(User? user) {
    if (user == null) {
      _session?.dispose();
      _session = null;
    } else if (_session?.uid != user.uid) {
      _session?.dispose();
      _session = Session.start(user, AppScope.of(context).api);
    }
    if (mounted) setState(() => _resolved = true);
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    return ListenableBuilder(
      listenable: app.settings,
      builder: (context, _) {
        final session = _session;
        final Widget child;
        if (!_resolved) {
          child = const _Booting(key: ValueKey('boot'));
        } else if (session != null) {
          child = SessionScope(
            key: ValueKey(session.uid),
            session: session,
            child: const ChatScreen(),
          );
        } else if (!app.settings.onboarded) {
          child = SplashScreen(
            key: const ValueKey('splash'),
            onStart: () => app.settings.setOnboarded(true),
          );
        } else {
          child = const LoginScreen(key: ValueKey('login'));
        }
        return AnimatedSwitcher(
          duration: const Duration(milliseconds: 250),
          child: child,
        );
      },
    );
  }
}

class _Booting extends StatelessWidget {
  const _Booting({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.q.bg,
      body: const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            QelvoLogo(size: 56),
            SizedBox(height: 28),
            QelvoSpinner(size: 24),
          ],
        ),
      ),
    );
  }
}
