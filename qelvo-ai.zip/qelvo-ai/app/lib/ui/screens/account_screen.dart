import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/state/app_state.dart';
import 'package:qelvo_ai/state/session.dart';
import 'package:qelvo_ai/ui/flows/session_flows.dart';
import 'package:qelvo_ai/ui/widgets/buttons.dart';
import 'package:qelvo_ai/ui/widgets/dialogs.dart';
import 'package:qelvo_ai/ui/widgets/google_mark.dart';
import 'package:qelvo_ai/ui/widgets/profile_avatar.dart';
import 'package:qelvo_ai/ui/widgets/screen_bar.dart';
import 'package:qelvo_ai/ui/widgets/setting_row.dart';

/// Profil akun: nama yang bisa diubah, email, dan cara masuk. Hanya untuk
/// akun asli; tamu tidak punya layar ini.
class AccountScreen extends StatefulWidget {
  const AccountScreen({super.key, required this.onHistoryCleared});

  /// Diteruskan ke alur keluar, agar chat yang terbuka ditutup.
  final VoidCallback onHistoryCleared;

  @override
  State<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  Future<void> _editName(Session session) async {
    final name = await showDialog<String>(
      context: context,
      builder: (_) => _NameDialog(initial: session.displayName),
    );
    if (name == null || !mounted) return;
    try {
      final user = session.liveUser;
      await user.updateDisplayName(name);
      await user.reload();
      if (mounted) setState(() {});
    } catch (_) {
      if (mounted) {
        showNotice(context, 'Nama belum tersimpan. Periksa koneksi lalu coba lagi.');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final session = SessionScope.of(context);
    final t = context.q;
    final name = session.displayName;
    final email = session.email;
    final verified = session.liveUser.emailVerified && email.isNotEmpty;

    return Scaffold(
      backgroundColor: t.bg,
      body: SafeArea(
        child: Column(
          children: [
            const ScreenBar(title: 'Akun'),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
                children: [
                  Center(child: ProfileAvatar(session: session, size: 88)),
                  const SizedBox(height: 16),
                  Text(
                    name.isNotEmpty ? name : email,
                    textAlign: TextAlign.center,
                    style: t.display(22, weight: FontWeight.w800),
                  ),
                  if (name.isNotEmpty && email.isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Text(
                      email,
                      textAlign: TextAlign.center,
                      style: t.body(15.5, color: t.muted),
                    ),
                  ],
                  if (verified) ...[
                    const SizedBox(height: 12),
                    const Center(child: _VerifiedChip()),
                  ],
                  SettingSection(
                    title: 'Profil',
                    children: [
                      SettingRow(
                        label: 'Nama',
                        value: name.isNotEmpty ? name : 'Belum diisi',
                        chevron: true,
                        onTap: () => _editName(session),
                      ),
                      SettingRow(
                        label: 'Email',
                        value: email.isNotEmpty ? email : '-',
                      ),
                    ],
                  ),
                  SettingSection(
                    title: 'Keamanan',
                    children: [
                      if (session.method == SignInMethod.google)
                        SettingRow(
                          label: 'Metode masuk',
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const GoogleMark(size: 18),
                              const SizedBox(width: 8),
                              Text('Google', style: t.body(16, color: t.muted)),
                            ],
                          ),
                        )
                      else
                        const SettingRow(
                          label: 'Metode masuk',
                          value: 'Kode lewat email',
                        ),
                    ],
                  ),
                  const SizedBox(height: 32),
                  OutlineActionButton(
                    label: 'Keluar',
                    icon: Icons.logout_rounded,
                    onPressed: () => leaveSession(
                      context,
                      app: app,
                      session: session,
                      onHistoryCleared: widget.onHistoryCleared,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _VerifiedChip extends StatelessWidget {
  const _VerifiedChip();

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color: t.accentSoft,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: t.accentLine),
      ),
      child: Text(
        'Terverifikasi',
        style: t.body(13.5, weight: FontWeight.w600, color: t.accentText),
      ),
    );
  }
}

class _NameDialog extends StatefulWidget {
  const _NameDialog({required this.initial});

  final String initial;

  @override
  State<_NameDialog> createState() => _NameDialogState();
}

class _NameDialogState extends State<_NameDialog> {
  late final TextEditingController _controller =
      TextEditingController(text: widget.initial);
  String? _error;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _save() {
    final name = _controller.text.trim();
    if (name.isEmpty) {
      setState(() => _error = 'Nama tidak boleh kosong.');
      return;
    }
    Navigator.of(context).pop(name);
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    OutlineInputBorder border(Color color, [double width = 1]) =>
        OutlineInputBorder(
          borderRadius: BorderRadius.circular(QelvoRadius.md),
          borderSide: BorderSide(color: color, width: width),
        );
    return AlertDialog(
      backgroundColor: t.surface,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(QelvoRadius.lg),
        side: BorderSide(color: t.border),
      ),
      title: Text('Ubah nama', style: t.display(19)),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Nama ini dipakai untuk sapaan di beranda.',
              style: t.body(15, color: t.muted, height: 1.45),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _controller,
              autofocus: true,
              maxLength: 60,
              textCapitalization: TextCapitalization.words,
              textInputAction: TextInputAction.done,
              onSubmitted: (_) => _save(),
              style: t.body(16),
              cursorColor: t.accentText,
              decoration: InputDecoration(
                counterText: '',
                hintText: 'Nama kamu',
                hintStyle: t.body(16, color: t.muted),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 14,
                ),
                border: border(t.outline),
                enabledBorder: border(t.outline),
                focusedBorder: border(t.accentText, 2),
              ),
            ),
            if (_error != null) ...[
              const SizedBox(height: 10),
              Text(_error!, style: t.body(14, color: t.warn)),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: Text(
            'Batal',
            style: t.body(15.5, weight: FontWeight.w600, color: t.muted),
          ),
        ),
        TextButton(
          onPressed: _save,
          child: Text(
            'Simpan',
            style: t.body(15.5, weight: FontWeight.w700, color: t.accentText),
          ),
        ),
      ],
    );
  }
}
