import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';

/// Ditampilkan sebagai ganti layar kosong atau crash ketika kunci Firebase
/// belum diberikan lewat --dart-define.
class SetupNeededApp extends StatelessWidget {
  const SetupNeededApp({super.key, this.detail});

  final String? detail;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'QELVO',
      theme: QelvoTheme.themeData(QelvoTheme.dark, Brightness.dark),
      home: Builder(
        builder: (context) {
          final t = context.q;
          return Scaffold(
            backgroundColor: t.bg,
            body: SafeArea(
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(28),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Firebase belum disiapkan', style: t.display(26)),
                      const SizedBox(height: 14),
                      Text(
                        'Aplikasi ini dibangun tanpa kunci Firebase. Isi env.json dari env.example.json, lalu jalankan:',
                        style: t.body(16, color: t.muted, height: 1.5),
                      ),
                      const SizedBox(height: 14),
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: t.codeBg,
                          borderRadius: BorderRadius.circular(QelvoRadius.md),
                          border: Border.all(color: t.border),
                        ),
                        child: Text(
                          'flutter run --dart-define-from-file=env.json',
                          style: t.mono(14),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Text(
                        'Langkah lengkapnya ada di docs/SETUP.md.',
                        style: t.body(16, color: t.muted, height: 1.5),
                      ),
                      if (detail != null) ...[
                        const SizedBox(height: 18),
                        Text(
                          detail!,
                          style: t.body(13.5, color: t.warn, height: 1.45),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
