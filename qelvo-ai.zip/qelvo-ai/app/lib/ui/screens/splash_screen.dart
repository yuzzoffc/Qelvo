import 'dart:math' as math;

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/ui/screens/legal_screen.dart';
import 'package:qelvo_ai/ui/widgets/buttons.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_logo.dart';

/// Tampil sekali, saat pertama kali membuka aplikasi.
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key, required this.onStart});

  final VoidCallback onStart;

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1400),
  );
  late final Animation<double> _eased = CurvedAnimation(
    parent: _controller,
    curve: Curves.easeOutCubic,
  );
  late final TapGestureRecognizer _termsTap = TapGestureRecognizer()
    ..onTap = () => _open(LegalKind.terms);
  late final TapGestureRecognizer _privacyTap = TapGestureRecognizer()
    ..onTap = () => _open(LegalKind.privacy);

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Titik orbit bergerak satu kali lalu diam. Dilewati kalau pengguna
    // meminta animasi dikurangi.
    if (MediaQuery.disableAnimationsOf(context)) {
      _controller.value = 1;
    } else if (_controller.status == AnimationStatus.dismissed) {
      _controller.forward();
    }
  }

  @override
  void dispose() {
    _termsTap.dispose();
    _privacyTap.dispose();
    _controller.dispose();
    super.dispose();
  }

  void _open(LegalKind kind) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => LegalScreen(kind: kind)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final media = MediaQuery.of(context);
    final link = TextStyle(
      decoration: TextDecoration.underline,
      decorationColor: t.muted,
      color: t.text,
    );

    return Scaffold(
      backgroundColor: t.bg,
      body: LayoutBuilder(
        builder: (context, box) {
          final width = box.maxWidth;
          final center = Offset(width / 2, box.maxHeight * 0.39);
          return Stack(
            children: [
              Positioned.fill(
                child: ExcludeSemantics(
                  child: AnimatedBuilder(
                    animation: _eased,
                    builder: (context, _) => CustomPaint(
                      painter: _OrbitPainter(
                        center: center,
                        width: width,
                        line: t.border,
                        dim: Color.lerp(t.border, t.outline, 0.5)!,
                        dot: t.accent,
                        progress: _eased.value,
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 0,
                right: 0,
                top: center.dy - 41,
                child: FadeTransition(
                  opacity: _eased,
                  child: Column(
                    children: [
                      const QelvoLogo(size: 82),
                      const SizedBox(height: 40),
                      // Spasi huruf menambah celah setelah huruf terakhir,
                      // jadi digeser agar wordmark tetap di tengah.
                      Padding(
                        padding: const EdgeInsets.only(left: 13),
                        child: Text(
                          'QELVO',
                          style: t.display(
                            32,
                            weight: FontWeight.w800,
                            spacing: 13,
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text('Think Beyond.', style: t.body(16, color: t.muted)),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 22,
                right: 22,
                bottom: math.max(media.padding.bottom, 16.0) + 8,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'Asisten AI untuk bertanya, belajar, menulis, dan coding.',
                      textAlign: TextAlign.center,
                      style: t.body(15.5, color: t.muted, height: 1.5),
                    ),
                    const SizedBox(height: 22),
                    PrimaryButton(label: 'Mulai', onPressed: widget.onStart),
                    const SizedBox(height: 18),
                    Text.rich(
                      TextSpan(
                        style: t.body(13.5, color: t.muted, height: 1.5),
                        children: [
                          const TextSpan(text: 'Dengan melanjutkan, kamu menyetujui '),
                          TextSpan(
                            text: 'Ketentuan',
                            style: link,
                            recognizer: _termsTap,
                          ),
                          const TextSpan(text: ' dan '),
                          TextSpan(
                            text: 'Kebijakan Privasi',
                            style: link,
                            recognizer: _privacyTap,
                          ),
                          const TextSpan(text: '.'),
                        ],
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

/// Tiga cincin konsentris sebagai motif merek ("orbit" di sekitar Q).
/// Titik terang berhenti di cincin tengah, dua titik redup diam.
class _OrbitPainter extends CustomPainter {
  _OrbitPainter({
    required this.center,
    required this.width,
    required this.line,
    required this.dim,
    required this.dot,
    required this.progress,
  });

  final Offset center;
  final double width;
  final Color line;
  final Color dim;
  final Color dot;
  final double progress;

  Offset _on(double radius, double angle) =>
      center + Offset(math.cos(angle), math.sin(angle)) * radius;

  @override
  void paint(Canvas canvas, Size size) {
    final radii = [width * 0.236, width * 0.40, width * 0.594];
    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = line;
    for (final radius in radii) {
      canvas.drawCircle(center, radius, ring);
    }

    final fill = Paint();
    canvas.drawCircle(_on(radii[0], 3 * math.pi / 4), 3.5, fill..color = dim);
    canvas.drawCircle(_on(radii[2], math.pi / 4), 3.5, fill..color = dim);

    final angle = -math.pi / 4 - (1 - progress) * math.pi * 0.9;
    canvas.drawCircle(_on(radii[1], angle), 5, fill..color = dot);
  }

  @override
  bool shouldRepaint(_OrbitPainter oldDelegate) =>
      oldDelegate.progress != progress ||
      oldDelegate.center != center ||
      oldDelegate.width != width ||
      oldDelegate.line != line ||
      oldDelegate.dot != dot;
}
