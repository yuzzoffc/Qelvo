import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_logo.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_spinner.dart';

/// Layar pembuka: logotype dengan slogan di tengah dan penanda memuat di
/// bawah. Tampil selama aplikasi memeriksa sesi masuk, tanpa tombol.
class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final media = MediaQuery.of(context);
    final width = math.min(media.size.width * 0.72, 320.0);
    return Scaffold(
      backgroundColor: t.bg,
      body: Stack(
        children: [
          Center(
            // Muncul perlahan satu kali. Dilewati kalau pengguna meminta
            // animasi dikurangi.
            child: TweenAnimationBuilder<double>(
              tween: Tween<double>(begin: 0, end: 1),
              duration: media.disableAnimations
                  ? Duration.zero
                  : const Duration(milliseconds: 450),
              curve: Curves.easeOut,
              builder: (context, value, child) =>
                  Opacity(opacity: value, child: child),
              child: QelvoWordmark(width: width, tagline: true),
            ),
          ),
          const Align(
            alignment: Alignment(0, 0.8),
            child: QelvoSpinner(size: 22),
          ),
        ],
      ),
    );
  }
}
