import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/ui/markdown/code_block.dart';
import 'package:qelvo_ai/ui/markdown/markdown_parser.dart';
import 'package:url_launcher/url_launcher.dart';

// Grup: 1 kode, 2 tebal, 3 miring, 4 label tautan, 5 alamat tautan.
final RegExp _inlinePattern = RegExp(
  r'`([^`\n]+)`|\*\*([^\n]+?)\*\*|\*([^*\s][^*\n]*?)\*|\[([^\]\n]+)\]\(([^)\s]+)\)',
);

/// Menampilkan teks Markdown dari model. Saat [streaming] aktif, titik kecil
/// di ujung teks menandai bahwa jawaban masih berjalan.
class MarkdownView extends StatefulWidget {
  const MarkdownView({super.key, required this.text, this.streaming = false});

  final String text;
  final bool streaming;

  @override
  State<MarkdownView> createState() => _MarkdownViewState();
}

class _MarkdownViewState extends State<MarkdownView> {
  final List<TapGestureRecognizer> _recognizers = [];

  void _disposeRecognizers() {
    for (final recognizer in _recognizers) {
      recognizer.dispose();
    }
    _recognizers.clear();
  }

  @override
  void dispose() {
    _disposeRecognizers();
    super.dispose();
  }

  Future<void> _openLink(String url) async {
    final uri = Uri.tryParse(url);
    if (uri == null || (uri.scheme != 'http' && uri.scheme != 'https')) return;
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    // Recognizer dibuat ulang tiap build, jadi yang lama harus dibuang dulu.
    _disposeRecognizers();

    final blocks = parseMarkdown(widget.text);
    final children = <Widget>[];
    for (var i = 0; i < blocks.length; i++) {
      final isLast = i == blocks.length - 1;
      children.add(_block(t, blocks[i], caret: widget.streaming && isLast));
    }
    if (widget.streaming && (blocks.isEmpty || blocks.last is! MdParagraph)) {
      children.add(_caretLine(t));
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        for (var i = 0; i < children.length; i++)
          Padding(
            padding: EdgeInsets.only(top: i == 0 ? 0 : 12),
            child: children[i],
          ),
      ],
    );
  }

  Widget _block(QelvoTheme t, MdBlock block, {required bool caret}) {
    return switch (block) {
      MdParagraph p => _paragraph(t, p.text, caret: caret),
      MdHeading h => _heading(t, h),
      MdCode c => CodeBlock(language: c.language, code: c.code),
      MdList l => _list(t, l),
      MdQuote q => _quote(t, q),
      MdRule() => Container(height: 1, color: t.border),
      MdTable table => _table(t, table),
    };
  }

  Widget _paragraph(QelvoTheme t, String text, {required bool caret}) {
    final spans = _inline(text, t);
    if (caret) spans.add(_caretSpan(t));
    return Text.rich(TextSpan(style: t.body(16.5, height: 1.55), children: spans));
  }

  Widget _heading(QelvoTheme t, MdHeading heading) {
    final size = switch (heading.level) {
      1 => 22.0,
      2 => 20.0,
      3 => 18.0,
      _ => 17.0,
    };
    return Text.rich(
      TextSpan(
        style: t.display(size, height: 1.3),
        children: _inline(heading.text, t),
      ),
    );
  }

  Widget _list(QelvoTheme t, MdList list) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        for (final item in list.items)
          Padding(
            padding: EdgeInsets.only(left: item.level * 18.0, bottom: 6),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: item.marker.length > 2 ? 32 : 22,
                  child: Text(
                    item.marker,
                    style: t.body(16.5, color: t.muted, height: 1.55),
                  ),
                ),
                Expanded(
                  child: Text.rich(
                    TextSpan(
                      style: t.body(16.5, height: 1.55),
                      children: _inline(item.text, t),
                    ),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _quote(QelvoTheme t, MdQuote quote) {
    return Container(
      padding: const EdgeInsets.only(left: 14),
      decoration: BoxDecoration(
        border: Border(left: BorderSide(color: t.outline, width: 3)),
      ),
      child: Text.rich(
        TextSpan(
          style: t.body(16, color: t.muted, height: 1.55),
          children: _inline(quote.text, t),
        ),
      ),
    );
  }

  Widget _table(QelvoTheme t, MdTable table) {
    final columns = table.header.length;
    List<String> fit(List<String> row) => [
          for (var i = 0; i < columns; i++) i < row.length ? row[i] : '',
        ];

    Widget cell(String text, {required bool header}) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 240),
          child: Text.rich(
            TextSpan(
              style: t.body(
                15,
                weight: header ? FontWeight.w700 : FontWeight.w400,
                height: 1.4,
              ),
              children: _inline(text, t),
            ),
          ),
        ),
      );
    }

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Table(
        defaultColumnWidth: const IntrinsicColumnWidth(),
        border: TableBorder.all(color: t.border),
        children: [
          TableRow(
            decoration: BoxDecoration(color: t.bubble),
            children: [
              for (final text in fit(table.header)) cell(text, header: true),
            ],
          ),
          for (final row in table.rows)
            TableRow(
              children: [for (final text in fit(row)) cell(text, header: false)],
            ),
        ],
      ),
    );
  }

  List<InlineSpan> _inline(String text, QelvoTheme t) {
    final spans = <InlineSpan>[];
    var cursor = 0;
    for (final match in _inlinePattern.allMatches(text)) {
      if (match.start > cursor) {
        spans.add(TextSpan(text: text.substring(cursor, match.start)));
      }
      final code = match.group(1);
      final bold = match.group(2);
      final italic = match.group(3);
      final label = match.group(4);
      final url = match.group(5);
      if (code != null) {
        // Spasi tanpa putus memberi ruang di dalam latar kode.
        spans.add(
          TextSpan(
            text: '\u00A0$code\u00A0',
            style: t.mono(14.5).copyWith(backgroundColor: t.bubble),
          ),
        );
      } else if (bold != null) {
        spans.add(
          TextSpan(
            style: const TextStyle(fontWeight: FontWeight.w700),
            children: _inline(bold, t),
          ),
        );
      } else if (italic != null) {
        spans.add(
          TextSpan(
            style: const TextStyle(fontStyle: FontStyle.italic),
            children: _inline(italic, t),
          ),
        );
      } else if (label != null && url != null) {
        final recognizer = TapGestureRecognizer()..onTap = () => _openLink(url);
        _recognizers.add(recognizer);
        spans.add(
          TextSpan(
            text: label,
            recognizer: recognizer,
            style: TextStyle(
              color: t.text,
              decoration: TextDecoration.underline,
              decorationColor: t.text,
            ),
          ),
        );
      }
      cursor = match.end;
    }
    if (cursor < text.length) {
      spans.add(TextSpan(text: text.substring(cursor)));
    }
    return spans;
  }

  TextSpan _caretSpan(QelvoTheme t) =>
      TextSpan(text: ' ●', style: TextStyle(color: t.muted, fontSize: 12));

  Widget _caretLine(QelvoTheme t) =>
      Text.rich(TextSpan(text: '●', style: TextStyle(color: t.muted, fontSize: 12)));
}
