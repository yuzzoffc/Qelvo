/// Parser Markdown seperlunya untuk jawaban model: paragraf, judul, daftar,
/// blok kode, kutipan, tabel, dan garis. Format inline (tebal, miring, kode,
/// tautan) diurai di layer tampilan.
sealed class MdBlock {
  const MdBlock();
}

final class MdParagraph extends MdBlock {
  const MdParagraph(this.text);

  final String text;
}

final class MdHeading extends MdBlock {
  const MdHeading(this.level, this.text);

  final int level;
  final String text;
}

final class MdCode extends MdBlock {
  const MdCode(this.language, this.code);

  final String language;
  final String code;
}

final class MdListItem {
  const MdListItem({
    required this.level,
    required this.marker,
    required this.text,
  });

  final int level;
  final String marker;
  final String text;
}

final class MdList extends MdBlock {
  const MdList(this.items);

  final List<MdListItem> items;
}

final class MdQuote extends MdBlock {
  const MdQuote(this.text);

  final String text;
}

final class MdRule extends MdBlock {
  const MdRule();
}

final class MdTable extends MdBlock {
  const MdTable(this.header, this.rows);

  final List<String> header;
  final List<List<String>> rows;
}

final RegExp _heading = RegExp(r'^\s{0,3}(#{1,6})\s+(.*?)\s*#*\s*$');
final RegExp _rule = RegExp(r'^\s{0,3}([-*_])(\s*\1){2,}\s*$');
final RegExp _bullet = RegExp(r'^(\s*)([-*+])\s+(.*)$');
final RegExp _ordered = RegExp(r'^(\s*)(\d{1,3}[.)])\s+(.*)$');
final RegExp _tableSeparator =
    RegExp(r'^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$');

List<MdBlock> parseMarkdown(String source) {
  final lines = source.replaceAll('\r\n', '\n').split('\n');
  final blocks = <MdBlock>[];
  final paragraph = <String>[];

  void flushParagraph() {
    if (paragraph.isEmpty) return;
    blocks.add(MdParagraph(paragraph.join('\n')));
    paragraph.clear();
  }

  var i = 0;
  while (i < lines.length) {
    final line = lines[i];
    final trimmed = line.trim();

    if (trimmed.isEmpty) {
      flushParagraph();
      i++;
      continue;
    }

    if (trimmed.startsWith('```')) {
      flushParagraph();
      final indent = line.length - line.trimLeft().length;
      final language =
          trimmed.substring(3).trim().split(RegExp(r'\s+')).first.toLowerCase();
      final body = <String>[];
      i++;
      while (i < lines.length && !lines[i].trim().startsWith('```')) {
        body.add(_dedent(lines[i], indent));
        i++;
      }
      // Melewati pagar penutup. Kalau jawaban masih mengalir, pagar belum ada
      // dan sisa teks tetap dianggap kode.
      i++;
      blocks.add(MdCode(language, body.join('\n')));
      continue;
    }

    final heading = _heading.firstMatch(line);
    if (heading != null) {
      flushParagraph();
      blocks.add(MdHeading(heading.group(1)!.length, heading.group(2)!));
      i++;
      continue;
    }

    if (_rule.hasMatch(line)) {
      flushParagraph();
      blocks.add(const MdRule());
      i++;
      continue;
    }

    if (trimmed.startsWith('>')) {
      flushParagraph();
      final quote = <String>[];
      while (i < lines.length && lines[i].trim().startsWith('>')) {
        quote.add(lines[i].trim().replaceFirst(RegExp(r'^>\s?'), ''));
        i++;
      }
      blocks.add(MdQuote(quote.join('\n')));
      continue;
    }

    if (line.contains('|') &&
        i + 1 < lines.length &&
        lines[i + 1].contains('|') &&
        _tableSeparator.hasMatch(lines[i + 1])) {
      flushParagraph();
      final header = _cells(line);
      i += 2;
      final rows = <List<String>>[];
      while (i < lines.length &&
          lines[i].trim().isNotEmpty &&
          lines[i].contains('|')) {
        rows.add(_cells(lines[i]));
        i++;
      }
      blocks.add(MdTable(header, rows));
      continue;
    }

    if (_bullet.hasMatch(line) || _ordered.hasMatch(line)) {
      flushParagraph();
      i = _readList(lines, i, blocks);
      continue;
    }

    paragraph.add(line);
    i++;
  }
  flushParagraph();
  return blocks;
}

/// Membaca satu daftar mulai dari [start] dan mengembalikan indeks baris
/// berikutnya. Level bersarang ditentukan dari tingkat indentasi relatif.
int _readList(List<String> lines, int start, List<MdBlock> blocks) {
  final items = <MdListItem>[];
  final indents = <int>[];
  var i = start;

  int levelFor(int indent) {
    while (indents.isNotEmpty && indent < indents.last) {
      indents.removeLast();
    }
    if (indents.isEmpty || indent > indents.last) {
      indents.add(indent);
    }
    return indents.length - 1;
  }

  bool isItem(String line) =>
      (_bullet.hasMatch(line) || _ordered.hasMatch(line)) &&
      !_rule.hasMatch(line);

  while (i < lines.length) {
    final line = lines[i];
    final trimmed = line.trim();

    if (trimmed.isEmpty) {
      // Baris kosong di antara butir tidak memutus daftar.
      var next = i + 1;
      while (next < lines.length && lines[next].trim().isEmpty) {
        next++;
      }
      if (next < lines.length && isItem(lines[next])) {
        i = next;
        continue;
      }
      break;
    }

    if (isItem(line)) {
      final bullet = _bullet.firstMatch(line);
      final match = bullet ?? _ordered.firstMatch(line)!;
      items.add(MdListItem(
        level: levelFor(match.group(1)!.length),
        marker: bullet != null ? '•' : match.group(2)!,
        text: match.group(3)!,
      ));
      i++;
      continue;
    }

    final indented = line.startsWith(' ') || line.startsWith('\t');
    if (indented && !trimmed.startsWith('```') && items.isNotEmpty) {
      final last = items.removeLast();
      items.add(MdListItem(
        level: last.level,
        marker: last.marker,
        text: '${last.text}\n$trimmed',
      ));
      i++;
      continue;
    }
    break;
  }

  blocks.add(MdList(items));
  return i;
}

String _dedent(String line, int indent) {
  var n = 0;
  while (n < indent && n < line.length && line[n] == ' ') {
    n++;
  }
  return line.substring(n);
}

List<String> _cells(String row) {
  var text = row.trim();
  if (text.startsWith('|')) text = text.substring(1);
  if (text.endsWith('|')) text = text.substring(0, text.length - 1);
  return text.split('|').map((cell) => cell.trim()).toList();
}
