import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/ui/widgets/tappable.dart';

class CodeBlock extends StatefulWidget {
  const CodeBlock({super.key, required this.language, required this.code});

  final String language;
  final String code;

  @override
  State<CodeBlock> createState() => _CodeBlockState();
}

class _CodeBlockState extends State<CodeBlock> {
  bool _copied = false;
  Timer? _timer;

  Future<void> _copy() async {
    await Clipboard.setData(ClipboardData(text: widget.code));
    if (!mounted) return;
    setState(() => _copied = true);
    _timer?.cancel();
    _timer = Timer(const Duration(milliseconds: 1600), () {
      if (mounted) setState(() => _copied = false);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final radius = BorderRadius.circular(QelvoRadius.lg - 2);
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: t.codeBg,
        borderRadius: radius,
        border: Border.all(color: t.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 16, right: 6),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    widget.language.isEmpty ? 'kode' : widget.language,
                    style: t.body(15, color: t.muted),
                  ),
                ),
                Tappable(
                  onTap: _copy,
                  borderRadius: BorderRadius.circular(QelvoRadius.sm),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          _copied
                              ? Icons.check_rounded
                              : Icons.content_copy_outlined,
                          size: 18,
                          color: _copied ? t.text : t.muted,
                        ),
                        const SizedBox(width: 7),
                        Text(
                          _copied ? 'Tersalin' : 'Salin',
                          style: t.body(
                            15,
                            color: _copied ? t.text : t.muted,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Container(height: 1, color: t.border),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.all(16),
            child: Text.rich(
              TextSpan(
                style: t.mono(14.5, height: 1.55),
                children: highlightCode(widget.code, widget.language, t),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

const Set<String> _hashCommentLanguages = {
  'python',
  'py',
  'bash',
  'sh',
  'shell',
  'zsh',
  'yaml',
  'yml',
  'ruby',
  'rb',
  'toml',
  'dockerfile',
  'env',
  'r',
  'perl',
  'powershell',
};

const Set<String> _keywords = {
  'abstract', 'as', 'async', 'await', 'break', 'case', 'catch', 'class',
  'const', 'continue', 'default', 'do', 'else', 'enum', 'export', 'extends',
  'false', 'final', 'finally', 'for', 'from', 'function', 'if', 'implements',
  'import', 'in', 'interface', 'is', 'late', 'let', 'new', 'null', 'override',
  'private', 'protected', 'public', 'required', 'return', 'static', 'super',
  'switch', 'this', 'throw', 'true', 'try', 'var', 'void', 'while', 'with',
  'yield', 'int', 'double', 'bool', 'String', 'dynamic', 'num', 'List', 'Map',
  'Set', 'Future', 'Stream', 'def', 'elif', 'except', 'lambda', 'pass',
  'raise', 'None', 'True', 'False', 'and', 'or', 'not', 'self', 'fn', 'mut',
  'pub', 'struct', 'impl', 'use', 'mod', 'loop', 'val', 'fun', 'func', 'defer',
  'typeof', 'instanceof', 'char', 'float', 'long', 'short', 'byte', 'echo',
  'then', 'fi', 'done', 'SELECT', 'FROM', 'WHERE', 'INSERT', 'INTO', 'VALUES',
  'UPDATE', 'DELETE', 'CREATE', 'TABLE', 'JOIN', 'ON', 'AND', 'OR', 'NOT',
  'NULL', 'ORDER', 'BY', 'GROUP', 'LIMIT',
};

// Grup: 1 komentar, 2 string, 3 angka, 4 kata.
final RegExp _slashTokens = RegExp(
  r'''(//[^\n]*|/\*[\s\S]*?(?:\*/|$))|("(?:\\.|[^"\\\n])*"?|'(?:\\.|[^'\\\n])*'?|`(?:\\.|[^`\\])*`?)|(\b\d+(?:\.\d+)?\b)|([A-Za-z_]\w*)''',
);
final RegExp _hashTokens = RegExp(
  r'''(#[^\n]*)|("(?:\\.|[^"\\\n])*"?|'(?:\\.|[^'\\\n])*'?|`(?:\\.|[^`\\])*`?)|(\b\d+(?:\.\d+)?\b)|([A-Za-z_]\w*)''',
);

/// Pewarnaan sintaks sederhana yang sama untuk semua bahasa: kata kunci,
/// string, angka, dan komentar. Cukup untuk dibaca, bukan pengganti IDE.
List<TextSpan> highlightCode(String code, String language, QelvoTheme t) {
  final pattern =
      _hashCommentLanguages.contains(language) ? _hashTokens : _slashTokens;
  final spans = <TextSpan>[];
  var cursor = 0;
  for (final match in pattern.allMatches(code)) {
    if (match.start > cursor) {
      spans.add(TextSpan(text: code.substring(cursor, match.start)));
    }
    final text = match.group(0)!;
    Color? color;
    if (match.group(1) != null) {
      color = t.muted;
    } else if (match.group(2) != null) {
      color = t.codeString;
    } else if (match.group(3) != null) {
      color = t.codeNumber;
    } else if (_keywords.contains(text)) {
      color = t.codeKeyword;
    }
    spans.add(
      TextSpan(
        text: text,
        style: color == null ? null : TextStyle(color: color),
      ),
    );
    cursor = match.end;
  }
  if (cursor < code.length) {
    spans.add(TextSpan(text: code.substring(cursor)));
  }
  return spans;
}
