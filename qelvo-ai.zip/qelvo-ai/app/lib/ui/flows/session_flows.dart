import 'package:flutter/material.dart';
import 'package:qelvo_ai/data/api_client.dart';
import 'package:qelvo_ai/state/app_state.dart';
import 'package:qelvo_ai/state/session.dart';
import 'package:qelvo_ai/ui/widgets/dialogs.dart';

/// Keluar dari akun. Untuk tamu, ini juga jalan menuju layar masuk: akun tamu
/// tidak bisa dimasuki lagi setelah keluar, jadi riwayat dan akunnya dihapus
/// lebih dulu supaya tidak tertinggal di Firestore dan Firebase. Dengan
/// [toSignIn] kalimat konfirmasinya menyebut masuk dengan akun, bukan keluar.
///
/// [onHistoryCleared] menutup chat yang sedang terbuka tanpa menyimpannya.
Future<void> leaveSession(
  BuildContext context, {
  required AppState app,
  required Session session,
  required VoidCallback onHistoryCleared,
  bool toSignIn = false,
}) async {
  if (session.isGuest) {
    final ok = await confirmDialog(
      context,
      title: toSignIn ? 'Masuk dengan akun?' : 'Keluar dari mode tamu?',
      message: toSignIn
          ? 'Riwayat chat tamu tidak ikut pindah ke akunmu. Riwayat itu akan dihapus dan tidak bisa dikembalikan.'
          : 'Riwayat chat tamu akan dihapus dan tidak bisa dikembalikan.',
      confirmLabel: toSignIn ? 'Lanjut' : 'Keluar',
      destructive: true,
    );
    if (!ok || !context.mounted) return;
    onHistoryCleared();
    try {
      await session.enqueue(session.repository.deleteEverything);
    } catch (error) {
      // Server menyatakan riwayat tidak aktif: tidak ada yang perlu dihapus.
      final nothingStored = error is ApiException &&
          (error.code == 'history_disabled' || error.code == 'history_not_ready');
      if (!nothingStored) {
        if (context.mounted) {
          showNotice(
            context,
            error is ApiException
                ? error.message
                : 'Riwayat tamu belum terhapus. Periksa koneksi lalu coba lagi.',
          );
        }
        return;
      }
    }
    if (!context.mounted) return;
  }
  // Tutup layar di atas dulu; AuthGate akan menampilkan layar masuk.
  Navigator.of(context).popUntil((route) => route.isFirst);
  app.catalog.reset();
  await app.auth.signOut(deleteGuestAccount: session.isGuest);
}
