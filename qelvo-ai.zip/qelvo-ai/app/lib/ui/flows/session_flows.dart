import 'package:flutter/material.dart';
import 'package:qelvo_ai/state/app_state.dart';

/// Keluar dari akun dan kembali ke layar masuk. Riwayat tetap tersimpan di
/// akunnya, jadi muncul lagi saat masuk dengan akun yang sama.
Future<void> leaveSession(
  BuildContext context, {
  required AppState app,
}) async {
  // Tutup layar di atas dulu; AuthGate akan menampilkan layar masuk.
  Navigator.of(context).popUntil((route) => route.isFirst);
  app.catalog.reset();
  await app.auth.signOut();
}
