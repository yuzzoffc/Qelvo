import 'package:qelvo_ai/data/models.dart';

/// Batas lampiran foto. Server punya batasnya sendiri (MAX_IMAGES_PER_REQUEST
/// dan kawan-kawannya) yang bernilai sama atau sedikit lebih longgar.
abstract final class AttachmentRules {
  /// Foto per pesan.
  static const int maxPerMessage = 4;

  /// Ukuran satu foto yang dikirim, dalam byte (batas server 1,5 MB).
  static const int maxPhotoBytes = 1400000;

  /// Ukuran gambar kecil untuk riwayat, dalam byte (batas server 45 KB).
  static const int maxThumbBytes = 40000;

  /// Total foto dalam satu permintaan (batas server 3 MB). Badan permintaan di
  /// Vercel dibatasi 4,5 MB dan base64 menambah sepertiga ukuran.
  static const int maxRequestBytes = 2800000;
}

/// Foto yang ikut dikirim bersama satu permintaan, dan pesan pemiliknya.
class RequestImages {
  const RequestImages(this.messageId, this.attachments);

  final String messageId;
  final List<ChatAttachment> attachments;
}

/// Memilih foto yang dikirim ke model. Foto dari pesan pengguna terbaru yang
/// membawa foto ikut terkirim di setiap permintaan, supaya pertanyaan lanjutan
/// ("coba lihat foto tadi lagi") tetap bisa dijawab. Foto dari pesan yang lebih
/// lama tidak dikirim ulang, dan pesan yang dimuat dari riwayat hanya punya
/// gambar kecil sehingga dilewati.
///
/// Mengembalikan null kalau tidak ada foto yang layak dikirim.
RequestImages? imagesForRequest(
  List<ChatMessage> context, {
  int maxCount = AttachmentRules.maxPerMessage,
  int maxBytes = AttachmentRules.maxRequestBytes,
}) {
  for (var i = context.length - 1; i >= 0; i--) {
    final message = context[i];
    if (message.role != ChatRole.user) continue;
    final chosen = <ChatAttachment>[];
    var total = 0;
    for (final attachment in message.attachments) {
      final full = attachment.full;
      if (full == null) continue;
      if (chosen.length >= maxCount || total + full.length > maxBytes) break;
      chosen.add(attachment);
      total += full.length;
    }
    if (chosen.isNotEmpty) return RequestImages(message.id, chosen);
    // Pesan berfoto terbaru yang tidak bisa dikirim (gambar penuhnya tidak ada,
    // atau terlalu besar) menghentikan pencarian: foto yang lebih lama tidak
    // boleh menggantikannya.
    if (message.attachments.isNotEmpty) return null;
  }
  return null;
}
