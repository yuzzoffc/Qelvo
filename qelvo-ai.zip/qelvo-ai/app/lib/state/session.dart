import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/widgets.dart';
import 'package:qelvo_ai/data/api_client.dart';
import 'package:qelvo_ai/data/chat_repository.dart';
import 'package:qelvo_ai/state/history_controller.dart';

enum SignInMethod { google, email, guest }

/// Dibuat saat login berhasil dan dibuang saat keluar akun. Semua data di
/// dalamnya terikat ke satu uid.
class Session {
  Session._(this.user, this.repository, this.history);

  factory Session.start(User user, ApiClient api) {
    final repository = ChatRepository(api);
    final history = HistoryController(repository);
    // Dimuat di latar belakang. Gagal memuat tidak boleh menahan layar chat.
    unawaited(history.refresh());
    return Session._(user, repository, history);
  }

  final User user;
  final ChatRepository repository;
  final HistoryController history;

  Future<void> _queue = Future<void>.value();

  /// Menjalankan [job] setelah semua pekerjaan sebelumnya selesai. Simpan,
  /// nilai, dan hapus riwayat lewat sini, supaya urutannya di server sama
  /// dengan urutan di layar (misalnya "hapus semua" tidak disusul pesan lama).
  /// Hasil atau kesalahan [job] diteruskan ke pemanggil.
  Future<T> enqueue<T>(Future<T> Function() job) {
    final completer = Completer<T>();
    _queue = _queue.then((_) async {
      try {
        completer.complete(await job());
      } catch (error, stack) {
        completer.completeError(error, stack);
      }
    });
    return completer.future;
  }

  String get uid => user.uid;

  String get email => user.email ?? '';

  bool get isGuest => user.isAnonymous;

  /// Pengguna terkini. Nama bisa diubah di layar Akun, dan objek [user] dari
  /// awal sesi tidak ikut diperbarui, jadi nama dibaca dari FirebaseAuth.
  User get liveUser => FirebaseAuth.instance.currentUser ?? user;

  String get displayName => (liveUser.displayName ?? '').trim();

  /// Kata pertama dari nama, untuk sapaan. Kosong untuk tamu.
  String get firstName {
    final name = displayName;
    if (name.isEmpty) return '';
    return name.split(RegExp(r'\s+')).first;
  }

  /// Dua huruf awal untuk lingkaran avatar. Kosong kalau tidak ada nama atau
  /// email (tamu), supaya layar memakai ikon orang.
  String get initials {
    final words = displayName
        .split(RegExp(r'\s+'))
        .where((word) => word.isNotEmpty)
        .toList();
    if (words.isEmpty) {
      final mail = email;
      return mail.isEmpty ? '' : String.fromCharCode(mail.runes.first).toUpperCase();
    }
    final first = String.fromCharCode(words.first.runes.first);
    if (words.length == 1) return first.toUpperCase();
    final last = String.fromCharCode(words.last.runes.first);
    return (first + last).toUpperCase();
  }

  SignInMethod get method {
    if (isGuest) return SignInMethod.guest;
    final providers = liveUser.providerData.map((info) => info.providerId);
    return providers.contains('google.com')
        ? SignInMethod.google
        : SignInMethod.email;
  }

  void dispose() => history.dispose();
}

class SessionScope extends InheritedWidget {
  const SessionScope({super.key, required this.session, required super.child});

  final Session session;

  static Session of(BuildContext context) {
    final scope = context.getInheritedWidgetOfExactType<SessionScope>();
    assert(scope != null, 'SessionScope tidak ditemukan di atas widget ini.');
    return scope!.session;
  }

  @override
  bool updateShouldNotify(SessionScope oldWidget) => session != oldWidget.session;
}
