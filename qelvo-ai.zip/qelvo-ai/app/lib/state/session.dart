import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/widgets.dart';
import 'package:qelvo_ai/data/chat_repository.dart';
import 'package:qelvo_ai/state/history_controller.dart';

/// Dibuat saat login berhasil dan dibuang saat keluar akun. Semua data di
/// dalamnya terikat ke satu uid.
class Session {
  Session._(this.user, this.repository, this.history);

  factory Session.start(User user) {
    final repository = ChatRepository(user.uid);
    final history = HistoryController(repository)..start();
    return Session._(user, repository, history);
  }

  final User user;
  final ChatRepository repository;
  final HistoryController history;

  String get uid => user.uid;

  String get email => user.email ?? '';

  bool get isGuest => user.isAnonymous;

  void dispose() => history.dispose();
}

class SessionScope extends InheritedWidget {
  const SessionScope({super.key, required this.session, required super.child});

  final Session session;

  static Session of(BuildContext context) {
    final scope = context.getInheritedWidgetOfExactType<SessionScope>();
    assert(scope != null, 'SessionScope tidak ditemukan di atas widget ini.');
    return scope!.session;
  }

  @override
  bool updateShouldNotify(SessionScope oldWidget) => session != oldWidget.session;
}
