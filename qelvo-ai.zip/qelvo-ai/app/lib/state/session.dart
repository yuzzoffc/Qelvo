import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/widgets.dart';
import 'package:qelvo_ai/data/api_client.dart';
import 'package:qelvo_ai/data/chat_repository.dart';
import 'package:qelvo_ai/state/history_controller.dart';

/// Dibuat saat login berhasil dan dibuang saat keluar akun. Semua data di
/// dalamnya terikat ke satu uid.
class Session {
  Session._(this.user, this.repository, this.history);

  factory Session.start(User user, ApiClient api) {
    final repository = ChatRepository(api);
    final history = HistoryController(repository);
    // Dimuat di latar belakang. Gagal memuat tidak boleh menahan layar chat.
    unawaited(history.refresh());
    return Session._(user, repository, history);
  }

  final User user;
  final ChatRepository repository;
  final HistoryController history;

  Future<void> _queue = Future<void>.value();

  /// Menjalankan [job] setelah semua pekerjaan sebelumnya selesai. Simpan,
  /// nilai, dan hapus riwayat lewat sini, supaya urutannya di server sama
  /// dengan urutan di layar (misalnya "hapus semua" tidak disusul pesan lama).
  /// Hasil atau kesalahan [job] diteruskan ke pemanggil.
  Future<T> enqueue<T>(Future<T> Function() job) {
    final completer = Completer<T>();
    _queue = _queue.then((_) async {
      try {
        completer.complete(await job());
      } catch (error, stack) {
        completer.completeError(error, stack);
      }
    });
    return completer.future;
  }

  String get uid => user.uid;

  String get email => user.email ?? '';

  bool get isGuest => user.isAnonymous;

  void dispose() => history.dispose();
}

class SessionScope extends InheritedWidget {
  const SessionScope({super.key, required this.session, required super.child});

  final Session session;

  static Session of(BuildContext context) {
    final scope = context.getInheritedWidgetOfExactType<SessionScope>();
    assert(scope != null, 'SessionScope tidak ditemukan di atas widget ini.');
    return scope!.session;
  }

  @override
  bool updateShouldNotify(SessionScope oldWidget) => session != oldWidget.session;
}
