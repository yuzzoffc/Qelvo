/// Kalimat status di penanda tunggu, sebelum potongan pertama jawaban tiba.
///
/// Berganti seiring lamanya menunggu, supaya pengguna tahu aplikasi masih
/// bekerja dan bukan macet. Pencarian web punya dua tahap yang terlihat:
/// mencari, lalu merangkum hasilnya. Server mengerjakan keduanya dalam satu
/// permintaan dan tidak memberi tahu kapan tahap pertama selesai, jadi pergantiannya
/// mengikuti waktu: pencarian biasanya selesai dalam beberapa detik pertama.
///
/// Tanpa titik di akhir; penanda menambahkan "…".
String waitStatus({
  required bool thinking,
  required bool searching,
  required Duration elapsed,
}) {
  final seconds = elapsed.inSeconds;
  if (seconds >= 60) return 'Butuh waktu lebih lama dari biasanya, masih dikerjakan';
  if (searching) {
    if (seconds < 7) return 'Sedang mencari di web';
    if (seconds < 30) return 'Sedang merangkum';
    return 'Masih merangkum, sebentar lagi';
  }
  if (thinking) {
    return seconds < 20 ? 'Sedang berpikir' : 'Masih berpikir, sebentar lagi';
  }
  return seconds < 20 ? 'Sedang menjawab' : 'Masih menjawab, sebentar lagi';
}
