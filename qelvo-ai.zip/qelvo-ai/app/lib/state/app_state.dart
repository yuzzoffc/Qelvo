import 'package:flutter/widgets.dart';
import 'package:qelvo_ai/core/config.dart';
import 'package:qelvo_ai/data/api_client.dart';
import 'package:qelvo_ai/data/auth_service.dart';
import 'package:qelvo_ai/data/settings_store.dart';
import 'package:qelvo_ai/data/update_service.dart';
import 'package:qelvo_ai/state/model_catalog.dart';
import 'package:qelvo_ai/state/update_controller.dart';

/// Hal-hal yang berlaku untuk seluruh aplikasi, sebelum dan sesudah login.
class AppState {
  AppState._({
    required this.settings,
    required this.auth,
    required this.api,
    required this.catalog,
    required this.updates,
  });

  final SettingsStore settings;
  final AuthService auth;
  final ApiClient api;
  final ModelCatalog catalog;

  /// Pembaruan lewat GitHub (OTA). Mati kalau build tidak punya UPDATE_REPO.
  final UpdateController updates;

  static Future<AppState> create() async {
    final settings = await SettingsStore.load();
    final auth = AuthService();
    final api = ApiClient(auth.idToken);
    final catalog = ModelCatalog(settings, api);
    final updates = UpdateController(
      settings: settings,
      platform: const MethodChannelUpdatePlatform(),
      source: AppConfig.updatesEnabled
          ? UpdateClient(repo: AppConfig.updateRepo)
          : null,
    );
    await updates.init();
    return AppState._(
      settings: settings,
      auth: auth,
      api: api,
      catalog: catalog,
      updates: updates,
    );
  }
}

class AppScope extends InheritedWidget {
  const AppScope({super.key, required this.state, required super.child});

  final AppState state;

  static AppState of(BuildContext context) {
    final scope = context.getInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope tidak ditemukan di atas widget ini.');
    return scope!.state;
  }

  @override
  bool updateShouldNotify(AppScope oldWidget) => state != oldWidget.state;
}
