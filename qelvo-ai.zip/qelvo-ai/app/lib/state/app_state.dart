import 'package:flutter/widgets.dart';
import 'package:qelvo_ai/data/api_client.dart';
import 'package:qelvo_ai/data/auth_service.dart';
import 'package:qelvo_ai/data/settings_store.dart';
import 'package:qelvo_ai/state/model_catalog.dart';

/// Hal-hal yang berlaku untuk seluruh aplikasi, sebelum dan sesudah login.
class AppState {
  AppState._({
    required this.settings,
    required this.auth,
    required this.api,
    required this.catalog,
  });

  final SettingsStore settings;
  final AuthService auth;
  final ApiClient api;
  final ModelCatalog catalog;

  static Future<AppState> create() async {
    final settings = await SettingsStore.load();
    final auth = AuthService();
    final api = ApiClient(auth.idToken);
    final catalog = ModelCatalog(settings, api);
    return AppState._(
      settings: settings,
      auth: auth,
      api: api,
      catalog: catalog,
    );
  }
}

class AppScope extends InheritedWidget {
  const AppScope({super.key, required this.state, required super.child});

  final AppState state;

  static AppState of(BuildContext context) {
    final scope = context.getInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope tidak ditemukan di atas widget ini.');
    return scope!.state;
  }

  @override
  bool updateShouldNotify(AppScope oldWidget) => state != oldWidget.state;
}
