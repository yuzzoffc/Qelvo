import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as img;
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/state/attachment_policy.dart';

/// Dua versi satu foto: gambar penuh untuk model, dan gambar kecil untuk
/// komposer, gelembung pesan, dan riwayat.
class EncodedPhoto {
  const EncodedPhoto({required this.full, required this.thumb});

  final Uint8List full;
  final Uint8List thumb;
}

/// Sisi terpanjang gambar penuh dan mutu JPEG. Dicoba berurutan sampai
/// ukurannya masuk batas server.
const List<(int, int)> _fullSteps = [(1280, 84), (1024, 74), (768, 64)];

/// Sisi terpendek gambar kecil dan mutu JPEG. Dicoba berurutan sampai ukurannya
/// masuk batas gambar kecil.
const List<(int, int)> _thumbSteps = [(320, 62), (256, 56), (192, 50), (144, 46)];

/// Mengolah satu foto dari pemilih bawaan HP menjadi lampiran. Berjalan di
/// isolate terpisah supaya layar tidak tersendat. Mengembalikan null kalau
/// fotonya tidak terbaca atau tetap terlalu besar.
Future<ChatAttachment?> attachmentFromBytes(Uint8List picked) async {
  try {
    final encoded = await compute(encodePhoto, picked);
    if (encoded == null) return null;
    return ChatAttachment(thumb: encoded.thumb, full: encoded.full);
  } catch (_) {
    return null;
  }
}

/// Inti pengolahan, tanpa isolate supaya mudah diuji. Foto dibaca, diputar
/// sesuai tanda arah dari kamera, lalu dibuat dua versi JPEG tanpa metadata:
/// lokasi dan data kamera tidak ikut terkirim ke penyedia AI.
EncodedPhoto? encodePhoto(Uint8List source) {
  final decoded = img.decodeImage(source);
  if (decoded == null) return null;
  final upright = img.bakeOrientation(decoded);

  Uint8List? full;
  for (final (side, quality) in _fullSteps) {
    full = _jpeg(_limitLongest(upright, side), quality);
    if (full.length <= AttachmentRules.maxPhotoBytes) break;
  }
  Uint8List? thumb;
  for (final (side, quality) in _thumbSteps) {
    thumb = _jpeg(_limitShortest(upright, side), quality);
    if (thumb.length <= AttachmentRules.maxThumbBytes) break;
  }
  if (full == null || full.length > AttachmentRules.maxPhotoBytes) return null;
  if (thumb == null || thumb.length > AttachmentRules.maxThumbBytes) return null;
  return EncodedPhoto(full: full, thumb: thumb);
}

Uint8List _jpeg(img.Image image, int quality) {
  return stripJpegMetadata(
    Uint8List.fromList(img.encodeJpg(image, quality: quality)),
  );
}

/// Memperkecil gambar sampai sisi terpanjangnya [side]. Gambar yang sudah lebih
/// kecil dibiarkan.
img.Image _limitLongest(img.Image source, int side) {
  if (source.width <= side && source.height <= side) return source;
  return source.width >= source.height
      ? img.copyResize(
          source,
          width: side,
          interpolation: img.Interpolation.average,
        )
      : img.copyResize(
          source,
          height: side,
          interpolation: img.Interpolation.average,
        );
}

/// Memperkecil gambar sampai sisi terpendeknya [side], dengan perbandingan
/// lebar dan tinggi tetap. Gambar yang sudah lebih kecil dibiarkan.
img.Image _limitShortest(img.Image source, int side) {
  final shortest = source.width < source.height ? source.width : source.height;
  if (shortest <= side) return source;
  final scale = side / shortest;
  return img.copyResize(
    source,
    width: (source.width * scale).round(),
    height: (source.height * scale).round(),
    interpolation: img.Interpolation.average,
  );
}

/// Membuang segmen metadata dari JPEG: APP1 (EXIF dan XMP, tempat koordinat
/// GPS), APP13 (IPTC), dan komentar. Segmen lain dan data gambar disalin apa
/// adanya. Berkas yang bukan JPEG atau rusak dikembalikan tanpa diubah.
Uint8List stripJpegMetadata(Uint8List jpeg) {
  if (jpeg.length < 4 || jpeg[0] != 0xFF || jpeg[1] != 0xD8) return jpeg;
  final out = BytesBuilder();
  out.add(const [0xFF, 0xD8]);
  var i = 2;
  while (i + 4 <= jpeg.length && jpeg[i] == 0xFF) {
    final marker = jpeg[i + 1];
    // SOS: data gambar mulai di sini dan disalin utuh sampai akhir.
    if (marker == 0xDA) break;
    final length = (jpeg[i + 2] << 8) | jpeg[i + 3];
    final end = i + 2 + length;
    if (length < 2 || end > jpeg.length) return jpeg;
    final metadata = marker == 0xE1 || marker == 0xED || marker == 0xFE;
    if (!metadata) out.add(Uint8List.sublistView(jpeg, i, end));
    i = end;
  }
  out.add(Uint8List.sublistView(jpeg, i));
  return out.takeBytes();
}
