import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:qelvo_ai/core/config.dart';
import 'package:qelvo_ai/data/settings_store.dart';
import 'package:qelvo_ai/data/update_models.dart';
import 'package:qelvo_ai/data/update_service.dart';

enum UpdateStatus {
  idle,
  checking,
  upToDate,
  available,
  downloading,
  ready,
  failed,
}

/// Pembaruan lewat GitHub, semi otomatis: aplikasi memeriksa sendiri saat dibuka,
/// tapi mengunduh hanya setelah pengguna menyetujui, dan pemasangnya sendiri
/// tetap meminta ketukan pengguna (Android tidak mengizinkan pemasangan diam-diam).
///
/// Tidak ada pemberitahuan di sini: satu-satunya pemberitahuan aplikasi adalah
/// "QELVO sudah menjawab". Pembaruan hanya tampil sebagai lembar di dalam aplikasi.
class UpdateController extends ChangeNotifier {
  UpdateController({
    required this.settings,
    required this.platform,
    this.source,
    DateTime Function()? now,
  }) : _now = now ?? DateTime.now;

  final SettingsStore settings;
  final UpdatePlatform platform;

  /// Null kalau pembaruan lewat aplikasi mati (build lokal tanpa UPDATE_REPO).
  final UpdateSource? source;
  final DateTime Function() _now;

  /// Pemeriksaan otomatis paling sering sekali dalam rentang ini.
  static const Duration checkInterval = Duration(hours: 12);

  UpdateStatus _status = UpdateStatus.idle;
  UpdateRelease? _release;
  AppVersion? _installed;
  Directory? _updatesDir;
  File? _apk;
  UpdateCancel? _cancel;
  String? _error;
  bool _needsPermission = false;
  bool _foundRelease = false;
  String? _promptedTag;
  int _received = 0;
  int _total = 0;
  double _progress = 0;
  DateTime? _lastProgressNotify;
  bool _disposed = false;

  UpdateStatus get status => _status;

  /// Rilis yang lebih baru dari versi terpasang, ada selama [status] available,
  /// downloading, atau ready.
  UpdateRelease? get release => _release;

  /// Versi yang terpasang, dibaca dari APK. Null di luar Android.
  AppVersion? get installed => _installed;

  String get versionLabel => _installed?.toString() ?? AppConfig.version;

  bool get enabled => source != null;

  /// Pesan galat untuk pengguna, kalau ada.
  String? get error => _error;

  /// Android belum mengizinkan aplikasi memasang paket; layar izinnya sudah dibuka.
  bool get needsPermission => _needsPermission;

  /// Pemeriksaan terakhir menemukan rilis resmi (walau bukan yang lebih baru).
  bool get foundRelease => _foundRelease;

  double get progress => _progress;
  int get receivedBytes => _received;
  int get totalBytes => _total;

  /// Ada pembaruan yang belum pernah ditawarkan di sesi ini.
  bool get shouldPrompt =>
      _status == UpdateStatus.available &&
      _release != null &&
      _promptedTag != _release!.tag;

  void markPrompted() => _promptedTag = _release?.tag;

  /// Membaca versi terpasang dan membuang sisa unduhan lama.
  Future<void> init() async {
    final info = await platform.appInfo();
    if (info == null) return;
    _installed = AppVersion.tryParse(info.version);
    final dir = Directory('${info.cacheDir}/updates');
    _updatesDir = dir;
    unawaited(UpdateClient.clearDirectory(dir).catchError((_) {}));
  }

  /// Pemeriksaan otomatis saat aplikasi dibuka: hanya kalau pengguna belum
  /// mematikannya, dan paling sering sekali per [checkInterval].
  Future<void> checkIfDue() async {
    if (!enabled || !settings.autoUpdate) return;
    if (_status != UpdateStatus.idle) return;
    final last = settings.lastUpdateCheck;
    if (last != null) {
      final age = _now().difference(last);
      if (!age.isNegative && age < checkInterval) return;
    }
    await check();
  }

  /// Menanyakan rilis terbaru ke GitHub. Kalau [manual], versi yang pernah
  /// dilewati tetap ditawarkan lagi.
  Future<void> check({bool manual = false}) async {
    final source = this.source;
    if (source == null) return;
    if (_status == UpdateStatus.checking || _status == UpdateStatus.downloading) {
      return;
    }
    _status = UpdateStatus.checking;
    _error = null;
    _notify();
    try {
      final latest = await source.fetchLatest();
      await settings.setLastUpdateCheck(_now());
      _foundRelease = latest != null;
      final current = _installed;
      final newer = latest != null && current != null && latest.version > current;
      final skipped = !manual &&
          latest != null &&
          settings.skippedUpdate == latest.version.toString();
      if (newer && !skipped) {
        _release = latest;
        _status = UpdateStatus.available;
      } else {
        _release = null;
        _status = UpdateStatus.upToDate;
      }
    } on UpdateException catch (e) {
      _error = e.message;
      _status = UpdateStatus.failed;
    } catch (_) {
      _error = 'Tidak bisa memeriksa pembaruan. Coba lagi nanti.';
      _status = UpdateStatus.failed;
    }
    _notify();
  }

  /// Mengunduh APK, memastikan checksum-nya cocok, lalu membuka pemasang Android.
  Future<void> download() async {
    final release = _release;
    final source = this.source;
    if (release == null || source == null) return;
    if (_status == UpdateStatus.downloading) return;
    final dir = _updatesDir;
    if (dir == null) {
      _fail('Pembaruan lewat aplikasi hanya tersedia di Android.');
      return;
    }
    _status = UpdateStatus.downloading;
    _error = null;
    _needsPermission = false;
    _received = 0;
    _total = release.apkSize;
    _progress = 0;
    final cancel = _cancel = UpdateCancel();
    _notify();
    try {
      _apk = await source.download(
        release,
        dir,
        cancel: cancel,
        onProgress: _onProgress,
      );
      if (_disposed) return;
      _progress = 1;
      _status = UpdateStatus.ready;
      _notify();
      await install();
    } on UpdateCancelled {
      _status = UpdateStatus.available;
      _notify();
    } on UpdateException catch (e) {
      _fail(e.message);
    } catch (_) {
      _fail('Unduhan gagal. Coba lagi.');
    }
  }

  /// Membuka pemasang Android untuk APK yang sudah diunduh. Kalau Android belum
  /// mengizinkan aplikasi memasang paket, layar izinnya dibuka lebih dulu.
  Future<void> install() async {
    final apk = _apk;
    if (apk == null) return;
    _error = null;
    _needsPermission = false;
    if (!await platform.canInstall()) {
      _needsPermission = true;
      _notify();
      await platform.openInstallSettings();
      return;
    }
    final opened = await platform.install(apk.path);
    if (!opened) {
      _error = 'Pemasang Android tidak bisa dibuka. Coba lagi.';
    }
    _notify();
  }

  void cancelDownload() => _cancel?.cancel();

  /// "Nanti": lembarnya ditutup dan tidak ditawarkan lagi sampai pemeriksaan berikutnya.
  void dismiss() {
    if (_status == UpdateStatus.downloading) return;
    _release = null;
    _apk = null;
    _error = null;
    _needsPermission = false;
    _status = UpdateStatus.idle;
    _notify();
  }

  /// "Lewati versi ini": versi itu tidak ditawarkan lagi oleh pemeriksaan otomatis.
  Future<void> skip() async {
    final release = _release;
    if (release != null) {
      await settings.setSkippedUpdate(release.version.toString());
    }
    dismiss();
  }

  void _onProgress(int received, int total) {
    _received = received;
    _total = total;
    _progress = total > 0 ? (received / total).clamp(0.0, 1.0) : 0.0;
    final now = _now();
    final last = _lastProgressNotify;
    if (last == null ||
        now.difference(last) >= const Duration(milliseconds: 150) ||
        received >= total) {
      _lastProgressNotify = now;
      _notify();
    }
  }

  void _fail(String message) {
    _error = message;
    _status = UpdateStatus.failed;
    _notify();
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _cancel?.cancel();
    super.dispose();
  }
}
