import 'dart:async';
import 'dart:convert';
import 'dart:collection';

import 'package:flutter/foundation.dart';
import 'package:qelvo_ai/data/api_client.dart';
import 'package:qelvo_ai/data/background_run.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/data/sse.dart';
import 'package:qelvo_ai/state/app_state.dart';
import 'package:qelvo_ai/state/attachment_policy.dart';
import 'package:qelvo_ai/state/session.dart';

/// Kegagalan terakhir di percakapan: pesan siap tampil, kode untuk logika,
/// dan kode status HTTP kalau ada.
class ChatFailure {
  const ChatFailure(this.message, {this.code = 'unknown', this.statusCode});

  final String message;
  final String code;
  final int? statusCode;

  /// Gagal karena tidak ada sambungan ke server, bukan karena server menolak.
  bool get offline => code == 'offline';
}

const String _newConversationTitle = 'Percakapan baru';

/// Keadaan satu percakapan: pesan, penanda jawaban, dan langganan aliran.
///
/// Yang sedang terbuka di layar dipegang [ChatController] sebagai `_current`.
/// Percakapan yang ditinggalkan saat jawabannya masih mengalir dipindah ke
/// `_parked` dan dibiarkan selesai sendiri, jadi berpindah percakapan tidak
/// memutus jawaban yang sedang diproses.
class _Thread {
  _Thread({
    this.id,
    this.createdAt,
    this.title = _newConversationTitle,
    this.modelLabel = '',
    this.lastPreview = '',
  });

  String? id;
  DateTime? createdAt;
  String title;
  String modelLabel;
  String lastPreview;
  final List<ChatMessage> messages = [];
  bool streaming = false;
  bool searching = false;
  bool loading = false;
  ChatFailure? failure;
  StreamSubscription<ChatEvent>? subscription;

  /// Percakapannya dihapus atau dikosongkan: tidak ada lagi yang perlu disimpan
  /// atau diberi judul.
  bool discarded = false;
}

/// Percakapan yang sedang terbuka di layar, ditambah percakapan lain yang
/// jawabannya masih mengalir di latar belakang. Pesan dikirim ke server untuk
/// disimpan setelah selesai (bukan per token), dan tidak disimpan sama sekali
/// kalau "Simpan riwayat" dimatikan.
///
/// Berpindah ke percakapan lain (atau memulai yang baru) saat jawaban masih
/// mengalir tidak menghentikannya: jawabannya selesai dan tersimpan sendiri,
/// dan terlihat lengkap begitu percakapannya dibuka lagi. Itu hanya berlaku kalau
/// percakapannya tersimpan di riwayat; tanpa riwayat tidak ada jalan kembali ke
/// percakapan itu, jadi alirannya dihentikan seperti biasa.
///
/// Selama ada jawaban yang mengalir, [background] meminta sistem menjaga proses
/// tetap hidup, jadi jawaban tetap selesai walau pengguna keluar dari aplikasi.
/// Kalau aplikasi sedang tidak terlihat saat jawaban selesai, pengguna diberi
/// tahu lewat pemberitahuan; selama mengalir tidak ada pemberitahuan apa pun.
class ChatController extends ChangeNotifier {
  ChatController({
    required this.app,
    required this.session,
    BackgroundRun background = const PlatformBackgroundRun(),
  })  : _background = background,
        _runs = RunLedger(background);

  final AppState app;
  final Session session;
  final BackgroundRun _background;

  /// Jawaban yang sedang mengalir, di percakapan terbuka maupun di latar
  /// belakang. Wake lock dipegang selama masih ada.
  final RunLedger _runs;

  /// Dipakai layar untuk menyembunyikan aplikasi (bukan menutupnya) saat tombol
  /// kembali ditekan di tengah jawaban.
  BackgroundRun get background => _background;

  static const int _contextLimit = 40;

  _Thread _current = _Thread();

  /// Percakapan lain yang jawabannya masih mengalir, atau sudah selesai tetapi
  /// belum dibuka lagi. Isinya di memori lebih baru daripada yang ada di server.
  final Map<String, _Thread> _parked = {};

  /// Percakapan di latar belakang yang selesai (atau gagal) dan belum dibuka.
  final Set<String> _unread = {};

  bool _disposed = false;

  String? get conversationId => _current.id;

  String get title => _current.title;

  bool get isEmpty => _current.messages.isEmpty;

  bool get isStreaming => _current.streaming;

  /// Server mencari di web untuk jawaban yang sedang ditunggu. Layar memakainya
  /// untuk menulis "Mencari di web" di penanda tunggu.
  bool get isSearching => _current.searching;

  bool get isLoading => _current.loading;

  ChatFailure? get failure => _current.failure;

  bool get canRetry =>
      _current.failure != null &&
      !_current.streaming &&
      _current.messages.isNotEmpty;

  UnmodifiableListView<ChatMessage> get messages =>
      UnmodifiableListView(_current.messages);

  /// Ada jawaban yang sedang mengalir, di percakapan terbuka maupun di
  /// percakapan lain. Layar memakainya supaya tombol kembali menyembunyikan
  /// aplikasi, bukan menutupnya.
  bool get hasActiveRuns => _runs.hasActive;

  /// Jawaban percakapan [id] sedang mengalir, terbuka di layar atau tidak.
  bool isRunning(String id) {
    if (_current.id == id) return _current.streaming;
    return _parked[id]?.streaming ?? false;
  }

  /// Jawaban percakapan [id] selesai (atau gagal) saat ia tidak terbuka, dan
  /// belum dilihat.
  bool hasUnread(String id) => _unread.contains(id);

  void send(String text, {List<ChatAttachment> attachments = const []}) {
    final thread = _current;
    final content = text.trim();
    if (content.isEmpty || thread.streaming || thread.loading) return;

    final message = ChatMessage(
      id: newId(),
      role: ChatRole.user,
      content: content,
      createdAt: DateTime.now(),
      attachments: List<ChatAttachment>.unmodifiable(attachments),
    );
    if (thread.messages.isEmpty) {
      thread.title = titleFrom(content);
      thread.id ??= newId();
    }
    thread.messages.add(message);
    thread.failure = null;
    _save(thread, message);
    _ask(thread);
  }

  void retry() {
    final thread = _current;
    if (!canRetry) return;
    if (thread.messages.last.role == ChatRole.assistant) {
      thread.messages.removeLast();
    }
    if (thread.messages.isNotEmpty &&
        thread.messages.last.role == ChatRole.user) {
      _ask(thread);
    }
  }

  void regenerate() {
    final thread = _current;
    if (thread.streaming || thread.messages.isEmpty) return;
    final last = thread.messages.last;
    if (last.role != ChatRole.assistant) return;
    thread.messages.removeLast();
    _deleteRemote(thread, last);
    _ask(thread);
  }

  /// Menarik pesan pengguna terakhir, beserta jawabannya, kembali ke kolom pesan
  /// supaya bisa diubah lalu dikirim ulang. Mengembalikan teksnya, atau null
  /// kalau tidak bisa: jawaban masih mengalir, bukan pesan pengguna terakhir,
  /// atau pesannya membawa foto.
  String? takeBackLastUser(ChatMessage message) {
    final thread = _current;
    if (thread.streaming || thread.loading) return null;
    final messages = thread.messages;
    final index = messages.lastIndexWhere((m) => m.role == ChatRole.user);
    if (index < 0 || messages[index].id != message.id) return null;
    if (message.attachments.isNotEmpty) return null;
    final removed = messages.sublist(index);
    messages.removeRange(index, messages.length);
    thread.failure = null;
    final id = thread.id;
    if (messages.isEmpty) {
      // Percakapan kosong lagi. Hapus juga di server supaya tidak tertinggal
      // percakapan tanpa pesan; mengirim ulang membuat percakapan baru.
      if (id != null && _canSave) {
        _enqueue(() async {
          await session.repository.deleteConversation(id);
          unawaited(session.history.refresh());
        });
      }
      thread.id = null;
      thread.createdAt = null;
      thread.title = _newConversationTitle;
      thread.modelLabel = '';
      thread.lastPreview = '';
    } else {
      for (final item in removed) {
        _deleteRemote(thread, item);
      }
    }
    _notify();
    return message.content;
  }

  /// Nama percakapan [id] diganti dari daftar riwayat. Simpanan berikutnya
  /// memakai nama baru, supaya tidak menimpanya kembali.
  void applyTitle(String id, String title) {
    final thread = _current.id == id ? _current : _parked[id];
    if (thread == null || thread.title == title) return;
    thread.title = title;
    _notifyFor(thread);
  }

  void stop() {
    _cancelStream(_current, persistPartial: true);
    _notify();
  }

  /// Mengosongkan layar untuk percakapan baru. Kalau jawaban percakapan yang
  /// ditinggalkan masih mengalir, ia dibiarkan selesai di latar belakang.
  /// [persistPartial] false dipakai saat riwayatnya sendiri dihapus: alirannya
  /// dihentikan dan jawaban setengah jadi tidak disimpan, supaya percakapan
  /// yang baru dihapus tidak hidup kembali.
  void reset({bool persistPartial = true}) {
    _leave(_current, persistPartial: persistPartial);
    _current = _Thread();
    _notify();
  }

  Future<void> open(Conversation conversation) async {
    final id = conversation.id;
    if (_current.id == id) return;
    _leave(_current, persistPartial: true);
    _unread.remove(id);

    final parked = _parked.remove(id);
    if (parked != null) {
      // Jawabannya masih mengalir, atau baru selesai: isi di memori yang paling
      // baru, jadi tidak perlu memuat ulang dari server.
      _current = parked;
      _notify();
      return;
    }

    final thread = _Thread(
      id: id,
      createdAt: conversation.createdAt,
      title: conversation.title,
      modelLabel: conversation.modelLabel,
      lastPreview: conversation.preview,
    )..loading = true;
    _current = thread;
    _notify();

    try {
      final loaded = await session.repository.messages(id);
      if (!identical(_current, thread)) return;
      thread.messages.addAll(loaded);
    } catch (error) {
      if (!identical(_current, thread)) return;
      thread.failure = _failureFrom(
        error,
        'Percakapan gagal dimuat. Periksa koneksi lalu buka lagi.',
      );
    }
    thread.loading = false;
    _notify();
  }

  /// Percakapan [id] dihapus dari riwayat: kalau jawabannya masih mengalir di
  /// latar belakang, alirannya dihentikan dan tidak ada yang disimpan lagi.
  /// Percakapan yang sedang terbuka ditangani [reset].
  void discard(String id) {
    final removedUnread = _unread.remove(id);
    final thread = _parked.remove(id);
    if (thread == null) {
      if (removedUnread) _notify();
      return;
    }
    thread.discarded = true;
    _cancelStream(thread, persistPartial: false);
    _notify();
  }

  /// Semua percakapan di latar belakang dihentikan dan dilupakan (riwayat
  /// dihapus seluruhnya).
  void discardBackground() {
    for (final thread in _parked.values) {
      thread.discarded = true;
      _cancelStream(thread, persistPartial: false);
    }
    _parked.clear();
    _unread.clear();
    _notify();
  }

  void rate(ChatMessage message, int value) {
    final next = message.rating == value ? 0 : value;
    message.rating = next;
    _notify();
    final id = _current.id;
    if (id == null || !_canSave) return;
    _enqueue(() => session.repository.setRating(id, message.id, next));
  }

  String toMarkdown() {
    final buffer = StringBuffer('# ${_current.title}\n\n');
    for (final message in _current.messages) {
      if (message.content.trim().isEmpty) continue;
      buffer.write(message.role == ChatRole.user ? '**Kamu**' : '**QELVO**');
      buffer.write('\n\n${message.content.trim()}\n\n');
      buffer.write(ChatSource.markdownList(message.sources));
      if (message.attachments.isNotEmpty) {
        buffer.write('_(${message.attachments.length} foto dilampirkan)_\n\n');
      }
    }
    return buffer.toString().trimRight();
  }

  bool get _canSave => app.settings.saveHistory && !session.history.unavailable;

  /// [thread] ditinggalkan dari layar. Kalau jawabannya masih mengalir dan
  /// percakapannya tersimpan, jawaban dibiarkan selesai di latar belakang.
  /// Selain itu alirannya dihentikan.
  void _leave(_Thread thread, {required bool persistPartial}) {
    final id = thread.id;
    if (persistPartial && thread.streaming && id != null && _canSave) {
      _parked[id] = thread;
      return;
    }
    if (!persistPartial) thread.discarded = true;
    _cancelStream(thread, persistPartial: persistPartial);
  }

  void _ask(_Thread thread) {
    final placeholder = ChatMessage(
      id: newId(),
      role: ChatRole.assistant,
      content: '',
      createdAt: DateTime.now(),
    );
    final messages = thread.messages;
    final context = messages.length > _contextLimit
        ? messages.sublist(messages.length - _contextLimit)
        : List<ChatMessage>.of(messages);
    final catalog = app.catalog;
    // Cari web hanya diminta kalau pengguna menyalakannya dan model yang dipilih
    // mendukungnya, supaya server lama atau model lain tidak menerima permintaan
    // yang tidak bisa dipenuhi. Server yang menilai apakah pesannya benar-benar
    // butuh pencarian, dan melewatinya kalau ada foto.
    final search = app.settings.webSearch && catalog.supportsWebSearch;
    messages.add(placeholder);
    thread.streaming = true;
    thread.searching = false;
    thread.failure = null;
    _notifyFor(thread);
    _beginRun();

    final images = imagesForRequest(context);
    final stream = app.api.streamChat(
      messages: [
        for (final m in context)
          {
            'role': m.role.name,
            'content': m.content,
            if (images != null && images.messageId == m.id)
              'images': [
                for (final attachment in images.attachments)
                  {
                    'mime': attachment.mime,
                    'data': base64Encode(attachment.full!),
                  },
              ],
          },
      ],
      providerId: catalog.activeProvider?.id,
      modelId: catalog.activeModel?.id,
      thinking: app.settings.thinking,
      instruction: app.settings.instruction.name,
      webSearch: search,
      customInstruction: app.settings.customInstruction,
    );

    // Semua penangan memegang [thread], bukan layar: jawaban terus mengisi
    // percakapannya sendiri walau sedang tidak terbuka.
    thread.subscription = stream.listen(
      (event) {
        if (event is DeltaEvent) {
          placeholder.content += event.text;
          _notifyFor(thread);
        } else if (event is MetaEvent) {
          if (event.modelLabel.isNotEmpty) {
            thread.modelLabel = event.modelLabel;
          }
          // Jawaban dari cache datang seketika: tidak perlu "Mencari di web".
          if (event.webSearch && !event.cached && !thread.searching) {
            thread.searching = true;
            _notifyFor(thread);
          }
        } else if (event is SourcesEvent) {
          placeholder.sources = event.sources;
          _notifyFor(thread);
        }
      },
      onError: (Object error) => _fail(thread, placeholder, error),
      onDone: () => _complete(thread, placeholder),
      cancelOnError: true,
    );
  }

  void _complete(_Thread thread, ChatMessage placeholder) {
    thread.subscription = null;
    thread.streaming = false;
    thread.searching = false;
    if (placeholder.content.trim().isEmpty) {
      thread.messages.remove(placeholder);
      thread.failure = const ChatFailure(
        'QELVO tidak mengirim jawaban. Coba lagi.',
        code: 'empty_response',
      );
      _endRun(RunOutcome.failed);
    } else {
      _save(thread, placeholder);
      _suggestTitle(thread, placeholder);
      _endRun(RunOutcome.done);
    }
    _runEnded(thread);
  }

  /// Percakapan baru diberi judul oleh AI dari pertanyaan dan jawaban pertama.
  /// Gagal atau kosong tidak jadi masalah: judul dari potongan pesan pertama
  /// tetap dipakai.
  void _suggestTitle(_Thread thread, ChatMessage answer) {
    final messages = thread.messages;
    if (messages.length != 2 || !_canSave) return;
    final id = thread.id;
    final first = messages.first;
    if (id == null || first.role != ChatRole.user) return;
    final fallback = titleFrom(first.content);
    if (thread.title != fallback) return;
    unawaited(
      _applySuggestedTitle(thread, id, fallback, first.content, answer.content),
    );
  }

  Future<void> _applySuggestedTitle(
    _Thread thread,
    String id,
    String fallback,
    String question,
    String answer,
  ) async {
    try {
      final title = await session.repository.generateTitle(question, answer);
      if (title.isEmpty ||
          _disposed ||
          thread.discarded ||
          thread.id != id ||
          thread.title != fallback ||
          !_tracked(thread)) {
        return;
      }
      thread.title = title;
      _notifyFor(thread);
      await session.enqueue(
        () => session.repository.updateConversation(id, title: title),
      );
      unawaited(session.history.refresh());
    } catch (_) {
      // Judul otomatis hanya pemanis; judul lama tetap berlaku.
    }
  }

  /// [thread] masih dipegang controller: sedang terbuka atau di latar belakang.
  bool _tracked(_Thread thread) {
    if (identical(_current, thread)) return true;
    final id = thread.id;
    return id != null && identical(_parked[id], thread);
  }

  void _fail(_Thread thread, ChatMessage placeholder, Object error) {
    thread.subscription = null;
    thread.streaming = false;
    thread.searching = false;
    thread.failure = _failureFrom(error, 'Terjadi kesalahan. Coba lagi.');
    if (placeholder.content.trim().isEmpty) {
      thread.messages.remove(placeholder);
    }
    _endRun(RunOutcome.failed);
    _runEnded(thread);
  }

  /// Satu jawaban selesai atau gagal. Kalau percakapannya tidak sedang terbuka,
  /// ia ditandai belum dilihat supaya daftar riwayat bisa menunjukkannya.
  void _runEnded(_Thread thread) {
    final id = thread.id;
    if (id != null && !identical(_current, thread) && _tracked(thread)) {
      _unread.add(id);
    }
    _notify();
  }

  ChatFailure _failureFrom(Object error, String fallback) {
    if (error is ApiException) {
      return ChatFailure(
        error.message,
        code: error.code,
        statusCode: error.statusCode,
      );
    }
    return ChatFailure(fallback);
  }

  void _cancelStream(_Thread thread, {required bool persistPartial}) {
    final subscription = thread.subscription;
    if (subscription == null) return;
    thread.subscription = null;
    unawaited(subscription.cancel());
    thread.streaming = false;
    thread.searching = false;
    _endRun(RunOutcome.cancelled);
    final messages = thread.messages;
    if (messages.isEmpty || messages.last.role != ChatRole.assistant) return;
    final last = messages.last;
    if (last.content.trim().isEmpty) {
      messages.removeLast();
    } else if (persistPartial) {
      _save(thread, last);
    }
  }

  void _save(_Thread thread, ChatMessage message) {
    if (!_canSave) return;
    final id = thread.id;
    if (id == null) return;

    final now = DateTime.now();
    if (message.role == ChatRole.assistant) {
      thread.lastPreview = previewFrom(message.content);
    }
    final conversation = Conversation(
      id: id,
      title: thread.title,
      modelLabel: thread.modelLabel,
      createdAt: thread.createdAt ??= now,
      updatedAt: now,
      preview: thread.lastPreview,
    );
    // Salinan, karena isi pesan masih bisa berubah sebelum giliran antreannya tiba.
    final snapshot = ChatMessage(
      id: message.id,
      role: message.role,
      content: message.content,
      createdAt: message.createdAt,
      rating: message.rating,
      attachments: message.attachments,
      sources: message.sources,
    );
    _enqueue(() async {
      await session.repository.save(
        conversation: conversation,
        message: snapshot,
      );
      unawaited(session.history.refresh());
    });
  }

  void _deleteRemote(_Thread thread, ChatMessage message) {
    final id = thread.id;
    if (id == null || !_canSave) return;
    _enqueue(() => session.repository.deleteMessage(id, message.id));
  }

  /// Simpan, nilai, dan hapus berjalan berurutan lewat antrean sesi. Tanpa
  /// itu, permintaan yang berangkat bersamaan bisa tiba terbalik di server
  /// (misalnya penilaian lebih dulu daripada pesannya). Gagal menyimpan tidak
  /// boleh mengganggu chat yang sedang berjalan.
  void _enqueue(Future<void> Function() job) {
    unawaited(
      session.enqueue(job).catchError((Object error) {
        if (error is ApiException) session.history.noteFailure(error);
      }),
    );
  }

  /// Jawaban mulai dialirkan: minta sistem menjaga proses tetap hidup kalau
  /// aplikasi ditinggal. Tanpa pemberitahuan; itu baru muncul saat jawaban selesai.
  void _beginRun() => _runs.begin();

  /// Jawaban berakhir. Pengguna diberi tahu hanya kalau jawabannya selesai dan
  /// aplikasi sedang tidak terlihat.
  void _endRun(RunOutcome outcome) => _runs.end(outcome);

  /// Layar hanya perlu digambar ulang kalau yang berubah percakapan yang
  /// sedang terbuka; kemajuan di latar belakang tidak terlihat.
  void _notifyFor(_Thread thread) {
    if (identical(thread, _current)) _notify();
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _cancelStream(_current, persistPartial: true);
    for (final thread in _parked.values) {
      _cancelStream(thread, persistPartial: true);
    }
    _parked.clear();
    super.dispose();
  }
}
