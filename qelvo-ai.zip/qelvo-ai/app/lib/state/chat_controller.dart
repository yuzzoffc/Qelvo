import 'dart:async';
import 'dart:convert';
import 'dart:collection';

import 'package:flutter/foundation.dart';
import 'package:qelvo_ai/data/api_client.dart';
import 'package:qelvo_ai/data/background_run.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/data/sse.dart';
import 'package:qelvo_ai/state/app_state.dart';
import 'package:qelvo_ai/state/attachment_policy.dart';
import 'package:qelvo_ai/state/session.dart';

/// Kegagalan terakhir di percakapan: pesan siap tampil, kode untuk logika,
/// dan kode status HTTP kalau ada.
class ChatFailure {
  const ChatFailure(this.message, {this.code = 'unknown', this.statusCode});

  final String message;
  final String code;
  final int? statusCode;

  /// Gagal karena tidak ada sambungan ke server, bukan karena server menolak.
  bool get offline => code == 'offline';
}

/// Satu percakapan yang sedang terbuka di layar. Pesan dikirim ke server untuk
/// disimpan setelah selesai (bukan per token), dan tidak disimpan sama sekali
/// kalau "Simpan riwayat" dimatikan.
///
/// Selama jawaban mengalir, [background] meminta sistem menjaga proses tetap
/// hidup, jadi jawaban tetap selesai dan tersimpan walau pengguna keluar dari
/// aplikasi. Kalau aplikasi sedang tidak terlihat saat jawaban berakhir,
/// pengguna diberi tahu lewat pemberitahuan.
class ChatController extends ChangeNotifier {
  ChatController({
    required this.app,
    required this.session,
    BackgroundRun background = const PlatformBackgroundRun(),
  }) : _background = background;

  final AppState app;
  final Session session;
  final BackgroundRun _background;

  /// Dipakai layar untuk menyembunyikan aplikasi (bukan menutupnya) saat tombol
  /// kembali ditekan di tengah jawaban.
  BackgroundRun get background => _background;

  static const int _contextLimit = 40;
  static const String _newTitle = 'Percakapan baru';

  final List<ChatMessage> _messages = [];
  late final UnmodifiableListView<ChatMessage> messages =
      UnmodifiableListView(_messages);

  String? _conversationId;
  DateTime? _createdAt;
  String _title = _newTitle;
  String _modelLabel = '';
  String _lastPreview = '';
  bool _streaming = false;
  bool _loading = false;
  ChatFailure? _failure;
  StreamSubscription<ChatEvent>? _subscription;
  bool _disposed = false;

  String? get conversationId => _conversationId;

  String get title => _title;

  bool get isEmpty => _messages.isEmpty;

  bool get isStreaming => _streaming;

  bool get isLoading => _loading;

  ChatFailure? get failure => _failure;

  bool get canRetry => _failure != null && !_streaming && _messages.isNotEmpty;

  void send(String text, {List<ChatAttachment> attachments = const []}) {
    final content = text.trim();
    if (content.isEmpty || _streaming || _loading) return;

    final message = ChatMessage(
      id: newId(),
      role: ChatRole.user,
      content: content,
      createdAt: DateTime.now(),
      attachments: List<ChatAttachment>.unmodifiable(attachments),
    );
    if (_messages.isEmpty) {
      _title = titleFrom(content);
      _conversationId ??= newId();
    }
    _messages.add(message);
    _failure = null;
    _save(message);
    _ask();
  }

  void retry() {
    if (!canRetry) return;
    if (_messages.last.role == ChatRole.assistant) {
      _messages.removeLast();
    }
    if (_messages.isNotEmpty && _messages.last.role == ChatRole.user) {
      _ask();
    }
  }

  void regenerate() {
    if (_streaming || _messages.isEmpty) return;
    final last = _messages.last;
    if (last.role != ChatRole.assistant) return;
    _messages.removeLast();
    _deleteRemote(last);
    _ask();
  }

  void stop() {
    _cancelStream(persistPartial: true);
    _notify();
  }

  /// Mengosongkan layar untuk percakapan baru. [persistPartial] false dipakai
  /// saat riwayatnya sendiri dihapus, supaya jawaban setengah jadi tidak
  /// menghidupkan kembali percakapan yang baru dihapus.
  void reset({bool persistPartial = true}) {
    _cancelStream(persistPartial: persistPartial);
    _messages.clear();
    _conversationId = null;
    _createdAt = null;
    _title = _newTitle;
    _modelLabel = '';
    _lastPreview = '';
    _failure = null;
    _loading = false;
    _notify();
  }

  Future<void> open(Conversation conversation) async {
    if (_conversationId == conversation.id) return;
    _cancelStream(persistPartial: true);
    _messages.clear();
    _conversationId = conversation.id;
    _createdAt = conversation.createdAt;
    _title = conversation.title;
    _modelLabel = conversation.modelLabel;
    _lastPreview = conversation.preview;
    _failure = null;
    _loading = true;
    _notify();

    try {
      final loaded = await session.repository.messages(conversation.id);
      if (_conversationId != conversation.id) return;
      _messages.addAll(loaded);
    } catch (error) {
      if (_conversationId != conversation.id) return;
      _failure = _failureFrom(
        error,
        'Percakapan gagal dimuat. Periksa koneksi lalu buka lagi.',
      );
    }
    _loading = false;
    _notify();
  }

  void rate(ChatMessage message, int value) {
    final next = message.rating == value ? 0 : value;
    message.rating = next;
    _notify();
    final id = _conversationId;
    if (id == null || !app.settings.saveHistory || session.history.unavailable) {
      return;
    }
    _enqueue(() => session.repository.setRating(id, message.id, next));
  }

  String toMarkdown() {
    final buffer = StringBuffer('# $_title\n\n');
    for (final message in _messages) {
      if (message.content.trim().isEmpty) continue;
      buffer.write(message.role == ChatRole.user ? '**Kamu**' : '**QELVO**');
      buffer.write('\n\n${message.content.trim()}\n\n');
      if (message.attachments.isNotEmpty) {
        buffer.write('_(${message.attachments.length} foto dilampirkan)_\n\n');
      }
    }
    return buffer.toString().trimRight();
  }

  void _ask() {
    final placeholder = ChatMessage(
      id: newId(),
      role: ChatRole.assistant,
      content: '',
      createdAt: DateTime.now(),
    );
    final context = _messages.length > _contextLimit
        ? _messages.sublist(_messages.length - _contextLimit)
        : List<ChatMessage>.of(_messages);
    _messages.add(placeholder);
    _streaming = true;
    _failure = null;
    _notify();
    _beginRun();

    final catalog = app.catalog;
    final images = imagesForRequest(context);
    final stream = app.api.streamChat(
      messages: [
        for (final m in context)
          {
            'role': m.role.name,
            'content': m.content,
            if (images != null && images.messageId == m.id)
              'images': [
                for (final attachment in images.attachments)
                  {
                    'mime': attachment.mime,
                    'data': base64Encode(attachment.full!),
                  },
              ],
          },
      ],
      providerId: catalog.activeProvider?.id,
      modelId: catalog.activeModel?.id,
      thinking: app.settings.thinking,
      instruction: app.settings.instruction.name,
    );

    _subscription = stream.listen(
      (event) {
        if (event is DeltaEvent) {
          placeholder.content += event.text;
          _notify();
        } else if (event is MetaEvent && event.modelLabel.isNotEmpty) {
          _modelLabel = event.modelLabel;
        }
      },
      onError: (Object error) => _fail(placeholder, error),
      onDone: () => _complete(placeholder),
      cancelOnError: true,
    );
  }

  void _complete(ChatMessage placeholder) {
    _subscription = null;
    _streaming = false;
    if (placeholder.content.trim().isEmpty) {
      _messages.remove(placeholder);
      _failure = const ChatFailure(
        'QELVO tidak mengirim jawaban. Coba lagi.',
        code: 'empty_response',
      );
      _endRun(RunOutcome.failed);
    } else {
      _save(placeholder);
      _endRun(RunOutcome.done);
    }
    _notify();
  }

  void _fail(ChatMessage placeholder, Object error) {
    _subscription = null;
    _streaming = false;
    _failure = _failureFrom(error, 'Terjadi kesalahan. Coba lagi.');
    if (placeholder.content.trim().isEmpty) {
      _messages.remove(placeholder);
    }
    _endRun(RunOutcome.failed);
    _notify();
  }

  ChatFailure _failureFrom(Object error, String fallback) {
    if (error is ApiException) {
      return ChatFailure(
        error.message,
        code: error.code,
        statusCode: error.statusCode,
      );
    }
    return ChatFailure(fallback);
  }

  void _cancelStream({required bool persistPartial}) {
    final subscription = _subscription;
    if (subscription == null) return;
    _subscription = null;
    unawaited(subscription.cancel());
    _streaming = false;
    _endRun(RunOutcome.cancelled);
    if (_messages.isEmpty || _messages.last.role != ChatRole.assistant) return;
    final last = _messages.last;
    if (last.content.trim().isEmpty) {
      _messages.removeLast();
    } else if (persistPartial) {
      _save(last);
    }
  }

  void _save(ChatMessage message) {
    if (!app.settings.saveHistory || session.history.unavailable) return;
    final id = _conversationId;
    if (id == null) return;

    final now = DateTime.now();
    if (message.role == ChatRole.assistant) {
      _lastPreview = previewFrom(message.content);
    }
    final conversation = Conversation(
      id: id,
      title: _title,
      modelLabel: _modelLabel,
      createdAt: _createdAt ??= now,
      updatedAt: now,
      preview: _lastPreview,
    );
    // Salinan, karena isi pesan masih bisa berubah sebelum giliran antreannya tiba.
    final snapshot = ChatMessage(
      id: message.id,
      role: message.role,
      content: message.content,
      createdAt: message.createdAt,
      rating: message.rating,
      attachments: message.attachments,
    );
    _enqueue(() async {
      await session.repository.save(
        conversation: conversation,
        message: snapshot,
      );
      unawaited(session.history.refresh());
    });
  }

  void _deleteRemote(ChatMessage message) {
    final id = _conversationId;
    if (id == null || !app.settings.saveHistory || session.history.unavailable) {
      return;
    }
    _enqueue(() => session.repository.deleteMessage(id, message.id));
  }

  /// Simpan, nilai, dan hapus berjalan berurutan lewat antrean sesi. Tanpa
  /// itu, permintaan yang berangkat bersamaan bisa tiba terbalik di server
  /// (misalnya penilaian lebih dulu daripada pesannya). Gagal menyimpan tidak
  /// boleh mengganggu chat yang sedang berjalan.
  void _enqueue(Future<void> Function() job) {
    unawaited(
      session.enqueue(job).catchError((Object error) {
        if (error is ApiException) session.history.noteFailure(error);
      }),
    );
  }

  /// Jawaban mulai dialirkan: minta sistem menjaga proses tetap hidup kalau
  /// aplikasi ditinggal.
  void _beginRun() {
    unawaited(
      _background.begin(
        title: app.settings.thinking
            ? 'QELVO sedang berpikir'
            : 'QELVO sedang menjawab',
        text: 'Jawaban tetap berjalan walau kamu keluar dari aplikasi.',
      ),
    );
  }

  /// Jawaban berakhir. Pengguna diberi tahu hanya kalau aplikasi sedang tidak
  /// terlihat dan bukan dia yang menghentikannya.
  void _endRun(RunOutcome outcome) {
    unawaited(
      _background.end(
        notice: noticeFor(outcome, inBackground: appInBackground()),
      ),
    );
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _cancelStream(persistPartial: true);
    super.dispose();
  }
}
