import 'dart:async';
import 'dart:collection';

import 'package:flutter/foundation.dart';
import 'package:qelvo_ai/data/api_client.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/data/sse.dart';
import 'package:qelvo_ai/state/app_state.dart';
import 'package:qelvo_ai/state/session.dart';

/// Satu percakapan yang sedang terbuka di layar. Pesan disimpan ke Firestore
/// setelah selesai (bukan per token), dan tidak disimpan sama sekali kalau
/// "Simpan riwayat" dimatikan.
class ChatController extends ChangeNotifier {
  ChatController({required this.app, required this.session});

  final AppState app;
  final Session session;

  static const int _contextLimit = 40;
  static const String _newTitle = 'Percakapan baru';

  final List<ChatMessage> _messages = [];
  late final UnmodifiableListView<ChatMessage> messages =
      UnmodifiableListView(_messages);

  String? _conversationId;
  DateTime? _createdAt;
  String _title = _newTitle;
  String _modelLabel = '';
  String _lastPreview = '';
  bool _streaming = false;
  bool _loading = false;
  String? _error;
  StreamSubscription<ChatEvent>? _subscription;
  bool _disposed = false;

  String? get conversationId => _conversationId;

  String get title => _title;

  bool get isEmpty => _messages.isEmpty;

  bool get isStreaming => _streaming;

  bool get isLoading => _loading;

  String? get error => _error;

  bool get canRetry => _error != null && !_streaming && _messages.isNotEmpty;

  void send(String text) {
    final content = text.trim();
    if (content.isEmpty || _streaming || _loading) return;

    final message = ChatMessage(
      id: newId(),
      role: ChatRole.user,
      content: content,
      createdAt: DateTime.now(),
    );
    if (_messages.isEmpty) {
      _title = titleFrom(content);
      _conversationId ??= newId();
    }
    _messages.add(message);
    _error = null;
    unawaited(_save(message));
    _ask();
  }

  void retry() {
    if (!canRetry) return;
    if (_messages.last.role == ChatRole.assistant) {
      _messages.removeLast();
    }
    if (_messages.isNotEmpty && _messages.last.role == ChatRole.user) {
      _ask();
    }
  }

  void regenerate() {
    if (_streaming || _messages.isEmpty) return;
    final last = _messages.last;
    if (last.role != ChatRole.assistant) return;
    _messages.removeLast();
    _deleteRemote(last);
    _ask();
  }

  void stop() {
    _cancelStream(persistPartial: true);
    _notify();
  }

  void reset() {
    _cancelStream(persistPartial: true);
    _messages.clear();
    _conversationId = null;
    _createdAt = null;
    _title = _newTitle;
    _modelLabel = '';
    _lastPreview = '';
    _error = null;
    _loading = false;
    _notify();
  }

  Future<void> open(Conversation conversation) async {
    if (_conversationId == conversation.id) return;
    _cancelStream(persistPartial: true);
    _messages.clear();
    _conversationId = conversation.id;
    _createdAt = conversation.createdAt;
    _title = conversation.title;
    _modelLabel = conversation.modelLabel;
    _lastPreview = conversation.preview;
    _error = null;
    _loading = true;
    _notify();

    try {
      final loaded = await session.repository.messages(conversation.id);
      if (_conversationId != conversation.id) return;
      _messages.addAll(loaded);
    } catch (_) {
      if (_conversationId != conversation.id) return;
      _error = 'Percakapan gagal dimuat. Periksa koneksi lalu buka lagi.';
    }
    _loading = false;
    _notify();
  }

  void rate(ChatMessage message, int value) {
    final next = message.rating == value ? 0 : value;
    message.rating = next;
    _notify();
    final id = _conversationId;
    if (id == null || !app.settings.saveHistory) return;
    unawaited(
      session.repository.setRating(id, message.id, next).catchError((_) {}),
    );
  }

  String toMarkdown() {
    final buffer = StringBuffer('# $_title\n\n');
    for (final message in _messages) {
      if (message.content.trim().isEmpty) continue;
      buffer.write(message.role == ChatRole.user ? '**Kamu**' : '**QELVO**');
      buffer.write('\n\n${message.content.trim()}\n\n');
    }
    return buffer.toString().trimRight();
  }

  void _ask() {
    final placeholder = ChatMessage(
      id: newId(),
      role: ChatRole.assistant,
      content: '',
      createdAt: DateTime.now(),
    );
    final context = _messages.length > _contextLimit
        ? _messages.sublist(_messages.length - _contextLimit)
        : List<ChatMessage>.of(_messages);
    _messages.add(placeholder);
    _streaming = true;
    _error = null;
    _notify();

    final catalog = app.catalog;
    final stream = app.api.streamChat(
      messages: [
        for (final m in context) {'role': m.role.name, 'content': m.content},
      ],
      providerId: catalog.activeProvider?.id,
      modelId: catalog.activeModel?.id,
      thinking: app.settings.thinking,
      instruction: app.settings.instruction.name,
    );

    _subscription = stream.listen(
      (event) {
        if (event is DeltaEvent) {
          placeholder.content += event.text;
          _notify();
        } else if (event is MetaEvent && event.modelLabel.isNotEmpty) {
          _modelLabel = event.modelLabel;
        }
      },
      onError: (Object error) => _fail(placeholder, error),
      onDone: () => _complete(placeholder),
      cancelOnError: true,
    );
  }

  void _complete(ChatMessage placeholder) {
    _subscription = null;
    _streaming = false;
    if (placeholder.content.trim().isEmpty) {
      _messages.remove(placeholder);
      _error = 'QELVO tidak mengirim jawaban. Coba lagi.';
    } else {
      unawaited(_save(placeholder));
    }
    _notify();
  }

  void _fail(ChatMessage placeholder, Object error) {
    _subscription = null;
    _streaming = false;
    _error =
        error is ApiException ? error.message : 'Terjadi kesalahan. Coba lagi.';
    if (placeholder.content.trim().isEmpty) {
      _messages.remove(placeholder);
    }
    _notify();
  }

  void _cancelStream({required bool persistPartial}) {
    final subscription = _subscription;
    if (subscription == null) return;
    _subscription = null;
    unawaited(subscription.cancel());
    _streaming = false;
    if (_messages.isEmpty || _messages.last.role != ChatRole.assistant) return;
    final last = _messages.last;
    if (last.content.trim().isEmpty) {
      _messages.removeLast();
    } else if (persistPartial) {
      unawaited(_save(last));
    }
  }

  Future<void> _save(ChatMessage message) async {
    if (!app.settings.saveHistory) return;
    final id = _conversationId;
    if (id == null) return;

    final now = DateTime.now();
    if (message.role == ChatRole.assistant) {
      _lastPreview = previewFrom(message.content);
    }
    final conversation = Conversation(
      id: id,
      title: _title,
      modelLabel: _modelLabel,
      createdAt: _createdAt ??= now,
      updatedAt: now,
      preview: _lastPreview,
    );
    try {
      await session.repository.save(
        conversation: conversation,
        message: message,
      );
    } catch (_) {
      // Gagal menyimpan tidak boleh mengganggu chat yang sedang berjalan.
    }
  }

  void _deleteRemote(ChatMessage message) {
    final id = _conversationId;
    if (id == null || !app.settings.saveHistory) return;
    unawaited(
      session.repository.deleteMessage(id, message.id).catchError((_) {}),
    );
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _cancelStream(persistPartial: true);
    super.dispose();
  }
}
