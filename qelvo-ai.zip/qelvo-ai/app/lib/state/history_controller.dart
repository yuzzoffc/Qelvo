import 'dart:async';

import 'package:firebase_core/firebase_core.dart' show FirebaseException;
import 'package:flutter/foundation.dart';
import 'package:qelvo_ai/data/chat_repository.dart';
import 'package:qelvo_ai/data/models.dart';

class HistoryController extends ChangeNotifier {
  HistoryController(this._repository);

  final ChatRepository _repository;

  StreamSubscription<List<Conversation>>? _subscription;
  List<Conversation> _items = const [];
  bool _loading = true;
  String? _error;
  bool _disposed = false;

  List<Conversation> get items => _items;

  bool get loading => _loading;

  String? get error => _error;

  /// Mulai (atau ulangi) mendengarkan perubahan. Firestore mengirim data dari
  /// cache lokal lebih dulu, jadi daftar tetap muncul saat koneksi lambat.
  void start() {
    _subscription?.cancel();
    _loading = true;
    _error = null;
    _notify();
    _subscription = _repository.watchConversations().listen(
      (list) {
        _items = list;
        _loading = false;
        _error = null;
        _notify();
      },
      onError: (Object error) {
        _loading = false;
        _error = error is FirebaseException && error.code == 'permission-denied'
            ? 'Akses riwayat ditolak. Pasang aturan dari firestore.rules di Firebase Console (lihat docs/SETUP.md).'
            : 'Riwayat gagal dimuat. Periksa koneksi lalu coba lagi.';
        _notify();
      },
    );
  }

  /// Pencarian dilakukan di perangkat, pada judul dan cuplikan jawaban terakhir.
  List<Conversation> search(String query) {
    final needle = query.trim().toLowerCase();
    if (needle.isEmpty) return _items;
    return _items
        .where((c) =>
            c.title.toLowerCase().contains(needle) ||
            c.preview.toLowerCase().contains(needle))
        .toList();
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _subscription?.cancel();
    super.dispose();
  }
}
