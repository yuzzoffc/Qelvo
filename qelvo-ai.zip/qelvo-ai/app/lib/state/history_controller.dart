import 'package:flutter/foundation.dart';
import 'package:qelvo_ai/data/api_client.dart';
import 'package:qelvo_ai/data/chat_repository.dart';
import 'package:qelvo_ai/data/models.dart';

/// Daftar percakapan di drawer riwayat. Data diambil dari server tiap kali
/// [refresh] dipanggil: saat sesi mulai, saat drawer dibuka, dan setelah ada
/// pesan yang tersimpan atau dihapus.
class HistoryController extends ChangeNotifier {
  HistoryController(this._repository);

  final ChatRepository _repository;

  List<Conversation> _items = const [];
  bool _loading = false;
  String? _error;
  bool _unavailable = false;
  bool _running = false;
  bool _again = false;
  bool _disposed = false;

  List<Conversation> get items => _items;

  bool get loading => _loading;

  String? get error => _error;

  /// True kalau server menyatakan riwayat tidak aktif (belum ada akun layanan
  /// Firebase, atau Firestore belum dibuat). Penyimpanan dilewati sampai
  /// pemuatan berikutnya berhasil, supaya tiap pesan tidak memicu error.
  bool get unavailable => _unavailable;

  /// Memuat ulang daftar. Panggilan yang datang saat pemuatan masih berjalan
  /// digabung jadi satu pemuatan lagi sesudahnya. Daftar lama tetap tampil
  /// kalau pemuatan gagal.
  Future<void> refresh() async {
    if (_disposed) return;
    if (_running) {
      _again = true;
      return;
    }
    _running = true;
    if (_items.isEmpty) {
      _loading = true;
      _error = null;
      _notify();
    }
    try {
      do {
        _again = false;
        try {
          _items = await _repository.conversations();
          _error = null;
          _unavailable = false;
        } on ApiException catch (error) {
          _error = error.message;
          _markUnavailable(error);
        } catch (_) {
          _error = 'Riwayat gagal dimuat. Periksa koneksi lalu coba lagi.';
        }
      } while (_again && !_disposed);
    } finally {
      _running = false;
      _loading = false;
      _notify();
    }
  }

  /// Dicatat saat penyimpanan ditolak server. Hanya kegagalan yang berarti
  /// riwayat memang tidak aktif yang ditandai; gagal sesaat (jaringan putus,
  /// pesan sudah tidak ada) dilewati begitu saja.
  void noteFailure(ApiException error) {
    if (_markUnavailable(error)) {
      _error = error.message;
      _notify();
    }
  }

  bool _markUnavailable(ApiException error) {
    final off =
        error.code == 'history_disabled' || error.code == 'history_not_ready';
    if (off) _unavailable = true;
    return off;
  }

  /// Pencarian dilakukan di perangkat, pada judul dan cuplikan jawaban terakhir.
  List<Conversation> search(String query) {
    final needle = query.trim().toLowerCase();
    if (needle.isEmpty) return _items;
    return _items
        .where((c) =>
            c.title.toLowerCase().contains(needle) ||
            c.preview.toLowerCase().contains(needle))
        .toList();
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}
