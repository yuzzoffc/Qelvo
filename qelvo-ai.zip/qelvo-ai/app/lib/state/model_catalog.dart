import 'package:flutter/foundation.dart';
import 'package:qelvo_ai/data/api_client.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/data/settings_store.dart';

enum CatalogStatus { idle, loading, ready, failed }

/// Daftar penyedia AI yang dikonfigurasi di server. Pilihan pengguna disimpan
/// di [SettingsStore]; kalau pilihan itu sudah tidak ada di server, yang
/// dipakai adalah bawaan server.
class ModelCatalog extends ChangeNotifier {
  ModelCatalog(this._settings, this._api);

  final SettingsStore _settings;
  final ApiClient _api;

  CatalogStatus _status = CatalogStatus.idle;
  String? _error;
  List<ProviderInfo> _providers = const [];
  String _defaultProvider = '';

  CatalogStatus get status => _status;

  String? get error => _error;

  List<ProviderInfo> get providers => _providers;

  Future<void> load() async {
    if (_status == CatalogStatus.loading) return;
    _status = CatalogStatus.loading;
    _error = null;
    notifyListeners();
    try {
      final data = await _api.fetchCatalog();
      _providers = data.providers;
      _defaultProvider = data.defaultProvider;
      _status = CatalogStatus.ready;
    } on ApiException catch (error) {
      _status = CatalogStatus.failed;
      _error = error.message;
    }
    notifyListeners();
  }

  /// Dipanggil saat keluar akun, supaya login berikutnya memuat ulang.
  void reset() {
    _status = CatalogStatus.idle;
    _error = null;
    _providers = const [];
    _defaultProvider = '';
    notifyListeners();
  }

  ProviderInfo? get activeProvider {
    if (_providers.isEmpty) return null;
    final wanted = _settings.providerId ?? _defaultProvider;
    for (final provider in _providers) {
      if (provider.id == wanted) return provider;
    }
    return _providers.first;
  }

  ModelOption? get activeModel {
    final provider = activeProvider;
    if (provider == null || provider.models.isEmpty) return null;
    final wanted = _settings.modelId ?? provider.defaultModel;
    for (final model in provider.models) {
      if (model.id == wanted) return model;
    }
    for (final model in provider.models) {
      if (model.id == provider.defaultModel) return model;
    }
    return provider.models.first;
  }

  Future<void> selectProvider(ProviderInfo provider) =>
      _settings.setSelection(providerId: provider.id, modelId: null);

  Future<void> selectModel(ModelOption model) => _settings.setSelection(
        providerId: activeProvider?.id,
        modelId: model.id,
      );
}
