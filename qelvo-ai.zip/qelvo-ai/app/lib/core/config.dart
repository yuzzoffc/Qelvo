/// Nilai yang diisi saat build lewat `--dart-define-from-file=env.json`.
class AppConfig {
  const AppConfig._();

  /// Versi cadangan untuk tampilan, diisi build lewat `APP_VERSION`. Pembaruan
  /// membandingkan versi yang dibaca dari APK-nya (`UpdateController.installed`),
  /// bukan nilai ini.
  static const String version =
      String.fromEnvironment('APP_VERSION', defaultValue: '0.1.0');

  /// Repositori GitHub (`pemilik/nama`) tempat rilis OTA dibaca, diisi build lewat
  /// `UPDATE_REPO`. Kosong (build lokal) berarti pembaruan lewat aplikasi mati.
  static const String updateRepo = String.fromEnvironment('UPDATE_REPO');

  static bool get updatesEnabled =>
      RegExp(r'^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$').hasMatch(updateRepo);

  static const String _serverUrl = String.fromEnvironment('QELVO_API_URL');

  /// Alamat backend. Hanya berasal dari build, tidak bisa dilihat atau diubah
  /// dari dalam aplikasi, dan tidak ditulis di pesan galat.
  /// 10.0.2.2 adalah alamat localhost komputer dari dalam emulator Android.
  static String get serverUrl =>
      _serverUrl.isEmpty ? 'http://10.0.2.2:8000' : _serverUrl;

  static const String firebaseApiKey = String.fromEnvironment('FIREBASE_API_KEY');
  static const String firebaseAppId = String.fromEnvironment('FIREBASE_APP_ID');
  static const String firebaseProjectId =
      String.fromEnvironment('FIREBASE_PROJECT_ID');
  static const String firebaseSenderId =
      String.fromEnvironment('FIREBASE_SENDER_ID');
  static const String firebaseStorageBucket =
      String.fromEnvironment('FIREBASE_STORAGE_BUCKET');

  /// Login email dengan kode (OTP). Aktif secara bawaan; matikan lewat
  /// `EMAIL_LOGIN=false` di env.json. Server harus punya SMTP.
  static const bool emailLogin =
      bool.fromEnvironment('EMAIL_LOGIN', defaultValue: true);

  static bool get firebaseConfigured =>
      firebaseApiKey.isNotEmpty &&
      firebaseAppId.isNotEmpty &&
      firebaseProjectId.isNotEmpty &&
      firebaseSenderId.isNotEmpty;
}
