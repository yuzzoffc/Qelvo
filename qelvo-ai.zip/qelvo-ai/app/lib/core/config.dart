/// Nilai yang diisi saat build lewat `--dart-define-from-file=env.json`.
class AppConfig {
  const AppConfig._();

  static const String version = '0.1.0';

  static const String _serverUrl = String.fromEnvironment('QELVO_API_URL');

  /// Alamat backend. Hanya berasal dari build, tidak bisa dilihat atau diubah
  /// dari dalam aplikasi, dan tidak ditulis di pesan galat.
  /// 10.0.2.2 adalah alamat localhost komputer dari dalam emulator Android.
  static String get serverUrl =>
      _serverUrl.isEmpty ? 'http://10.0.2.2:8000' : _serverUrl;

  static const String firebaseApiKey = String.fromEnvironment('FIREBASE_API_KEY');
  static const String firebaseAppId = String.fromEnvironment('FIREBASE_APP_ID');
  static const String firebaseProjectId =
      String.fromEnvironment('FIREBASE_PROJECT_ID');
  static const String firebaseSenderId =
      String.fromEnvironment('FIREBASE_SENDER_ID');
  static const String firebaseStorageBucket =
      String.fromEnvironment('FIREBASE_STORAGE_BUCKET');

  /// Login email dengan kode, dimatikan sementara. Nyalakan lewat
  /// `EMAIL_LOGIN=true` di env.json; server juga harus punya SMTP.
  static const bool emailLogin = bool.fromEnvironment('EMAIL_LOGIN');

  static bool get firebaseConfigured =>
      firebaseApiKey.isNotEmpty &&
      firebaseAppId.isNotEmpty &&
      firebaseProjectId.isNotEmpty &&
      firebaseSenderId.isNotEmpty;
}
