/// Selisih hari kalender (bukan selisih 24 jam), supaya jam 23.59 dan 00.01
/// tetap dianggap beda hari.
int dayDiff(DateTime now, DateTime then) {
  final a = DateTime.utc(now.year, now.month, now.day);
  final b = DateTime.utc(then.year, then.month, then.day);
  return a.difference(b).inDays;
}

/// Label grup di drawer riwayat.
String groupLabel(DateTime now, DateTime then) {
  final diff = dayDiff(now, then);
  if (diff <= 0) return 'Hari ini';
  if (diff == 1) return 'Kemarin';
  if (diff < 7) return '7 hari terakhir';
  return 'Lebih lama';
}
