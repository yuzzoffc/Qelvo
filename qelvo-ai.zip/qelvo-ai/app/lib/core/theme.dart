import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Skala radius: kontrol kecil, kartu, panel besar. Bentuk pil hanya untuk
/// chip dan toggle, supaya tidak semua elemen terlihat sama.
class QelvoRadius {
  const QelvoRadius._();

  static const double sm = 10;
  static const double md = 16;
  static const double lg = 22;
  static const double xl = 28;
}

/// Semua warna dan gaya teks aplikasi. Pasangan teks/latar sudah dicek
/// minimal 4.5:1 di tema gelap dan terang (lihat docs/DESIGN.md).
@immutable
class QelvoTheme extends ThemeExtension<QelvoTheme> {
  const QelvoTheme({
    required this.bg,
    required this.surface,
    required this.bubble,
    required this.codeBg,
    required this.border,
    required this.outline,
    required this.text,
    required this.muted,
    required this.accent,
    required this.accentText,
    required this.onAccent,
    required this.accentSoft,
    required this.accentLine,
    required this.warn,
    required this.codeString,
    required this.codeNumber,
  });

  final Color bg;
  final Color surface;
  final Color bubble;
  final Color codeBg;

  /// Garis tipis pemisah dan tepi kartu.
  final Color border;

  /// Tepi kolom isian, cukup tegas (>= 3:1) agar field terlihat jelas.
  final Color outline;
  final Color text;
  final Color muted;

  /// Warna isian tombol utama.
  final Color accent;

  /// Warna aksen untuk teks dan ikon di atas latar biasa.
  final Color accentText;
  final Color onAccent;
  final Color accentSoft;
  final Color accentLine;

  /// Peringatan dan aksi yang menghapus.
  final Color warn;
  final Color codeString;
  final Color codeNumber;

  static const QelvoTheme dark = QelvoTheme(
    bg: Color(0xFF040810),
    surface: Color(0xFF0B1220),
    bubble: Color(0xFF131C30),
    codeBg: Color(0xFF080E1A),
    border: Color(0xFF172136),
    outline: Color(0xFF4F647F),
    text: Color(0xFFEEF2FA),
    muted: Color(0xFF8F9BB5),
    accent: Color(0xFF34E0F7),
    accentText: Color(0xFF34E0F7),
    onAccent: Color(0xFF031018),
    accentSoft: Color(0xFF0A2830),
    accentLine: Color(0xFF1B8FA0),
    warn: Color(0xFFF2B84B),
    codeString: Color(0xFF9BE3B1),
    codeNumber: Color(0xFFF2B84B),
  );

  static const QelvoTheme light = QelvoTheme(
    bg: Color(0xFFF4F7FB),
    surface: Color(0xFFFFFFFF),
    bubble: Color(0xFFE6EDF6),
    codeBg: Color(0xFFEBF1F8),
    border: Color(0xFFD9E2EC),
    outline: Color(0xFF7C8FA8),
    text: Color(0xFF0B1320),
    muted: Color(0xFF536278),
    accent: Color(0xFF22CBE8),
    accentText: Color(0xFF07697E),
    onAccent: Color(0xFF031018),
    accentSoft: Color(0xFFD5F2F8),
    accentLine: Color(0xFF0A7C95),
    warn: Color(0xFF8F5200),
    codeString: Color(0xFF0B6B3F),
    codeNumber: Color(0xFF8F5200),
  );

  /// Teks isi dan antarmuka padat.
  TextStyle body(
    double size, {
    FontWeight weight = FontWeight.w400,
    Color? color,
    double? height,
    double? spacing,
  }) {
    return GoogleFonts.inter(
      fontSize: size,
      fontWeight: weight,
      color: color ?? text,
      height: height,
      letterSpacing: spacing,
    );
  }

  /// Judul, sapaan, dan wordmark.
  TextStyle display(
    double size, {
    FontWeight weight = FontWeight.w700,
    Color? color,
    double? height,
    double? spacing,
  }) {
    return GoogleFonts.plusJakartaSans(
      fontSize: size,
      fontWeight: weight,
      color: color ?? text,
      height: height,
      letterSpacing: spacing,
    );
  }

  /// Kode dan potongan teknis.
  TextStyle mono(
    double size, {
    FontWeight weight = FontWeight.w400,
    Color? color,
    double? height,
    double? spacing,
  }) {
    return GoogleFonts.jetBrainsMono(
      fontSize: size,
      fontWeight: weight,
      color: color ?? text,
      height: height,
      letterSpacing: spacing,
    );
  }

  static ThemeData themeData(QelvoTheme t, Brightness brightness) {
    final scheme = ColorScheme(
      brightness: brightness,
      primary: t.accent,
      onPrimary: t.onAccent,
      secondary: t.accent,
      onSecondary: t.onAccent,
      error: t.warn,
      onError: t.onAccent,
      surface: t.bg,
      onSurface: t.text,
    );
    final baseText = ThemeData(brightness: brightness).textTheme;
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: t.bg,
      canvasColor: t.bg,
      splashFactory: NoSplash.splashFactory,
      textTheme: GoogleFonts.interTextTheme(baseText)
          .apply(bodyColor: t.text, displayColor: t.text),
      textSelectionTheme: TextSelectionThemeData(
        cursorColor: t.accentText,
        selectionColor: t.accent.withAlpha(80),
        selectionHandleColor: t.accentText,
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: t.bubble,
        contentTextStyle: t.body(14.5),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(QelvoRadius.md),
        ),
      ),
      extensions: <ThemeExtension<dynamic>>[t],
    );
  }

  @override
  QelvoTheme copyWith() => this;

  @override
  QelvoTheme lerp(ThemeExtension<QelvoTheme>? other, double t) {
    if (other is! QelvoTheme) return this;
    Color mix(Color a, Color b) => Color.lerp(a, b, t)!;
    return QelvoTheme(
      bg: mix(bg, other.bg),
      surface: mix(surface, other.surface),
      bubble: mix(bubble, other.bubble),
      codeBg: mix(codeBg, other.codeBg),
      border: mix(border, other.border),
      outline: mix(outline, other.outline),
      text: mix(text, other.text),
      muted: mix(muted, other.muted),
      accent: mix(accent, other.accent),
      accentText: mix(accentText, other.accentText),
      onAccent: mix(onAccent, other.onAccent),
      accentSoft: mix(accentSoft, other.accentSoft),
      accentLine: mix(accentLine, other.accentLine),
      warn: mix(warn, other.warn),
      codeString: mix(codeString, other.codeString),
      codeNumber: mix(codeNumber, other.codeNumber),
    );
  }
}

extension QelvoContext on BuildContext {
  QelvoTheme get q => Theme.of(this).extension<QelvoTheme>()!;
}
