import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Skala radius: kontrol kecil, kartu, panel besar. Bentuk pil hanya untuk
/// chip dan toggle, supaya tidak semua elemen terlihat sama.
class QelvoRadius {
  const QelvoRadius._();

  static const double sm = 10;
  static const double md = 16;
  static const double lg = 22;
  static const double xl = 28;
}

/// Ukuran tata letak yang dipakai bersama oleh kolom tulis dan beranda, supaya
/// sapaan, teks saran, dan isian pesan mulai dari garis kiri yang sama. Kolom
/// tulis memakai angka-angka ini, jadi mengubahnya di satu tempat menggeser
/// semuanya bersama.
class QelvoLayout {
  const QelvoLayout._();

  /// Jarak kartu kolom tulis ke tepi layar.
  static const double cardMargin = 12;

  /// Garis tepi kartu, padding kartu, dan padding kolom isian di dalamnya.
  static const double cardBorder = 1;
  static const double cardPadding = 10;
  static const double fieldPadding = 10;

  /// Jarak awal teks isian ke tepi kartu kolom tulis.
  static const double cardTextInset = cardBorder + cardPadding + fieldPadding;

  /// Jarak awal teks isian ke tepi layar. Sapaan dan teks saran di beranda
  /// mulai dari sini.
  static const double textStart = cardMargin + cardTextInset;
}

/// Semua warna dan gaya teks aplikasi. Pasangan teks/latar sudah dicek
/// minimal 4.5:1 di tema gelap dan terang (lihat docs/DESIGN.md).
@immutable
class QelvoTheme extends ThemeExtension<QelvoTheme> {
  const QelvoTheme({
    required this.bg,
    required this.surface,
    required this.panel,
    required this.bubble,
    required this.raised,
    required this.raisedLine,
    required this.aiBubbleLine,
    required this.codeBg,
    required this.border,
    required this.outline,
    required this.text,
    required this.muted,
    required this.accent,
    required this.onAccent,
    required this.warn,
    required this.codeString,
    required this.codeNumber,
    required this.codeKeyword,
    required this.logoRing,
    required this.logoTail,
  });

  final Color bg;
  final Color surface;

  /// Latar panel samping (drawer riwayat), sedikit di atas [bg].
  final Color panel;

  /// Latar chip kode inline, kepala tabel, dan tombol netral.
  final Color bubble;

  /// Biru navy yang lebih terang dari [surface], untuk hal yang perlu menonjol
  /// tanpa cyan: gelembung pesan pengguna, pilihan yang terpilih, dan ikon yang
  /// menyala. Garis tepinya [raisedLine]. Teks di atasnya memakai [text].
  final Color raised;
  final Color raisedLine;

  /// Garis tepi kartu yang duduk di atas [surface]: kartu jawaban AI (isinya
  /// memakai [surface]) dan kartu di lembar Tambahkan ke chat. Pesan pengguna
  /// berwarna [raised] dan rata kanan, jadi terbedakan dari jawaban AI.
  final Color aiBubbleLine;
  final Color codeBg;

  /// Garis tipis pemisah dan tepi kartu.
  final Color border;

  /// Tepi kolom isian, cukup tegas (>= 3:1) agar field terlihat jelas.
  final Color outline;
  final Color text;
  final Color muted;

  /// Cyan, satu-satunya aksen. Hanya untuk momen kunci: isian tombol utama
  /// (kirim, lanjut), sakelar yang menyala, dan ekor logo. Bukan untuk teks,
  /// tautan, ikon, garis, latar, atau tanda pilihan.
  final Color accent;

  /// Teks dan ikon di atas [accent].
  final Color onAccent;

  /// Peringatan dan aksi yang menghapus.
  final Color warn;
  final Color codeString;
  final Color codeNumber;
  final Color codeKeyword;

  /// Logo QELVO v3.0: cincin dan ekor punya warna sendiri. Di tema terang
  /// ekor memakai #0891B2 (3,5 : 1 di atas putih) karena cyan terlalu pucat.
  /// Warna ekor juga dipakai untuk titik kecil penanda model di bilah atas.
  final Color logoRing;
  final Color logoTail;

  /// Ikon yang sengaja diredupkan supaya tidak berebut perhatian, misalnya
  /// pensil di beranda yang belum punya apa-apa untuk ditulis. Berupa [muted]
  /// dengan alfa 185; tes memastikan hasilnya di atas [bg] tetap minimal 3:1.
  Color get quietIcon => muted.withAlpha(185);

  static const QelvoTheme dark = QelvoTheme(
    bg: Color(0xFF060912),
    surface: Color(0xFF0C1220),
    panel: Color(0xFF080D19),
    bubble: Color(0xFF131C30),
    raised: Color(0xFF263A66),
    raisedLine: Color(0xFF44609B),
    aiBubbleLine: Color(0xFF2B3A5C),
    codeBg: Color(0xFF080D19),
    border: Color(0xFF1B2540),
    outline: Color(0xFF566B88),
    text: Color(0xFFE8EDF7),
    muted: Color(0xFFA8B6CB),
    accent: Color(0xFF3DE0F5),
    onAccent: Color(0xFF031318),
    warn: Color(0xFFF5B84A),
    codeString: Color(0xFF9BE3B1),
    codeNumber: Color(0xFFF5B84A),
    codeKeyword: Color(0xFF9AB0EE),
    logoRing: Color(0xFFF1F5FB),
    logoTail: Color(0xFF3DE0F5),
  );

  static const QelvoTheme light = QelvoTheme(
    bg: Color(0xFFF5F8FC),
    surface: Color(0xFFFFFFFF),
    panel: Color(0xFFFFFFFF),
    bubble: Color(0xFFE6EDF6),
    raised: Color(0xFFCBD8EF),
    raisedLine: Color(0xFF8CA3CF),
    aiBubbleLine: Color(0xFFB4C2D3),
    codeBg: Color(0xFFEBF1F8),
    border: Color(0xFFD9E2EC),
    outline: Color(0xFF72849E),
    text: Color(0xFF0A1226),
    muted: Color(0xFF475770),
    accent: Color(0xFF22CBE8),
    onAccent: Color(0xFF031318),
    warn: Color(0xFF8F5200),
    codeString: Color(0xFF0B6B3F),
    codeNumber: Color(0xFF8F5200),
    codeKeyword: Color(0xFF344AB0),
    logoRing: Color(0xFF0A1226),
    logoTail: Color(0xFF0891B2),
  );

  /// Teks isi dan antarmuka padat.
  TextStyle body(
    double size, {
    FontWeight weight = FontWeight.w400,
    Color? color,
    double? height,
    double? spacing,
  }) {
    return GoogleFonts.inter(
      fontSize: size,
      fontWeight: weight,
      color: color ?? text,
      height: height,
      letterSpacing: spacing,
    );
  }

  /// Judul, sapaan, dan wordmark.
  TextStyle display(
    double size, {
    FontWeight weight = FontWeight.w700,
    Color? color,
    double? height,
    double? spacing,
  }) {
    return GoogleFonts.plusJakartaSans(
      fontSize: size,
      fontWeight: weight,
      color: color ?? text,
      height: height,
      letterSpacing: spacing,
    );
  }

  /// Kode dan potongan teknis.
  TextStyle mono(
    double size, {
    FontWeight weight = FontWeight.w400,
    Color? color,
    double? height,
    double? spacing,
  }) {
    return GoogleFonts.jetBrainsMono(
      fontSize: size,
      fontWeight: weight,
      color: color ?? text,
      height: height,
      letterSpacing: spacing,
    );
  }

  static ThemeData themeData(QelvoTheme t, Brightness brightness) {
    final scheme = ColorScheme(
      brightness: brightness,
      primary: t.text,
      onPrimary: t.bg,
      secondary: t.muted,
      onSecondary: t.bg,
      error: t.warn,
      onError: t.onAccent,
      surface: t.bg,
      onSurface: t.text,
    );
    final baseText = ThemeData(brightness: brightness).textTheme;
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: t.bg,
      canvasColor: t.bg,
      splashFactory: NoSplash.splashFactory,
      textTheme: GoogleFonts.interTextTheme(baseText)
          .apply(bodyColor: t.text, displayColor: t.text),
      textSelectionTheme: TextSelectionThemeData(
        cursorColor: t.text,
        selectionColor: t.outline.withAlpha(110),
        selectionHandleColor: t.text,
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: t.bubble,
        contentTextStyle: t.body(14.5),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(QelvoRadius.md),
        ),
      ),
      extensions: <ThemeExtension<dynamic>>[t],
    );
  }

  @override
  QelvoTheme copyWith() => this;

  @override
  QelvoTheme lerp(ThemeExtension<QelvoTheme>? other, double t) {
    if (other is! QelvoTheme) return this;
    Color mix(Color a, Color b) => Color.lerp(a, b, t)!;
    return QelvoTheme(
      bg: mix(bg, other.bg),
      surface: mix(surface, other.surface),
      panel: mix(panel, other.panel),
      bubble: mix(bubble, other.bubble),
      raised: mix(raised, other.raised),
      raisedLine: mix(raisedLine, other.raisedLine),
      aiBubbleLine: mix(aiBubbleLine, other.aiBubbleLine),
      codeBg: mix(codeBg, other.codeBg),
      border: mix(border, other.border),
      outline: mix(outline, other.outline),
      text: mix(text, other.text),
      muted: mix(muted, other.muted),
      accent: mix(accent, other.accent),
      onAccent: mix(onAccent, other.onAccent),
      warn: mix(warn, other.warn),
      codeString: mix(codeString, other.codeString),
      codeNumber: mix(codeNumber, other.codeNumber),
      codeKeyword: mix(codeKeyword, other.codeKeyword),
      logoRing: mix(logoRing, other.logoRing),
      logoTail: mix(logoTail, other.logoTail),
    );
  }
}

extension QelvoContext on BuildContext {
  QelvoTheme get q => Theme.of(this).extension<QelvoTheme>()!;
}
