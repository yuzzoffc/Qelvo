import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:qelvo_ai/app.dart';
import 'package:qelvo_ai/core/config.dart';
import 'package:qelvo_ai/state/app_state.dart';
import 'package:qelvo_ai/ui/screens/setup_needed_app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  if (!AppConfig.firebaseConfigured) {
    runApp(const SetupNeededApp());
    return;
  }

  try {
    // Opsi diberikan lewat --dart-define, jadi tidak perlu google-services.json
    // atau plugin Gradle tambahan.
    await Firebase.initializeApp(
      options: FirebaseOptions(
        apiKey: AppConfig.firebaseApiKey,
        appId: AppConfig.firebaseAppId,
        messagingSenderId: AppConfig.firebaseSenderId,
        projectId: AppConfig.firebaseProjectId,
        storageBucket: AppConfig.firebaseStorageBucket.isEmpty
            ? null
            : AppConfig.firebaseStorageBucket,
      ),
    );
  } catch (error) {
    runApp(SetupNeededApp(detail: 'Firebase gagal diinisialisasi: $error'));
    return;
  }

  final state = await AppState.create();
  runApp(QelvoApp(state: state));
}
