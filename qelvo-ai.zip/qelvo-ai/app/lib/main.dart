import 'dart:ui' show PlatformDispatcher;

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:qelvo_ai/app.dart';
import 'package:qelvo_ai/core/config.dart';
import 'package:qelvo_ai/data/error_reporter.dart';
import 'package:qelvo_ai/state/app_state.dart';
import 'package:qelvo_ai/ui/screens/setup_needed_app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Crash dan error tak tertangani dilaporkan ke server (lihat error_reporter.dart).
  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.presentError(details);
    errorReporter.report(details.exception, details.stack, kind: 'error');
  };
  PlatformDispatcher.instance.onError = (Object error, StackTrace stack) {
    FlutterError.presentError(
      FlutterErrorDetails(exception: error, stack: stack),
    );
    errorReporter.report(error, stack);
    return true;
  };

  if (!AppConfig.firebaseConfigured) {
    runApp(const SetupNeededApp());
    return;
  }

  try {
    // Opsi diberikan lewat --dart-define. Kalau plugin Google Services aktif
    // (ada app/google-services.json), nilainya harus sama dengan isi berkas itu.
    await Firebase.initializeApp(
      options: FirebaseOptions(
        apiKey: AppConfig.firebaseApiKey,
        appId: AppConfig.firebaseAppId,
        messagingSenderId: AppConfig.firebaseSenderId,
        projectId: AppConfig.firebaseProjectId,
        storageBucket: AppConfig.firebaseStorageBucket.isEmpty
            ? null
            : AppConfig.firebaseStorageBucket,
      ),
    );
  } catch (error) {
    runApp(SetupNeededApp(detail: 'Firebase gagal diinisialisasi: $error'));
    return;
  }

  final state = await AppState.create();
  errorReporter.attach(state.api, () => state.settings.crashReports);
  runApp(QelvoApp(state: state));
}
