import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qelvo_ai/core/theme.dart';
import 'package:qelvo_ai/state/app_state.dart';
import 'package:qelvo_ai/ui/screens/auth_gate.dart';

class QelvoApp extends StatelessWidget {
  const QelvoApp({super.key, required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) {
    return AppScope(
      state: state,
      child: ListenableBuilder(
        listenable: state.settings,
        builder: (context, _) {
          return MaterialApp(
            title: 'QELVO',
            debugShowCheckedModeBanner: false,
            themeMode: state.settings.themeMode,
            theme: QelvoTheme.themeData(QelvoTheme.light, Brightness.light),
            darkTheme: QelvoTheme.themeData(QelvoTheme.dark, Brightness.dark),
            builder: (context, child) => _Chrome(
              textScale: state.settings.textScale.factor,
              child: child ?? const SizedBox.shrink(),
            ),
            home: const AuthGate(),
          );
        },
      ),
    );
  }
}

/// Menerapkan ukuran teks pilihan pengguna di atas ukuran dari sistem, dan
/// menyesuaikan warna ikon bilah status dan navigasi dengan tema.
class _Chrome extends StatelessWidget {
  const _Chrome({required this.textScale, required this.child});

  final double textScale;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final t = context.q;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final media = MediaQuery.of(context);
    final iconBrightness = dark ? Brightness.light : Brightness.dark;
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: iconBrightness,
        systemNavigationBarColor: t.bg,
        systemNavigationBarIconBrightness: iconBrightness,
      ),
      child: MediaQuery(
        data: media.copyWith(
          textScaler: TextScaler.linear(media.textScaler.scale(1) * textScale),
        ),
        child: child,
      ),
    );
  }
}
