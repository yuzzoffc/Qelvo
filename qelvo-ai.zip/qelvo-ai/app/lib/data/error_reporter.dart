import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:qelvo_ai/core/config.dart';
import 'package:qelvo_ai/data/api_client.dart';

/// Mengirim crash dan error tak tertangani ke server (`POST /v1/report`).
/// Isinya hanya teks teknis: pesan error, jejak tumpukan, versi aplikasi, dan
/// jenis perangkat. Tidak ada isi percakapan, nama, atau email.
///
/// Dipasang sekali di `main()`. Laporan hanya terkirim setelah [attach] (butuh
/// token login) dan kalau pengguna belum mematikannya di Pengaturan.
class ErrorReporter {
  ApiClient? _api;
  bool Function() _enabled = () => true;
  int _sent = 0;
  final Set<String> _seen = <String>{};

  /// Batas per sesi aplikasi, supaya error yang berulang tidak membanjiri server.
  static const int maxPerRun = 5;

  void attach(ApiClient api, bool Function() enabled) {
    _api = api;
    _enabled = enabled;
  }

  void report(Object error, StackTrace? stack, {String kind = 'crash'}) {
    final api = _api;
    if (api == null || !_enabled() || _sent >= maxPerRun) return;
    final message = _clip(error.toString(), 600);
    // Error yang sama persis cukup dilaporkan sekali.
    if (!_seen.add(message)) return;
    _sent++;
    unawaited(_send(api, kind, message, _clip(stack?.toString() ?? '', 6000)));
  }

  Future<void> _send(
    ApiClient api,
    String kind,
    String message,
    String stack,
  ) async {
    try {
      await api.request(
        'POST',
        '/v1/report',
        body: {
          'kind': kind,
          'message': message,
          'stack': stack,
          'version': AppConfig.version,
          'platform': defaultTargetPlatform.name,
        },
        timeout: const Duration(seconds: 15),
      );
    } catch (_) {
      // Laporan hanya bantuan. Gagal terkirim tidak boleh jadi masalah baru.
    }
  }

  static String _clip(String text, int max) {
    if (text.length <= max) return text;
    var end = max;
    final last = text.codeUnitAt(end - 1);
    if (last >= 0xD800 && last <= 0xDBFF) end--;
    return text.substring(0, end);
  }
}

/// Satu pelapor untuk seluruh aplikasi, dipasang di `main()`.
final ErrorReporter errorReporter = ErrorReporter();
