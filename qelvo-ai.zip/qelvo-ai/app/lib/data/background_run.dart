import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';

/// Bagaimana satu jawaban berakhir. Menentukan apakah pengguna diberi tahu.
enum RunOutcome { done, failed, cancelled }

/// Isi pemberitahuan yang muncul saat jawaban berakhir di latar belakang.
class RunNotice {
  const RunNotice(this.title, this.text);

  final String title;
  final String text;
}

/// Pemberitahuan untuk akhir sebuah jawaban, atau null kalau tidak perlu:
/// pengguna masih melihat aplikasi, atau dialah yang menghentikan jawabannya.
/// Isi jawaban sengaja tidak ikut ditulis, karena pemberitahuan bisa terbaca
/// di layar kunci.
RunNotice? noticeFor(RunOutcome outcome, {required bool inBackground}) {
  if (!inBackground) return null;
  return switch (outcome) {
    RunOutcome.done => const RunNotice(
        'QELVO sudah menjawab',
        'Ketuk untuk membaca jawabannya.',
      ),
    RunOutcome.failed => const RunNotice(
        'Jawaban QELVO gagal',
        'Ketuk untuk melihat penyebabnya dan mencoba lagi.',
      ),
    RunOutcome.cancelled => null,
  };
}

/// True saat aplikasi tidak terlihat (tombol Home, layar mati). Keadaan
/// `inactive` tidak dihitung: saat itu jawabannya masih bisa dilihat, misalnya
/// di layar terbagi atau saat bilah notifikasi ditarik.
bool appInBackground() {
  try {
    final state = WidgetsBinding.instance.lifecycleState;
    return state == AppLifecycleState.paused ||
        state == AppLifecycleState.hidden;
  } catch (_) {
    // Belum ada binding (tes tanpa Flutter): anggap aplikasi terlihat.
    return false;
  }
}

/// Menjaga jawaban yang sedang dialirkan tetap berjalan saat aplikasi
/// ditinggal. Di Android ini berupa layanan latar depan dengan pemberitahuan
/// "sedang menjawab"; tanpa itu sistem bisa membekukan proses beberapa saat
/// setelah layar mati atau aplikasi ditutup dan memutus aliran jawaban.
abstract class BackgroundRun {
  /// Jawaban mulai. [title] dan [text] tampil di pemberitahuan selama berjalan.
  Future<void> begin({required String title, required String text});

  /// Jawaban berakhir. Layanan dihentikan; kalau [notice] ada, pengguna diberi
  /// tahu bahwa jawabannya sudah siap atau gagal.
  Future<void> end({RunNotice? notice});

  /// Menyembunyikan aplikasi tanpa menutupnya, seperti tombol Home.
  Future<void> moveToBack();
}

/// Implementasi lewat MethodChannel ke MainActivity (`tool/android/`).
///
/// Kegagalan di sini tidak boleh mengganggu chat. Di luar Android (tes,
/// desktop) salurannya memang tidak ada, dan di Android sistem bisa menolak
/// layanan latar depan. Dalam kedua kasus jawaban tetap berjalan selama
/// aplikasi terbuka, hanya tidak dilindungi saat ditinggal.
class PlatformBackgroundRun implements BackgroundRun {
  const PlatformBackgroundRun();

  static const MethodChannel _channel =
      MethodChannel('com.qelvo.qelvo_ai/background');

  @override
  Future<void> begin({required String title, required String text}) {
    return _call('begin', {'title': title, 'text': text});
  }

  @override
  Future<void> end({RunNotice? notice}) {
    return _call('end', {
      'notify': notice != null,
      'title': notice?.title,
      'text': notice?.text,
    });
  }

  @override
  Future<void> moveToBack() => _call('moveToBack');

  Future<void> _call(String method, [Map<String, Object?>? arguments]) async {
    try {
      await _channel.invokeMethod<Object?>(method, arguments);
    } catch (_) {
      // Lihat catatan kelas: gagal diam-diam adalah perilaku yang disengaja.
    }
  }
}
