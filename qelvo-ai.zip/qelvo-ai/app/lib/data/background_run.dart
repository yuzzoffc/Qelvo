import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';

/// Bagaimana satu jawaban berakhir. Menentukan apakah pengguna diberi tahu.
enum RunOutcome { done, failed, cancelled }

/// Isi pemberitahuan yang muncul saat jawaban berakhir di latar belakang.
class RunNotice {
  const RunNotice(this.title, this.text);

  final String title;
  final String text;
}

/// Pemberitahuan untuk akhir sebuah jawaban, atau null kalau tidak perlu. Satu-satunya
/// pemberitahuan aplikasi: hanya saat QELVO selesai menjawab dan aplikasi sedang
/// tidak terlihat. Jawaban yang gagal atau dihentikan pengguna tidak memberi
/// pemberitahuan; kegagalannya tampil di chat saat pengguna kembali. Isi jawaban
/// sengaja tidak ditulis, karena pemberitahuan bisa terbaca di layar kunci.
RunNotice? noticeFor(RunOutcome outcome, {required bool inBackground}) {
  if (!inBackground || outcome != RunOutcome.done) return null;
  return const RunNotice(
    'QELVO sudah menjawab',
    'Ketuk untuk membaca jawabannya.',
  );
}

/// True saat aplikasi tidak terlihat (tombol Home, layar mati). Keadaan
/// `inactive` tidak dihitung: saat itu jawabannya masih bisa dilihat, misalnya
/// di layar terbagi atau saat bilah notifikasi ditarik.
bool appInBackground() {
  try {
    final state = WidgetsBinding.instance.lifecycleState;
    return state == AppLifecycleState.paused ||
        state == AppLifecycleState.hidden;
  } catch (_) {
    // Belum ada binding (tes tanpa Flutter): anggap aplikasi terlihat.
    return false;
  }
}

/// Menjaga jawaban yang sedang dialirkan tetap berjalan saat aplikasi ditinggal.
/// Di Android ini berupa wake lock berbatas waktu, tanpa pemberitahuan selama
/// berjalan: pemberitahuan hanya muncul saat jawaban selesai. Tanpa layanan latar
/// depan, Android masih bisa memutus jawaban saat layar mati lama, saat penghemat
/// baterai menyala, atau saat sistem mematikan proses aplikasi.
abstract class BackgroundRun {
  /// Jawaban mulai.
  Future<void> begin();

  /// Jawaban berakhir. Wake lock dilepas; kalau [notice] ada, pengguna diberi
  /// tahu bahwa jawabannya sudah siap.
  Future<void> end({RunNotice? notice});

  /// Menyembunyikan aplikasi tanpa menutupnya, seperti tombol Home.
  Future<void> moveToBack();
}

/// Implementasi lewat MethodChannel ke MainActivity (`tool/android/`).
///
/// Kegagalan di sini tidak boleh mengganggu chat. Di luar Android (tes,
/// desktop) salurannya memang tidak ada. Jawaban tetap berjalan selama aplikasi
/// terbuka, hanya tidak dilindungi saat ditinggal.
class PlatformBackgroundRun implements BackgroundRun {
  const PlatformBackgroundRun();

  static const MethodChannel _channel =
      MethodChannel('com.qelvo.qelvo_ai/background');

  @override
  Future<void> begin() => _call('begin');

  @override
  Future<void> end({RunNotice? notice}) {
    return _call('end', {
      'notify': notice != null,
      'title': notice?.title,
      'text': notice?.text,
    });
  }

  @override
  Future<void> moveToBack() => _call('moveToBack');

  Future<void> _call(String method, [Map<String, Object?>? arguments]) async {
    try {
      await _channel.invokeMethod<Object?>(method, arguments);
    } catch (_) {
      // Lihat catatan kelas: gagal diam-diam adalah perilaku yang disengaja.
    }
  }
}
