import 'dart:async';

import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';

/// Bagaimana satu jawaban berakhir. Menentukan apakah pengguna diberi tahu.
enum RunOutcome { done, failed, cancelled }

/// Isi pemberitahuan yang muncul saat jawaban berakhir di latar belakang.
class RunNotice {
  const RunNotice(this.title, this.text);

  final String title;
  final String text;
}

/// Pemberitahuan untuk akhir sebuah jawaban, atau null kalau tidak perlu. Satu-satunya
/// pemberitahuan aplikasi: hanya saat QELVO selesai menjawab dan aplikasi sedang
/// tidak terlihat. Jawaban yang gagal atau dihentikan pengguna tidak memberi
/// pemberitahuan; kegagalannya tampil di chat saat pengguna kembali. Isi jawaban
/// sengaja tidak ditulis, karena pemberitahuan bisa terbaca di layar kunci.
RunNotice? noticeFor(RunOutcome outcome, {required bool inBackground}) {
  if (!inBackground || outcome != RunOutcome.done) return null;
  return const RunNotice(
    'QELVO sudah menjawab',
    'Ketuk untuk membaca jawabannya.',
  );
}

/// True saat aplikasi tidak terlihat (tombol Home, layar mati). Keadaan
/// `inactive` tidak dihitung: saat itu jawabannya masih bisa dilihat, misalnya
/// di layar terbagi atau saat bilah notifikasi ditarik.
bool appInBackground() {
  try {
    final state = WidgetsBinding.instance.lifecycleState;
    return state == AppLifecycleState.paused ||
        state == AppLifecycleState.hidden;
  } catch (_) {
    // Belum ada binding (tes tanpa Flutter): anggap aplikasi terlihat.
    return false;
  }
}

/// Menjaga jawaban yang sedang dialirkan tetap berjalan saat aplikasi ditinggal.
/// Di Android ini berupa wake lock berbatas waktu, tanpa pemberitahuan selama
/// berjalan: pemberitahuan hanya muncul saat jawaban selesai. Tanpa layanan latar
/// depan, Android masih bisa memutus jawaban saat layar mati lama, saat penghemat
/// baterai menyala, atau saat sistem mematikan proses aplikasi.
abstract class BackgroundRun {
  /// Jawaban mulai.
  Future<void> begin();

  /// Jawaban berakhir. Kalau [notice] ada, pengguna diberi tahu bahwa
  /// jawabannya sudah siap. Wake lock dilepas kecuali [release] false, yaitu saat
  /// masih ada jawaban lain yang mengalir (percakapan di latar belakang).
  Future<void> end({RunNotice? notice, bool release = true});

  /// Menyembunyikan aplikasi tanpa menutupnya, seperti tombol Home.
  Future<void> moveToBack();
}

/// Menghitung jawaban yang sedang mengalir dan memutuskan kapan sistem diberi
/// tahu. Beberapa jawaban bisa mengalir bersamaan (percakapan yang ditinggalkan
/// tetap berjalan di latar belakang), jadi wake lock dipegang sejak jawaban
/// pertama mulai sampai yang terakhir selesai, dan "sudah menjawab" tetap muncul
/// untuk tiap jawaban yang selesai saat aplikasi tidak terlihat.
class RunLedger {
  RunLedger(this._background, {bool Function()? inBackground})
      : _inBackground = inBackground ?? appInBackground;

  final BackgroundRun _background;
  final bool Function() _inBackground;
  int _active = 0;

  /// Masih ada jawaban yang mengalir.
  bool get hasActive => _active > 0;

  /// Satu jawaban mulai. Sistem hanya diberi tahu saat yang pertama mulai.
  void begin() {
    _active++;
    if (_active == 1) unawaited(_background.begin());
  }

  /// Satu jawaban berakhir. Pemberitahuan menyusul hanya kalau selesai dan
  /// aplikasi sedang tidak terlihat; wake lock baru dilepas saat tidak ada lagi
  /// jawaban yang mengalir.
  void end(RunOutcome outcome) {
    if (_active > 0) _active--;
    final release = _active == 0;
    final notice = noticeFor(outcome, inBackground: _inBackground());
    if (!release && notice == null) return;
    unawaited(_background.end(notice: notice, release: release));
  }
}

/// Implementasi lewat MethodChannel ke MainActivity (`tool/android/`).
///
/// Kegagalan di sini tidak boleh mengganggu chat. Di luar Android (tes,
/// desktop) salurannya memang tidak ada. Jawaban tetap berjalan selama aplikasi
/// terbuka, hanya tidak dilindungi saat ditinggal.
class PlatformBackgroundRun implements BackgroundRun {
  const PlatformBackgroundRun();

  static const MethodChannel _channel =
      MethodChannel('com.qelvo.qelvo_ai/background');

  @override
  Future<void> begin() => _call('begin');

  @override
  Future<void> end({RunNotice? notice, bool release = true}) {
    return _call('end', {
      'notify': notice != null,
      'title': notice?.title,
      'text': notice?.text,
      'release': release,
    });
  }

  @override
  Future<void> moveToBack() => _call('moveToBack');

  Future<void> _call(String method, [Map<String, Object?>? arguments]) async {
    try {
      await _channel.invokeMethod<Object?>(method, arguments);
    } catch (_) {
      // Lihat catatan kelas: gagal diam-diam adalah perilaku yang disengaja.
    }
  }
}
