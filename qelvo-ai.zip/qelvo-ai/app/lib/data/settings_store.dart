import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum TextScaleOption {
  kecil('Kecil', 0.9),
  sedang('Sedang', 1.0),
  besar('Besar', 1.15);

  const TextScaleOption(this.label, this.factor);

  final String label;
  final double factor;
}

/// Nama enum dikirim apa adanya ke backend sebagai `instruction`.
enum InstructionPreset {
  standar('Standar', 'Seimbang untuk semua topik'),
  ringkas('Ringkas', 'Jawaban pendek dan langsung'),
  guru('Guru', 'Menjelaskan bertahap, dengan contoh'),
  developer('Developer', 'Fokus ke kode dan detail teknis');

  const InstructionPreset(this.label, this.description);

  final String label;
  final String description;
}

/// Pengaturan yang hanya berlaku di perangkat ini. Riwayat chat tidak ada di
/// sini, karena disimpan server di Firestore per akun.
class SettingsStore extends ChangeNotifier {
  SettingsStore._(this._prefs);

  final SharedPreferences _prefs;

  static Future<SettingsStore> load() async {
    final prefs = await SharedPreferences.getInstance();
    // Versi lama menyimpan alamat server pilihan pengguna di sini. Alamat
    // backend sekarang hanya berasal dari build dan tidak tampil di aplikasi,
    // jadi sisa nilai lama dibuang.
    await prefs.remove(_legacyServerUrl);
    return SettingsStore._(prefs);
  }

  static const String _theme = 'theme';
  static const String _textScale = 'text_scale';
  static const String _instruction = 'instruction';
  static const String _thinking = 'thinking';
  static const String _webSearch = 'web_search';
  static const String _autoUpdate = 'auto_update';
  static const String _lastUpdateCheck = 'last_update_check';
  static const String _skippedUpdate = 'skipped_update';
  static const String _saveHistory = 'save_history';
  static const String _provider = 'provider';
  static const String _model = 'model';
  static const String _legacyServerUrl = 'server_url';

  ThemeMode get themeMode => switch (_prefs.getString(_theme)) {
        'light' => ThemeMode.light,
        'system' => ThemeMode.system,
        _ => ThemeMode.dark,
      };

  TextScaleOption get textScale => TextScaleOption.values.firstWhere(
        (o) => o.name == _prefs.getString(_textScale),
        orElse: () => TextScaleOption.sedang,
      );

  InstructionPreset get instruction => InstructionPreset.values.firstWhere(
        (o) => o.name == _prefs.getString(_instruction),
        orElse: () => InstructionPreset.standar,
      );

  /// Mode berpikir menyala secara bawaan.
  bool get thinking => _prefs.getBool(_thinking) ?? true;

  /// Cari web mati secara bawaan: pencarian menambah waktu tunggu dan memakai
  /// kuota penyedia, jadi pengguna menyalakannya sendiri saat perlu.
  bool get webSearch => _prefs.getBool(_webSearch) ?? false;

  bool get saveHistory => _prefs.getBool(_saveHistory) ?? true;

  String? get providerId => _prefs.getString(_provider);

  String? get modelId => _prefs.getString(_model);

  Future<void> setThemeMode(ThemeMode mode) => _store(_theme, mode.name);

  Future<void> setTextScale(TextScaleOption option) =>
      _store(_textScale, option.name);

  Future<void> setInstruction(InstructionPreset preset) =>
      _store(_instruction, preset.name);

  Future<void> setThinking(bool value) => _store(_thinking, value);

  Future<void> setWebSearch(bool value) => _store(_webSearch, value);

  /// Periksa pembaruan saat aplikasi dibuka. Hanya memeriksa: apa pun yang
  /// ditemukan baru diunduh setelah pengguna menyetujuinya.
  bool get autoUpdate => _prefs.getBool(_autoUpdate) ?? true;

  Future<void> setAutoUpdate(bool value) => _store(_autoUpdate, value);

  /// Kapan terakhir kali GitHub ditanyai, untuk membatasi pemeriksaan otomatis.
  DateTime? get lastUpdateCheck {
    final millis = _prefs.getInt(_lastUpdateCheck);
    return millis == null ? null : DateTime.fromMillisecondsSinceEpoch(millis);
  }

  Future<void> setLastUpdateCheck(DateTime time) =>
      _store(_lastUpdateCheck, time.millisecondsSinceEpoch);

  /// Versi yang dipilih pengguna untuk dilewati ("Lewati versi ini").
  String? get skippedUpdate => _prefs.getString(_skippedUpdate);

  Future<void> setSkippedUpdate(String? version) =>
      _store(_skippedUpdate, version);

  Future<void> setSaveHistory(bool value) => _store(_saveHistory, value);

  Future<void> setSelection({String? providerId, String? modelId}) async {
    if (providerId == null) {
      await _prefs.remove(_provider);
    } else {
      await _prefs.setString(_provider, providerId);
    }
    if (modelId == null) {
      await _prefs.remove(_model);
    } else {
      await _prefs.setString(_model, modelId);
    }
    notifyListeners();
  }

  Future<void> _store(String key, Object? value) async {
    if (value == null) {
      await _prefs.remove(key);
    } else if (value is bool) {
      await _prefs.setBool(key, value);
    } else if (value is String) {
      await _prefs.setString(key, value);
    } else if (value is int) {
      await _prefs.setInt(key, value);
    }
    notifyListeners();
  }
}
