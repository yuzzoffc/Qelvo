import 'dart:math';
import 'dart:typed_data';

enum ChatRole { user, assistant }

/// Satu foto yang dilampirkan ke pesan pengguna.
class ChatAttachment {
  const ChatAttachment({
    required this.thumb,
    this.full,
    this.mime = 'image/jpeg',
  });

  /// Gambar kecil (sisi terpendek sekitar 256 px). Tampil di komposer dan di
  /// gelembung pesan, dan ikut disimpan di riwayat.
  final Uint8List thumb;

  /// Foto yang dikirim ke model (sisi terpendek sekitar 1280 px). Hanya ada
  /// selama aplikasi terbuka: pesan yang dimuat dari riwayat hanya punya [thumb].
  final Uint8List? full;

  final String mime;
}

class ChatMessage {
  ChatMessage({
    required this.id,
    required this.role,
    required this.content,
    required this.createdAt,
    this.rating = 0,
    this.attachments = const [],
  });

  final String id;
  final ChatRole role;
  String content;
  final DateTime createdAt;

  /// Foto yang dilampirkan. Hanya pesan pengguna yang bisa memilikinya.
  final List<ChatAttachment> attachments;

  /// 1 = suka, -1 = tidak suka, 0 = belum dinilai.
  int rating;
}

class Conversation {
  const Conversation({
    required this.id,
    required this.title,
    required this.createdAt,
    required this.updatedAt,
    this.modelLabel = '',
    this.preview = '',
  });

  final String id;
  final String title;
  final DateTime createdAt;
  final DateTime updatedAt;
  final String modelLabel;
  final String preview;
}

final Random _random = Random();

/// ID percakapan dan pesan (dokumen Firestore di server): unik cukup untuk satu
/// pengguna, hanya huruf kecil dan angka.
String newId() {
  final time = DateTime.now().microsecondsSinceEpoch.toRadixString(36);
  final noise = _random.nextInt(1 << 20).toRadixString(36);
  return '$time$noise';
}

String titleFrom(String text) {
  final firstLine = text.trim().split('\n').first;
  final collapsed = firstLine.replaceAll(RegExp(r'\s+'), ' ').trim();
  if (collapsed.isEmpty) return 'Percakapan baru';
  if (collapsed.length <= 42) return collapsed;
  return '${collapsed.substring(0, 42).trimRight()}…';
}

/// Potongan satu baris dari jawaban, untuk pencarian di drawer riwayat.
String previewFrom(String markdown) {
  final plain = markdown
      .replaceAll(RegExp(r'```[\s\S]*?```'), ' ')
      .replaceAll(RegExp(r'[`*#>_]+'), '')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
  if (plain.length <= 90) return plain;
  return '${plain.substring(0, 90).trimRight()}…';
}

class ModelOption {
  const ModelOption({
    required this.id,
    required this.label,
    this.vision = false,
  });

  final String id;
  final String label;

  /// Model bisa membaca foto. Server lama tidak mengirim kolom ini, dan
  /// artinya tidak ada dukungan foto.
  final bool vision;
}

class ProviderInfo {
  const ProviderInfo({
    required this.id,
    required this.name,
    required this.tagline,
    required this.defaultModel,
    required this.models,
  });

  final String id;
  final String name;
  final String tagline;
  final String defaultModel;
  final List<ModelOption> models;

  factory ProviderInfo.fromJson(Map<String, dynamic> json) {
    final models = <ModelOption>[];
    final raw = json['models'];
    if (raw is List) {
      for (final item in raw) {
        if (item is Map<String, dynamic>) {
          models.add(ModelOption(
            id: '${item['id']}',
            label: '${item['label'] ?? item['id']}',
            vision: item['vision'] == true,
          ));
        }
      }
    }
    return ProviderInfo(
      id: '${json['id']}',
      name: '${json['name'] ?? json['id']}',
      tagline: '${json['tagline'] ?? ''}',
      defaultModel: '${json['default_model'] ?? ''}',
      models: models,
    );
  }
}

class CatalogData {
  const CatalogData({required this.defaultProvider, required this.providers});

  final String defaultProvider;
  final List<ProviderInfo> providers;

  factory CatalogData.fromJson(Map<String, dynamic> json) {
    final providers = <ProviderInfo>[];
    final raw = json['providers'];
    if (raw is List) {
      for (final item in raw) {
        if (item is Map<String, dynamic>) {
          providers.add(ProviderInfo.fromJson(item));
        }
      }
    }
    return CatalogData(
      defaultProvider: '${json['default_provider'] ?? ''}',
      providers: providers,
    );
  }
}

class EmailCodeInfo {
  const EmailCodeInfo({required this.expiresIn, required this.resendIn});

  final int expiresIn;
  final int resendIn;

  factory EmailCodeInfo.fromJson(Map<String, dynamic> json) {
    int read(String key, int fallback) {
      final value = json[key];
      return value is int ? value : fallback;
    }

    return EmailCodeInfo(
      expiresIn: read('expires_in', 600),
      resendIn: read('resend_in', 60),
    );
  }
}
