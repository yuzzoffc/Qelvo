import 'dart:math';
import 'dart:typed_data';

enum ChatRole { user, assistant }

/// Satu foto yang dilampirkan ke pesan pengguna.
class ChatAttachment {
  const ChatAttachment({
    required this.thumb,
    this.full,
    this.mime = 'image/jpeg',
  });

  /// Gambar kecil (sisi terpendek sekitar 256 px). Tampil di komposer dan di
  /// gelembung pesan, dan ikut disimpan di riwayat.
  final Uint8List thumb;

  /// Foto yang dikirim ke model (sisi terpendek sekitar 1280 px). Hanya ada
  /// selama aplikasi terbuka: pesan yang dimuat dari riwayat hanya punya [thumb].
  final Uint8List? full;

  final String mime;
}

/// Satu sumber yang dikutip jawaban hasil pencarian web.
class ChatSource {
  const ChatSource({required this.title, required this.url});

  /// Judul halaman atau nama situsnya, seperti yang dikirim server. Bisa kosong.
  final String title;

  /// Alamat halaman. Selalu http atau https (lihat [tryParse]).
  final String url;

  /// Paling banyak sumber yang diterima untuk satu jawaban.
  static const int maxPerAnswer = 8;

  static const int _maxTitle = 120;
  static const int _maxUrl = 2048;

  /// Nama situs tanpa awalan "www.", dari [url].
  String get host {
    final host = Uri.tryParse(url)?.host ?? '';
    return host.startsWith('www.') ? host.substring(4) : host;
  }

  /// Tulisan di tombol sumber: judul kalau ada, kalau tidak nama situsnya.
  String get label => title.isNotEmpty ? title : host;

  /// Membaca satu entri dari server. Hanya tautan http atau https yang
  /// diterima, supaya skema aneh (javascript:, intent:, file:) tidak pernah
  /// sampai ke tombol yang dibuka pengguna. Entri lain dibuang.
  static ChatSource? tryParse(Object? raw) {
    if (raw is! Map) return null;
    final url = raw['url'];
    if (url is! String || url.isEmpty || url.length > _maxUrl) return null;
    final uri = Uri.tryParse(url);
    if (uri == null || uri.host.isEmpty) return null;
    if (uri.scheme != 'http' && uri.scheme != 'https') return null;
    final rawTitle = raw['title'];
    // Kurung siku dibuang karena judul ikut ditulis sebagai label tautan
    // Markdown saat diekspor.
    final title = rawTitle is String
        ? rawTitle
            .replaceAll(RegExp(r'[\[\]]+'), ' ')
            .replaceAll(RegExp(r'\s+'), ' ')
            .trim()
        : '';
    return ChatSource(title: _cut(title, _maxTitle), url: url);
  }

  /// Daftar dari server, tanpa tautan ganda, paling banyak [maxPerAnswer].
  static List<ChatSource> listFrom(Object? raw) {
    if (raw is! List) return const [];
    final seen = <String>{};
    final result = <ChatSource>[];
    for (final item in raw) {
      final source = tryParse(item);
      if (source == null || !seen.add(source.url)) continue;
      result.add(source);
      if (result.length == maxPerAnswer) break;
    }
    return result;
  }

  /// Daftar sumber sebagai Markdown untuk ekspor dan berbagi. Kosong kalau
  /// tidak ada sumber.
  static String markdownList(List<ChatSource> sources) {
    if (sources.isEmpty) return '';
    final buffer = StringBuffer('Sumber:\n');
    for (final source in sources) {
      buffer.write('- [${source.label}](${source.url})\n');
    }
    return '$buffer\n';
  }

  /// Memotong tanpa membelah pasangan surrogate, karena hasilnya bukan teks
  /// yang sah.
  static String _cut(String text, int max) {
    if (text.length <= max) return text;
    var end = max;
    final last = text.codeUnitAt(end - 1);
    if (last >= 0xD800 && last <= 0xDBFF) end--;
    return '${text.substring(0, end).trimRight()}…';
  }
}

class ChatMessage {
  ChatMessage({
    required this.id,
    required this.role,
    required this.content,
    required this.createdAt,
    this.rating = 0,
    this.attachments = const [],
    this.sources = const [],
  });

  final String id;
  final ChatRole role;
  String content;
  final DateTime createdAt;

  /// Foto yang dilampirkan. Hanya pesan pengguna yang bisa memilikinya.
  final List<ChatAttachment> attachments;

  /// 1 = suka, -1 = tidak suka, 0 = belum dinilai.
  int rating;

  /// Sumber yang dikutip jawaban hasil pencarian web. Kosong kalau jawabannya
  /// tidak memakai pencarian. Datang dari server setelah teks jawaban.
  List<ChatSource> sources;
}

class Conversation {
  const Conversation({
    required this.id,
    required this.title,
    required this.createdAt,
    required this.updatedAt,
    this.modelLabel = '',
    this.preview = '',
  });

  final String id;
  final String title;
  final DateTime createdAt;
  final DateTime updatedAt;
  final String modelLabel;
  final String preview;
}

final Random _random = Random();

/// ID percakapan dan pesan (dokumen Firestore di server): unik cukup untuk satu
/// pengguna, hanya huruf kecil dan angka.
String newId() {
  final time = DateTime.now().microsecondsSinceEpoch.toRadixString(36);
  final noise = _random.nextInt(1 << 20).toRadixString(36);
  return '$time$noise';
}

String titleFrom(String text) {
  final firstLine = text.trim().split('\n').first;
  final collapsed = firstLine.replaceAll(RegExp(r'\s+'), ' ').trim();
  if (collapsed.isEmpty) return 'Percakapan baru';
  if (collapsed.length <= 42) return collapsed;
  return '${collapsed.substring(0, 42).trimRight()}…';
}

/// Potongan satu baris dari jawaban, untuk pencarian di drawer riwayat.
String previewFrom(String markdown) {
  final plain = markdown
      .replaceAll(RegExp(r'```[\s\S]*?```'), ' ')
      .replaceAll(RegExp(r'[`*#>_]+'), '')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
  if (plain.length <= 90) return plain;
  return '${plain.substring(0, 90).trimRight()}…';
}

class ModelOption {
  const ModelOption({
    required this.id,
    required this.label,
    this.vision = false,
    this.webSearch = false,
  });

  final String id;
  final String label;

  /// Model bisa membaca foto. Server lama tidak mengirim kolom ini, dan
  /// artinya tidak ada dukungan foto.
  final bool vision;

  /// Model bisa menjawab dengan pencarian web. Sama seperti [vision]: server
  /// lama tidak mengirim kolom ini, dan artinya fitur itu belum ada di sana.
  final bool webSearch;
}

class ProviderInfo {
  const ProviderInfo({
    required this.id,
    required this.name,
    required this.tagline,
    required this.defaultModel,
    required this.models,
  });

  final String id;
  final String name;
  final String tagline;
  final String defaultModel;
  final List<ModelOption> models;

  factory ProviderInfo.fromJson(Map<String, dynamic> json) {
    final models = <ModelOption>[];
    final raw = json['models'];
    if (raw is List) {
      for (final item in raw) {
        if (item is Map<String, dynamic>) {
          models.add(ModelOption(
            id: '${item['id']}',
            label: '${item['label'] ?? item['id']}',
            vision: item['vision'] == true,
            webSearch: item['web_search'] == true,
          ));
        }
      }
    }
    return ProviderInfo(
      id: '${json['id']}',
      name: '${json['name'] ?? json['id']}',
      tagline: '${json['tagline'] ?? ''}',
      defaultModel: '${json['default_model'] ?? ''}',
      models: models,
    );
  }
}

class CatalogData {
  const CatalogData({required this.defaultProvider, required this.providers});

  final String defaultProvider;
  final List<ProviderInfo> providers;

  factory CatalogData.fromJson(Map<String, dynamic> json) {
    final providers = <ProviderInfo>[];
    final raw = json['providers'];
    if (raw is List) {
      for (final item in raw) {
        if (item is Map<String, dynamic>) {
          providers.add(ProviderInfo.fromJson(item));
        }
      }
    }
    return CatalogData(
      defaultProvider: '${json['default_provider'] ?? ''}',
      providers: providers,
    );
  }
}

class EmailCodeInfo {
  const EmailCodeInfo({required this.expiresIn, required this.resendIn});

  final int expiresIn;
  final int resendIn;

  factory EmailCodeInfo.fromJson(Map<String, dynamic> json) {
    int read(String key, int fallback) {
      final value = json[key];
      return value is int ? value : fallback;
    }

    return EmailCodeInfo(
      expiresIn: read('expires_in', 600),
      resendIn: read('resend_in', 60),
    );
  }
}
