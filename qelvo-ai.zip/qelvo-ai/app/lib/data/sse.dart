import 'dart:convert';

sealed class ChatEvent {
  const ChatEvent();
}

final class DeltaEvent extends ChatEvent {
  const DeltaEvent(this.text);

  final String text;
}

final class MetaEvent extends ChatEvent {
  const MetaEvent({required this.modelLabel});

  final String modelLabel;
}

final class DoneEvent extends ChatEvent {
  const DoneEvent();
}

final class ErrorEvent extends ChatEvent {
  const ErrorEvent({required this.code, required this.message});

  final String code;
  final String message;
}

/// Membaca satu baris SSE dari server. Baris selain `data:` (komentar,
/// baris kosong) dan JSON yang rusak diabaikan.
ChatEvent? parseSseLine(String line) {
  if (!line.startsWith('data:')) return null;
  final payload = line.substring(5).trim();
  if (payload.isEmpty) return null;

  Object? decoded;
  try {
    decoded = jsonDecode(payload);
  } on FormatException {
    return null;
  }
  if (decoded is! Map<String, dynamic>) return null;

  final error = decoded['error'];
  if (error is Map<String, dynamic>) {
    return ErrorEvent(
      code: '${error['code'] ?? 'unknown'}',
      message: '${error['message'] ?? 'Terjadi kesalahan.'}',
    );
  }
  if (decoded['done'] == true) return const DoneEvent();

  final delta = decoded['delta'];
  if (delta is String && delta.isNotEmpty) return DeltaEvent(delta);

  final meta = decoded['meta'];
  if (meta is Map<String, dynamic>) {
    return MetaEvent(modelLabel: '${meta['model_label'] ?? ''}');
  }
  return null;
}
