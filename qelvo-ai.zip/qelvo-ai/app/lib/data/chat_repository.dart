import 'dart:convert';

import 'package:qelvo_ai/data/api_client.dart';
import 'package:qelvo_ai/data/models.dart';

class ExportResult {
  const ExportResult({
    required this.markdown,
    required this.included,
    required this.total,
  });

  final String markdown;
  final int included;
  final int total;
}

/// Riwayat disimpan server di Firestore (`users/{uid}/conversations/{id}/messages/{id}`).
/// Aplikasi tidak menyentuh Firestore: firestore.rules menolak semua akses
/// klien, jadi semuanya lewat endpoint `/v1/conversations` di backend.
class ChatRepository {
  ChatRepository(this._api);

  final ApiClient _api;

  static const int listLimit = 300;
  static const int _maxContent = 50000;

  static String _id(String value) => Uri.encodeComponent(value);

  Future<List<Conversation>> conversations() async {
    final json = await _api.request('GET', '/v1/conversations?limit=$listLimit');
    final raw = json is Map<String, dynamic> ? json['conversations'] : null;
    if (raw is! List) throw _badResponse();
    return [
      for (final item in raw)
        if (item is Map<String, dynamic>) _conversationFrom(item),
    ];
  }

  Future<List<ChatMessage>> messages(String conversationId) async {
    final json = await _api.request(
      'GET',
      '/v1/conversations/${_id(conversationId)}/messages',
    );
    final raw = json is Map<String, dynamic> ? json['messages'] : null;
    if (raw is! List) throw _badResponse();
    return [
      for (final item in raw)
        if (item is Map<String, dynamic>) _messageFrom(item),
    ];
  }

  /// Menyimpan satu pesan sekaligus memperbarui data percakapan induknya.
  Future<void> save({
    required Conversation conversation,
    required ChatMessage message,
  }) async {
    await _api.request(
      'PUT',
      '/v1/conversations/${_id(conversation.id)}/messages/${_id(message.id)}',
      body: {
        'conversation': {
          'title': conversation.title,
          'model_label': conversation.modelLabel,
          'preview': conversation.preview,
          'created_at': conversation.createdAt.millisecondsSinceEpoch,
        },
        'message': {
          'role': message.role.name,
          'content': _clip(message.content),
          'created_at': message.createdAt.millisecondsSinceEpoch,
          'rating': message.rating,
          // Hanya gambar kecil yang disimpan, bukan foto aslinya.
          if (message.attachments.isNotEmpty)
            'images': [
              for (final attachment in message.attachments)
                {'mime': attachment.mime, 'data': base64Encode(attachment.thumb)},
            ],
        },
      },
    );
  }

  Future<void> setRating(
    String conversationId,
    String messageId,
    int rating,
  ) async {
    await _api.request(
      'PATCH',
      '/v1/conversations/${_id(conversationId)}/messages/${_id(messageId)}',
      body: {'rating': rating},
    );
  }

  Future<void> deleteMessage(String conversationId, String messageId) async {
    await _api.request(
      'DELETE',
      '/v1/conversations/${_id(conversationId)}/messages/${_id(messageId)}',
    );
  }

  Future<void> deleteConversation(String id) async {
    await _api.request(
      'DELETE',
      '/v1/conversations/${_id(id)}',
      timeout: const Duration(seconds: 60),
    );
  }

  Future<void> deleteEverything() async {
    await _api.request(
      'DELETE',
      '/v1/conversations',
      timeout: const Duration(seconds: 120),
    );
  }

  /// Seluruh riwayat sebagai Markdown, dibatasi supaya aman masuk clipboard.
  Future<ExportResult> exportMarkdown({int maxChars = 300000}) async {
    final all = await conversations();
    final selected = all.length > 200 ? all.sublist(0, 200) : all;
    final buffer = StringBuffer();
    var included = 0;
    for (final conversation in selected) {
      final items = await messages(conversation.id);
      final block = StringBuffer('# ${conversation.title}\n\n');
      for (final m in items) {
        block.write(m.role == ChatRole.user ? '**Kamu**' : '**QELVO**');
        block.write('\n\n${m.content.trim()}\n\n');
        if (m.attachments.isNotEmpty) {
          block.write('_(${m.attachments.length} foto dilampirkan)_\n\n');
        }
      }
      block.write('---\n\n');
      if (buffer.length + block.length > maxChars) break;
      buffer.write(block);
      included++;
    }
    return ExportResult(
      markdown: buffer.toString().trimRight(),
      included: included,
      total: all.length,
    );
  }

  /// Server menolak isi di atas 50.000 karakter. Pemotongan tidak boleh
  /// membelah pasangan surrogate, karena hasilnya bukan teks yang sah.
  static String _clip(String text) {
    if (text.length <= _maxContent) return text;
    var end = _maxContent;
    final last = text.codeUnitAt(end - 1);
    if (last >= 0xD800 && last <= 0xDBFF) end--;
    return text.substring(0, end);
  }

  static ApiException _badResponse() => const ApiException(
        'Respons server tidak dikenali.',
        code: 'bad_response',
      );

  static Conversation _conversationFrom(Map<String, dynamic> json) {
    return Conversation(
      id: '${json['id']}',
      title: (json['title'] as String?) ?? 'Percakapan',
      modelLabel: (json['model_label'] as String?) ?? '',
      preview: (json['preview'] as String?) ?? '',
      createdAt: _time(json['created_at']),
      updatedAt: _time(json['updated_at']),
    );
  }

  static ChatMessage _messageFrom(Map<String, dynamic> json) {
    final rating = json['rating'];
    return ChatMessage(
      id: '${json['id']}',
      role: json['role'] == 'assistant' ? ChatRole.assistant : ChatRole.user,
      content: (json['content'] as String?) ?? '',
      createdAt: _time(json['created_at']),
      rating: rating is int ? rating : 0,
      attachments: _attachmentsFrom(json['images']),
    );
  }

  /// Gambar kecil dari server. Entri yang rusak dilewati supaya pesannya
  /// tetap tampil.
  static List<ChatAttachment> _attachmentsFrom(Object? raw) {
    if (raw is! List) return const [];
    final result = <ChatAttachment>[];
    for (final item in raw) {
      if (item is! Map<String, dynamic>) continue;
      final data = item['data'];
      if (data is! String) continue;
      final mime = item['mime'];
      try {
        result.add(
          ChatAttachment(
            thumb: base64Decode(data),
            mime: mime is String ? mime : 'image/jpeg',
          ),
        );
      } on FormatException {
        // Gambar rusak: dilewati.
      }
    }
    return result;
  }

  static DateTime _time(Object? value) => value is num
      ? DateTime.fromMillisecondsSinceEpoch(value.toInt())
      : DateTime.now();
}
