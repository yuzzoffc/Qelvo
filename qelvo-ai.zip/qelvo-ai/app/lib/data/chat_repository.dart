import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:qelvo_ai/data/models.dart';

class ExportResult {
  const ExportResult({
    required this.markdown,
    required this.included,
    required this.total,
  });

  final String markdown;
  final int included;
  final int total;
}

/// Riwayat disimpan di `users/{uid}/conversations/{id}/messages/{id}`.
/// Aturan keamanan di firestore.rules membatasi akses ke pemilik akun.
class ChatRepository {
  ChatRepository(String uid)
      : _conversations = FirebaseFirestore.instance
            .collection('users')
            .doc(uid)
            .collection('conversations');

  final CollectionReference<Map<String, dynamic>> _conversations;

  static const int _watchLimit = 300;

  Stream<List<Conversation>> watchConversations() {
    return _conversations
        .orderBy('updatedAt', descending: true)
        .limit(_watchLimit)
        .snapshots()
        .map((snapshot) => snapshot.docs.map(_conversationFrom).toList());
  }

  Future<List<ChatMessage>> messages(String conversationId) async {
    final snapshot = await _conversations
        .doc(conversationId)
        .collection('messages')
        .orderBy('createdAt')
        .get();
    return snapshot.docs.map((doc) {
      final data = doc.data();
      final rating = data['rating'];
      return ChatMessage(
        id: doc.id,
        role: data['role'] == 'assistant' ? ChatRole.assistant : ChatRole.user,
        content: (data['content'] as String?) ?? '',
        createdAt: _time(data['createdAt']),
        rating: rating is int ? rating : 0,
      );
    }).toList();
  }

  /// Menyimpan satu pesan sekaligus memperbarui data percakapan induknya.
  Future<void> save({
    required Conversation conversation,
    required ChatMessage message,
  }) async {
    final conversationRef = _conversations.doc(conversation.id);
    final batch = FirebaseFirestore.instance.batch();

    // Field kosong tidak ditulis supaya tidak menimpa nilai yang sudah ada.
    batch.set(
      conversationRef,
      {
        'title': conversation.title,
        'createdAt': Timestamp.fromDate(conversation.createdAt),
        'updatedAt': Timestamp.fromDate(conversation.updatedAt),
        if (conversation.modelLabel.isNotEmpty)
          'modelLabel': conversation.modelLabel,
        if (conversation.preview.isNotEmpty) 'preview': conversation.preview,
      },
      SetOptions(merge: true),
    );
    batch.set(conversationRef.collection('messages').doc(message.id), {
      'role': message.role.name,
      'content': message.content,
      'createdAt': Timestamp.fromDate(message.createdAt),
      'rating': message.rating,
    });
    await batch.commit();
  }

  Future<void> setRating(
    String conversationId,
    String messageId,
    int rating,
  ) {
    return _conversations
        .doc(conversationId)
        .collection('messages')
        .doc(messageId)
        .update({'rating': rating});
  }

  Future<void> deleteMessage(String conversationId, String messageId) {
    return _conversations
        .doc(conversationId)
        .collection('messages')
        .doc(messageId)
        .delete();
  }

  Future<void> deleteConversation(String id) async {
    final ref = _conversations.doc(id);
    await _deleteAll(ref.collection('messages'));
    await ref.delete();
  }

  Future<void> deleteEverything() async {
    final snapshot = await _conversations.get();
    for (final doc in snapshot.docs) {
      await deleteConversation(doc.id);
    }
  }

  /// Seluruh riwayat sebagai Markdown, dibatasi supaya aman masuk clipboard.
  Future<ExportResult> exportMarkdown({int maxChars = 300000}) async {
    final snapshot = await _conversations
        .orderBy('updatedAt', descending: true)
        .limit(200)
        .get();
    final buffer = StringBuffer();
    var included = 0;
    for (final doc in snapshot.docs) {
      final conversation = _conversationFrom(doc);
      final items = await messages(doc.id);
      final block = StringBuffer('# ${conversation.title}\n\n');
      for (final m in items) {
        block.write(m.role == ChatRole.user ? '**Kamu**' : '**QELVO**');
        block.write('\n\n${m.content.trim()}\n\n');
      }
      block.write('---\n\n');
      if (buffer.length + block.length > maxChars) break;
      buffer.write(block);
      included++;
    }
    return ExportResult(
      markdown: buffer.toString().trimRight(),
      included: included,
      total: snapshot.docs.length,
    );
  }

  /// Firestore membatasi satu batch hingga 500 operasi.
  Future<void> _deleteAll(CollectionReference<Map<String, dynamic>> collection) async {
    while (true) {
      final snapshot = await collection.limit(400).get();
      if (snapshot.docs.isEmpty) return;
      final batch = FirebaseFirestore.instance.batch();
      for (final doc in snapshot.docs) {
        batch.delete(doc.reference);
      }
      await batch.commit();
    }
  }

  Conversation _conversationFrom(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data();
    return Conversation(
      id: doc.id,
      title: (data['title'] as String?) ?? 'Percakapan',
      modelLabel: (data['modelLabel'] as String?) ?? '',
      preview: (data['preview'] as String?) ?? '',
      createdAt: _time(data['createdAt']),
      updatedAt: _time(data['updatedAt']),
    );
  }

  static DateTime _time(Object? value) =>
      value is Timestamp ? value.toDate() : DateTime.now();
}
