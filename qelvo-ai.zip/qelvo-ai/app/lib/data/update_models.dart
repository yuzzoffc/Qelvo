/// Nomor versi tiga angka (1.2.3), untuk membandingkan versi yang terpasang dengan
/// rilis di GitHub.
class AppVersion implements Comparable<AppVersion> {
  const AppVersion(this.major, this.minor, this.patch);

  final int major;
  final int minor;
  final int patch;

  static final RegExp _pattern = RegExp(r'^v?(\d+)\.(\d+)\.(\d+)');

  /// Membaca `1.2.3` atau `v1.2.3`. Apa pun sesudah angka ketiga (`+45`, `-beta`)
  /// diabaikan. Null kalau bukan nomor versi.
  static AppVersion? tryParse(String? text) {
    final match = _pattern.firstMatch((text ?? '').trim());
    if (match == null) return null;
    final major = int.tryParse(match.group(1)!);
    final minor = int.tryParse(match.group(2)!);
    final patch = int.tryParse(match.group(3)!);
    if (major == null || minor == null || patch == null) return null;
    return AppVersion(major, minor, patch);
  }

  @override
  int compareTo(AppVersion other) {
    if (major != other.major) return major.compareTo(other.major);
    if (minor != other.minor) return minor.compareTo(other.minor);
    return patch.compareTo(other.patch);
  }

  bool operator >(AppVersion other) => compareTo(other) > 0;

  @override
  bool operator ==(Object other) =>
      other is AppVersion && compareTo(other) == 0;

  @override
  int get hashCode => Object.hash(major, minor, patch);

  @override
  String toString() => '$major.$minor.$patch';
}

/// Isi berkas `.sha256` (`<hash>  <nama berkas>`, seperti keluaran `sha256sum`):
/// hash 64 heksadesimal pertama, dalam huruf kecil. Null kalau tidak ada.
String? parseSha256(String text) {
  final pattern = RegExp(r'^\s*([0-9a-fA-F]{64})(?![0-9a-fA-F])');
  for (final line in text.split('\n')) {
    final match = pattern.firstMatch(line);
    if (match != null) return match.group(1)!.toLowerCase();
  }
  return null;
}

/// Satu rilis resmi di GitHub yang bisa dipasang lewat aplikasi.
class UpdateRelease {
  const UpdateRelease({
    required this.version,
    required this.tag,
    required this.notes,
    required this.apkName,
    required this.apkUrl,
    required this.apkSize,
    this.sha256,
    this.checksumUrl,
  });

  final AppVersion version;
  final String tag;

  /// Catatan rilis (Markdown) dari deskripsi rilis. Bisa kosong.
  final String notes;
  final String apkName;
  final Uri apkUrl;

  /// Ukuran APK dalam bita menurut GitHub, 0 kalau tidak diketahui.
  final int apkSize;

  /// Checksum SHA-256 dari kolom `digest` GitHub (huruf kecil). Kalau null, hash
  /// diambil dari berkas [checksumUrl].
  final String? sha256;
  final Uri? checksumUrl;

  static const int _maxNotes = 4000;

  /// Membaca respons `GET /repos/{repo}/releases/latest`. Null kalau rilisnya draf
  /// atau prarilis, tag-nya bukan nomor versi, atau tidak ada APK yang sah.
  ///
  /// Hanya alamat unduhan di github.com milik [repo] yang diterima, jadi respons
  /// yang menunjuk ke tempat lain tidak pernah sampai ke pengunduh.
  static UpdateRelease? fromGitHub(Object? json, {required String repo}) {
    if (json is! Map) return null;
    if (json['draft'] == true || json['prerelease'] == true) return null;
    final tag = json['tag_name'];
    if (tag is! String) return null;
    final version = AppVersion.tryParse(tag);
    if (version == null) return null;
    final assets = json['assets'];
    if (assets is! List) return null;

    Map? apk;
    Uri? apkUrl;
    for (final asset in assets) {
      if (asset is! Map) continue;
      final name = asset['name'];
      if (name is! String || !name.toLowerCase().endsWith('.apk')) continue;
      if (asset['state'] != null && asset['state'] != 'uploaded') continue;
      final url = _downloadUri(asset['browser_download_url'], repo);
      if (url == null) continue;
      apk = asset;
      apkUrl = url;
      break;
    }
    if (apk == null || apkUrl == null) return null;
    final apkName = apk['name'] as String;

    Uri? checksumUrl;
    for (final asset in assets) {
      if (asset is Map && asset['name'] == '$apkName.sha256') {
        checksumUrl = _downloadUri(asset['browser_download_url'], repo);
        break;
      }
    }

    final size = apk['size'];
    final body = json['body'];
    var notes = body is String ? body.trim() : '';
    if (notes.length > _maxNotes) {
      notes = '${notes.substring(0, _maxNotes).trimRight()}…';
    }
    return UpdateRelease(
      version: version,
      tag: tag,
      notes: notes,
      apkName: apkName,
      apkUrl: apkUrl,
      apkSize: size is int && size > 0 ? size : 0,
      sha256: _digestOf(apk['digest']),
      checksumUrl: checksumUrl,
    );
  }

  static Uri? _downloadUri(Object? raw, String repo) {
    if (raw is! String) return null;
    final uri = Uri.tryParse(raw);
    if (uri == null || uri.scheme != 'https' || uri.host != 'github.com') {
      return null;
    }
    final prefix = '/${repo.toLowerCase()}/releases/download/';
    if (!uri.path.toLowerCase().startsWith(prefix)) return null;
    return uri;
  }

  static String? _digestOf(Object? raw) {
    if (raw is! String) return null;
    final match = RegExp(r'^sha256:([0-9a-fA-F]{64})$').firstMatch(raw.trim());
    return match?.group(1)?.toLowerCase();
  }
}
