import 'dart:typed_data';

import 'package:image_picker/image_picker.dart';

/// Sisi terpanjang foto yang diminta dari Android, dan mutu JPEG-nya. Android
/// yang mengecilkan, jadi foto 12 MP tidak perlu dibuka di Dart.
const double _maxSide = 1280;
const int _quality = 85;

/// Hasil pemilih foto bawaan HP.
class PickedPhotos {
  const PickedPhotos({required this.photos, required this.skipped});

  /// Isi foto yang dipilih, paling banyak sebanyak batas yang diminta.
  final List<Uint8List> photos;

  /// Jumlah foto yang dipilih melebihi batas dan tidak ikut dibaca.
  final int skipped;
}

/// Membuka pemilih foto bawaan HP dan membaca foto yang dipilih.
///
/// Di Android 13 ke atas ini Photo Picker milik sistem, yang tidak meminta izin
/// galeri. Di Android yang lebih lama ini pemilih gambar bawaan HP. QELVO tidak
/// punya daftar foto sendiri, dan tidak membaca foto yang tidak dipilih.
///
/// Mengembalikan daftar kosong kalau pemilih ditutup tanpa memilih.
Future<PickedPhotos> pickPhotosFromDevice({required int limit}) async {
  assert(limit >= 1);
  final picker = ImagePicker();
  final List<XFile> files;
  if (limit == 1) {
    // pickMultiImage menolak batas di bawah 2, jadi satu foto lewat pickImage.
    final single = await picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: _maxSide,
      maxHeight: _maxSide,
      imageQuality: _quality,
    );
    files = single == null ? const <XFile>[] : <XFile>[single];
  } else {
    files = await picker.pickMultiImage(
      maxWidth: _maxSide,
      maxHeight: _maxSide,
      imageQuality: _quality,
      limit: limit,
    );
  }
  // Pemilih di Android lama tidak selalu menghormati batas, jadi dipotong di sini.
  final chosen = files.length > limit ? files.sublist(0, limit) : files;
  final photos = <Uint8List>[];
  for (final file in chosen) {
    photos.add(await file.readAsBytes());
  }
  return PickedPhotos(photos: photos, skipped: files.length - chosen.length);
}
