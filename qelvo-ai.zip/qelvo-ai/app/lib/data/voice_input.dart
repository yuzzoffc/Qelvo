import 'package:flutter/services.dart';

/// HP ini tidak punya pengenal ucapan (biasanya tanpa aplikasi Google).
class VoiceUnavailable implements Exception {
  const VoiceUnavailable();
}

/// Input suara lewat dialog pengenal ucapan bawaan Android. Aplikasi tidak
/// meminta izin mikrofon sendiri: dialog sistem itulah yang mengurusnya.
class VoiceInput {
  const VoiceInput();

  static const MethodChannel _channel =
      MethodChannel('com.qelvo.qelvo_ai/voice');

  /// Teks hasil ucapan, atau null kalau pengguna membatalkan. Melempar
  /// [VoiceUnavailable] kalau HP tidak punya pengenal ucapan.
  Future<String?> listen({String locale = 'id-ID'}) async {
    try {
      final text = await _channel.invokeMethod<String>(
        'listen',
        <String, Object>{'locale': locale},
      );
      final clean = text?.trim() ?? '';
      return clean.isEmpty ? null : clean;
    } on PlatformException catch (error) {
      if (error.code == 'unavailable') throw const VoiceUnavailable();
      return null;
    } on MissingPluginException {
      throw const VoiceUnavailable();
    }
  }
}
