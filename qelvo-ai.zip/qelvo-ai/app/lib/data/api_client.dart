import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:qelvo_ai/core/config.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/data/sse.dart';

/// Error dengan pesan yang sudah siap ditampilkan ke pengguna.
class ApiException implements Exception {
  const ApiException(this.message, {this.code = 'unknown', this.statusCode});

  final String message;
  final String code;
  final int? statusCode;

  @override
  String toString() => message;
}

typedef TokenProvider = Future<String?> Function();

class ApiClient {
  ApiClient(this._token);

  final TokenProvider _token;

  /// Jawaban yang berpikir lama atau mencari web tidak boleh terputus di tengah
  /// jalan. Server sendiri sabar sampai REQUEST_TIMEOUT_SECONDS (180 detik) dan
  /// mengirim keep-alive tiap beberapa detik selama menunggu, jadi batas di sini
  /// hanya jaring pengaman kalau server benar-benar tidak menjawab: [_connectTimeout]
  /// untuk menunggu balasan pertama, [_idleTimeout] untuk jeda antar baris.
  static const Duration _connectTimeout = Duration(seconds: 210);
  static const Duration _idleTimeout = Duration(seconds: 120);

  Uri _uri(String path) {
    final base = AppConfig.serverUrl.replaceAll(RegExp(r'/+$'), '');
    return Uri.parse('$base$path');
  }

  Future<Map<String, String>> _headers({bool auth = true}) async {
    final headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
    if (auth) {
      final token = await _token();
      if (token == null || token.isEmpty) {
        throw const ApiException(
          'Sesi belum aktif. Masuk dulu untuk memakai QELVO.',
          code: 'unauthorized',
          statusCode: 401,
        );
      }
      headers['Authorization'] = 'Bearer $token';
    }
    return headers;
  }

  Future<CatalogData> fetchCatalog() async {
    try {
      final response = await http
          .get(_uri('/v1/providers'), headers: await _headers())
          .timeout(const Duration(seconds: 15));
      final body = utf8.decode(response.bodyBytes);
      if (response.statusCode != 200) {
        throw _errorFromBody(response.statusCode, body);
      }
      final json = jsonDecode(body);
      if (json is! Map<String, dynamic>) throw const FormatException();
      return CatalogData.fromJson(json);
    } catch (error) {
      throw _translate(error);
    }
  }

  /// Minta server mengirim kode 6 digit ke email. Tanpa login.
  Future<EmailCodeInfo> startEmailCode(String email) async {
    try {
      final response = await http
          .post(
            _uri('/v1/auth/email/start'),
            headers: await _headers(auth: false),
            body: jsonEncode({'email': email}),
          )
          .timeout(const Duration(seconds: 30));
      final body = utf8.decode(response.bodyBytes);
      if (response.statusCode != 200) {
        throw _errorFromBody(response.statusCode, body);
      }
      final json = jsonDecode(body);
      if (json is! Map<String, dynamic>) throw const FormatException();
      return EmailCodeInfo.fromJson(json);
    } catch (error) {
      throw _translate(error);
    }
  }

  /// Menukar kode dari email dengan custom token Firebase.
  Future<String> verifyEmailCode(String email, String code) async {
    try {
      final response = await http
          .post(
            _uri('/v1/auth/email/verify'),
            headers: await _headers(auth: false),
            body: jsonEncode({'email': email, 'code': code}),
          )
          .timeout(const Duration(seconds: 30));
      final body = utf8.decode(response.bodyBytes);
      if (response.statusCode != 200) {
        throw _errorFromBody(response.statusCode, body);
      }
      final json = jsonDecode(body);
      final token = json is Map<String, dynamic> ? json['custom_token'] : null;
      if (token is! String || token.isEmpty) throw const FormatException();
      return token;
    } catch (error) {
      throw _translate(error);
    }
  }

  /// Meminta kode konfirmasi hapus akun dikirim ke email akun. Tanpa login:
  /// kode yang dikirim ke emailnya itulah buktinya.
  Future<EmailCodeInfo> startAccountDeletion(String email) async {
    try {
      final response = await http
          .post(
            _uri('/v1/account/delete/start'),
            headers: await _headers(auth: false),
            body: jsonEncode({'email': email}),
          )
          .timeout(const Duration(seconds: 30));
      final body = utf8.decode(response.bodyBytes);
      if (response.statusCode != 200) {
        throw _errorFromBody(response.statusCode, body);
      }
      final json = jsonDecode(body);
      return EmailCodeInfo.fromJson(
        json is Map<String, dynamic> ? json : const <String, dynamic>{},
      );
    } catch (error) {
      throw _translate(error);
    }
  }

  /// Menghapus akun beserta seluruh riwayatnya setelah kode terbukti benar.
  Future<void> confirmAccountDeletion(String email, String code) async {
    try {
      final response = await http
          .post(
            _uri('/v1/account/delete/confirm'),
            headers: await _headers(auth: false),
            body: jsonEncode({'email': email, 'code': code}),
          )
          .timeout(const Duration(seconds: 90));
      if (response.statusCode != 200) {
        throw _errorFromBody(response.statusCode, utf8.decode(response.bodyBytes));
      }
    } catch (error) {
      throw _translate(error);
    }
  }

  /// Satu permintaan JSON ke server dengan token login. Mengembalikan hasil
  /// decode, atau null kalau badan respons kosong. Kesalahan selalu berupa
  /// [ApiException] dengan pesan siap tampil.
  Future<Object?> request(
    String method,
    String path, {
    Object? body,
    Duration timeout = const Duration(seconds: 25),
  }) async {
    final client = http.Client();
    try {
      final outgoing = http.Request(method, _uri(path))
        ..headers.addAll(await _headers());
      if (body != null) outgoing.body = jsonEncode(body);
      final streamed = await client.send(outgoing).timeout(timeout);
      final response = await http.Response.fromStream(streamed).timeout(timeout);
      final text = utf8.decode(response.bodyBytes);
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw _errorFromBody(response.statusCode, text);
      }
      return text.trim().isEmpty ? null : jsonDecode(text);
    } catch (error) {
      throw _translate(error);
    } finally {
      client.close();
    }
  }

  /// Mengalirkan potongan jawaban. Koneksi ditutup begitu langganan dibatalkan.
  Stream<ChatEvent> streamChat({
    required List<Map<String, Object>> messages,
    String? providerId,
    String? modelId,
    required bool thinking,
    required String instruction,
    bool webSearch = false,
    String customInstruction = '',
  }) async* {
    final client = http.Client();
    try {
      final request = http.Request('POST', _uri('/v1/chat'))
        ..headers.addAll(await _headers())
        ..headers['Accept'] = 'text/event-stream'
        ..body = jsonEncode({
          'messages': messages,
          'provider': providerId,
          'model': modelId,
          'thinking': thinking,
          'instruction': instruction,
          // Hanya dikirim kalau menyala: server lama tidak mengenalnya. "auto"
          // menyerahkan penilaian ke server, yang mencari hanya untuk pertanyaan
          // yang butuh informasi terbaru atau kalau diminta, dan melewatinya
          // kalau ada foto.
          if (webSearch) 'web_search': 'auto',
          // Catatan pribadi dari pengaturan. Hanya dikirim kalau diisi.
          if (customInstruction.isNotEmpty) 'custom_instruction': customInstruction,
          'stream': true,
        });

      final response = await client.send(request).timeout(_connectTimeout);
      if (response.statusCode != 200) {
        final body = await response.stream.bytesToString();
        throw _errorFromBody(response.statusCode, body);
      }

      final lines = response.stream
          .transform(utf8.decoder)
          .transform(const LineSplitter())
          .timeout(_idleTimeout);

      await for (final line in lines) {
        final event = parseSseLine(line);
        if (event == null) continue;
        switch (event) {
          case DoneEvent():
            return;
          case ErrorEvent(:final code, :final message):
            throw ApiException(message, code: code);
          case DeltaEvent() || MetaEvent() || SourcesEvent():
            yield event;
        }
      }
      // Sampai di sini berarti aliran berhenti tanpa penanda selesai: koneksi
      // putus di tengah jawaban, jadi jangan dianggap sebagai jawaban lengkap.
      throw const ApiException(
        'Koneksi terputus sebelum jawaban selesai. Coba lagi.',
        code: 'stream_cut',
      );
    } catch (error) {
      throw _translate(error);
    } finally {
      client.close();
    }
  }

  ApiException _errorFromBody(int status, String body) {
    String? message;
    String? code;
    try {
      final json = jsonDecode(body);
      final error = json is Map<String, dynamic> ? json['error'] : null;
      if (error is Map<String, dynamic>) {
        final m = error['message'];
        final c = error['code'];
        if (m is String) message = m;
        if (c is String) code = c;
      }
    } on FormatException {
      // Badan respons bukan JSON (misalnya halaman error dari proxy).
    }
    message ??= switch (status) {
      401 => 'Sesi berakhir. Masuk lagi.',
      413 => 'Foto terlalu besar untuk dikirim. Kurangi jumlah foto.',
      429 => 'Terlalu banyak permintaan. Tunggu sebentar lalu coba lagi.',
      >= 500 => 'Server sedang bermasalah. Coba lagi nanti.',
      _ => 'Permintaan gagal ($status).',
    };
    return ApiException(message, code: code ?? 'http_$status', statusCode: status);
  }

  ApiException _translate(Object error) {
    if (error is ApiException) return error;
    if (error is TimeoutException) {
      return const ApiException(
        'Server tidak merespons. Coba lagi sebentar lagi.',
        code: 'timeout',
      );
    }
    if (error is SocketException ||
        error is HandshakeException ||
        error is http.ClientException) {
      return const ApiException(
        'Tidak bisa terhubung ke server QELVO. Periksa koneksi internet, lalu coba lagi.',
        code: 'offline',
      );
    }
    if (error is FormatException) {
      return const ApiException(
        'Respons server tidak dikenali.',
        code: 'bad_response',
      );
    }
    return const ApiException(
      'Terjadi kesalahan tak terduga. Coba lagi.',
      code: 'unknown',
    );
  }
}
