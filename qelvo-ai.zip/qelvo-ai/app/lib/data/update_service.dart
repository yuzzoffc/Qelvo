import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:qelvo_ai/data/update_models.dart';

/// Galat yang pesannya aman ditampilkan ke pengguna.
class UpdateException implements Exception {
  const UpdateException(this.message);

  final String message;

  @override
  String toString() => message;
}

/// Unduhan dibatalkan pengguna.
class UpdateCancelled implements Exception {
  const UpdateCancelled();
}

/// Penanda pembatalan yang dibaca pengunduh di tiap potongan data.
class UpdateCancel {
  bool isCancelled = false;

  void cancel() => isCancelled = true;
}

/// Sumber rilis: GitHub di aplikasi, palsu di tes.
abstract class UpdateSource {
  /// Rilis resmi terbaru, atau null kalau belum ada.
  Future<UpdateRelease?> fetchLatest();

  /// Mengunduh APK ke [dir] dan memastikan checksum-nya cocok.
  Future<File> download(
    UpdateRelease release,
    Directory dir, {
    required UpdateCancel cancel,
    required void Function(int received, int total) onProgress,
  });
}

/// Membaca rilis dari GitHub. Hanya repositori publik yang bisa dibaca tanpa token.
class UpdateClient implements UpdateSource {
  UpdateClient({required this.repo, http.Client? client})
      : _client = client ?? http.Client();

  /// `pemilik/nama`.
  final String repo;
  final http.Client _client;

  static const Duration _apiTimeout = Duration(seconds: 15);
  static const Duration _idleTimeout = Duration(seconds: 30);
  static const Map<String, String> _headers = {
    'Accept': 'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28',
    'User-Agent': 'QELVO-AI-Updater',
  };

  @override
  Future<UpdateRelease?> fetchLatest() => _guard(() async {
        final uri = Uri.https('api.github.com', '/repos/$repo/releases/latest');
        final response =
            await _client.get(uri, headers: _headers).timeout(_apiTimeout);
        // Belum ada rilis resmi, atau repositorinya privat (GitHub menjawab 404
        // tanpa token supaya tidak membocorkan keberadaannya).
        if (response.statusCode == 404) return null;
        if (response.statusCode == 403 || response.statusCode == 429) {
          throw const UpdateException(
            'Batas pemeriksaan GitHub tercapai. Coba lagi beberapa saat lagi.',
          );
        }
        if (response.statusCode != 200) {
          throw UpdateException('GitHub membalas ${response.statusCode}.');
        }
        final json = jsonDecode(utf8.decode(response.bodyBytes));
        return UpdateRelease.fromGitHub(json, repo: repo);
      });

  @override
  Future<File> download(
    UpdateRelease release,
    Directory dir, {
    required UpdateCancel cancel,
    required void Function(int received, int total) onProgress,
  }) =>
      _guard(() async {
        final expected = release.sha256 ?? await _fetchChecksum(release);
        if (expected == null) {
          throw const UpdateException(
            'Rilis ini tidak menyertakan checksum, jadi tidak dipasang demi keamanan.',
          );
        }
        await dir.create(recursive: true);
        await clearDirectory(dir);
        final target = File('${dir.path}/${release.apkName}');
        final part = File('${target.path}.part');

        final request = http.Request('GET', release.apkUrl)
          ..headers['User-Agent'] = _headers['User-Agent']!;
        final response = await _client.send(request).timeout(_apiTimeout);
        if (response.statusCode != 200) {
          throw UpdateException('Unduhan ditolak GitHub (${response.statusCode}).');
        }
        final total = response.contentLength ?? release.apkSize;
        final sink = part.openWrite();
        var received = 0;
        try {
          await for (final chunk in response.stream.timeout(_idleTimeout)) {
            if (cancel.isCancelled) throw const UpdateCancelled();
            sink.add(chunk);
            received += chunk.length;
            onProgress(received, total);
          }
          await sink.flush();
        } catch (_) {
          await sink.close().catchError((_) {});
          await _deleteQuietly(part);
          rethrow;
        }
        await sink.close();

        if (release.apkSize > 0 && received != release.apkSize) {
          await _deleteQuietly(part);
          throw const UpdateException('Unduhan tidak lengkap. Coba lagi.');
        }
        final actual = (await sha256.bind(part.openRead()).first).toString();
        if (actual != expected) {
          await _deleteQuietly(part);
          throw const UpdateException(
            'Berkas unduhan rusak (checksum tidak cocok). Coba lagi.',
          );
        }
        await part.rename(target.path);
        return target;
      });

  Future<String?> _fetchChecksum(UpdateRelease release) async {
    final url = release.checksumUrl;
    if (url == null) return null;
    final response =
        await _client.get(url, headers: _headers).timeout(_apiTimeout);
    if (response.statusCode != 200) return null;
    return parseSha256(utf8.decode(response.bodyBytes));
  }

  /// Menghapus sisa unduhan di [dir]. Aman dipanggil kalau folder belum ada.
  static Future<void> clearDirectory(Directory dir) async {
    if (!await dir.exists()) return;
    await for (final entity in dir.list()) {
      if (entity is File) await _deleteQuietly(entity);
    }
  }

  static Future<void> _deleteQuietly(File file) async {
    try {
      if (await file.exists()) await file.delete();
    } catch (_) {
      // Berkas sementara: gagal menghapusnya tidak mengubah hasil apa pun.
    }
  }

  /// Menerjemahkan galat jaringan dan berkas menjadi pesan yang bisa dibaca.
  Future<T> _guard<T>(Future<T> Function() action) async {
    try {
      return await action();
    } on UpdateException {
      rethrow;
    } on UpdateCancelled {
      rethrow;
    } on TimeoutException {
      throw const UpdateException('GitHub tidak merespons. Coba lagi nanti.');
    } on FileSystemException {
      throw const UpdateException(
        'Tidak bisa menyimpan unduhan. Ruang penyimpanan mungkin penuh.',
      );
    } on IOException {
      throw const UpdateException(
        'Tidak bisa terhubung ke GitHub. Periksa koneksi internetmu.',
      );
    } on http.ClientException {
      throw const UpdateException(
        'Tidak bisa terhubung ke GitHub. Periksa koneksi internetmu.',
      );
    } on FormatException {
      throw const UpdateException('Jawaban dari GitHub tidak terbaca.');
    }
  }

  void close() => _client.close();
}

/// Versi yang terpasang di HP, dibaca dari APK-nya.
class InstalledApp {
  const InstalledApp({
    required this.version,
    required this.code,
    required this.cacheDir,
  });

  final String version;
  final int code;

  /// Folder cache aplikasi. Unduhan disimpan di `updates/` di dalamnya, satu-satunya
  /// folder yang boleh disajikan `UpdateFileProvider` ke pemasang Android.
  final String cacheDir;
}

/// Jembatan ke bagian Android: versi terpasang, izin pasang, dan pemasangnya.
abstract class UpdatePlatform {
  Future<InstalledApp?> appInfo();

  /// Aplikasi sudah boleh memasang paket ("Izinkan dari sumber ini").
  Future<bool> canInstall();

  /// Membuka layar izin pasang untuk aplikasi ini.
  Future<void> openInstallSettings();

  /// Membuka pemasang Android untuk APK di [apkPath]. True kalau pemasangnya terbuka.
  Future<bool> install(String apkPath);
}

/// Lewat MethodChannel ke MainActivity (`tool/android/`). Di luar Android
/// salurannya tidak ada, dan semuanya berakhir sebagai "tidak tersedia".
class MethodChannelUpdatePlatform implements UpdatePlatform {
  const MethodChannelUpdatePlatform();

  static const MethodChannel _channel =
      MethodChannel('com.qelvo.qelvo_ai/updater');

  @override
  Future<InstalledApp?> appInfo() async {
    try {
      final raw = await _channel.invokeMapMethod<String, Object?>('appInfo');
      final version = raw?['version'];
      final code = raw?['code'];
      final cacheDir = raw?['cacheDir'];
      if (version is String && code is num && cacheDir is String) {
        return InstalledApp(
          version: version,
          code: code.toInt(),
          cacheDir: cacheDir,
        );
      }
    } catch (_) {
      // Bukan Android (tes, desktop): versi terpasang tidak diketahui.
    }
    return null;
  }

  @override
  Future<bool> canInstall() async {
    try {
      return await _channel.invokeMethod<bool>('canInstall') ?? false;
    } catch (_) {
      return false;
    }
  }

  @override
  Future<void> openInstallSettings() async {
    try {
      await _channel.invokeMethod<void>('openInstallSettings');
    } catch (_) {
      // Tidak ada yang bisa dilakukan dari sini; pengguna bisa membukanya sendiri.
    }
  }

  @override
  Future<bool> install(String apkPath) async {
    try {
      return await _channel.invokeMethod<bool>('install', {'path': apkPath}) ??
          false;
    } catch (_) {
      return false;
    }
  }
}
