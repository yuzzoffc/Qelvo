import 'package:firebase_auth/firebase_auth.dart';

/// Gagal masuk dengan pesan yang siap ditampilkan.
class AuthFailure implements Exception {
  const AuthFailure(this.message);

  final String message;

  @override
  String toString() => message;
}

class AuthService {
  FirebaseAuth get _auth => FirebaseAuth.instance;

  Stream<User?> get authState => _auth.authStateChanges();

  User? get currentUser => _auth.currentUser;

  /// Token ID Firebase untuk header Authorization ke backend. SDK memperbarui
  /// token otomatis kalau sudah hampir kedaluwarsa.
  Future<String?> idToken() async => _auth.currentUser?.getIdToken();

  /// Login Google lewat halaman Firebase (Custom Tab), tanpa paket google_sign_in.
  /// Mengembalikan false kalau pengguna menutup halamannya.
  Future<bool> signInWithGoogle() async {
    try {
      final provider = GoogleAuthProvider();
      provider.addScope('email');
      await _auth.signInWithProvider(provider);
      return true;
    } on FirebaseAuthException catch (error) {
      if (_isCancel(error.code)) return false;
      throw AuthFailure(_messageFor(error));
    }
  }

  Future<void> signInWithCustomToken(String token) async {
    try {
      await _auth.signInWithCustomToken(token);
    } on FirebaseAuthException catch (error) {
      throw AuthFailure(_messageFor(error));
    }
  }

  Future<void> signOut() => _auth.signOut();

  bool _isCancel(String code) =>
      code == 'canceled' ||
      code == 'cancelled' ||
      code == 'web-context-canceled' ||
      code == 'web-context-cancelled' ||
      code == 'popup-closed-by-user';

  String _messageFor(FirebaseAuthException error) {
    switch (error.code) {
      case 'network-request-failed':
        return 'Tidak ada koneksi internet. Coba lagi setelah tersambung.';
      case 'user-disabled':
        return 'Akun ini dinonaktifkan.';
      case 'account-exists-with-different-credential':
        return 'Email ini sudah dipakai dengan cara masuk yang lain.';
      case 'invalid-custom-token':
      case 'custom-token-mismatch':
        return 'Kode diterima, tetapi proyek Firebase di aplikasi dan server tidak sama.';
      case 'too-many-requests':
        return 'Terlalu banyak percobaan. Tunggu beberapa menit.';
      default:
        return 'Gagal masuk (${error.code}). Coba lagi.';
    }
  }
}
