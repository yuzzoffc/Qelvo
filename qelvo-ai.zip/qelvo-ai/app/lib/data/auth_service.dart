import 'package:firebase_auth/firebase_auth.dart';

/// Gagal masuk dengan pesan yang siap ditampilkan.
class AuthFailure implements Exception {
  const AuthFailure(this.message);

  final String message;

  @override
  String toString() => message;
}

class AuthService {
  FirebaseAuth get _auth => FirebaseAuth.instance;

  Stream<User?> get authState => _auth.authStateChanges();

  User? get currentUser => _auth.currentUser;

  /// Token ID Firebase untuk header Authorization ke backend. SDK memperbarui
  /// token otomatis kalau sudah hampir kedaluwarsa.
  Future<String?> idToken() async => _auth.currentUser?.getIdToken();

  /// Login Google lewat halaman Firebase (Custom Tab), tanpa paket google_sign_in.
  /// Mengembalikan false kalau pengguna menutup halamannya.
  ///
  /// `prompt=select_account` membuat Google selalu menampilkan pilihan akun.
  /// Tanpa itu, setelah keluar, tombol ini langsung masuk lagi dengan akun yang
  /// sama dan pengguna tidak bisa ganti akun Google.
  Future<bool> signInWithGoogle() async {
    try {
      final provider = GoogleAuthProvider()
        ..addScope('email')
        ..addScope('profile')
        ..setCustomParameters({'prompt': 'select_account'});
      await _auth.signInWithProvider(provider);
      return true;
    } on FirebaseAuthException catch (error) {
      if (_isCancel(error.code)) return false;
      throw AuthFailure(_messageFor(error));
    }
  }

  /// Akun tamu: akun anonim Firebase, punya uid dan token tetapi tanpa email.
  Future<void> signInAsGuest() async {
    try {
      await _auth.signInAnonymously();
    } on FirebaseAuthException catch (error) {
      throw AuthFailure(_messageFor(error));
    }
  }

  Future<void> signInWithCustomToken(String token) async {
    try {
      await _auth.signInWithCustomToken(token);
    } on FirebaseAuthException catch (error) {
      throw AuthFailure(_messageFor(error));
    }
  }

  /// Keluar. Akun tamu tidak bisa dimasuki lagi, jadi [deleteGuestAccount]
  /// ikut menghapusnya dari Firebase supaya tidak menumpuk akun anonim.
  /// Kalau penghapusan ditolak (misalnya sesi sudah lama), tetap keluar biasa.
  Future<void> signOut({bool deleteGuestAccount = false}) async {
    final user = _auth.currentUser;
    if (deleteGuestAccount && user != null && user.isAnonymous) {
      try {
        await user.delete();
      } on FirebaseAuthException {
        // Dilanjutkan ke signOut di bawah.
      }
    }
    await _auth.signOut();
  }

  bool _isCancel(String code) =>
      code == 'canceled' ||
      code == 'cancelled' ||
      code == 'user-cancelled' ||
      code == 'web-context-canceled' ||
      code == 'web-context-cancelled' ||
      code == 'popup-closed-by-user';

  String _messageFor(FirebaseAuthException error) {
    switch (error.code) {
      case 'network-request-failed':
        return 'Tidak ada koneksi internet. Coba lagi setelah tersambung.';
      case 'user-disabled':
        return 'Akun ini dinonaktifkan.';
      case 'operation-not-allowed':
      case 'admin-restricted-operation':
        return 'Cara masuk ini belum diaktifkan di Firebase (Authentication, Sign-in method).';
      case 'account-exists-with-different-credential':
        return 'Email ini sudah dipakai dengan cara masuk yang lain.';
      case 'web-internal-error':
      case 'internal-error':
      case 'missing-client-identifier':
      case 'app-not-authorized':
        return 'Login Google belum siap. Daftarkan SHA-1 dan SHA-256 aplikasi di Firebase, aktifkan Google di Authentication, lalu bangun ulang APK (lihat docs/SETUP.md).';
      case 'credential-already-in-use':
        return 'Akun Google ini sudah terhubung ke akun QELVO lain.';
      case 'invalid-credential':
        return 'Data masuk dari Google ditolak atau sudah kedaluwarsa. Coba masuk lagi.';
      case 'invalid-custom-token':
      case 'custom-token-mismatch':
        return 'Kode diterima, tetapi proyek Firebase di aplikasi dan server tidak sama.';
      case 'too-many-requests':
        return 'Terlalu banyak percobaan. Tunggu beberapa menit.';
      default:
        return 'Gagal masuk (${error.code}). Coba lagi.';
    }
  }
}
