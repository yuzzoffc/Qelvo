package com.qelvo.qelvo_ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager

/**
 * Menjaga CPU tetap menyala selama QELVO menyiapkan jawaban, supaya aliran jawaban
 * tidak berhenti saat layar mati atau aplikasi ditinggal. Sengaja tanpa layanan
 * latar depan: layanan itu mewajibkan pemberitahuan tetap selama berjalan, sedangkan
 * pemberitahuan hanya boleh muncul saat jawaban sudah selesai.
 *
 * Batasnya sengaja dibiarkan: wake lock tidak menahan Android yang menghemat baterai,
 * membatasi jaringan latar belakang, atau mematikan proses aplikasi.
 * [MAX_HOLD_MS] menjaga wake lock tidak tertahan kalau Dart tak sempat melepasnya.
 */
internal object AnswerKeeper {
    private const val MAX_HOLD_MS = 10 * 60 * 1000L

    private var wakeLock: PowerManager.WakeLock? = null

    @Synchronized
    fun hold(context: Context) {
        if (wakeLock?.isHeld == true) return
        val power = context.applicationContext.getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "qelvo:answer").apply {
            setReferenceCounted(false)
            acquire(MAX_HOLD_MS)
        }
    }

    @Synchronized
    fun release() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }
}

/** Satu-satunya pemberitahuan aplikasi: "sudah menjawab", saat jawaban selesai di latar belakang. */
internal object Notifications {
    private const val DONE_ID = 4202
    private const val CHANNEL_DONE = "qelvo_answer_done"

    fun postDone(context: Context, title: String, text: String) {
        val manager = manager(context) ?: return
        ensureChannel(manager)
        val notification = builder(context)
            .setSmallIcon(R.drawable.ic_stat_qelvo)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(openApp(context))
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_MESSAGE)
            .build()
        manager.notify(DONE_ID, notification)
    }

    fun clearDone(context: Context) {
        manager(context)?.cancel(DONE_ID)
    }

    private fun ensureChannel(manager: NotificationManager) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_DONE,
                "Jawaban selesai",
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply {
                description = "Memberi tahu saat jawaban QELVO siap dan kamu sedang di luar aplikasi."
            },
        )
    }

    private fun manager(context: Context): NotificationManager? =
        context.getSystemService(NotificationManager::class.java)

    @Suppress("DEPRECATION")
    private fun builder(context: Context): Notification.Builder {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(context, CHANNEL_DONE)
        } else {
            Notification.Builder(context)
        }
    }

    /** Membuka aplikasi seperti mengetuk ikonnya: tugas yang ada dibawa ke depan. */
    private fun openApp(context: Context): PendingIntent {
        val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
            ?: Intent()
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        var flags = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags = flags or PendingIntent.FLAG_IMMUTABLE
        }
        return PendingIntent.getActivity(context, 0, launch, flags)
    }
}
