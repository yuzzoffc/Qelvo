package com.qelvo.qelvo_ai

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

/**
 * Activity utama. Selain menjalankan Flutter, ia menjembatani Dart ke
 * [AnswerService] supaya jawaban AI tetap mengalir saat aplikasi ditinggal, dan
 * menyembunyikan aplikasi (bukan menutupnya) saat tombol kembali ditekan di
 * tengah jawaban. Saluran dan perintahnya dipakai oleh
 * lib/data/background_run.dart.
 */
class MainActivity : FlutterActivity() {

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result -> onCall(call, result) }
    }

    override fun onResume() {
        super.onResume()
        // Pengguna sudah kembali, jadi "sudah menjawab" tak perlu lagi tampil.
        Notifications.clearDone(this)
    }

    override fun onDestroy() {
        // Mesin Flutter ikut mati bersama activity, jadi tak ada lagi yang
        // mengalirkan jawaban. Jangan biarkan "sedang menjawab" menggantung.
        if (isFinishing) AnswerService.stop()
        super.onDestroy()
    }

    private fun onCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "begin" -> result.success(begin(call.argument<String>("title"), call.argument<String>("text")))
            "end" -> {
                end(
                    notify = call.argument<Boolean>("notify") ?: false,
                    title = call.argument<String>("title"),
                    text = call.argument<String>("text"),
                )
                result.success(null)
            }
            "moveToBack" -> result.success(moveTaskToBack(true))
            else -> result.notImplemented()
        }
    }

    private fun begin(title: String?, text: String?): Boolean {
        return try {
            AnswerService.start(this, title, text)
            askNotificationPermissionOnce()
            true
        } catch (e: Exception) {
            // Sistem bisa menolak layanan latar depan. Jawaban tetap berjalan
            // selama aplikasi terbuka, hanya tidak dilindungi saat ditinggal.
            Log.w(TAG, "Layanan latar depan tidak bisa dimulai", e)
            false
        }
    }

    private fun end(notify: Boolean, title: String?, text: String?) {
        AnswerService.stop()
        if (notify && title != null && text != null) {
            Notifications.postDone(this, title, text)
        }
    }

    /**
     * Android 13 ke atas menyembunyikan pemberitahuan sampai pengguna mengizinkan.
     * Ditanyakan sekali saja, saat pesan pertama dikirim, supaya "sudah menjawab"
     * bisa muncul kalau pengguna keluar dari aplikasi. Layanannya sendiri tetap
     * jalan tanpa izin ini.
     */
    private fun askNotificationPermissionOnce() {
        // 33 = Android 13, versi pertama dengan izin pemberitahuan.
        if (Build.VERSION.SDK_INT < 33) return
        val permission = "android.permission.POST_NOTIFICATIONS"
        if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) return
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_ASKED, false)) return
        prefs.edit().putBoolean(KEY_ASKED, true).apply()
        requestPermissions(arrayOf(permission), REQUEST_NOTIFICATIONS)
    }

    private companion object {
        const val CHANNEL = "com.qelvo.qelvo_ai/background"
        const val TAG = "QelvoBackground"
        const val PREFS = "qelvo_background"
        const val KEY_ASKED = "asked_notifications"
        const val REQUEST_NOTIFICATIONS = 4101
    }
}
