package com.qelvo.qelvo_ai

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.speech.RecognizerIntent
import android.util.Log
import java.io.File
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

/**
 * Activity utama. Selain menjalankan Flutter, ia menjembatani Dart ke [AnswerKeeper]
 * supaya jawaban AI tetap mengalir saat aplikasi ditinggal, memberi tahu pengguna
 * lewat [Notifications] hanya saat jawaban selesai, dan menyembunyikan aplikasi
 * (bukan menutupnya) saat tombol kembali ditekan di tengah jawaban. Saluran dan
 * perintahnya dipakai oleh lib/data/background_run.dart.
 *
 * Saluran [VOICE] membuka dialog pengenal ucapan bawaan Android untuk input suara
 * (lib/data/voice_input.dart).
 *
 * Saluran kedua, [UPDATER], melayani pembaruan lewat GitHub (lib/data/update_service.dart):
 * versi yang terpasang, izin pasang, dan membuka pemasang Android untuk APK yang
 * sudah diunduh dan diperiksa checksum-nya oleh Dart.
 */
class MainActivity : FlutterActivity() {

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result -> onCall(call, result) }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, UPDATER)
            .setMethodCallHandler { call, result -> onUpdaterCall(call, result) }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, VOICE)
            .setMethodCallHandler { call, result -> onVoiceCall(call, result) }
    }

    /** Hasil dialog suara yang sedang menunggu jawaban; hanya satu dialog sekaligus. */
    private var pendingVoice: MethodChannel.Result? = null

    /**
     * Input suara lewat dialog pengenal ucapan bawaan Android (lib/data/voice_input.dart).
     * Dialog sistem itu yang meminta izin mikrofon, jadi aplikasi tidak butuh izinnya.
     */
    @Suppress("DEPRECATION")
    private fun onVoiceCall(call: MethodCall, result: MethodChannel.Result) {
        if (call.method != "listen") {
            result.notImplemented()
            return
        }
        if (pendingVoice != null) {
            result.error("busy", "Input suara sedang berjalan.", null)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, call.argument<String>("locale") ?: "id-ID")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Bicara sekarang")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        pendingVoice = result
        try {
            startActivityForResult(intent, REQUEST_VOICE)
        } catch (e: ActivityNotFoundException) {
            pendingVoice = null
            result.error("unavailable", "Input suara tidak tersedia di HP ini.", null)
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQUEST_VOICE) {
            val reply = pendingVoice
            pendingVoice = null
            val text = if (resultCode == Activity.RESULT_OK) {
                data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            } else {
                null
            }
            reply?.success(text)
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    override fun onResume() {
        super.onResume()
        // Pengguna sudah kembali, jadi "sudah menjawab" tak perlu lagi tampil.
        Notifications.clearDone(this)
    }

    override fun onDestroy() {
        // Mesin Flutter ikut mati bersama activity, jadi tak ada lagi yang
        // mengalirkan jawaban. Jangan biarkan wake lock tertahan.
        if (isFinishing) AnswerKeeper.release()
        super.onDestroy()
    }

    private fun onCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "begin" -> result.success(begin())
            "end" -> {
                end(
                    notify = call.argument<Boolean>("notify") ?: false,
                    title = call.argument<String>("title"),
                    text = call.argument<String>("text"),
                )
                result.success(null)
            }
            "moveToBack" -> result.success(moveTaskToBack(true))
            else -> result.notImplemented()
        }
    }

    private fun onUpdaterCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "appInfo" -> result.success(appInfo())
            "canInstall" -> result.success(canInstallPackages())
            "openInstallSettings" -> {
                openInstallSettings()
                result.success(null)
            }
            "install" -> result.success(installApk(call.argument<String>("path")))
            else -> result.notImplemented()
        }
    }

    /** Versi dan folder cache, dibaca dari APK yang sedang berjalan. */
    @Suppress("DEPRECATION")
    private fun appInfo(): Map<String, Any?> {
        val info = packageManager.getPackageInfo(packageName, 0)
        val code: Long = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            info.longVersionCode
        } else {
            info.versionCode.toLong()
        }
        return mapOf(
            "version" to (info.versionName ?: ""),
            "code" to code,
            "cacheDir" to cacheDir.absolutePath,
        )
    }

    /** Android 8 ke atas butuh izin "Pasang aplikasi tak dikenal" per aplikasi. */
    private fun canInstallPackages(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.O || packageManager.canRequestPackageInstalls()

    private fun openInstallSettings() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        try {
            startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
            )
        } catch (e: ActivityNotFoundException) {
            Log.w(TAG, "Layar izin pasang tidak bisa dibuka", e)
        }
    }

    /**
     * Membuka pemasang Android untuk APK di [path]. Hanya berkas `.apk` di
     * `cache/updates/` yang diterima, sama seperti yang dilayani [UpdateFileProvider].
     */
    private fun installApk(path: String?): Boolean {
        if (path == null) return false
        return try {
            val file = File(path)
            val dir = File(cacheDir, UpdateFileProvider.UPDATES_DIR)
            if (!file.isFile || file.canonicalFile.parentFile != dir.canonicalFile) return false
            val uri = UpdateFileProvider.uriFor(packageName, file.name)
            val intent = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, UpdateFileProvider.APK_MIME)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            true
        } catch (e: Exception) {
            Log.w(TAG, "Pemasang Android tidak bisa dibuka", e)
            false
        }
    }

    private fun begin(): Boolean {
        return try {
            AnswerKeeper.hold(this)
            askNotificationPermissionOnce()
            true
        } catch (e: Exception) {
            // Jawaban tetap berjalan selama aplikasi terbuka, hanya tidak
            // dilindungi saat ditinggal.
            Log.w(TAG, "Wake lock tidak bisa dipegang", e)
            false
        }
    }

    private fun end(notify: Boolean, title: String?, text: String?) {
        AnswerKeeper.release()
        if (notify && title != null && text != null) {
            Notifications.postDone(this, title, text)
        }
    }

    /**
     * Android 13 ke atas menyembunyikan pemberitahuan sampai pengguna mengizinkan.
     * Ditanyakan sekali saja, saat pesan pertama dikirim, supaya "sudah menjawab"
     * bisa muncul kalau pengguna keluar dari aplikasi. Jawabannya sendiri tetap
     * berjalan tanpa izin ini.
     */
    private fun askNotificationPermissionOnce() {
        // 33 = Android 13, versi pertama dengan izin pemberitahuan.
        if (Build.VERSION.SDK_INT < 33) return
        val permission = "android.permission.POST_NOTIFICATIONS"
        if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) return
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_ASKED, false)) return
        prefs.edit().putBoolean(KEY_ASKED, true).apply()
        requestPermissions(arrayOf(permission), REQUEST_NOTIFICATIONS)
    }

    private companion object {
        const val CHANNEL = "com.qelvo.qelvo_ai/background"
        const val UPDATER = "com.qelvo.qelvo_ai/updater"
        const val VOICE = "com.qelvo.qelvo_ai/voice"
        const val TAG = "QelvoBackground"
        const val PREFS = "qelvo_background"
        const val KEY_ASKED = "asked_notifications"
        const val REQUEST_NOTIFICATIONS = 4101
        const val REQUEST_VOICE = 4102
    }
}
