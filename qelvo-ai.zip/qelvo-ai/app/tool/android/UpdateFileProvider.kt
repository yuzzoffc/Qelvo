package com.qelvo.qelvo_ai

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.File
import java.io.FileNotFoundException

/**
 * Menyajikan APK pembaruan yang sudah diunduh ke pemasang Android lewat `content://`.
 *
 * Pemasang sistem tidak boleh membaca folder cache aplikasi secara langsung, jadi
 * APK-nya dibukakan lewat penyedia ini dengan izin sementara dari intent pemasangan
 * (`grantUriPermissions`). Sengaja sempit: hanya mode baca, hanya berkas `.apk`, dan
 * hanya yang ada langsung di `cache/updates/`. Tidak memakai androidx FileProvider
 * supaya tidak bergantung pada pustaka yang belum tentu ikut terpasang.
 */
class UpdateFileProvider : ContentProvider() {

    override fun onCreate(): Boolean = true

    override fun getType(uri: Uri): String? =
        if (resolve(uri) != null) APK_MIME else null

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor? {
        if (mode != "r") throw FileNotFoundException("Hanya mode baca")
        val file = resolve(uri) ?: throw FileNotFoundException(uri.toString())
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?,
    ): Cursor? {
        val file = resolve(uri) ?: return null
        val columns = arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        val cursor = MatrixCursor(columns, 1)
        cursor.addRow(arrayOf<Any>(file.name, file.length()))
        return cursor
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null

    override fun update(
        uri: Uri,
        values: ContentValues?,
        selection: String?,
        selectionArgs: Array<out String>?,
    ): Int = 0

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0

    /**
     * Berkas yang dimaksud [uri], atau null kalau bukan APK di `cache/updates/`.
     * Nama diambil dari segmen terakhir lalu diperiksa tiga kali: tanpa pemisah
     * folder, berakhiran .apk, dan alamat aslinya tetap di dalam folder itu.
     */
    private fun resolve(uri: Uri): File? {
        val name = uri.lastPathSegment ?: return null
        if (name.contains('/') || name.contains('\\') || !name.endsWith(".apk")) return null
        val base = context?.cacheDir ?: return null
        val dir = File(base, UPDATES_DIR)
        val file = File(dir, name)
        return try {
            val inside = file.canonicalFile.parentFile == dir.canonicalFile
            if (inside && file.isFile) file else null
        } catch (e: java.io.IOException) {
            null
        }
    }

    companion object {
        const val UPDATES_DIR = "updates"
        const val APK_MIME = "application/vnd.android.package-archive"

        /** Alamat `content://` untuk APK bernama [fileName] di `cache/updates/`. */
        fun uriFor(packageName: String, fileName: String): Uri =
            Uri.Builder()
                .scheme("content")
                .authority("$packageName.updates")
                .appendPath(fileName)
                .build()
    }
}
