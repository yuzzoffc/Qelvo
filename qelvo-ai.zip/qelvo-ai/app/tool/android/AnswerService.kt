package com.qelvo.qelvo_ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log

/**
 * Layanan latar depan selama QELVO menyiapkan jawaban. Dengan ini Android jauh
 * lebih jarang mematikan proses saat aplikasi ditinggal, layar mati, atau hemat
 * baterai menyala; wake lock saja tidak cukup untuk itu.
 *
 * Harganya satu pemberitahuan senyap ("QELVO sedang menjawab") yang hilang begitu
 * jawabannya selesai. Dimulai oleh [AnswerKeeper.hold] saat pengguna mengirim
 * pesan (aplikasi sedang di depan, jadi Android 12 ke atas mengizinkannya) dan
 * dihentikan oleh [AnswerKeeper.release].
 */
class AnswerService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val notification = buildNotification(this)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            // Android menolak (misalnya aplikasi sudah tidak di depan). Jawaban tetap
            // berjalan dengan wake lock saja.
            Log.w(TAG, "Layanan latar depan tidak bisa dimulai", e)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    companion object {
        private const val TAG = "QelvoAnswerService"
        private const val NOTIFICATION_ID = 4203
        private const val CHANNEL_ID = "qelvo_answering"

        fun start(context: Context) {
            val intent = Intent(context, AnswerService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, AnswerService::class.java))
        }

        private fun buildNotification(context: Context): Notification {
            val manager = context.getSystemService(NotificationManager::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                manager?.createNotificationChannel(
                    NotificationChannel(
                        CHANNEL_ID,
                        "Sedang menjawab",
                        NotificationManager.IMPORTANCE_LOW,
                    ).apply {
                        description = "Tampil singkat selama QELVO menyiapkan jawaban."
                        setShowBadge(false)
                    },
                )
            }
            @Suppress("DEPRECATION")
            val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification.Builder(context, CHANNEL_ID)
            } else {
                Notification.Builder(context)
            }
            return builder
                .setSmallIcon(R.drawable.ic_stat_qelvo)
                .setContentTitle("QELVO sedang menjawab")
                .setContentText("Jawaban tetap berjalan di latar belakang.")
                .setContentIntent(openApp(context))
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_PROGRESS)
                .build()
        }

        private fun openApp(context: Context): PendingIntent {
            val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
                ?: Intent()
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            var flags = PendingIntent.FLAG_UPDATE_CURRENT
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                flags = flags or PendingIntent.FLAG_IMMUTABLE
            }
            return PendingIntent.getActivity(context, 1, launch, flags)
        }
    }
}
