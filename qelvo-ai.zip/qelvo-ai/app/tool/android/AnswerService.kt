package com.qelvo.qelvo_ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

/**
 * Layanan latar depan yang menjaga proses aplikasi tetap hidup selama QELVO
 * menyiapkan jawaban. Dart yang mengalirkan jawabannya (di isolate utama);
 * layanan ini hanya memberi tahu sistem bahwa ada pekerjaan jaringan yang
 * sedang berjalan, supaya proses tidak dibekukan saat layar mati atau aplikasi
 * ditinggal, dan pengguna melihat pemberitahuan "sedang menjawab".
 *
 * Dimulai saat jawaban mulai dan dihentikan saat jawaban berakhir. Batas waktu
 * [MAX_RUN_MS] menjaga layanan tidak menggantung kalau Dart tak sempat
 * memanggil berhenti.
 */
class AnswerService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val giveUp = Runnable { stopRunning() }
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val title = intent?.getStringExtra(EXTRA_TITLE) ?: DEFAULT_TITLE
        val text = intent?.getStringExtra(EXTRA_TEXT) ?: DEFAULT_TEXT
        Notifications.ensureChannels(this)

        // Wajib dipanggil segera setelah startForegroundService, kalau tidak
        // sistem menutup aplikasi. Tipe layanan (dataSync) diambil dari manifest.
        startForeground(
            Notifications.RUNNING_ID,
            Notifications.running(this, title, text),
        )

        if (stopRequested) {
            // Jawabannya sudah berakhir sebelum layanan sempat siap (misalnya
            // gagal seketika). Berhenti sekarang, setelah startForeground.
            stopRequested = false
            stopRunning()
            return START_NOT_STICKY
        }

        instance = this
        holdWakeLock()
        handler.removeCallbacks(giveUp)
        handler.postDelayed(giveUp, MAX_RUN_MS)
        // Kalau proses dimatikan, jawabannya hilang bersama isolate Dart, jadi
        // tidak ada gunanya menghidupkan layanan ini lagi.
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Aplikasi digeser dari daftar terbaru: mesin Flutter ikut mati, jadi
        // tidak ada lagi yang mengalirkan jawaban.
        stopRunning()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        handler.removeCallbacks(giveUp)
        releaseWakeLock()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun stopRunning() {
        if (instance === this) instance = null
        handler.removeCallbacks(giveUp)
        releaseWakeLock()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(Service.STOP_FOREGROUND_REMOVE)
        } else {
            stopForeground(true)
        }
        stopSelf()
    }

    private fun holdWakeLock() {
        if (wakeLock?.isHeld == true) return
        val power = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "qelvo:answer").apply {
            setReferenceCounted(false)
            acquire(MAX_RUN_MS)
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_TEXT = "text"

        private const val DEFAULT_TITLE = "QELVO sedang menjawab"
        private const val DEFAULT_TEXT = "Jawaban tetap berjalan walau kamu keluar dari aplikasi."
        private const val MAX_RUN_MS = 10 * 60 * 1000L

        @Volatile
        private var instance: AnswerService? = null

        /** Permintaan berhenti yang datang sebelum layanan sempat siap. */
        @Volatile
        private var stopRequested = false

        /** Memulai layanan. Harus dipanggil saat aplikasi masih terlihat. */
        fun start(context: Context, title: String?, text: String?) {
            stopRequested = false
            val intent = Intent(context, AnswerService::class.java)
                .putExtra(EXTRA_TITLE, title)
                .putExtra(EXTRA_TEXT, text)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        /**
         * Menghentikan layanan. Sengaja tidak lewat stopService: menghentikan
         * layanan latar depan sebelum ia memanggil startForeground membuat
         * aplikasi ditutup sistem, dan jawaban yang gagal seketika bisa
         * berakhir lebih cepat daripada layanannya siap.
         */
        fun stop() {
            val running = instance
            if (running != null) {
                running.stopRunning()
            } else {
                stopRequested = true
            }
        }
    }
}

/** Saluran dan isi pemberitahuan: "sedang menjawab" dan "sudah menjawab". */
internal object Notifications {
    const val RUNNING_ID = 4201
    private const val DONE_ID = 4202
    private const val CHANNEL_RUNNING = "qelvo_answer_running"
    private const val CHANNEL_DONE = "qelvo_answer_done"

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = manager(context) ?: return
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_RUNNING,
                "Jawaban berjalan",
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "Tampil selama QELVO menyiapkan jawaban di latar belakang."
                setShowBadge(false)
            },
        )
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_DONE,
                "Jawaban selesai",
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply {
                description = "Memberi tahu saat jawaban QELVO siap dan kamu sedang di luar aplikasi."
            },
        )
    }

    @Suppress("DEPRECATION")
    fun running(context: Context, title: String, text: String): Notification {
        return builder(context, CHANNEL_RUNNING)
            .setSmallIcon(R.drawable.ic_stat_qelvo)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(openApp(context))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(Notification.CATEGORY_PROGRESS)
            .setPriority(Notification.PRIORITY_LOW)
            .setProgress(0, 0, true)
            .build()
    }

    fun postDone(context: Context, title: String, text: String) {
        val manager = manager(context) ?: return
        ensureChannels(context)
        val notification = builder(context, CHANNEL_DONE)
            .setSmallIcon(R.drawable.ic_stat_qelvo)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(openApp(context))
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_MESSAGE)
            .build()
        manager.notify(DONE_ID, notification)
    }

    fun clearDone(context: Context) {
        manager(context)?.cancel(DONE_ID)
    }

    private fun manager(context: Context): NotificationManager? =
        context.getSystemService(NotificationManager::class.java)

    @Suppress("DEPRECATION")
    private fun builder(context: Context, channel: String): Notification.Builder {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(context, channel)
        } else {
            Notification.Builder(context)
        }
    }

    /** Membuka aplikasi seperti mengetuk ikonnya: tugas yang ada dibawa ke depan. */
    private fun openApp(context: Context): PendingIntent {
        val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
            ?: Intent()
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        var flags = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags = flags or PendingIntent.FLAG_IMMUTABLE
        }
        return PendingIntent.getActivity(context, 0, launch, flags)
    }
}
