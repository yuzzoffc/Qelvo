#!/usr/bin/env bash
# Menyiapkan folder android/ untuk proyek ini. Aman dijalankan berulang kali.
# Butuh Flutter di PATH dan sed versi GNU (Linux, Codespaces, GitHub Actions).
set -euo pipefail
cd "$(dirname "$0")/.."

if [ ! -d android ]; then
  flutter create --platforms=android --org com.qelvo --project-name qelvo_ai .
fi

# Tes contoh bawaan flutter create merujuk MyApp yang tidak ada di proyek ini.
if grep -q 'MyApp' test/widget_test.dart 2>/dev/null; then
  rm test/widget_test.dart
fi

# Manifest milik proyek: izin INTERNET, nama aplikasi, queries untuk url_launcher,
# serta izin wake lock dan pemberitahuan untuk jawaban di latar belakang.
cp tool/AndroidManifest.xml android/app/src/main/AndroidManifest.xml

# Build debug boleh http:// ke server lokal; build rilis hanya https.
mkdir -p android/app/src/debug
cp tool/AndroidManifestDebug.xml android/app/src/debug/AndroidManifest.xml

# Kode native untuk jawaban di latar belakang (lihat docs/ARCHITECTURE.md):
# wake lock, layanan latar depan, pemberitahuan "sudah menjawab", input suara,
# pemasang pembaruan OTA
# (UpdateFileProvider), jembatan ke Dart, dan ikon pemberitahuan. MainActivity
# bawaan flutter create diganti karena harus membuka saluran ke semuanya.
# Foldernya mengikuti MainActivity bawaan supaya paketnya tetap cocok.
found=$(find android/app/src/main \( -name MainActivity.kt -o -name MainActivity.java \) | head -n 1 || true)
if [ -n "$found" ]; then
  native_dir=$(dirname "$found")
else
  native_dir=android/app/src/main/kotlin/com/qelvo/qelvo_ai
  mkdir -p "$native_dir"
fi
rm -f "$native_dir/MainActivity.java"
cp tool/android/MainActivity.kt tool/android/Notifications.kt tool/android/AnswerService.kt tool/android/UpdateFileProvider.kt "$native_dir/"
mkdir -p android/app/src/main/res/drawable
cp tool/android/ic_stat_qelvo.xml android/app/src/main/res/drawable/ic_stat_qelvo.xml

# Firebase membutuhkan minSdk 23. Kalau bawaan Flutter sudah lebih tinggi,
# nilai yang lebih tinggi itu yang dipakai.
kts=android/app/build.gradle.kts
groovy=android/app/build.gradle
if [ -f "$kts" ] && grep -q 'flutter.minSdkVersion' "$kts" && ! grep -q 'maxOf(23' "$kts"; then
  sed -i 's/flutter\.minSdkVersion/maxOf(23, flutter.minSdkVersion)/' "$kts"
elif [ -f "$groovy" ] && grep -q 'flutter.minSdkVersion' "$groovy" && ! grep -q 'Math.max(23' "$groovy"; then
  sed -i 's/flutter\.minSdkVersion/Math.max(23, flutter.minSdkVersion)/' "$groovy"
fi

# assembleRelease ikut menjalankan lint rilis (lintVital). Ia bisa menggagalkan build karena
# temuan atau karena lint sendiri crash ("LINT_PRINT_STACKTRACE" di log), padahal tidak
# mengubah isi APK. Untuk build CI dimatikan; kesalahan nyata tetap tertangkap oleh
# kompilasi Dart dan Kotlin. Aman dijalankan berulang.
if [ -f "$kts" ] && ! grep -q 'checkReleaseBuilds' "$kts"; then
  sed -i '0,/^android {/s//android {\n    lint {\n        checkReleaseBuilds = false\n        abortOnError = false\n    }/' "$kts"
elif [ -f "$groovy" ] && ! grep -q 'checkReleaseBuilds' "$groovy"; then
  sed -i '0,/^android {/s//android {\n    lint {\n        checkReleaseBuilds false\n        abortOnError false\n    }/' "$groovy"
fi
if ! grep -q 'checkReleaseBuilds' "$kts" "$groovy" 2> /dev/null; then
  echo "Peringatan: blok android { } tidak ditemukan, lint rilis tidak dimatikan."
fi

# Plugin Google Services membaca google-services.json dan melengkapi
# inisialisasi native dengan nilai yang sama seperti --dart-define. Dipasang
# hanya kalau berkasnya ada dan pola Gradle dikenali, supaya build tidak pecah.
if [ -f google-services.json ]; then
  gms="com.google.gms.google-services"
  settings=android/settings.gradle.kts
  [ -f "$settings" ] || settings=android/settings.gradle
  appgradle="$kts"
  [ -f "$appgradle" ] || appgradle="$groovy"
  # Kunci qelvo_api_url hanya dipakai CI; plugin cukup dengan isi aslinya.
  if command -v jq > /dev/null; then
    jq 'del(.qelvo_api_url)' google-services.json > android/app/google-services.json
  else
    cp google-services.json android/app/google-services.json
  fi
  if [ -f "$settings" ] && [ -f "$appgradle" ] && ! grep -q "$gms" "$settings" "$appgradle"; then
    s_line=$(grep -n -m1 -E 'com\.android\.application.*apply false' "$settings" | cut -d: -f1 || true)
    a_line=$(grep -n -m1 'com\.android\.application' "$appgradle" | cut -d: -f1 || true)
    if [ -n "$s_line" ] && [ -n "$a_line" ]; then
      sed -i "${s_line}a\\    id(\"$gms\") version \"4.5.0\" apply false" "$settings"
      sed -i "${a_line}a\\    id(\"$gms\")" "$appgradle"
    else
      echo "Plugin Google Services dilewati: pola Gradle tidak dikenali. Build tetap jalan lewat --dart-define."
    fi
  fi
fi

flutter pub get
dart run flutter_launcher_icons || echo "Ikon launcher dilewati (build tetap bisa jalan)."
