#!/usr/bin/env bash
# Menyiapkan folder android/ untuk proyek ini. Aman dijalankan berulang kali.
# Butuh Flutter di PATH dan sed versi GNU (Linux, Codespaces, GitHub Actions).
set -euo pipefail
cd "$(dirname "$0")/.."

if [ ! -d android ]; then
  flutter create --platforms=android --org com.qelvo --project-name qelvo_ai .
fi

# Tes contoh bawaan flutter create merujuk MyApp yang tidak ada di proyek ini.
if grep -q 'MyApp' test/widget_test.dart 2>/dev/null; then
  rm test/widget_test.dart
fi

# Manifest milik proyek: izin INTERNET, nama aplikasi, dan queries untuk url_launcher.
cp tool/AndroidManifest.xml android/app/src/main/AndroidManifest.xml

# Firebase membutuhkan minSdk 23. Kalau bawaan Flutter sudah lebih tinggi,
# nilai yang lebih tinggi itu yang dipakai.
kts=android/app/build.gradle.kts
groovy=android/app/build.gradle
if [ -f "$kts" ] && grep -q 'flutter.minSdkVersion' "$kts" && ! grep -q 'maxOf(23' "$kts"; then
  sed -i 's/flutter\.minSdkVersion/maxOf(23, flutter.minSdkVersion)/' "$kts"
elif [ -f "$groovy" ] && grep -q 'flutter.minSdkVersion' "$groovy" && ! grep -q 'Math.max(23' "$groovy"; then
  sed -i 's/flutter\.minSdkVersion/Math.max(23, flutter.minSdkVersion)/' "$groovy"
fi

flutter pub get
dart run flutter_launcher_icons || echo "Ikon launcher dilewati (build tetap bisa jalan)."
