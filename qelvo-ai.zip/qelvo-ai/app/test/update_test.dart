import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:qelvo_ai/data/settings_store.dart';
import 'package:qelvo_ai/data/update_models.dart';
import 'package:qelvo_ai/data/update_service.dart';
import 'package:qelvo_ai/state/update_controller.dart';
import 'package:qelvo_ai/ui/widgets/update_sheet.dart' show megabytes;
import 'package:shared_preferences/shared_preferences.dart';

const String _repo = 'pemilik/qelvo';

Map<String, Object?> _asset(
  String name, {
  String? url,
  int size = 1000,
  String? digest,
  String state = 'uploaded',
}) {
  return {
    'name': name,
    'state': state,
    'size': size,
    'browser_download_url':
        url ?? 'https://github.com/$_repo/releases/download/v0.2.0/$name',
    if (digest != null) 'digest': digest,
  };
}

Map<String, Object?> _releaseJson({
  String tag = 'v0.2.0',
  bool draft = false,
  bool prerelease = false,
  Object? body = 'Catatan rilis',
  List<Object?>? assets,
}) {
  return {
    'tag_name': tag,
    'draft': draft,
    'prerelease': prerelease,
    'body': body,
    'assets': assets ??
        [
          _asset('QELVO-v0.2.0.apk', digest: 'sha256:${'a' * 64}'),
          _asset('QELVO-v0.2.0.apk.sha256', size: 90),
        ],
  };
}

UpdateRelease _release(String version, {int size = 10}) {
  return UpdateRelease(
    version: AppVersion.tryParse(version)!,
    tag: 'v$version',
    notes: 'Catatan',
    apkName: 'QELVO-v$version.apk',
    apkUrl: Uri.parse(
      'https://github.com/$_repo/releases/download/v$version/QELVO-v$version.apk',
    ),
    apkSize: size,
    sha256: 'a' * 64,
  );
}

class _FakePlatform implements UpdatePlatform {
  _FakePlatform({this.version = '0.1.0', this.allowInstall = true});

  String? version;
  bool allowInstall;
  bool installOpens = true;
  final List<String> calls = [];

  @override
  Future<InstalledApp?> appInfo() async => version == null
      ? null
      : InstalledApp(
          version: version!,
          code: 1000,
          cacheDir: Directory.systemTemp.path,
        );

  @override
  Future<bool> canInstall() async => allowInstall;

  @override
  Future<void> openInstallSettings() async => calls.add('settings');

  @override
  Future<bool> install(String apkPath) async {
    calls.add('install:$apkPath');
    return installOpens;
  }
}

class _FakeSource implements UpdateSource {
  UpdateRelease? latest;
  Object? fetchError;
  Object? downloadError;
  File? file;
  int fetches = 0;

  @override
  Future<UpdateRelease?> fetchLatest() async {
    fetches++;
    if (fetchError != null) throw fetchError!;
    return latest;
  }

  @override
  Future<File> download(
    UpdateRelease release,
    Directory dir, {
    required UpdateCancel cancel,
    required void Function(int received, int total) onProgress,
  }) async {
    if (downloadError != null) throw downloadError!;
    onProgress(5, 10);
    onProgress(10, 10);
    return file!;
  }
}

class _Setup {
  _Setup(this.controller, this.platform, this.source, this.settings);

  final UpdateController controller;
  final _FakePlatform platform;
  final _FakeSource source;
  final SettingsStore settings;
}

Future<_Setup> _setup({
  String? installed = '0.1.0',
  DateTime Function()? now,
  bool withSource = true,
}) async {
  SharedPreferences.setMockInitialValues({});
  final settings = await SettingsStore.load();
  final platform = _FakePlatform(version: installed);
  final source = _FakeSource();
  final controller = UpdateController(
    settings: settings,
    platform: platform,
    source: withSource ? source : null,
    now: now,
  );
  await controller.init();
  return _Setup(controller, platform, source, settings);
}

/// MockClient yang menjawab dari tabel alamat -> (status, isi).
MockClient _client(Map<String, (int, List<int>)> routes) {
  return MockClient.streaming((request, _) async {
    final route = routes[request.url.toString()];
    if (route == null) return http.StreamedResponse(const Stream.empty(), 404);
    return http.StreamedResponse(
      Stream.value(route.$2),
      route.$1,
      contentLength: route.$2.length,
    );
  });
}

void main() {
  group('AppVersion', () {
    test('membaca 1.2.3, v1.2.3, dan sisipan sesudahnya', () {
      expect(AppVersion.tryParse('1.2.3'), const AppVersion(1, 2, 3));
      expect(AppVersion.tryParse('v1.2.3'), const AppVersion(1, 2, 3));
      expect(AppVersion.tryParse(' v1.2.3+45 '), const AppVersion(1, 2, 3));
      expect(AppVersion.tryParse('1.2.3-beta.1'), const AppVersion(1, 2, 3));
    });

    test('yang bukan nomor versi menjadi null', () {
      for (final text in ['1.2', 'abc', '', 'v', '1.x.3', null]) {
        expect(AppVersion.tryParse(text), isNull, reason: '$text');
      }
    });

    test('dibandingkan sebagai angka, bukan teks', () {
      expect(AppVersion.tryParse('1.10.0')! > AppVersion.tryParse('1.9.9')!, isTrue);
      expect(AppVersion.tryParse('2.0.0')! > AppVersion.tryParse('1.99.99')!, isTrue);
      expect(AppVersion.tryParse('0.1.1')! > AppVersion.tryParse('0.1.0')!, isTrue);
      expect(AppVersion.tryParse('1.2.3')! > AppVersion.tryParse('1.2.3')!, isFalse);
      expect(AppVersion.tryParse('1.2.3'), AppVersion.tryParse('v1.2.3+9'));
    });

    test('toString menulis tiga angka', () {
      expect(const AppVersion(0, 2, 10).toString(), '0.2.10');
    });
  });

  group('parseSha256', () {
    final hash = 'ab12' * 16;

    test('membaca keluaran sha256sum', () {
      expect(parseSha256('$hash  QELVO-v0.2.0.apk\n'), hash);
    });

    test('huruf besar jadi huruf kecil', () {
      expect(parseSha256('${hash.toUpperCase()} *berkas.apk'), hash);
    });

    test('baris kosong dilewati dan hanya hash penuh yang dihitung', () {
      expect(parseSha256('\n\n  $hash\n'), hash);
      expect(parseSha256('${hash}0 terlalu panjang'), isNull);
      expect(parseSha256('bukan hash'), isNull);
      expect(parseSha256(''), isNull);
    });
  });

  group('UpdateRelease.fromGitHub', () {
    test('rilis lengkap dibaca', () {
      final release = UpdateRelease.fromGitHub(_releaseJson(), repo: _repo)!;
      expect(release.version, const AppVersion(0, 2, 0));
      expect(release.tag, 'v0.2.0');
      expect(release.apkName, 'QELVO-v0.2.0.apk');
      expect(release.apkSize, 1000);
      expect(release.sha256, 'a' * 64);
      expect(release.notes, 'Catatan rilis');
      expect(release.checksumUrl?.path.endsWith('.apk.sha256'), isTrue);
    });

    test('draf dan prarilis diabaikan', () {
      expect(UpdateRelease.fromGitHub(_releaseJson(draft: true), repo: _repo), isNull);
      expect(UpdateRelease.fromGitHub(_releaseJson(prerelease: true), repo: _repo), isNull);
    });

    test('tag yang bukan nomor versi diabaikan', () {
      expect(UpdateRelease.fromGitHub(_releaseJson(tag: 'build-12'), repo: _repo), isNull);
    });

    test('tanpa APK, atau APK belum selesai diunggah, hasilnya null', () {
      final noApk = _releaseJson(assets: [_asset('catatan.txt')]);
      final partial =
          _releaseJson(assets: [_asset('QELVO.apk', state: 'starter')]);
      expect(UpdateRelease.fromGitHub(noApk, repo: _repo), isNull);
      expect(UpdateRelease.fromGitHub(partial, repo: _repo), isNull);
      expect(UpdateRelease.fromGitHub(_releaseJson(assets: []), repo: _repo), isNull);
    });

    test('alamat unduhan di luar repositori ini ditolak', () {
      final evil = <String>[
        'https://evil.example.com/pemilik/qelvo/releases/download/v1/a.apk',
        'http://github.com/pemilik/qelvo/releases/download/v1/a.apk',
        'https://github.com/lain/repo/releases/download/v1/a.apk',
        'https://github.com/pemilik/qelvo/archive/a.apk',
        'https://github.com.evil.example/pemilik/qelvo/releases/download/v1/a.apk',
      ];
      for (final url in evil) {
        final json = _releaseJson(assets: [_asset('a.apk', url: url)]);
        expect(UpdateRelease.fromGitHub(json, repo: _repo), isNull, reason: url);
      }
    });

    test('APK pertama yang sah dipakai, dan nama repo tak peka huruf besar', () {
      final json = _releaseJson(assets: [
        _asset('palsu.apk', url: 'https://evil.example.com/x.apk'),
        _asset('QELVO-v0.2.0.apk'),
      ]);
      final release = UpdateRelease.fromGitHub(json, repo: 'Pemilik/QELVO')!;
      expect(release.apkName, 'QELVO-v0.2.0.apk');
    });

    test('digest rusak diabaikan, checksum berkas tetap dicatat', () {
      final json = _releaseJson(assets: [
        _asset('QELVO-v0.2.0.apk', digest: 'sha256:pendek'),
        _asset('QELVO-v0.2.0.apk.sha256'),
      ]);
      final release = UpdateRelease.fromGitHub(json, repo: _repo)!;
      expect(release.sha256, isNull);
      expect(release.checksumUrl, isNotNull);
    });

    test('catatan panjang dipotong, dan catatan bukan teks jadi kosong', () {
      final long = UpdateRelease.fromGitHub(
        _releaseJson(body: 'x' * 5000),
        repo: _repo,
      )!;
      expect(long.notes.length, lessThanOrEqualTo(4001));
      expect(long.notes.endsWith('…'), isTrue);
      final none = UpdateRelease.fromGitHub(_releaseJson(body: null), repo: _repo)!;
      expect(none.notes, '');
    });

    test('bentuk yang bukan peta ditolak', () {
      expect(UpdateRelease.fromGitHub('x', repo: _repo), isNull);
      expect(UpdateRelease.fromGitHub(null, repo: _repo), isNull);
      expect(UpdateRelease.fromGitHub({'tag_name': 'v1.0.0'}, repo: _repo), isNull);
    });
  });

  test('megabytes memakai koma desimal', () {
    expect(megabytes(25 * 1024 * 1024), '25,0 MB');
    expect(megabytes(1536 * 1024), '1,5 MB');
  });

  group('UpdateController', () {
    test('rilis yang lebih baru ditawarkan', () async {
      final s = await _setup();
      s.source.latest = _release('0.2.0');
      await s.controller.check();
      expect(s.controller.status, UpdateStatus.available);
      expect(s.controller.release?.version, const AppVersion(0, 2, 0));
      expect(s.controller.foundRelease, isTrue);
      expect(s.settings.lastUpdateCheck, isNotNull);
    });

    test('versi sama atau lebih lama berarti sudah terbaru', () async {
      for (final latest in ['0.1.0', '0.0.9']) {
        final s = await _setup();
        s.source.latest = _release(latest);
        await s.controller.check();
        expect(s.controller.status, UpdateStatus.upToDate, reason: latest);
        expect(s.controller.release, isNull);
        expect(s.controller.foundRelease, isTrue);
      }
    });

    test('belum ada rilis sama sekali dicatat terpisah', () async {
      final s = await _setup();
      await s.controller.check();
      expect(s.controller.status, UpdateStatus.upToDate);
      expect(s.controller.foundRelease, isFalse);
    });

    test('versi terpasang yang tidak diketahui tidak pernah memicu pembaruan', () async {
      final s = await _setup(installed: null);
      s.source.latest = _release('9.9.9');
      await s.controller.check();
      expect(s.controller.status, UpdateStatus.upToDate);
    });

    test('versi yang dilewati tidak ditawarkan otomatis, tapi muncul di pemeriksaan manual', () async {
      final s = await _setup();
      s.source.latest = _release('0.2.0');
      await s.settings.setSkippedUpdate('0.2.0');
      await s.controller.check();
      expect(s.controller.status, UpdateStatus.upToDate);
      await s.controller.check(manual: true);
      expect(s.controller.status, UpdateStatus.available);
    });

    test('pemeriksaan otomatis menghormati sakelar dan jedanya', () async {
      final now = DateTime(2026, 11, 8, 12);
      var s = await _setup(now: () => now);
      await s.settings.setAutoUpdate(false);
      await s.controller.checkIfDue();
      expect(s.source.fetches, 0);

      s = await _setup(now: () => now);
      await s.settings.setLastUpdateCheck(now.subtract(const Duration(hours: 1)));
      await s.controller.checkIfDue();
      expect(s.source.fetches, 0);

      s = await _setup(now: () => now);
      await s.settings.setLastUpdateCheck(now.subtract(const Duration(hours: 13)));
      await s.controller.checkIfDue();
      expect(s.source.fetches, 1);

      s = await _setup(now: () => now);
      await s.controller.checkIfDue();
      expect(s.source.fetches, 1);
    });

    test('jam yang mundur tidak membuat pemeriksaan macet selamanya', () async {
      final now = DateTime(2026, 11, 8, 12);
      final s = await _setup(now: () => now);
      await s.settings.setLastUpdateCheck(now.add(const Duration(days: 30)));
      await s.controller.checkIfDue();
      expect(s.source.fetches, 1);
    });

    test('galat pemeriksaan menjadi pesan, bukan pengecualian', () async {
      var s = await _setup();
      s.source.fetchError = const UpdateException('GitHub tidak merespons.');
      await s.controller.check();
      expect(s.controller.status, UpdateStatus.failed);
      expect(s.controller.error, 'GitHub tidak merespons.');

      s = await _setup();
      s.source.fetchError = StateError('aneh');
      await s.controller.check();
      expect(s.controller.status, UpdateStatus.failed);
      expect(s.controller.error, contains('Tidak bisa memeriksa'));
    });

    test('tanpa sumber (build lokal) tidak ada yang terjadi', () async {
      final s = await _setup(withSource: false);
      expect(s.controller.enabled, isFalse);
      await s.controller.check(manual: true);
      await s.controller.checkIfDue();
      expect(s.controller.status, UpdateStatus.idle);
    });

    test('unduhan selesai lalu membuka pemasang', () async {
      final s = await _setup();
      final apk = File('${Directory.systemTemp.path}/qelvo_test_unduhan.apk')
        ..writeAsBytesSync([1, 2, 3]);
      addTearDown(() {
        if (apk.existsSync()) apk.deleteSync();
      });
      s.source
        ..latest = _release('0.2.0')
        ..file = apk;
      await s.controller.check();
      await s.controller.download();
      expect(s.controller.status, UpdateStatus.ready);
      expect(s.controller.progress, 1);
      expect(s.platform.calls, ['install:${apk.path}']);
      expect(s.controller.needsPermission, isFalse);
    });

    test('tanpa izin pasang, layar izin dibuka dan pemasang belum', () async {
      final s = await _setup();
      s.platform.allowInstall = false;
      final apk = File('${Directory.systemTemp.path}/qelvo_test_izin.apk')
        ..writeAsBytesSync([1]);
      addTearDown(() {
        if (apk.existsSync()) apk.deleteSync();
      });
      s.source
        ..latest = _release('0.2.0')
        ..file = apk;
      await s.controller.check();
      await s.controller.download();
      expect(s.controller.needsPermission, isTrue);
      expect(s.platform.calls, ['settings']);
      // Setelah izin diberikan, ketukan Pasang melanjutkan tanpa mengunduh ulang.
      s.platform.allowInstall = true;
      await s.controller.install();
      expect(s.controller.needsPermission, isFalse);
      expect(s.platform.calls, ['settings', 'install:${apk.path}']);
    });

    test('pemasang yang gagal dibuka meninggalkan pesan dan tombol Pasang', () async {
      final s = await _setup();
      s.platform.installOpens = false;
      final apk = File('${Directory.systemTemp.path}/qelvo_test_gagal.apk')
        ..writeAsBytesSync([1]);
      addTearDown(() {
        if (apk.existsSync()) apk.deleteSync();
      });
      s.source
        ..latest = _release('0.2.0')
        ..file = apk;
      await s.controller.check();
      await s.controller.download();
      expect(s.controller.status, UpdateStatus.ready);
      expect(s.controller.error, contains('Pemasang Android'));
    });

    test('unduhan gagal atau dibatalkan', () async {
      var s = await _setup();
      s.source
        ..latest = _release('0.2.0')
        ..downloadError = const UpdateException('Checksum tidak cocok.');
      await s.controller.check();
      await s.controller.download();
      expect(s.controller.status, UpdateStatus.failed);
      expect(s.controller.error, 'Checksum tidak cocok.');

      s = await _setup();
      s.source
        ..latest = _release('0.2.0')
        ..downloadError = const UpdateCancelled();
      await s.controller.check();
      await s.controller.download();
      expect(s.controller.status, UpdateStatus.available);
      expect(s.controller.error, isNull);
    });

    test('lewati versi ini menyimpan pilihan dan menutup tawaran', () async {
      final s = await _setup();
      s.source.latest = _release('0.2.0');
      await s.controller.check();
      await s.controller.skip();
      expect(s.settings.skippedUpdate, '0.2.0');
      expect(s.controller.status, UpdateStatus.idle);
      expect(s.controller.release, isNull);
    });

    test('tawaran hanya muncul sekali per sesi, dan Nanti menutupnya', () async {
      final s = await _setup();
      s.source.latest = _release('0.2.0');
      await s.controller.check();
      expect(s.controller.shouldPrompt, isTrue);
      s.controller.markPrompted();
      expect(s.controller.shouldPrompt, isFalse);
      s.controller.dismiss();
      expect(s.controller.status, UpdateStatus.idle);
      expect(s.controller.release, isNull);
    });
  });

  group('UpdateClient', () {
    late Directory dir;

    setUp(() => dir = Directory.systemTemp.createTempSync('qelvo_update_test'));
    tearDown(() {
      if (dir.existsSync()) dir.deleteSync(recursive: true);
    });

    final apiUrl = 'https://api.github.com/repos/$_repo/releases/latest';
    final bytes = List<int>.generate(1000, (i) => i % 251);
    final hash = sha256.convert(bytes).toString();

    UpdateRelease release({String? sha, int size = 1000, Uri? checksumUrl}) {
      final apkUrl = Uri.parse(
        'https://github.com/$_repo/releases/download/v0.2.0/QELVO-v0.2.0.apk',
      );
      return UpdateRelease(
        version: const AppVersion(0, 2, 0),
        tag: 'v0.2.0',
        notes: '',
        apkName: 'QELVO-v0.2.0.apk',
        apkUrl: apkUrl,
        apkSize: size,
        sha256: sha,
        checksumUrl: checksumUrl,
      );
    }

    String apkUrl() =>
        'https://github.com/$_repo/releases/download/v0.2.0/QELVO-v0.2.0.apk';

    test('fetchLatest membaca rilis, 404 berarti belum ada, 403 berarti kena batas', () async {
      final ok = UpdateClient(
        repo: _repo,
        client: _client({apiUrl: (200, utf8.encode(jsonEncode(_releaseJson())))}),
      );
      expect((await ok.fetchLatest())?.version, const AppVersion(0, 2, 0));

      final none = UpdateClient(repo: _repo, client: _client({}));
      expect(await none.fetchLatest(), isNull);

      final limited = UpdateClient(
        repo: _repo,
        client: _client({apiUrl: (403, utf8.encode('{}'))}),
      );
      await expectLater(limited.fetchLatest(), throwsA(isA<UpdateException>()));

      final broken = UpdateClient(
        repo: _repo,
        client: _client({apiUrl: (200, utf8.encode('bukan json'))}),
      );
      await expectLater(broken.fetchLatest(), throwsA(isA<UpdateException>()));
    });

    test('unduhan lengkap: berkas utuh, checksum cocok, tanpa sisa .part', () async {
      final client = UpdateClient(repo: _repo, client: _client({apkUrl(): (200, bytes)}));
      final seen = <int>[];
      final file = await client.download(
        release(sha: hash),
        dir,
        cancel: UpdateCancel(),
        onProgress: (received, total) => seen.add(received),
      );
      expect(file.readAsBytesSync(), bytes);
      expect(seen.last, 1000);
      final names = dir.listSync().map((e) => e.uri.pathSegments.last).toList();
      expect(names, ['QELVO-v0.2.0.apk']);
    });

    test('checksum boleh datang dari berkas .sha256', () async {
      final shaUrl = Uri.parse('${apkUrl()}.sha256');
      final client = UpdateClient(
        repo: _repo,
        client: _client({
          apkUrl(): (200, bytes),
          shaUrl.toString(): (200, utf8.encode('$hash  QELVO-v0.2.0.apk\n')),
        }),
      );
      final file = await client.download(
        release(checksumUrl: shaUrl),
        dir,
        cancel: UpdateCancel(),
        onProgress: (_, __) {},
      );
      expect(file.existsSync(), isTrue);
    });

    test('checksum yang tidak cocok membuang berkasnya', () async {
      final client = UpdateClient(repo: _repo, client: _client({apkUrl(): (200, bytes)}));
      await expectLater(
        client.download(
          release(sha: 'b' * 64),
          dir,
          cancel: UpdateCancel(),
          onProgress: (_, __) {},
        ),
        throwsA(isA<UpdateException>()),
      );
      expect(dir.listSync(), isEmpty);
    });

    test('ukuran yang tidak sama dengan menurut GitHub ditolak', () async {
      final client = UpdateClient(repo: _repo, client: _client({apkUrl(): (200, bytes)}));
      await expectLater(
        client.download(
          release(sha: hash, size: 999),
          dir,
          cancel: UpdateCancel(),
          onProgress: (_, __) {},
        ),
        throwsA(isA<UpdateException>()),
      );
      expect(dir.listSync(), isEmpty);
    });

    test('rilis tanpa checksum tidak dipasang', () async {
      final client = UpdateClient(repo: _repo, client: _client({apkUrl(): (200, bytes)}));
      await expectLater(
        client.download(release(), dir, cancel: UpdateCancel(), onProgress: (_, __) {}),
        throwsA(
          isA<UpdateException>().having((e) => e.message, 'pesan', contains('checksum')),
        ),
      );
    });

    test('unduhan yang ditolak GitHub gagal dengan pesan', () async {
      final client = UpdateClient(repo: _repo, client: _client({}));
      await expectLater(
        client.download(
          release(sha: hash),
          dir,
          cancel: UpdateCancel(),
          onProgress: (_, __) {},
        ),
        throwsA(isA<UpdateException>()),
      );
    });

    test('dibatalkan di tengah jalan: UpdateCancelled dan tanpa sisa', () async {
      final client = UpdateClient(repo: _repo, client: _client({apkUrl(): (200, bytes)}));
      final cancel = UpdateCancel()..cancel();
      await expectLater(
        client.download(
          release(sha: hash),
          dir,
          cancel: cancel,
          onProgress: (_, __) {},
        ),
        throwsA(isA<UpdateCancelled>()),
      );
      expect(dir.listSync(), isEmpty);
    });

    test('clearDirectory menghapus berkas dan aman untuk folder yang tidak ada', () async {
      File('${dir.path}/a.apk').writeAsBytesSync([1]);
      File('${dir.path}/b.apk.part').writeAsBytesSync([1]);
      await UpdateClient.clearDirectory(dir);
      expect(dir.listSync(), isEmpty);
      await UpdateClient.clearDirectory(Directory('${dir.path}/tidak_ada'));
    });
  });
}
