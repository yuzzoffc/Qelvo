import 'dart:async';

import 'package:flutter_test/flutter_test.dart';
import 'package:qelvo_ai/data/api_client.dart';
import 'package:qelvo_ai/data/chat_repository.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/state/history_controller.dart';

class _FakeApi implements ApiClient {
  final List<(String, String, Object?)> calls = [];
  Object? reply;

  @override
  Future<Object?> request(
    String method,
    String path, {
    Object? body,
    Duration timeout = const Duration(seconds: 25),
  }) async {
    calls.add((method, path, body));
    return reply;
  }

  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

class _FakeRepository implements ChatRepository {
  _FakeRepository(this.script);

  final Future<List<Conversation>> Function() script;

  @override
  Future<List<Conversation>> conversations() => script();

  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

Conversation _conversation(String id, {String title = 'Judul', String preview = ''}) {
  return Conversation(
    id: id,
    title: title,
    createdAt: DateTime(2026, 10, 24),
    updatedAt: DateTime(2026, 10, 24),
    preview: preview,
  );
}

void main() {
  group('ChatRepository', () {
    test('daftar percakapan dibaca dari JSON server', () async {
      final api = _FakeApi()
        ..reply = {
          'conversations': [
            {
              'id': 'c1',
              'title': 'Fotosintesis',
              'model_label': 'Gemini',
              'preview': 'Proses tumbuhan',
              'created_at': 1700000000000,
              'updated_at': 1700000060000,
            },
          ],
        };
      final items = await ChatRepository(api).conversations();

      expect(api.calls.single.$1, 'GET');
      expect(api.calls.single.$2, '/v1/conversations?limit=300');
      expect(items.single.id, 'c1');
      expect(items.single.title, 'Fotosintesis');
      expect(items.single.modelLabel, 'Gemini');
      expect(items.single.preview, 'Proses tumbuhan');
      expect(
        items.single.updatedAt,
        DateTime.fromMillisecondsSinceEpoch(1700000060000),
      );
    });

    test('pesan dibaca lengkap dengan peran dan penilaian', () async {
      final api = _FakeApi()
        ..reply = {
          'messages': [
            {
              'id': 'm1',
              'role': 'user',
              'content': 'Halo',
              'created_at': 1700000000000,
              'rating': 0,
            },
            {
              'id': 'm2',
              'role': 'assistant',
              'content': 'Hai',
              'created_at': 1700000001000,
              'rating': -1,
            },
          ],
        };
      final items = await ChatRepository(api).messages('c1');

      expect(api.calls.single.$2, '/v1/conversations/c1/messages');
      expect(items.map((m) => m.role), [ChatRole.user, ChatRole.assistant]);
      expect(items.last.rating, -1);
      expect(items.first.content, 'Halo');
    });

    test('simpan mengirim PUT berisi percakapan dan pesan', () async {
      final api = _FakeApi();
      final message = ChatMessage(
        id: 'm1',
        role: ChatRole.user,
        content: 'Halo',
        createdAt: DateTime.fromMillisecondsSinceEpoch(1700000000000),
      );
      final conversation = Conversation(
        id: 'c1',
        title: 'Halo',
        createdAt: DateTime.fromMillisecondsSinceEpoch(1700000000000),
        updatedAt: DateTime.fromMillisecondsSinceEpoch(1700000000000),
        modelLabel: 'Gemini',
      );
      await ChatRepository(api).save(conversation: conversation, message: message);

      final call = api.calls.single;
      expect(call.$1, 'PUT');
      expect(call.$2, '/v1/conversations/c1/messages/m1');
      final body = call.$3! as Map<String, dynamic>;
      expect((body['conversation'] as Map)['title'], 'Halo');
      expect((body['conversation'] as Map)['model_label'], 'Gemini');
      expect((body['conversation'] as Map)['created_at'], 1700000000000);
      expect((body['message'] as Map)['role'], 'user');
      expect((body['message'] as Map)['content'], 'Halo');
    });

    test('isi yang kepanjangan dipotong tanpa membelah pasangan surrogate', () async {
      final api = _FakeApi();
      // Emoji memakai dua unit UTF-16; pemotongan di 50.000 akan membelahnya.
      final content = '${'a' * 49999}\u{1F600}';
      final message = ChatMessage(
        id: 'm1',
        role: ChatRole.assistant,
        content: content,
        createdAt: DateTime(2026, 10, 24),
      );
      await ChatRepository(api).save(
        conversation: _conversation('c1'),
        message: message,
      );

      final body = api.calls.single.$3! as Map<String, dynamic>;
      final sent = (body['message'] as Map)['content'] as String;
      expect(sent.length, 49999);
      expect(sent.codeUnits.every((unit) => unit < 0xD800 || unit > 0xDFFF), isTrue);
    });

    test('penilaian dan penghapusan memakai metode dan alamat yang tepat', () async {
      final api = _FakeApi();
      final repository = ChatRepository(api);
      await repository.setRating('c1', 'm1', 1);
      await repository.deleteMessage('c1', 'm1');
      await repository.deleteConversation('c1');
      await repository.deleteEverything();

      expect(api.calls.map((c) => '${c.$1} ${c.$2}').toList(), [
        'PATCH /v1/conversations/c1/messages/m1',
        'DELETE /v1/conversations/c1/messages/m1',
        'DELETE /v1/conversations/c1',
        'DELETE /v1/conversations',
      ]);
      expect(api.calls.first.$3, {'rating': 1});
    });

    test('respons yang bentuknya salah menjadi ApiException', () async {
      final api = _FakeApi()..reply = 'bukan peta';
      await expectLater(
        ChatRepository(api).conversations(),
        throwsA(isA<ApiException>()),
      );
    });
  });

  group('HistoryController', () {
    test('memuat daftar dari server', () async {
      final controller = HistoryController(
        _FakeRepository(() async => [_conversation('a'), _conversation('b')]),
      );
      expect(controller.items, isEmpty);
      await controller.refresh();

      expect(controller.items.map((c) => c.id), ['a', 'b']);
      expect(controller.loading, isFalse);
      expect(controller.error, isNull);
      expect(controller.unavailable, isFalse);
    });

    test('pemuatan yang tumpang tindih digabung jadi satu pemuatan lagi', () async {
      final gate = Completer<List<Conversation>>();
      var calls = 0;
      final controller = HistoryController(
        _FakeRepository(() {
          calls++;
          return calls == 1 ? gate.future : Future.value(<Conversation>[]);
        }),
      );

      final first = controller.refresh();
      await controller.refresh();
      await controller.refresh();
      expect(calls, 1);

      gate.complete([_conversation('a')]);
      await first;
      expect(calls, 2);
    });

    test('riwayat nonaktif di server ditandai sampai pemuatan berhasil', () async {
      var failing = true;
      final controller = HistoryController(
        _FakeRepository(() async {
          if (failing) {
            throw const ApiException(
              'Riwayat chat belum aktif di server.',
              code: 'history_disabled',
              statusCode: 503,
            );
          }
          return [_conversation('a')];
        }),
      );

      await controller.refresh();
      expect(controller.unavailable, isTrue);
      expect(controller.error, 'Riwayat chat belum aktif di server.');

      failing = false;
      await controller.refresh();
      expect(controller.unavailable, isFalse);
      expect(controller.error, isNull);
      expect(controller.items, hasLength(1));
    });

    test('gagal memuat tidak menghapus daftar yang sudah ada', () async {
      var failing = false;
      final controller = HistoryController(
        _FakeRepository(() async {
          if (failing) {
            throw const ApiException('Tidak bisa terhubung.', code: 'offline');
          }
          return [_conversation('a')];
        }),
      );

      await controller.refresh();
      failing = true;
      await controller.refresh();

      expect(controller.items, hasLength(1));
      expect(controller.error, 'Tidak bisa terhubung.');
      expect(controller.unavailable, isFalse);
    });

    test('kegagalan simpan sesaat tidak menandai riwayat nonaktif', () {
      final controller = HistoryController(
        _FakeRepository(() async => <Conversation>[]),
      );
      controller.noteFailure(
        const ApiException('Terlalu banyak permintaan.', code: 'rate_limited'),
      );
      expect(controller.unavailable, isFalse);
      expect(controller.error, isNull);

      controller.noteFailure(
        const ApiException('Belum aktif.', code: 'history_disabled'),
      );
      expect(controller.unavailable, isTrue);
      expect(controller.error, 'Belum aktif.');
    });

    test('pencarian memeriksa judul dan cuplikan', () async {
      final controller = HistoryController(
        _FakeRepository(
          () async => [
            _conversation('a', title: 'Resep nasi goreng'),
            _conversation('b', title: 'Catatan', preview: 'tentang FOTOSINTESIS'),
          ],
        ),
      );
      await controller.refresh();

      expect(controller.search('nasi').map((c) => c.id), ['a']);
      expect(controller.search('fotosintesis').map((c) => c.id), ['b']);
      expect(controller.search('  '), hasLength(2));
    });
  });
}
