import 'package:flutter_test/flutter_test.dart';
import 'package:qelvo_ai/data/background_run.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('noticeFor', () {
    test('jawaban selesai saat aplikasi di latar belakang memberi tahu', () {
      final notice = noticeFor(RunOutcome.done, inBackground: true);
      expect(notice, isNotNull);
      expect(notice!.title, 'QELVO sudah menjawab');
    });

    test('jawaban gagal saat aplikasi di latar belakang juga memberi tahu', () {
      final notice = noticeFor(RunOutcome.failed, inBackground: true);
      expect(notice, isNotNull);
      expect(notice!.title, 'Jawaban QELVO gagal');
    });

    test('tidak memberi tahu saat aplikasi masih terlihat', () {
      for (final outcome in RunOutcome.values) {
        expect(noticeFor(outcome, inBackground: false), isNull);
      }
    });

    test('dihentikan pengguna tidak pernah memberi tahu', () {
      expect(noticeFor(RunOutcome.cancelled, inBackground: true), isNull);
    });
  });

  group('PlatformBackgroundRun', () {
    test('tidak melempar error saat saluran native tidak ada', () async {
      // Di tes (dan di desktop) tidak ada MainActivity yang menjawab saluran.
      // Chat harus tetap jalan, jadi semua panggilan diam-diam diabaikan.
      const run = PlatformBackgroundRun();
      await run.begin(
        title: 'QELVO sedang menjawab',
        text: 'Jawaban tetap berjalan walau kamu keluar dari aplikasi.',
      );
      await run.end(notice: const RunNotice('judul', 'isi'));
      await run.end();
      await run.moveToBack();
    });
  });

  group('appInBackground', () {
    test('aplikasi dianggap terlihat di dalam tes', () {
      expect(appInBackground(), isFalse);
    });
  });
}
