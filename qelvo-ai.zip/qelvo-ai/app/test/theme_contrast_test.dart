import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:qelvo_ai/core/theme.dart';

/// Rasio kontras WCAG antara dua warna.
double ratio(Color a, Color b) {
  final la = a.computeLuminance();
  final lb = b.computeLuminance();
  return (math.max(la, lb) + 0.05) / (math.min(la, lb) + 0.05);
}

void main() {
  final themes = <String, QelvoTheme>{
    'gelap': QelvoTheme.dark,
    'terang': QelvoTheme.light,
  };

  for (final entry in themes.entries) {
    final t = entry.value;

    group('kontras tema ${entry.key}', () {
      test('teks, muted, dan accentText di atas semua latar minimal 4.5:1', () {
        final backgrounds = <String, Color>{
          'bg': t.bg,
          'surface': t.surface,
          'panel': t.panel,
          'bubble': t.bubble,
          'codeBg': t.codeBg,
        };
        final foregrounds = <String, Color>{
          'text': t.text,
          'muted': t.muted,
          'accentText': t.accentText,
        };
        for (final bg in backgrounds.entries) {
          for (final fg in foregrounds.entries) {
            expect(
              ratio(fg.value, bg.value),
              greaterThanOrEqualTo(4.5),
              reason: '${fg.key} di atas ${bg.key}',
            );
          }
        }
      });

      test('teks dan muted terbaca di dalam gelembung pesan pengguna', () {
        expect(ratio(t.text, t.userBubble), greaterThanOrEqualTo(7));
        expect(ratio(t.muted, t.userBubble), greaterThanOrEqualTo(4.5));
      });

      test('muted dan accentText terbaca di atas isi ikon yang menyala', () {
        expect(ratio(t.accentText, t.accentSoft), greaterThanOrEqualTo(4.5));
        expect(ratio(t.muted, t.accentSoft), greaterThanOrEqualTo(4.5));
      });

      test('isi tombol utama dan teks kode terbaca', () {
        expect(ratio(t.onAccent, t.accent), greaterThanOrEqualTo(4.5));
        for (final color in [t.warn, t.codeString, t.codeNumber]) {
          expect(ratio(color, t.codeBg), greaterThanOrEqualTo(4.5));
        }
      });

      test('garis tepi kontrol (outline) minimal 3:1 di atas latarnya', () {
        for (final bg in [t.bg, t.surface, t.bubble]) {
          expect(ratio(t.outline, bg), greaterThanOrEqualTo(3));
        }
      });

      test('gelembung pengguna terpisah dari latar, dan beda dari kartu AI', () {
        // Isi gelembung pengguna harus lebih menonjol dari latar layar.
        expect(ratio(t.userBubble, t.bg), greaterThan(ratio(t.bubble, t.bg)));
        // Pesan pengguna dan jawaban AI tidak boleh memakai isi yang sama.
        expect(t.userBubble, isNot(t.surface));
        expect(t.userBubbleLine, isNot(t.aiBubbleLine));
      });
    });
  }

  test('muted tema gelap naik dari nilai PDF (7,2:1 di atas bg) ke minimal 9:1', () {
    expect(ratio(QelvoTheme.dark.muted, QelvoTheme.dark.bg),
        greaterThanOrEqualTo(9));
    expect(ratio(QelvoTheme.dark.muted, QelvoTheme.dark.bubble),
        greaterThanOrEqualTo(8));
  });
}
