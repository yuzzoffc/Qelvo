import 'dart:ui';

import 'package:flutter_test/flutter_test.dart';
import 'package:qelvo_ai/state/model_catalog.dart';
import 'package:qelvo_ai/ui/widgets/qelvo_logo.dart';

void main() {
  group('geometri logo v3.0', () {
    test('cincin menebal di kiri bawah dan menipis di kanan atas', () {
      final ring = debugRingPath;
      // Sisi kiri tebal, sisi kanan atas tipis, lubang di tengah.
      expect(ring.contains(const Offset(8, 50)), isTrue);
      expect(ring.contains(const Offset(81.7, 18.3)), isTrue);
      expect(ring.contains(const Offset(50, 92)), isTrue);
      expect(ring.contains(const Offset(50, 50)), isFalse);
    });

    test('celah di kanan bawah kosong untuk ekor', () {
      expect(debugRingPath.contains(const Offset(80, 80)), isFalse);
      expect(debugTailPath.contains(const Offset(80, 80)), isTrue);
    });

    test('ekor menembus kotak 100 satuan di sumbu 45 derajat', () {
      final tail = debugTailPath;
      expect(tail.contains(const Offset(110, 110)), isTrue);
      expect(tail.contains(const Offset(90, 90)), isTrue);
      expect(tail.contains(const Offset(60, 90)), isFalse);
    });
  });

  group('shortModelLabel', () {
    test('membuang awalan nama penyedia', () {
      expect(shortModelLabel('Gemini 2.5 Flash', 'Gemini'), '2.5 Flash');
      expect(shortModelLabel('gemini 2.5 flash', 'Gemini'), '2.5 flash');
    });

    test('mempertahankan label yang tidak berawalan penyedia', () {
      expect(shortModelLabel('Llama 3.3 70B', 'OpenRouter'), 'Llama 3.3 70B');
      expect(shortModelLabel('Flash', 'Gemini'), 'Flash');
    });

    test('tidak mengosongkan label yang hanya berisi nama penyedia', () {
      expect(shortModelLabel('Gemini', 'Gemini'), 'Gemini');
      expect(shortModelLabel('Gemini 2', ''), 'Gemini 2');
    });
  });
}
