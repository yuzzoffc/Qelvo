import 'package:flutter_test/flutter_test.dart';
import 'package:qelvo_ai/data/api_client.dart';
import 'package:qelvo_ai/data/chat_repository.dart';
import 'package:qelvo_ai/data/error_reporter.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/data/settings_store.dart';
import 'package:qelvo_ai/data/sse.dart';
import 'package:qelvo_ai/state/history_controller.dart';
import 'package:shared_preferences/shared_preferences.dart';

class _FakeApi implements ApiClient {
  final List<(String, String, Object?)> calls = [];
  Object? reply;
  Object? error;

  @override
  Future<Object?> request(
    String method,
    String path, {
    Object? body,
    Duration timeout = const Duration(seconds: 25),
  }) async {
    calls.add((method, path, body));
    final failure = error;
    if (failure != null) throw failure;
    return reply;
  }

  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

class _FakeRepository implements ChatRepository {
  _FakeRepository(this.items);

  final List<Conversation> items;

  @override
  Future<List<Conversation>> conversations() async => items;

  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

Conversation _conversation(String id, {bool pinned = false}) => Conversation(
      id: id,
      title: 'Judul $id',
      createdAt: DateTime(2026, 11, 12),
      updatedAt: DateTime(2026, 11, 12),
      pinned: pinned,
    );

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('meta pencarian web', () {
    test('web_search true terbaca dari event meta', () {
      final event = parseSseLine(
        'data: {"meta":{"model_label":"Gemini","web_search":true}}',
      );
      expect(event, isA<MetaEvent>());
      expect((event! as MetaEvent).webSearch, isTrue);
      expect((event as MetaEvent).modelLabel, 'Gemini');
    });

    test('tanpa web_search nilainya false', () {
      final event = parseSseLine('data: {"meta":{"model_label":"Gemini"}}');
      expect((event! as MetaEvent).webSearch, isFalse);
    });

    test('cached true menandai jawaban yang dikirim ulang dari cache server', () {
      final cached = parseSseLine(
        'data: {"meta":{"model_label":"Gemini","web_search":true,"cached":true}}',
      ) as MetaEvent;
      expect(cached.cached, isTrue);
      expect(cached.webSearch, isTrue);
    });

    test('tanpa cached nilainya false', () {
      final fresh = parseSseLine(
        'data: {"meta":{"model_label":"Gemini","web_search":true}}',
      ) as MetaEvent;
      expect(fresh.cached, isFalse);
    });

    test('baris komentar penjaga koneksi diabaikan', () {
      expect(parseSseLine(': keep-alive'), isNull);
    });
  });

  group('ChatRepository judul, nama, dan sematan', () {
    test('daftar membaca sematan', () async {
      final api = _FakeApi()
        ..reply = {
          'conversations': [
            {
              'id': 'c1',
              'title': 'A',
              'created_at': 1700000000000,
              'updated_at': 1700000060000,
              'pinned': true,
            },
            {
              'id': 'c2',
              'title': 'B',
              'created_at': 1700000000000,
              'updated_at': 1700000060000,
            },
          ],
        };
      final items = await ChatRepository(api).conversations();
      expect(items.map((c) => c.pinned), [true, false]);
    });

    test('ganti nama dan sematkan memakai PATCH', () async {
      final api = _FakeApi();
      final repository = ChatRepository(api);
      await repository.updateConversation('c1', title: 'Baru', pinned: true);
      await repository.updateConversation('c1', pinned: false);

      expect(api.calls.first.$1, 'PATCH');
      expect(api.calls.first.$2, '/v1/conversations/c1');
      expect(api.calls.first.$3, {'title': 'Baru', 'pinned': true});
      expect(api.calls.last.$3, {'pinned': false});
    });

    test('judul otomatis: dibaca, dipangkas, dan kosong kalau bentuknya salah', () async {
      final api = _FakeApi()..reply = {'title': '  Resep nasi goreng '};
      final repository = ChatRepository(api);
      final title = await repository.generateTitle('a' * 4000, 'b');

      expect(title, 'Resep nasi goreng');
      expect(api.calls.single.$2, '/v1/title');
      final body = api.calls.single.$3! as Map<String, dynamic>;
      expect((body['user'] as String).length, 1500);
      expect(body['assistant'], 'b');

      api.reply = 'bukan peta';
      expect(await repository.generateTitle('x', 'y'), '');
    });

    test('pemotongan judul tidak membelah pasangan surrogate', () async {
      final api = _FakeApi()..reply = {'title': 'x'};
      await ChatRepository(api).generateTitle('${'a' * 1499}\u{1F600}', 'y');
      final user = (api.calls.single.$3! as Map<String, dynamic>)['user'] as String;
      expect(user.length, 1499);
    });
  });

  group('HistoryController dan sematan', () {
    test('yang disematkan di atas, urutan lainnya tetap', () async {
      final controller = HistoryController(
        _FakeRepository([
          _conversation('a'),
          _conversation('b', pinned: true),
          _conversation('c'),
          _conversation('d', pinned: true),
        ]),
      );
      await controller.refresh();
      expect(controller.items.map((c) => c.id), ['b', 'd', 'a', 'c']);
    });

    test('copyWith mengganti judul dan sematan saja', () {
      final changed = _conversation('a').copyWith(title: 'Baru', pinned: true);
      expect((changed.id, changed.title, changed.pinned), ('a', 'Baru', true));
      expect(changed.updatedAt, DateTime(2026, 11, 12));
    });
  });

  group('SettingsStore catatan pribadi dan laporan crash', () {
    test('bawaan: catatan kosong, laporan crash menyala', () async {
      SharedPreferences.setMockInitialValues({});
      final settings = await SettingsStore.load();
      expect(settings.customInstruction, '');
      expect(settings.crashReports, isTrue);
    });

    test('catatan dirapikan, dipotong, dan bisa dikosongkan', () async {
      SharedPreferences.setMockInitialValues({});
      final settings = await SettingsStore.load();
      await settings.setCustomInstruction('  Panggil aku Mutu.  ');
      expect(settings.customInstruction, 'Panggil aku Mutu.');

      await settings.setCustomInstruction('x' * 900);
      expect(settings.customInstruction.length, SettingsStore.aboutMaxChars);

      await settings.setCustomInstruction('   ');
      expect(settings.customInstruction, '');
    });

    test('laporan crash bisa dimatikan', () async {
      SharedPreferences.setMockInitialValues({});
      final settings = await SettingsStore.load();
      await settings.setCrashReports(false);
      expect(settings.crashReports, isFalse);
    });
  });

  group('ErrorReporter', () {
    test('belum terpasang atau dimatikan: tidak mengirim apa pun', () async {
      final api = _FakeApi();
      final reporter = ErrorReporter()..report('boom', null);
      reporter.attach(api, () => false);
      reporter.report('boom', null);
      await Future<void>.delayed(Duration.zero);
      expect(api.calls, isEmpty);
    });

    test('error yang sama persis hanya dilaporkan sekali', () async {
      final api = _FakeApi();
      final reporter = ErrorReporter()..attach(api, () => true);
      reporter.report('Null check', StackTrace.current);
      reporter.report('Null check', StackTrace.current);
      await Future<void>.delayed(Duration.zero);

      expect(api.calls, hasLength(1));
      final call = api.calls.single;
      expect((call.$1, call.$2), ('POST', '/v1/report'));
      final body = call.$3! as Map<String, dynamic>;
      expect(body['kind'], 'crash');
      expect(body['message'], 'Null check');
      expect(body.keys, containsAll(['stack', 'version', 'platform']));
      expect(body.containsKey('email'), isFalse);
    });

    test('dibatasi per sesi dan kegagalan kirim diam saja', () async {
      final api = _FakeApi()..error = Exception('offline');
      final reporter = ErrorReporter()..attach(api, () => true);
      for (var i = 0; i < 20; i++) {
        reporter.report('error $i', null);
      }
      await Future<void>.delayed(Duration.zero);
      expect(api.calls, hasLength(ErrorReporter.maxPerRun));
    });
  });
}
