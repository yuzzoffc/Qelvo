import 'package:flutter_test/flutter_test.dart';
import 'package:qelvo_ai/core/time_format.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/data/sse.dart';

void main() {
  group('groupLabel', () {
    final now = DateTime(2026, 10, 24, 12);

    test('hari ini, kemarin, 7 hari terakhir, lebih lama', () {
      expect(groupLabel(now, DateTime(2026, 10, 24, 0, 5)), 'Hari ini');
      expect(groupLabel(now, DateTime(2026, 10, 23, 23, 59)), 'Kemarin');
      expect(groupLabel(now, DateTime(2026, 10, 18)), '7 hari terakhir');
      expect(groupLabel(now, DateTime(2026, 10, 17)), 'Lebih lama');
    });
  });

  group('parseSseLine', () {
    test('potongan teks', () {
      final event = parseSseLine('data: {"delta":"Halo"}');
      expect(event, isA<DeltaEvent>());
      expect((event as DeltaEvent).text, 'Halo');
    });

    test('selesai', () {
      expect(parseSseLine('data: {"done":true}'), isA<DoneEvent>());
    });

    test('error dari server', () {
      final event = parseSseLine(
        'data: {"error":{"code":"rate_limited","message":"Terlalu cepat"}}',
      ) as ErrorEvent;
      expect(event.code, 'rate_limited');
      expect(event.message, 'Terlalu cepat');
    });

    test('baris lain diabaikan', () {
      expect(parseSseLine(''), isNull);
      expect(parseSseLine(': ping'), isNull);
      expect(parseSseLine('data: bukan-json'), isNull);
    });
  });

  group('judul dan cuplikan', () {
    test('judul dipotong dan diberi elipsis', () {
      final title = titleFrom('${'a' * 60}\nbaris dua');
      expect(title.length, 43);
      expect(title.endsWith('…'), isTrue);
    });

    test('cuplikan membuang blok kode', () {
      final preview = previewFrom('Ini **jawaban**\n```dart\nvar a = 1;\n```');
      expect(preview, 'Ini jawaban');
    });
  });
}
