import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:qelvo_ai/data/api_client.dart';
import 'package:qelvo_ai/data/chat_repository.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/state/attachment_policy.dart';

class _FakeApi implements ApiClient {
  final List<(String, String, Object?)> calls = [];
  Object? reply;

  @override
  Future<Object?> request(
    String method,
    String path, {
    Object? body,
    Duration timeout = const Duration(seconds: 25),
  }) async {
    calls.add((method, path, body));
    return reply;
  }

  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

Uint8List _bytes(int length) => Uint8List(length);

ChatAttachment _photo({int full = 1000, bool onlyThumb = false}) {
  return ChatAttachment(
    thumb: _bytes(10),
    full: onlyThumb ? null : _bytes(full),
  );
}

ChatMessage _message(
  String id,
  ChatRole role, {
  List<ChatAttachment> attachments = const [],
}) {
  return ChatMessage(
    id: id,
    role: role,
    content: 'isi $id',
    createdAt: DateTime.fromMillisecondsSinceEpoch(1700000000000),
    attachments: attachments,
  );
}

void main() {
  group('imagesForRequest', () {
    test('tanpa lampiran tidak ada foto yang dikirim', () {
      final context = [
        _message('a', ChatRole.user),
        _message('b', ChatRole.assistant),
        _message('c', ChatRole.user),
      ];
      expect(imagesForRequest(context), isNull);
    });

    test('foto pesan terbaru yang berfoto ikut terkirim, meski bukan pesan terakhir', () {
      final photo = _photo();
      final context = [
        _message('a', ChatRole.user, attachments: [_photo()]),
        _message('b', ChatRole.assistant),
        _message('c', ChatRole.user, attachments: [photo]),
        _message('d', ChatRole.assistant),
        _message('e', ChatRole.user),
      ];
      final result = imagesForRequest(context)!;
      expect(result.messageId, 'c');
      expect(result.attachments, [photo]);
    });

    test('foto dari pesan yang lebih lama tidak dikirim ulang', () {
      final context = [
        _message('a', ChatRole.user, attachments: [_photo()]),
        _message('b', ChatRole.assistant),
        _message('c', ChatRole.user, attachments: [_photo()]),
      ];
      expect(imagesForRequest(context)!.messageId, 'c');
    });

    test('pesan dari riwayat hanya punya gambar kecil dan dilewati', () {
      final context = [
        _message('a', ChatRole.user, attachments: [_photo(onlyThumb: true)]),
        _message('b', ChatRole.assistant),
        _message('c', ChatRole.user),
      ];
      expect(imagesForRequest(context), isNull);
    });

    test('foto lama tidak menggantikan foto terbaru yang gagal masuk batas', () {
      final context = [
        _message('a', ChatRole.user, attachments: [_photo(full: 500)]),
        _message('b', ChatRole.assistant),
        _message('c', ChatRole.user, attachments: [_photo(full: 5000)]),
      ];
      expect(imagesForRequest(context, maxBytes: 1000), isNull);
    });

    test('jumlah dan total ukuran dibatasi', () {
      final context = [
        _message(
          'a',
          ChatRole.user,
          attachments: [_photo(), _photo(), _photo(), _photo()],
        ),
      ];
      expect(imagesForRequest(context, maxCount: 3)!.attachments.length, 3);
      expect(imagesForRequest(context, maxBytes: 2500)!.attachments.length, 2);
    });

    test('hanya pesan pengguna yang dipertimbangkan', () {
      final context = [
        _message('a', ChatRole.assistant, attachments: [_photo()]),
      ];
      expect(imagesForRequest(context), isNull);
    });

    test('batas bawaan sejalan dengan batas server', () {
      // Server: 4 foto, 1,5 MB per foto, 3 MB total, 45 KB per gambar kecil.
      expect(AttachmentRules.maxPerMessage, 4);
      expect(AttachmentRules.maxPhotoBytes, lessThanOrEqualTo(1500000));
      expect(AttachmentRules.maxRequestBytes, lessThanOrEqualTo(3000000));
      expect(AttachmentRules.maxThumbBytes, lessThanOrEqualTo(45000));
    });
  });

  group('katalog', () {
    test('kolom vision dibaca, dan server lama berarti tanpa dukungan foto', () {
      final data = CatalogData.fromJson({
        'default_provider': 'gemini',
        'providers': [
          {
            'id': 'gemini',
            'name': 'Gemini',
            'default_model': 'a',
            'models': [
              {'id': 'a', 'label': 'A', 'vision': true},
              {'id': 'b', 'label': 'B', 'vision': false},
              {'id': 'c', 'label': 'C'},
            ],
          },
        ],
      });
      final models = data.providers.single.models;
      expect(models.map((m) => m.vision), [true, false, false]);
    });
  });

  group('ChatRepository dan foto', () {
    test('gambar kecil dibaca dari pesan, gambar rusak dilewati', () async {
      final thumb = _bytes(5);
      final api = _FakeApi()
        ..reply = {
          'messages': [
            {
              'id': 'm1',
              'role': 'user',
              'content': 'apa ini?',
              'created_at': 1700000000000,
              'rating': 0,
              'images': [
                {'mime': 'image/jpeg', 'data': base64Encode(thumb)},
                {'mime': 'image/jpeg', 'data': '%%% bukan base64 %%%'},
                {'mime': 'image/jpeg'},
                'teks',
              ],
            },
            {
              'id': 'm2',
              'role': 'assistant',
              'content': 'jawaban',
              'created_at': 1700000001000,
              'rating': 0,
            },
          ],
        };
      final items = await ChatRepository(api).messages('c1');

      expect(items.first.attachments.length, 1);
      expect(items.first.attachments.single.thumb, thumb);
      expect(items.first.attachments.single.full, isNull);
      expect(items.last.attachments, isEmpty);
    });

    test('simpan mengirim gambar kecil, bukan foto penuh', () async {
      final api = _FakeApi();
      final thumb = Uint8List.fromList([1, 2, 3]);
      final message = _message(
        'm1',
        ChatRole.user,
        attachments: [
          ChatAttachment(thumb: thumb, full: _bytes(2000)),
        ],
      );
      final conversation = Conversation(
        id: 'c1',
        title: 'Foto',
        createdAt: DateTime.fromMillisecondsSinceEpoch(1700000000000),
        updatedAt: DateTime.fromMillisecondsSinceEpoch(1700000000000),
      );
      await ChatRepository(api).save(conversation: conversation, message: message);

      final body = api.calls.single.$3! as Map<String, dynamic>;
      final images = (body['message'] as Map)['images'] as List;
      expect(images.length, 1);
      expect((images.single as Map)['mime'], 'image/jpeg');
      expect((images.single as Map)['data'], base64Encode(thumb));
    });

    test('pesan tanpa foto tidak membawa kolom images', () async {
      final api = _FakeApi();
      final conversation = Conversation(
        id: 'c1',
        title: 'Halo',
        createdAt: DateTime.fromMillisecondsSinceEpoch(1700000000000),
        updatedAt: DateTime.fromMillisecondsSinceEpoch(1700000000000),
      );
      await ChatRepository(api).save(
        conversation: conversation,
        message: _message('m1', ChatRole.user),
      );
      final body = api.calls.single.$3! as Map<String, dynamic>;
      expect((body['message'] as Map).containsKey('images'), isFalse);
    });
  });
}
