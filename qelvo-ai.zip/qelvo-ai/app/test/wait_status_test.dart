import 'package:flutter_test/flutter_test.dart';
import 'package:qelvo_ai/state/wait_status.dart';

String _status({
  required bool thinking,
  required bool searching,
  required int seconds,
}) {
  return waitStatus(
    thinking: thinking,
    searching: searching,
    elapsed: Duration(seconds: seconds),
  );
}

void main() {
  group('waitStatus saat mencari di web', () {
    String at(int seconds) =>
        _status(thinking: true, searching: true, seconds: seconds);

    test('mulai dengan mencari, lalu berubah menjadi merangkum', () {
      expect(at(0), 'Sedang mencari di web');
      expect(at(6), 'Sedang mencari di web');
      expect(at(7), 'Sedang merangkum');
      expect(at(29), 'Sedang merangkum');
    });

    test('makin lama makin menenangkan, tanpa pernah menyerah', () {
      expect(at(30), 'Masih merangkum, sebentar lagi');
      expect(at(59), 'Masih merangkum, sebentar lagi');
      expect(at(60), 'Butuh waktu lebih lama dari biasanya, masih dikerjakan');
      expect(at(600), 'Butuh waktu lebih lama dari biasanya, masih dikerjakan');
    });

    test('mencari web tidak bergantung pada mode berpikir', () {
      expect(
        _status(thinking: false, searching: true, seconds: 3),
        'Sedang mencari di web',
      );
    });
  });

  group('waitStatus tanpa pencarian', () {
    test('mode berpikir', () {
      String at(int seconds) =>
          _status(thinking: true, searching: false, seconds: seconds);
      expect(at(0), 'Sedang berpikir');
      expect(at(19), 'Sedang berpikir');
      expect(at(20), 'Masih berpikir, sebentar lagi');
      expect(at(60), 'Butuh waktu lebih lama dari biasanya, masih dikerjakan');
    });

    test('mode berpikir mati', () {
      String at(int seconds) =>
          _status(thinking: false, searching: false, seconds: seconds);
      expect(at(0), 'Sedang menjawab');
      expect(at(20), 'Masih menjawab, sebentar lagi');
      expect(at(61), 'Butuh waktu lebih lama dari biasanya, masih dikerjakan');
    });
  });

  test('waktu negatif (jam bergeser) diperlakukan seperti baru mulai', () {
    expect(
      waitStatus(
        thinking: true,
        searching: true,
        elapsed: const Duration(seconds: -5),
      ),
      'Sedang mencari di web',
    );
  });
}
