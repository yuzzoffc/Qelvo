import 'package:flutter_test/flutter_test.dart';
import 'package:qelvo_ai/data/background_run.dart';

/// BackgroundRun yang hanya mencatat panggilan, tanpa saluran ke Android.
class _FakeBackground implements BackgroundRun {
  final List<String> calls = [];

  @override
  Future<void> begin() async => calls.add('begin');

  @override
  Future<void> end({RunNotice? notice, bool release = true}) async {
    calls.add('end notify=${notice != null} release=$release');
  }

  @override
  Future<void> moveToBack() async => calls.add('moveToBack');
}

void main() {
  late _FakeBackground background;
  late bool appHidden;
  late RunLedger ledger;

  setUp(() {
    background = _FakeBackground();
    appHidden = false;
    ledger = RunLedger(background, inBackground: () => appHidden);
  });

  group('RunLedger satu jawaban', () {
    test('selesai saat aplikasi terlihat: wake lock dilepas, tanpa pemberitahuan',
        () {
      ledger.begin();
      expect(ledger.hasActive, isTrue);
      ledger.end(RunOutcome.done);
      expect(ledger.hasActive, isFalse);
      expect(background.calls, ['begin', 'end notify=false release=true']);
    });

    test('selesai saat aplikasi tidak terlihat: ada pemberitahuan', () {
      ledger.begin();
      appHidden = true;
      ledger.end(RunOutcome.done);
      expect(background.calls, ['begin', 'end notify=true release=true']);
    });

    test('gagal atau dihentikan tidak pernah memberi pemberitahuan', () {
      appHidden = true;
      ledger.begin();
      ledger.end(RunOutcome.failed);
      ledger.begin();
      ledger.end(RunOutcome.cancelled);
      expect(background.calls, [
        'begin',
        'end notify=false release=true',
        'begin',
        'end notify=false release=true',
      ]);
    });

    test('end tanpa begin tidak membuat hitungan negatif', () {
      ledger.end(RunOutcome.cancelled);
      expect(ledger.hasActive, isFalse);
      ledger.begin();
      expect(ledger.hasActive, isTrue);
    });
  });

  group('RunLedger beberapa jawaban bersamaan (percakapan di latar belakang)', () {
    test('sistem hanya diberi tahu saat jawaban pertama mulai', () {
      ledger.begin();
      ledger.begin();
      expect(background.calls, ['begin']);
    });

    test('wake lock bertahan sampai jawaban terakhir selesai', () {
      ledger.begin();
      ledger.begin();
      ledger.end(RunOutcome.done); // aplikasi terlihat, tanpa pemberitahuan
      expect(ledger.hasActive, isTrue);
      expect(background.calls, ['begin']);
      ledger.end(RunOutcome.done);
      expect(ledger.hasActive, isFalse);
      expect(background.calls, ['begin', 'end notify=false release=true']);
    });

    test('tiap jawaban yang selesai di latar belakang memberi pemberitahuan', () {
      ledger.begin();
      ledger.begin();
      appHidden = true;
      ledger.end(RunOutcome.done);
      expect(background.calls.last, 'end notify=true release=false');
      ledger.end(RunOutcome.done);
      expect(background.calls.last, 'end notify=true release=true');
    });

    test('jawaban yang dihentikan saat yang lain masih jalan tidak melepas wake lock',
        () {
      ledger.begin();
      ledger.begin();
      ledger.end(RunOutcome.cancelled);
      expect(background.calls, ['begin']);
      expect(ledger.hasActive, isTrue);
    });
  });
}
