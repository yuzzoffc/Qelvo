import 'package:flutter_test/flutter_test.dart';
import 'package:qelvo_ai/core/theme.dart';

void main() {
  group('QelvoLayout', () {
    test('jarak teks isian ke tepi kartu = garis + padding kartu + padding kolom', () {
      expect(
        QelvoLayout.cardTextInset,
        QelvoLayout.cardBorder + QelvoLayout.cardPadding + QelvoLayout.fieldPadding,
      );
    });

    test('sapaan dan saran mulai dari garis kiri yang sama dengan teks isian', () {
      // Beranda memberi sapaan jarak cardMargin + cardTextInset dari tepi layar,
      // persis posisi awal teks di dalam kartu kolom tulis.
      expect(
        QelvoLayout.textStart,
        QelvoLayout.cardMargin + QelvoLayout.cardTextInset,
      );
    });
  });
}
