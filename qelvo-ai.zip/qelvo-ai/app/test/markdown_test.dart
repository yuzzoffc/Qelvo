import 'package:flutter_test/flutter_test.dart';
import 'package:qelvo_ai/ui/markdown/markdown_parser.dart';

void main() {
  test('judul dan paragraf', () {
    final blocks = parseMarkdown('# Judul\n\nIsi teks');
    expect(blocks, hasLength(2));
    final heading = blocks[0] as MdHeading;
    expect(heading.level, 1);
    expect(heading.text, 'Judul');
    expect((blocks[1] as MdParagraph).text, 'Isi teks');
  });

  test('blok kode yang ditutup', () {
    final blocks = parseMarkdown('Contoh:\n```dart\nvar a = 1;\n```\nSelesai');
    expect(blocks, hasLength(3));
    final code = blocks[1] as MdCode;
    expect(code.language, 'dart');
    expect(code.code, 'var a = 1;');
  });

  test('blok kode yang belum ditutup tetap dianggap kode', () {
    final blocks = parseMarkdown('```python\nprint(1)\nprint(2)');
    expect(blocks, hasLength(1));
    final code = blocks.single as MdCode;
    expect(code.language, 'python');
    expect(code.code, 'print(1)\nprint(2)');
  });

  test('daftar bersarang memakai level relatif', () {
    final list = parseMarkdown('- satu\n    - anak\n- dua').single as MdList;
    expect(list.items.map((item) => item.level).toList(), [0, 1, 0]);
    expect(list.items.map((item) => item.text).toList(), ['satu', 'anak', 'dua']);
  });

  test('daftar bernomor mempertahankan nomor aslinya', () {
    final list = parseMarkdown('1. a\n2. b').single as MdList;
    expect(list.items.map((item) => item.marker).toList(), ['1.', '2.']);
  });

  test('tabel', () {
    final table =
        parseMarkdown('| A | B |\n|---|---|\n| 1 | 2 |').single as MdTable;
    expect(table.header, ['A', 'B']);
    expect(table.rows, [
      ['1', '2'],
    ]);
  });

  test('garis pemisah', () {
    expect(parseMarkdown('---').single, isA<MdRule>());
  });
}
