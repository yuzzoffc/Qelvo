import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:qelvo_ai/state/attachment_policy.dart';
import 'package:qelvo_ai/state/photo_prep.dart';

/// Foto contoh dengan gradasi, supaya JPEG-nya tidak sekecil gambar polos.
Uint8List _sampleJpeg(int width, int height) {
  final image = img.Image(width: width, height: height);
  for (var y = 0; y < height; y++) {
    for (var x = 0; x < width; x++) {
      image.setPixelRgb(x, y, (x * 255) ~/ width, (y * 255) ~/ height, (x + y) % 256);
    }
  }
  return Uint8List.fromList(img.encodeJpg(image, quality: 92));
}

/// Penanda segmen JPEG dari awal berkas sampai SOS (0xDA), dalam urutan muncul.
List<int> _markers(Uint8List jpeg) {
  final markers = <int>[];
  var i = 2;
  while (i + 4 <= jpeg.length && jpeg[i] == 0xFF) {
    final marker = jpeg[i + 1];
    markers.add(marker);
    if (marker == 0xDA) break;
    i += 2 + ((jpeg[i + 2] << 8) | jpeg[i + 3]);
  }
  return markers;
}

void main() {
  group('stripJpegMetadata', () {
    // SOI, APP0 (JFIF), APP1 (EXIF), DQT, SOS, dua byte data, EOI.
    final jpeg = Uint8List.fromList([
      0xFF, 0xD8,
      0xFF, 0xE0, 0x00, 0x04, 0x4A, 0x46,
      0xFF, 0xE1, 0x00, 0x06, 0x45, 0x78, 0x69, 0x66,
      0xFF, 0xDB, 0x00, 0x04, 0x01, 0x02,
      0xFF, 0xDA, 0x00, 0x04, 0x03, 0x04,
      0x11, 0x22, 0xFF, 0xD9,
    ]);

    test('segmen EXIF dibuang, segmen lain dan data gambar tetap', () {
      final result = stripJpegMetadata(jpeg);
      expect(result, [
        0xFF, 0xD8,
        0xFF, 0xE0, 0x00, 0x04, 0x4A, 0x46,
        0xFF, 0xDB, 0x00, 0x04, 0x01, 0x02,
        0xFF, 0xDA, 0x00, 0x04, 0x03, 0x04,
        0x11, 0x22, 0xFF, 0xD9,
      ]);
    });

    test('komentar dan IPTC ikut dibuang', () {
      final withExtras = Uint8List.fromList([
        0xFF, 0xD8,
        0xFF, 0xFE, 0x00, 0x04, 0x68, 0x69,
        0xFF, 0xED, 0x00, 0x03, 0x01,
        0xFF, 0xDA, 0x00, 0x04, 0x03, 0x04,
        0x11, 0xFF, 0xD9,
      ]);
      expect(stripJpegMetadata(withExtras), [
        0xFF, 0xD8,
        0xFF, 0xDA, 0x00, 0x04, 0x03, 0x04,
        0x11, 0xFF, 0xD9,
      ]);
    });

    test('berkas yang bukan JPEG atau terpotong dikembalikan apa adanya', () {
      final notJpeg = Uint8List.fromList([1, 2, 3, 4, 5]);
      expect(stripJpegMetadata(notJpeg), notJpeg);
      final truncated = Uint8List.fromList([0xFF, 0xD8, 0xFF, 0xE1, 0x00, 0x20, 0x01]);
      expect(stripJpegMetadata(truncated), truncated);
    });
  });

  group('encodePhoto', timeout: const Timeout(Duration(minutes: 3)), () {
    test('foto besar dikecilkan dan gambar kecilnya masuk batas ukuran', () {
      final result = encodePhoto(_sampleJpeg(1400, 1050))!;

      final full = img.decodeImage(result.full)!;
      expect(full.width, 1280);
      expect(full.height, 960);
      expect(result.full.length, lessThanOrEqualTo(AttachmentRules.maxPhotoBytes));

      final thumb = img.decodeImage(result.thumb)!;
      expect(thumb.height, lessThanOrEqualTo(320));
      expect(result.thumb.length, lessThanOrEqualTo(AttachmentRules.maxThumbBytes));
    });

    test('foto tegak dibatasi di sisi tingginya', () {
      final result = encodePhoto(_sampleJpeg(1050, 1400))!;
      final full = img.decodeImage(result.full)!;
      expect(full.height, 1280);
      expect(full.width, lessThan(full.height));
    });

    test('foto yang sudah kecil tidak diperbesar', () {
      final result = encodePhoto(_sampleJpeg(400, 300))!;
      final full = img.decodeImage(result.full)!;
      expect(full.width, 400);
      expect(full.height, 300);
    });

    test('hasil berupa JPEG tanpa segmen EXIF, XMP, IPTC, atau komentar', () {
      final result = encodePhoto(_sampleJpeg(600, 400))!;
      for (final bytes in [result.full, result.thumb]) {
        expect(bytes[0], 0xFF);
        expect(bytes[1], 0xD8);
        final markers = _markers(bytes);
        expect(markers, contains(0xDA));
        expect(markers, isNot(contains(0xE1)));
        expect(markers, isNot(contains(0xED)));
        expect(markers, isNot(contains(0xFE)));
      }
    });

    test('data yang bukan gambar menghasilkan null', () {
      expect(encodePhoto(Uint8List.fromList([1, 2, 3, 4, 5, 6])), isNull);
    });
  });
}
