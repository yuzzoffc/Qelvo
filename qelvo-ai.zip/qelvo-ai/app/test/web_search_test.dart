import 'package:flutter_test/flutter_test.dart';
import 'package:qelvo_ai/data/api_client.dart';
import 'package:qelvo_ai/data/models.dart';
import 'package:qelvo_ai/data/settings_store.dart';
import 'package:qelvo_ai/data/sse.dart';
import 'package:qelvo_ai/state/model_catalog.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// ApiClient yang daftar modelnya diisi dari tes, tanpa jaringan.
class _FakeApi extends ApiClient {
  _FakeApi(this.data) : super(() async => null);

  final CatalogData data;

  @override
  Future<CatalogData> fetchCatalog() async => data;
}

CatalogData _catalog({required bool modelA, required bool modelB}) {
  return CatalogData(
    defaultProvider: 'gemini',
    providers: [
      ProviderInfo(
        id: 'gemini',
        name: 'Gemini',
        tagline: '',
        defaultModel: 'a',
        models: [
          ModelOption(id: 'a', label: 'Gemini A', webSearch: modelA),
          ModelOption(id: 'b', label: 'Gemini B', webSearch: modelB),
        ],
      ),
    ],
  );
}

Future<ModelCatalog> _loaded(CatalogData data) async {
  SharedPreferences.setMockInitialValues({});
  final settings = await SettingsStore.load();
  final catalog = ModelCatalog(settings, _FakeApi(data));
  await catalog.load();
  return catalog;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('ChatSource.tryParse', () {
    test('menerima tautan http dan https', () {
      final https = ChatSource.tryParse({'title': 'Kompas', 'url': 'https://kompas.com/a'});
      final http = ChatSource.tryParse({'title': 'Lama', 'url': 'http://contoh.id/a'});
      expect(https?.url, 'https://kompas.com/a');
      expect(http?.url, 'http://contoh.id/a');
    });

    test('membuang skema selain http dan https', () {
      const urls = [
        'javascript:alert(1)',
        'intent://x#Intent;end',
        'file:///etc/passwd',
        'ftp://contoh.com/a',
        'tel:123',
        'mailto:a@b.co',
        'https://',
        '//contoh.com/a',
        'contoh.com/a',
        '',
      ];
      for (final url in urls) {
        expect(
          ChatSource.tryParse({'title': 'x', 'url': url}),
          isNull,
          reason: url,
        );
      }
    });

    test('membuang entri yang bukan peta atau tanpa alamat teks', () {
      expect(ChatSource.tryParse('https://contoh.com'), isNull);
      expect(ChatSource.tryParse(null), isNull);
      expect(ChatSource.tryParse({'title': 'tanpa url'}), isNull);
      expect(ChatSource.tryParse({'url': 5}), isNull);
    });

    test('judul kosong memakai nama situs tanpa www', () {
      final source = ChatSource.tryParse({'url': 'https://www.kompas.com/a/b'})!;
      expect(source.title, '');
      expect(source.host, 'kompas.com');
      expect(source.label, 'kompas.com');
    });

    test('kurung siku dan baris baru di judul dibuang', () {
      final source = ChatSource.tryParse({
        'title': 'Euro [2024]\nJuara',
        'url': 'https://contoh.com/x',
      })!;
      expect(source.title, 'Euro 2024 Juara');
    });

    test('judul panjang dipotong tanpa membelah pasangan surrogate', () {
      final title = '${'a' * 119}😀${'b' * 10}';
      final source = ChatSource.tryParse({
        'title': title,
        'url': 'https://contoh.com/x',
      })!;
      expect(source.title, '${'a' * 119}…');
    });
  });

  group('ChatSource.listFrom', () {
    test('membuang tautan ganda dan menjaga urutan', () {
      final list = ChatSource.listFrom([
        {'title': 'A', 'url': 'https://a.com/1'},
        {'title': 'B', 'url': 'https://b.com/1'},
        {'title': 'A lagi', 'url': 'https://a.com/1'},
      ]);
      expect(list.map((s) => s.title), ['A', 'B']);
    });

    test('paling banyak delapan sumber', () {
      final list = ChatSource.listFrom([
        for (var i = 0; i < 12; i++) {'title': 'S$i', 'url': 'https://s$i.com/'},
      ]);
      expect(list.length, ChatSource.maxPerAnswer);
      expect(list.first.title, 'S0');
    });

    test('entri rusak dilewati, bukan daftar menghasilkan daftar kosong', () {
      final list = ChatSource.listFrom([
        1,
        null,
        'teks',
        {'url': 5},
        {'url': 'https://ok.com/'},
      ]);
      expect(list.length, 1);
      expect(ChatSource.listFrom('bukan daftar'), isEmpty);
      expect(ChatSource.listFrom(null), isEmpty);
    });
  });

  group('ChatSource.markdownList', () {
    test('kosong kalau tidak ada sumber', () {
      expect(ChatSource.markdownList(const []), '');
    });

    test('daftar tautan Markdown dengan label judul atau nama situs', () {
      const sources = [
        ChatSource(title: 'Kompas', url: 'https://kompas.com/a'),
        ChatSource(title: '', url: 'https://www.detik.com/b'),
      ];
      expect(
        ChatSource.markdownList(sources),
        'Sumber:\n- [Kompas](https://kompas.com/a)\n- [detik.com](https://www.detik.com/b)\n\n',
      );
    });
  });

  group('parseSseLine sumber', () {
    test('event sumber dibaca', () {
      final event = parseSseLine(
        'data: {"sources":[{"title":"Kompas","url":"https://kompas.com/x"}]}',
      );
      expect(event, isA<SourcesEvent>());
      final sources = (event as SourcesEvent).sources;
      expect(sources.single.title, 'Kompas');
      expect(sources.single.url, 'https://kompas.com/x');
    });

    test('sumber yang semuanya ditolak tidak menghasilkan event', () {
      expect(
        parseSseLine('data: {"sources":[{"url":"javascript:alert(1)"}]}'),
        isNull,
      );
      expect(parseSseLine('data: {"sources":"bukan daftar"}'), isNull);
      expect(parseSseLine('data: {"sources":[]}'), isNull);
    });

    test('teks dan penanda selesai tetap dibaca seperti biasa', () {
      expect(parseSseLine('data: {"delta":"Halo"}'), isA<DeltaEvent>());
      expect(parseSseLine('data: {"done":true}'), isA<DoneEvent>());
    });
  });

  group('ProviderInfo.fromJson', () {
    test('kolom web_search dibaca, dan server lama berarti tidak ada', () {
      final provider = ProviderInfo.fromJson({
        'id': 'gemini',
        'name': 'Gemini',
        'default_model': 'a',
        'models': [
          {'id': 'a', 'label': 'A', 'vision': true, 'web_search': true},
          {'id': 'b', 'label': 'B', 'vision': true},
        ],
      });
      expect(provider.models[0].webSearch, isTrue);
      expect(provider.models[1].webSearch, isFalse);
    });
  });

  group('ModelCatalog dan Cari web', () {
    test('sebelum daftar dimuat: tidak ada dukungan', () async {
      SharedPreferences.setMockInitialValues({});
      final settings = await SettingsStore.load();
      final catalog = ModelCatalog(
        settings,
        _FakeApi(_catalog(modelA: true, modelB: true)),
      );
      expect(catalog.supportsWebSearch, isFalse);
      expect(catalog.webSearchOnServer, isFalse);
    });

    test('server lama: tidak ada model yang mengiklankan pencarian', () async {
      final catalog = await _loaded(_catalog(modelA: false, modelB: false));
      expect(catalog.webSearchOnServer, isFalse);
      expect(catalog.supportsWebSearch, isFalse);
    });

    test('server punya fiturnya tapi model terpilih tidak mendukung', () async {
      final catalog = await _loaded(_catalog(modelA: false, modelB: true));
      expect(catalog.webSearchOnServer, isTrue);
      expect(catalog.supportsWebSearch, isFalse);
    });

    test('model terpilih mendukung pencarian', () async {
      final catalog = await _loaded(_catalog(modelA: true, modelB: false));
      expect(catalog.webSearchOnServer, isTrue);
      expect(catalog.supportsWebSearch, isTrue);
    });
  });

  group('SettingsStore.webSearch', () {
    test('mati secara bawaan dan tersimpan saat diubah', () async {
      SharedPreferences.setMockInitialValues({});
      final settings = await SettingsStore.load();
      expect(settings.webSearch, isFalse);
      await settings.setWebSearch(true);
      expect(settings.webSearch, isTrue);
      await settings.setWebSearch(false);
      expect(settings.webSearch, isFalse);
    });
  });
}
