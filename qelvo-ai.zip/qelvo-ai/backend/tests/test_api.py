"""Tes endpoint dengan FastAPI TestClient. Dilewati kalau fastapi atau httpx belum terpasang."""

import unittest

from app.auth import OpenVerifier
from app.config import Settings
from app.emailcode import EmailCodeService, MemoryCodeStore
from app.errors import ApiError, ProviderError
from app.providers.base import ModelInfo, Provider

try:
    from fastapi.testclient import TestClient

    from app.main import create_app

    HAS_STACK = True
except ImportError:
    HAS_STACK = False


class FakeProvider(Provider):
    id = "fake"
    name = "Fake"
    tagline = "uji"

    def __init__(self, pieces=("Ha", "lo"), error=None):
        super().__init__([ModelInfo("fake-1", "Fake 1")])
        self.pieces = pieces
        self.error = error
        self.calls = []

    async def stream(self, turns, model, *, system, thinking, max_output_tokens):
        self.calls.append({"turns": list(turns), "system": system, "thinking": thinking})
        if self.error is not None:
            raise self.error
        for piece in self.pieces:
            yield piece


class DenyVerifier:
    async def verify(self, token):
        raise ApiError(401, "unauthorized", "Masuk dulu untuk memakai QELVO.")


class FakeAccounts:
    async def custom_token_for_email(self, email):
        return f"token-{email}"


class FakeMailer:
    def __init__(self):
        self.sent = []

    async def send_code(self, recipient, code, minutes):
        self.sent.append((recipient, code, minutes))


@unittest.skipUnless(HAS_STACK, "fastapi dan httpx belum terpasang")
class ApiTest(unittest.TestCase):
    CHAT = {"messages": [{"role": "user", "content": "hai"}], "provider": "fake"}

    def client(self, provider=None, verifier=None, settings=None, email=None):
        app = create_app(
            settings or Settings(auth_mode="off"),
            providers={"fake": provider or FakeProvider()},
            verifier=verifier or OpenVerifier(),
            email_service=email,
            accounts=FakeAccounts() if email else None,
        )
        return TestClient(app)

    def test_health(self):
        with self.client() as client:
            response = client.get("/health")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["providers"], ["fake"])

    def test_katalog_penyedia(self):
        with self.client() as client:
            data = client.get("/v1/providers").json()
        self.assertEqual(data["default_provider"], "fake")
        self.assertEqual(data["providers"][0]["models"], [{"id": "fake-1", "label": "Fake 1"}])
        self.assertEqual(data["providers"][0]["default_model"], "fake-1")

    def test_chat_streaming(self):
        with self.client() as client:
            response = client.post("/v1/chat", json=self.CHAT)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.headers["content-type"].startswith("text/event-stream"))
        body = response.text
        self.assertIn('data: {"meta":', body)
        self.assertIn('data: {"delta":"Ha"}', body)
        self.assertIn('data: {"delta":"lo"}', body)
        self.assertTrue(body.rstrip().endswith('data: {"done":true}'))

    def test_chat_tanpa_stream(self):
        with self.client() as client:
            data = client.post("/v1/chat", json={**self.CHAT, "stream": False}).json()
        self.assertEqual(data["content"], "Halo")
        self.assertEqual(data["model_label"], "Fake 1")

    def test_gaya_dan_mode_berpikir_diteruskan(self):
        provider = FakeProvider()
        body = {**self.CHAT, "instruction": "ringkas", "thinking": False}
        with self.client(provider=provider) as client:
            client.post("/v1/chat", json=body)
        call = provider.calls[0]
        self.assertFalse(call["thinking"])
        self.assertIn("keep answers short", call["system"])

    def test_tanpa_login_ditolak(self):
        with self.client(verifier=DenyVerifier()) as client:
            catalog = client.get("/v1/providers")
            chat = client.post("/v1/chat", json=self.CHAT)
        self.assertEqual(catalog.status_code, 401)
        self.assertEqual(chat.status_code, 401)
        self.assertEqual(chat.json()["error"]["code"], "unauthorized")

    def test_penolakan_penyedia_menjadi_status_http(self):
        error = ProviderError(429, "provider_rate_limited", "Kuota habis.")
        with self.client(provider=FakeProvider(error=error)) as client:
            response = client.post("/v1/chat", json=self.CHAT)
        self.assertEqual(response.status_code, 429)
        self.assertEqual(response.json()["error"]["code"], "provider_rate_limited")

    def test_batas_permintaan_per_pengguna(self):
        settings = Settings(auth_mode="off", rate_limit_per_minute=1)
        with self.client(settings=settings) as client:
            first = client.post("/v1/chat", json=self.CHAT)
            second = client.post("/v1/chat", json=self.CHAT)
        self.assertEqual(first.status_code, 200)
        self.assertEqual(second.status_code, 429)
        self.assertEqual(second.json()["error"]["code"], "rate_limited")

    def test_model_tidak_dikenal(self):
        with self.client() as client:
            response = client.post("/v1/chat", json={**self.CHAT, "model": "tidak-ada"})
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json()["error"]["code"], "unknown_model")

    def test_validasi_permintaan(self):
        with self.client() as client:
            response = client.post("/v1/chat", json={"messages": []})
        self.assertEqual(response.status_code, 422)
        self.assertEqual(response.json()["error"]["code"], "invalid_request")

    def test_login_email_lengkap(self):
        email = EmailCodeService(
            MemoryCodeStore(), FakeMailer(), pepper="p", code_factory=lambda: "123456"
        )
        with self.client(email=email) as client:
            start = client.post("/v1/auth/email/start", json={"email": "User@Email.com"})
            wrong = client.post(
                "/v1/auth/email/verify", json={"email": "user@email.com", "code": "000000"}
            )
            right = client.post(
                "/v1/auth/email/verify", json={"email": "user@email.com", "code": "123456"}
            )
            short = client.post(
                "/v1/auth/email/verify", json={"email": "user@email.com", "code": "12"}
            )
        self.assertEqual(start.status_code, 200)
        self.assertEqual(start.json()["resend_in"], 60)
        self.assertEqual(wrong.status_code, 400)
        self.assertEqual(wrong.json()["error"]["code"], "code_invalid")
        self.assertEqual(right.json(), {"custom_token": "token-user@email.com"})
        self.assertEqual(short.status_code, 422)

    def test_login_email_nonaktif_tanpa_layanan(self):
        with self.client() as client:
            response = client.post("/v1/auth/email/start", json={"email": "a@b.co"})
        self.assertEqual(response.status_code, 503)
        self.assertEqual(response.json()["error"]["code"], "email_disabled")


if __name__ == "__main__":
    unittest.main()
