import unittest

from app.emailcode import EmailCodeService, MemoryCodeStore, normalize_email
from app.errors import ApiError
from app.mailer import MailError, MailNotConfigured, build_code_message


class Clock:
    def __init__(self, now: float = 1000.0) -> None:
        self.now = now

    def __call__(self) -> float:
        return self.now


class FakeMailer:
    def __init__(self) -> None:
        self.sent: list[tuple[str, str, int]] = []
        self.error: Exception | None = None

    async def send_code(self, recipient: str, code: str, minutes: int) -> None:
        if self.error:
            raise self.error
        self.sent.append((recipient, code, minutes))


def make_service(clock: Clock, mailer: FakeMailer, **kwargs) -> EmailCodeService:
    return EmailCodeService(
        MemoryCodeStore(clock),
        mailer,
        pepper="rahasia",
        clock=clock,
        code_factory=lambda: "123456",
        **kwargs,
    )


class EmailCodeServiceTest(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self.clock = Clock()
        self.mailer = FakeMailer()
        self.service = make_service(self.clock, self.mailer)

    async def assertCode(self, coro, code: str) -> ApiError:
        with self.assertRaises(ApiError) as ctx:
            await coro
        self.assertEqual(ctx.exception.code, code)
        return ctx.exception

    async def test_kode_dikirim_lalu_diverifikasi_sekali_pakai(self) -> None:
        result = await self.service.start(" User@Email.com ")
        self.assertEqual(result, {"ok": True, "expires_in": 600, "resend_in": 60})
        self.assertEqual(self.mailer.sent, [("user@email.com", "123456", 10)])

        self.assertEqual(await self.service.verify("user@email.com", "123456"), "user@email.com")
        await self.assertCode(self.service.verify("user@email.com", "123456"), "code_expired")

    async def test_kode_salah_menghabiskan_percobaan(self) -> None:
        await self.service.start("a@b.co")
        error = await self.assertCode(self.service.verify("a@b.co", "000000"), "code_invalid")
        self.assertIn("Sisa percobaan: 4", error.message)
        for _ in range(3):
            await self.assertCode(self.service.verify("a@b.co", "000000"), "code_invalid")
        await self.assertCode(self.service.verify("a@b.co", "000000"), "too_many_attempts")
        await self.assertCode(self.service.verify("a@b.co", "123456"), "code_expired")

    async def test_kode_kedaluwarsa(self) -> None:
        await self.service.start("a@b.co")
        self.clock.now += 601
        await self.assertCode(self.service.verify("a@b.co", "123456"), "code_expired")

    async def test_kirim_ulang_terlalu_cepat(self) -> None:
        await self.service.start("a@b.co")
        error = await self.assertCode(self.service.start("a@b.co"), "resend_too_soon")
        self.assertEqual(error.status, 429)
        self.assertEqual(error.headers["Retry-After"], "60")
        self.clock.now += 61
        await self.service.start("a@b.co")
        self.assertEqual(len(self.mailer.sent), 2)

    async def test_batas_per_jam(self) -> None:
        service = make_service(self.clock, self.mailer, hourly_limit=2)
        await service.start("a@b.co")
        self.clock.now += 61
        await service.start("a@b.co")
        self.clock.now += 61
        await self.assertCode(service.start("a@b.co"), "too_many_codes")
        self.clock.now += 3600
        await service.start("a@b.co")

    async def test_email_gagal_terkirim_tidak_mengunci_pengguna(self) -> None:
        self.mailer.error = MailError("SMTPException")
        error = await self.assertCode(self.service.start("a@b.co"), "email_failed")
        self.assertEqual(error.status, 502)
        self.mailer.error = None
        await self.service.start("a@b.co")
        self.assertEqual(len(self.mailer.sent), 1)

    async def test_smtp_belum_diatur(self) -> None:
        self.mailer.error = MailNotConfigured("kosong")
        error = await self.assertCode(self.service.start("a@b.co"), "email_not_configured")
        self.assertEqual(error.status, 503)


class EmailHelpersTest(unittest.TestCase):
    def test_normalize_email(self) -> None:
        self.assertEqual(normalize_email("  Nama@Contoh.ID "), "nama@contoh.id")
        for bad in ["", "tanpa-at", "a@b", "a b@c.co", "x" * 250 + "@a.co"]:
            with self.assertRaises(ApiError) as ctx:
                normalize_email(bad)
            self.assertEqual(ctx.exception.code, "invalid_email")

    def test_isi_email(self) -> None:
        message = build_code_message("QELVO <no-reply@contoh.com>", "a@b.co", "123456", 10)
        self.assertEqual(message["Subject"], "Kode masuk QELVO: 123456")
        self.assertEqual(message["To"], "a@b.co")
        self.assertIn("10 menit", message.get_body(("plain",)).get_content())
        self.assertIn("123456", message.get_body(("html",)).get_content())


if __name__ == "__main__":
    unittest.main()
