"""Pembatas permintaan jendela geser, di memori (satu proses)."""

from __future__ import annotations

import time
from collections import deque
from collections.abc import Callable, Mapping


class SlidingWindowLimiter:
    """Maksimal `limit` permintaan per `window_seconds` untuk tiap kunci.

    `limit <= 0` berarti tanpa batas. Data hanya ada di memori proses ini,
    jadi untuk beberapa instance server pakai penyimpanan bersama.
    """

    def __init__(
        self,
        limit: int,
        window_seconds: float = 60.0,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self._limit = limit
        self._window = window_seconds
        self._clock = clock
        self._hits: dict[str, deque[float]] = {}

    def check(self, key: str) -> float:
        """0.0 kalau diizinkan (dan dicatat), selain itu detik tunggu."""
        if self._limit <= 0:
            return 0.0
        now = self._clock()
        hits = self._hits.setdefault(key, deque())
        while hits and now - hits[0] >= self._window:
            hits.popleft()
        if len(hits) >= self._limit:
            return max(self._window - (now - hits[0]), 0.001)
        hits.append(now)
        if len(self._hits) > 2048:
            self._purge(now)
        return 0.0

    def _purge(self, now: float) -> None:
        stale = [k for k, h in self._hits.items() if not h or now - h[-1] >= self._window]
        for key in stale:
            del self._hits[key]


def client_ip(headers: Mapping[str, str], peer: str | None, trust_proxy: bool) -> str:
    """Alamat klien. X-Forwarded-For hanya dipercaya kalau server di belakang proxy tepercaya."""
    if trust_proxy:
        forwarded = headers.get("x-forwarded-for", "")
        first = forwarded.split(",")[0].strip()
        if first:
            return first
    return peer or "unknown"
