from typing import Literal

from pydantic import BaseModel, Field


class ChatMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(max_length=50_000)


class ChatRequest(BaseModel):
    messages: list[ChatMessage] = Field(min_length=1, max_length=200)
    provider: str | None = None
    model: str | None = None
    thinking: bool = True
    instruction: str = "standar"
    stream: bool = True


class EmailStartRequest(BaseModel):
    email: str = Field(max_length=254)


class EmailVerifyRequest(BaseModel):
    email: str = Field(max_length=254)
    code: str = Field(pattern=r"^\d{6}$")
