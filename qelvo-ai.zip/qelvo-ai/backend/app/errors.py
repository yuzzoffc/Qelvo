"""Kesalahan API: kode mesin dan pesan yang aman ditampilkan ke pengguna."""

from __future__ import annotations


class ApiError(Exception):
    def __init__(
        self,
        status: int,
        code: str,
        message: str,
        headers: dict[str, str] | None = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.code = code
        self.message = message
        self.headers = headers or {}


class ProviderError(ApiError):
    """Kesalahan dari penyedia AI: kuota habis, key ditolak, jaringan putus."""
