"""Pengaturan dari environment variable dan berkas .env (tanpa dependensi tambahan)."""

from __future__ import annotations

import os
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path

DEFAULT_GEMINI_MODELS = (
    "gemini-2.5-flash| Gemini 2.5 Flash,"
    "gemini-3.5-flash-lite|Gemini 3.5 Flash-Lite,"
    "gemini-3.8-flash|Gemini 3.8 Flash,"
    "gemini-3.1-flash-lite|Gemini 3.1 Flash-Lite"
)
DEFAULT_OPENROUTER_MODELS = "openrouter/free|OpenRouter Gratis (otomatis)"

# Dibaca dari folder kerja (backend/) lalu dari root repo. Yang pertama menang.
DEFAULT_ENV_FILES = (Path(".env"), Path("../.env"))


@dataclass(frozen=True)
class Settings:
    gemini_api_key: str = "AQ.Ab8RN6LOrdZxg7mf_45P9POlzQpXG1iW5zkgkhpzRY-eu3wYTA"
    gemini_models: str = DEFAULT_GEMINI_MODELS
    gemini_effort_thinking: str = "medium"
    gemini_effort_fast: str = "low"
    openrouter_api_key: str = ""
    openrouter_models: str = DEFAULT_OPENROUTER_MODELS
    default_provider: str = ""

    auth_mode: str = "firebase"
    firebase_project_id: str = ""
    firebase_credentials_json: str = ""
    google_application_credentials: str = ""
    allow_guest: bool = True
    guest_rate_limit_per_minute: int = 10

    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_from: str = ""
    smtp_security: str = "starttls"
    code_pepper: str = ""
    email_code_store: str = "firestore"
    email_code_ttl_seconds: int = 600
    email_code_max_attempts: int = 5
    email_code_resend_seconds: int = 60
    email_code_hourly_limit: int = 5
    dev_print_codes: bool = False

    rate_limit_per_minute: int = 20
    max_messages: int = 40
    max_message_chars: int = 8000
    max_context_chars: int = 48000
    max_output_tokens: int = 8192
    request_timeout_seconds: float = 90.0
    cors_origins: tuple[str, ...] = ("*",)
    trust_proxy: bool = False


def _read_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.is_file():
        return values
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        values[key.strip()] = value
    return values


def load_settings(
    environ: Mapping[str, str] | None = None,
    env_files: Sequence[Path] | None = None,
) -> Settings:
    """Environment variable mengalahkan isi berkas .env."""
    values: dict[str, str] = {}
    files = DEFAULT_ENV_FILES if env_files is None else tuple(env_files)
    for path in reversed(files):
        values.update(_read_env_file(path))
    values.update(os.environ if environ is None else environ)

    def text(key: str, default: str = "") -> str:
        raw = values.get(key)
        return default if raw is None else raw.strip()

    def whole(key: str, default: int) -> int:
        raw = text(key)
        if not raw:
            return default
        try:
            return int(raw)
        except ValueError as error:
            raise ValueError(f"{key} harus berupa bilangan bulat, bukan {raw!r}") from error

    def decimal(key: str, default: float) -> float:
        raw = text(key)
        if not raw:
            return default
        try:
            return float(raw)
        except ValueError as error:
            raise ValueError(f"{key} harus berupa angka, bukan {raw!r}") from error

    def flag(key: str, default: bool = False) -> bool:
        raw = text(key)
        if not raw:
            return default
        return raw.lower() in {"1", "true", "yes", "ya", "on"}

    origins = tuple(o.strip() for o in text("CORS_ORIGINS", "*").split(",") if o.strip())

    return Settings(
        gemini_api_key=text("GEMINI_API_KEY"),
        gemini_models=text("GEMINI_MODELS") or DEFAULT_GEMINI_MODELS,
        gemini_effort_thinking=text("GEMINI_EFFORT_THINKING", "medium"),
        gemini_effort_fast=text("GEMINI_EFFORT_FAST", "low"),
        openrouter_api_key=text("OPENROUTER_API_KEY"),
        openrouter_models=text("OPENROUTER_MODELS") or DEFAULT_OPENROUTER_MODELS,
        default_provider=text("DEFAULT_PROVIDER").lower(),
        auth_mode=text("AUTH_MODE", "firebase").lower(),
        firebase_project_id=text("FIREBASE_PROJECT_ID"),
        firebase_credentials_json=text("FIREBASE_CREDENTIALS_JSON"),
        google_application_credentials=text("GOOGLE_APPLICATION_CREDENTIALS"),
        allow_guest=flag("ALLOW_GUEST", default=True),
        guest_rate_limit_per_minute=whole("GUEST_RATE_LIMIT_PER_MINUTE", 10),
        smtp_host=text("SMTP_HOST"),
        smtp_port=whole("SMTP_PORT", 587),
        smtp_user=text("SMTP_USER"),
        smtp_password=text("SMTP_PASSWORD"),
        smtp_from=text("SMTP_FROM"),
        smtp_security=text("SMTP_SECURITY", "starttls").lower(),
        code_pepper=text("CODE_PEPPER"),
        email_code_store=text("EMAIL_CODE_STORE", "firestore").lower(),
        email_code_ttl_seconds=whole("EMAIL_CODE_TTL_SECONDS", 600),
        email_code_max_attempts=whole("EMAIL_CODE_MAX_ATTEMPTS", 5),
        email_code_resend_seconds=whole("EMAIL_CODE_RESEND_SECONDS", 60),
        email_code_hourly_limit=whole("EMAIL_CODE_HOURLY_LIMIT", 5),
        dev_print_codes=flag("DEV_PRINT_CODES"),
        rate_limit_per_minute=whole("RATE_LIMIT_PER_MINUTE", 20),
        max_messages=whole("MAX_MESSAGES", 40),
        max_message_chars=whole("MAX_MESSAGE_CHARS", 8000),
        max_context_chars=whole("MAX_CONTEXT_CHARS", 48000),
        max_output_tokens=whole("MAX_OUTPUT_TOKENS", 8192),
        request_timeout_seconds=decimal("REQUEST_TIMEOUT_SECONDS", 90.0),
        cors_origins=origins or ("*",),
        trust_proxy=flag("TRUST_PROXY"),
    )
