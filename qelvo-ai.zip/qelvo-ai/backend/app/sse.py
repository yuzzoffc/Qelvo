"""Server-Sent Events: menulis event ke klien dan membaca baris dari penyedia."""

from __future__ import annotations

import json
from typing import Any


def encode_event(payload: dict[str, Any]) -> str:
    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    return f"data: {body}\n\n"


def parse_data_line(line: str) -> str | None:
    """Isi `data:` dari satu baris SSE. Komentar dan baris kosong diabaikan."""
    if not line.startswith("data:"):
        return None
    data = line[5:].strip()
    return data or None
