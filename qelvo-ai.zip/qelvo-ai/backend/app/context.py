"""Merapikan riwayat chat dari klien sebelum dikirim ke penyedia AI."""

from __future__ import annotations

from collections.abc import Iterable
from typing import NamedTuple

from .errors import ApiError


class Turn(NamedTuple):
    role: str
    content: str


def prepare_turns(
    turns: Iterable[Turn],
    *,
    max_messages: int,
    max_message_chars: int,
    max_context_chars: int,
) -> list[Turn]:
    """Validasi dan rapikan riwayat.

    Pesan kosong dibuang, riwayat harus diawali dan diakhiri pesan pengguna,
    pesan beruntun dari peran yang sama digabung (beberapa penyedia menolak
    peran yang tidak bergantian), dan bagian terlama dipangkas bila terlalu
    panjang.
    """
    cleaned: list[Turn] = []
    for turn in turns:
        content = turn.content.strip()
        if not content:
            continue
        if len(content) > max_message_chars:
            raise ApiError(
                422,
                "message_too_long",
                f"Pesan terlalu panjang. Maksimal {max_message_chars} karakter per pesan.",
            )
        cleaned.append(Turn(turn.role, content))

    while cleaned and cleaned[0].role != "user":
        cleaned.pop(0)
    if not cleaned or cleaned[-1].role != "user":
        raise ApiError(422, "invalid_request", "Pesan terakhir harus dari pengguna.")

    merged: list[Turn] = []
    for turn in cleaned:
        if merged and merged[-1].role == turn.role:
            merged[-1] = Turn(turn.role, f"{merged[-1].content}\n\n{turn.content}")
        else:
            merged.append(turn)

    merged = merged[-max_messages:]
    total = sum(len(turn.content) for turn in merged)
    while len(merged) > 1 and total > max_context_chars:
        total -= len(merged.pop(0).content)
    while len(merged) > 1 and merged[0].role != "user":
        total -= len(merged.pop(0).content)
    return merged
