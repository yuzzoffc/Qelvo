"""Adapter untuk API gaya OpenAI (/chat/completions dengan SSE)."""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator, Sequence
from typing import Any

import httpx

from ..context import Turn
from ..errors import ProviderError
from ..sse import parse_data_line
from .base import ModelInfo, Provider
from .wire import UpstreamChunkError, error_message, extract_text

logger = logging.getLogger("qelvo.providers")


class OpenAICompatProvider(Provider):
    base_url = ""

    def __init__(
        self,
        *,
        api_key: str,
        models: Sequence[ModelInfo],
        client: httpx.AsyncClient,
    ) -> None:
        super().__init__(models)
        self._api_key = api_key
        self._client = client

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        }

    def _extra_payload(self, thinking: bool) -> dict[str, Any]:
        """Parameter khusus penyedia, misalnya tingkat berpikir."""
        return {}

    def _payload(
        self,
        turns: Sequence[Turn],
        model: ModelInfo,
        system: str,
        thinking: bool,
        max_output_tokens: int,
    ) -> dict[str, Any]:
        messages = [{"role": "system", "content": system}]
        messages.extend({"role": t.role, "content": t.content} for t in turns)
        payload: dict[str, Any] = {
            "model": model.id,
            "messages": messages,
            "stream": True,
            "max_tokens": max_output_tokens,
        }
        payload.update(self._extra_payload(thinking))
        return payload

    async def stream(
        self,
        turns: Sequence[Turn],
        model: ModelInfo,
        *,
        system: str,
        thinking: bool,
        max_output_tokens: int,
    ) -> AsyncIterator[str]:
        payload = self._payload(turns, model, system, thinking, max_output_tokens)
        url = f"{self.base_url}/chat/completions"
        produced = False

        try:
            for attempt in range(2):
                async with self._client.stream(
                    "POST", url, json=payload, headers=self._headers()
                ) as response:
                    if response.status_code != 200:
                        body = (await response.aread()).decode("utf-8", errors="replace")
                        detail = error_message(body)
                        logger.warning(
                            "%s membalas %s untuk model %s: %s",
                            self.id, response.status_code, model.id, detail,
                        )
                        # Parameter tingkat berpikir tidak dikenali model tertentu: coba sekali lagi tanpa itu.
                        if (
                            attempt == 0
                            and response.status_code == 400
                            and "reasoning_effort" in payload
                            and "reasoning" in detail.lower()
                        ):
                            payload = {k: v for k, v in payload.items() if k != "reasoning_effort"}
                            continue
                        raise self._http_error(response.status_code)

                    async for line in response.aiter_lines():
                        data = parse_data_line(line)
                        if data is None:
                            continue
                        if data == "[DONE]":
                            break
                        text = extract_text(data)
                        if text:
                            produced = True
                            yield text
                    break
        except UpstreamChunkError as error:
            logger.warning("%s mengirim error di tengah aliran: %s", self.id, error.message)
            raise ProviderError(
                502, "provider_error", "Penyedia AI berhenti di tengah jawaban. Coba lagi."
            ) from error
        except httpx.TimeoutException as error:
            raise ProviderError(
                504, "provider_timeout", "Penyedia AI terlalu lama merespons. Coba lagi."
            ) from error
        except httpx.HTTPError as error:
            raise ProviderError(
                502,
                "provider_unreachable",
                "Server tidak bisa menghubungi penyedia AI. Coba lagi sebentar lagi.",
            ) from error

        if not produced:
            raise ProviderError(
                502,
                "empty_response",
                "Penyedia AI tidak mengirim jawaban. Coba ulang atau pilih model lain.",
            )

    def _http_error(self, status: int) -> ProviderError:
        if status in (401, 403):
            return ProviderError(
                502, "provider_auth", "API key penyedia ditolak. Periksa konfigurasi di server."
            )
        if status == 402:
            return ProviderError(
                502,
                "provider_payment",
                "Kredit akun penyedia tidak cukup untuk model ini. Pilih model gratis.",
            )
        if status == 404:
            return ProviderError(
                502, "model_not_found", "Model tidak ditemukan di penyedia. Pilih model lain."
            )
        if status == 429:
            return ProviderError(
                429,
                "provider_rate_limited",
                "Kuota gratis penyedia sedang habis. Coba lagi nanti atau pilih model lain.",
            )
        if status == 400:
            return ProviderError(
                502, "provider_rejected", "Penyedia menolak permintaan ini. Coba ubah pertanyaannya."
            )
        if status >= 500:
            return ProviderError(
                502, "provider_unavailable", "Penyedia AI sedang bermasalah. Coba lagi sebentar lagi."
            )
        return ProviderError(502, "provider_error", f"Penyedia AI mengembalikan error ({status}).")
