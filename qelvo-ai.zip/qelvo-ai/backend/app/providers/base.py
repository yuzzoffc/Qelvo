"""Antarmuka penyedia AI. Satu penyedia = satu adapter kecil."""

from __future__ import annotations

import re
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator, Sequence
from dataclasses import dataclass

from ..context import Turn


@dataclass(frozen=True)
class ModelInfo:
    id: str
    label: str


def prettify_model_id(model_id: str) -> str:
    """Label cadangan dari ID model, dipakai kalau pengguna tidak menulis label."""
    name = model_id.split("/")[-1].split(":")[0].replace("_", "-")
    words = []
    for part in name.split("-"):
        if re.fullmatch(r"\d+(\.\d+)?b", part, re.IGNORECASE):
            words.append(part.upper())
        elif part[:1].isdigit():
            words.append(part)
        else:
            words.append(part.capitalize())
    return " ".join(words)


def parse_model_list(raw: str) -> list[ModelInfo]:
    """Membaca `id|Label,id2|Label2`. Label boleh dikosongkan; ID kembar dibuang."""
    models: list[ModelInfo] = []
    seen: set[str] = set()
    for chunk in raw.split(","):
        model_id, _, label = chunk.strip().partition("|")
        model_id = model_id.strip()
        if not model_id or model_id in seen:
            continue
        seen.add(model_id)
        models.append(ModelInfo(model_id, label.strip() or prettify_model_id(model_id)))
    return models


class Provider(ABC):
    id: str = ""
    name: str = ""
    tagline: str = ""

    def __init__(self, models: Sequence[ModelInfo]) -> None:
        if not models:
            raise ValueError("Penyedia membutuhkan minimal satu model.")
        self.models: tuple[ModelInfo, ...] = tuple(models)

    @property
    def default_model(self) -> ModelInfo:
        return self.models[0]

    def find_model(self, model_id: str | None) -> ModelInfo | None:
        """Model bawaan kalau `model_id` kosong, None kalau tidak ada di daftar."""
        if not model_id:
            return self.default_model
        return next((m for m in self.models if m.id == model_id), None)

    @abstractmethod
    def stream(
        self,
        turns: Sequence[Turn],
        model: ModelInfo,
        *,
        system: str,
        thinking: bool,
        max_output_tokens: int,
    ) -> AsyncIterator[str]:
        """Mengalirkan potongan teks jawaban. Melempar ProviderError bila gagal."""
