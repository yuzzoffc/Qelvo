from __future__ import annotations

from typing import TYPE_CHECKING

from ..config import Settings
from .base import ModelInfo, Provider, parse_model_list

if TYPE_CHECKING:
    import httpx

__all__ = ["ModelInfo", "Provider", "build_providers", "default_provider_id"]


def build_providers(settings: Settings, client: "httpx.AsyncClient") -> dict[str, Provider]:
    """Hanya penyedia yang punya API key yang dibuat."""
    from .gemini import GeminiProvider
    from .openrouter import OpenRouterProvider

    providers: dict[str, Provider] = {}

    gemini_models = parse_model_list(settings.gemini_models)
    if settings.gemini_api_key and gemini_models:
        providers["gemini"] = GeminiProvider(
            api_key=settings.gemini_api_key,
            models=gemini_models,
            client=client,
            effort_thinking=settings.gemini_effort_thinking,
            effort_fast=settings.gemini_effort_fast,
        )

    openrouter_models = parse_model_list(settings.openrouter_models)
    if settings.openrouter_api_key and openrouter_models:
        providers["openrouter"] = OpenRouterProvider(
            api_key=settings.openrouter_api_key,
            models=openrouter_models,
            client=client,
        )
    return providers


def default_provider_id(providers: dict[str, Provider], preferred: str) -> str:
    if preferred in providers:
        return preferred
    return next(iter(providers), "")
