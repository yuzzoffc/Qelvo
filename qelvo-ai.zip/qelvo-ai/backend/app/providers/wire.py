"""Membaca respons gaya OpenAI (dipakai Gemini dan OpenRouter). Tanpa dependensi jaringan."""

from __future__ import annotations

import json
from typing import Any


class UpstreamChunkError(Exception):
    """Penyedia mengirim error di tengah aliran."""

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message


def extract_text(data: str) -> str:
    """Teks dari satu potongan `data:`; kosong kalau potongan tidak membawa teks."""
    try:
        chunk = json.loads(data)
    except json.JSONDecodeError:
        return ""
    if not isinstance(chunk, dict):
        return ""

    error = chunk.get("error")
    if error:
        message = error.get("message") if isinstance(error, dict) else error
        raise UpstreamChunkError(str(message or "error dari penyedia"))

    pieces: list[str] = []
    for choice in chunk.get("choices") or []:
        if not isinstance(choice, dict):
            continue
        delta = choice.get("delta")
        content = delta.get("content") if isinstance(delta, dict) else None
        if isinstance(content, str):
            pieces.append(content)
        elif isinstance(content, list):
            pieces.extend(
                part["text"]
                for part in content
                if isinstance(part, dict) and isinstance(part.get("text"), str)
            )
    return "".join(pieces)


def error_message(body: str) -> str:
    """Pesan error dari badan respons non-200. Hanya untuk log server."""
    try:
        parsed: Any = json.loads(body)
    except json.JSONDecodeError:
        return body[:300]
    if isinstance(parsed, list) and parsed:
        parsed = parsed[0]
    if isinstance(parsed, dict):
        error = parsed.get("error")
        if isinstance(error, dict) and error.get("message"):
            return str(error["message"])[:300]
        if isinstance(error, str):
            return error[:300]
    return body[:300]
