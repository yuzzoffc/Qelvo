"""OpenRouter: satu API untuk banyak model, termasuk varian gratis."""

from __future__ import annotations

from .openai_compat import OpenAICompatProvider


class OpenRouterProvider(OpenAICompatProvider):
    id = "openrouter"
    name = "OpenRouter"
    tagline = "Satu API, banyak model · ada varian gratis"
    base_url = "https://openrouter.ai/api/v1"

    def _headers(self) -> dict[str, str]:
        headers = super()._headers()
        headers["X-Title"] = "QELVO"
        return headers
