"""Gemini lewat endpoint kompatibel OpenAI milik Google AI Studio."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

import httpx

from .base import ModelInfo
from .openai_compat import OpenAICompatProvider


class GeminiProvider(OpenAICompatProvider):
    id = "gemini"
    name = "Gemini"
    tagline = "Google AI Studio · ada kuota gratis"
    base_url = "https://generativelanguage.googleapis.com/v1beta/openai"

    def __init__(
        self,
        *,
        api_key: str,
        models: Sequence[ModelInfo],
        client: httpx.AsyncClient,
        effort_thinking: str = "medium",
        effort_fast: str = "low",
    ) -> None:
        super().__init__(api_key=api_key, models=models, client=client)
        self._effort_thinking = effort_thinking
        self._effort_fast = effort_fast

    def _extra_payload(self, thinking: bool) -> dict[str, Any]:
        effort = self._effort_thinking if thinking else self._effort_fast
        return {"reasoning_effort": effort} if effort else {}
