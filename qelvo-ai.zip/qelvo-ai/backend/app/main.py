"""Aplikasi FastAPI QELVO: chat streaming, katalog penyedia, dan login kode email."""

import logging
import math
import secrets
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

import httpx
from fastapi import Depends, FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse

from . import __version__
from .accounts import Accounts, FirebaseAccounts
from .auth import (
    AuthenticatedUser,
    FirebaseVerifier,
    OpenVerifier,
    TokenVerifier,
    init_firebase_app,
)
from .config import Settings, load_settings
from .context import Turn, prepare_turns
from .emailcode import EmailCodeService, FirestoreCodeStore, MemoryCodeStore
from .errors import ApiError
from .mailer import build_mailer
from .prompts import build_system_prompt
from .providers import Provider, build_providers, default_provider_id
from .ratelimit import SlidingWindowLimiter, client_ip
from .schemas import ChatRequest, EmailStartRequest, EmailVerifyRequest
from .sse import encode_event

logger = logging.getLogger("qelvo")


def _build_email_service(settings: Settings, firebase_app: Any) -> EmailCodeService:
    pepper = settings.code_pepper
    if not pepper:
        pepper = secrets.token_hex(32)
        logger.warning("CODE_PEPPER kosong: kode yang sudah dikirim jadi tidak valid setelah server restart.")
    if settings.email_code_store == "memory":
        store: Any = MemoryCodeStore()
    else:
        store = FirestoreCodeStore(firebase_app)
    return EmailCodeService(
        store,
        build_mailer(settings),
        pepper=pepper,
        ttl_seconds=settings.email_code_ttl_seconds,
        max_attempts=settings.email_code_max_attempts,
        resend_seconds=settings.email_code_resend_seconds,
        hourly_limit=settings.email_code_hourly_limit,
    )


def _wire_auth(
    settings: Settings,
    verifier: TokenVerifier | None,
    email_service: EmailCodeService | None,
    accounts: Accounts | None,
) -> tuple[TokenVerifier, EmailCodeService | None, Accounts | None]:
    if verifier is not None:
        return verifier, email_service, accounts
    if settings.auth_mode == "off":
        logger.warning("AUTH_MODE=off: chat bisa dipakai tanpa login. Hanya untuk uji lokal.")
        return OpenVerifier(), email_service, accounts
    if settings.auth_mode != "firebase":
        raise RuntimeError("AUTH_MODE harus 'firebase' atau 'off'.")

    firebase_app = init_firebase_app(
        settings.firebase_credentials_json,
        settings.google_application_credentials,
        settings.firebase_project_id,
    )
    return (
        FirebaseVerifier(firebase_app),
        _build_email_service(settings, firebase_app),
        FirebaseAccounts(firebase_app),
    )


async def current_user(request: Request) -> AuthenticatedUser:
    header = request.headers.get("authorization", "")
    scheme, _, token = header.partition(" ")
    bearer = token.strip() if scheme.lower() == "bearer" else None
    return await request.app.state.verifier.verify(bearer)


async def limited_user(
    request: Request, user: AuthenticatedUser = Depends(current_user)
) -> AuthenticatedUser:
    wait = request.app.state.chat_limiter.check(user.uid)
    if wait:
        seconds = math.ceil(wait)
        raise ApiError(
            429,
            "rate_limited",
            f"Terlalu banyak permintaan. Coba lagi dalam {seconds} detik.",
            headers={"Retry-After": str(seconds)},
        )
    return user


def _limit_by_ip(request: Request, limiter: SlidingWindowLimiter) -> None:
    settings: Settings = request.app.state.settings
    peer = request.client.host if request.client else None
    wait = limiter.check(client_ip(request.headers, peer, settings.trust_proxy))
    if wait:
        seconds = math.ceil(wait)
        raise ApiError(
            429,
            "rate_limited",
            f"Terlalu banyak permintaan dari jaringan ini. Coba lagi dalam {seconds} detik.",
            headers={"Retry-After": str(seconds)},
        )


def _email_parts(request: Request) -> tuple[EmailCodeService, Accounts]:
    service = request.app.state.email_service
    accounts = request.app.state.accounts
    if service is None or accounts is None:
        raise ApiError(503, "email_disabled", "Login email belum diaktifkan di server.")
    return service, accounts


async def _event_stream(
    meta: dict[str, str], first: str, iterator: AsyncIterator[str]
) -> AsyncIterator[str]:
    try:
        yield encode_event({"meta": meta})
        yield encode_event({"delta": first})
        async for piece in iterator:
            yield encode_event({"delta": piece})
        yield encode_event({"done": True})
    except ApiError as error:
        yield encode_event({"error": {"code": error.code, "message": error.message}})
    finally:
        aclose = getattr(iterator, "aclose", None)
        if aclose is not None:
            await aclose()


def create_app(
    settings: Settings | None = None,
    *,
    providers: dict[str, Provider] | None = None,
    verifier: TokenVerifier | None = None,
    email_service: EmailCodeService | None = None,
    accounts: Accounts | None = None,
) -> FastAPI:
    """Parameter selain `settings` dipakai tes untuk mengganti dependensi."""
    settings = settings or load_settings()

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        client = httpx.AsyncClient(
            timeout=httpx.Timeout(settings.request_timeout_seconds, connect=10.0)
        )
        try:
            app.state.providers = (
                providers if providers is not None else build_providers(settings, client)
            )
            wired = _wire_auth(settings, verifier, email_service, accounts)
            app.state.verifier, app.state.email_service, app.state.accounts = wired
            if not app.state.providers:
                logger.warning("Belum ada API key penyedia AI. Isi GEMINI_API_KEY atau OPENROUTER_API_KEY.")
            yield
        finally:
            await client.aclose()

    app = FastAPI(title="QELVO API", version=__version__, lifespan=lifespan)
    app.state.settings = settings
    app.state.chat_limiter = SlidingWindowLimiter(settings.rate_limit_per_minute, 60.0)
    app.state.email_start_limiter = SlidingWindowLimiter(10, 600.0)
    app.state.email_verify_limiter = SlidingWindowLimiter(30, 600.0)

    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(settings.cors_origins),
        allow_methods=["GET", "POST"],
        allow_headers=["Authorization", "Content-Type"],
    )

    @app.exception_handler(ApiError)
    async def handle_api_error(_: Request, error: ApiError) -> JSONResponse:
        return JSONResponse(
            status_code=error.status,
            content={"error": {"code": error.code, "message": error.message}},
            headers=error.headers,
        )

    @app.exception_handler(RequestValidationError)
    async def handle_validation(_: Request, error: RequestValidationError) -> JSONResponse:
        return JSONResponse(
            status_code=422,
            content={
                "error": {
                    "code": "invalid_request",
                    "message": "Permintaan tidak valid. Periksa isi pesan.",
                }
            },
        )

    @app.get("/health")
    async def health(request: Request) -> dict[str, Any]:
        return {
            "status": "ok",
            "version": __version__,
            "providers": list(request.app.state.providers),
        }

    @app.get("/v1/providers")
    async def list_providers(
        request: Request, _: AuthenticatedUser = Depends(current_user)
    ) -> dict[str, Any]:
        available: dict[str, Provider] = request.app.state.providers
        return {
            "default_provider": default_provider_id(available, settings.default_provider),
            "providers": [
                {
                    "id": p.id,
                    "name": p.name,
                    "tagline": p.tagline,
                    "default_model": p.default_model.id,
                    "models": [{"id": m.id, "label": m.label} for m in p.models],
                }
                for p in available.values()
            ],
        }

    @app.post("/v1/chat")
    async def chat(
        body: ChatRequest,
        request: Request,
        user: AuthenticatedUser = Depends(limited_user),
    ) -> Any:
        available: dict[str, Provider] = request.app.state.providers
        if not available:
            raise ApiError(
                503,
                "no_provider",
                "Server belum punya penyedia AI. Isi GEMINI_API_KEY atau OPENROUTER_API_KEY.",
            )
        provider = available.get(body.provider or default_provider_id(available, settings.default_provider))
        if provider is None:
            raise ApiError(400, "unknown_provider", "Penyedia tidak tersedia di server ini.")
        model = provider.find_model(body.model)
        if model is None:
            raise ApiError(400, "unknown_model", "Model tidak tersedia untuk penyedia ini.")

        turns = prepare_turns(
            [Turn(m.role, m.content) for m in body.messages],
            max_messages=settings.max_messages,
            max_message_chars=settings.max_message_chars,
            max_context_chars=settings.max_context_chars,
        )
        source = provider.stream(
            turns,
            model,
            system=build_system_prompt(provider.name, model.label, body.instruction),
            thinking=body.thinking,
            max_output_tokens=settings.max_output_tokens,
        )
        meta = {
            "provider": provider.id,
            "provider_name": provider.name,
            "model": model.id,
            "model_label": model.label,
        }

        if not body.stream:
            text = "".join([piece async for piece in source])
            return {**meta, "content": text}

        # Potongan pertama diambil dulu: kalau penyedia langsung menolak
        # (kuota, key), klien menerima status HTTP yang tepat, bukan 200.
        iterator = source.__aiter__()
        try:
            first = await iterator.__anext__()
        except StopAsyncIteration:
            raise ApiError(502, "empty_response", "Penyedia AI tidak mengirim jawaban.") from None
        return StreamingResponse(
            _event_stream(meta, first, iterator),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )

    @app.post("/v1/auth/email/start")
    async def email_start(body: EmailStartRequest, request: Request) -> dict[str, Any]:
        service, _ = _email_parts(request)
        _limit_by_ip(request, request.app.state.email_start_limiter)
        return await service.start(body.email)

    @app.post("/v1/auth/email/verify")
    async def email_verify(body: EmailVerifyRequest, request: Request) -> dict[str, str]:
        service, account_service = _email_parts(request)
        _limit_by_ip(request, request.app.state.email_verify_limiter)
        email = await service.verify(body.email, body.code)
        return {"custom_token": await account_service.custom_token_for_email(email)}

    return app


app = create_app()
