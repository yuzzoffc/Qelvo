"""Kode verifikasi email 6 digit: dibuat, dikirim, dicek, lalu dihapus."""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import math
import re
import secrets
import time
from collections.abc import Callable
from dataclasses import asdict, dataclass
from typing import Any, Protocol

from .errors import ApiError
from .mailer import MailError, MailNotConfigured, Mailer

EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
HOUR = 3600.0


def normalize_email(raw: str) -> str:
    email = raw.strip().lower()
    if len(email) > 254 or not EMAIL_PATTERN.match(email):
        raise ApiError(400, "invalid_email", "Alamat email tidak valid.")
    return email


@dataclass
class CodeRecord:
    code_hash: str
    expires_at: float
    attempts: int
    sent_at: float
    window_start: float
    sent_in_window: int


class CodeStore(Protocol):
    async def get(self, key: str) -> CodeRecord | None: ...
    async def put(self, key: str, record: CodeRecord) -> None: ...
    async def delete(self, key: str) -> None: ...


class MemoryCodeStore:
    """Cukup untuk satu proses. Data hilang saat server restart."""

    def __init__(self, clock: Callable[[], float] = time.time) -> None:
        self._items: dict[str, CodeRecord] = {}
        self._clock = clock

    async def get(self, key: str) -> CodeRecord | None:
        return self._items.get(key)

    async def put(self, key: str, record: CodeRecord) -> None:
        self._items[key] = record
        if len(self._items) > 2048:
            now = self._clock()
            for old in [k for k, r in self._items.items() if now - r.window_start > HOUR]:
                del self._items[old]

    async def delete(self, key: str) -> None:
        self._items.pop(key, None)


class FirestoreCodeStore:
    """Menyimpan hash kode di koleksi `email_codes` lewat Admin SDK."""

    def __init__(self, firebase_app: Any, collection: str = "email_codes") -> None:
        from firebase_admin import firestore

        self._db = firestore.client(firebase_app)
        self._collection = collection

    def _doc(self, key: str) -> Any:
        return self._db.collection(self._collection).document(key)

    async def get(self, key: str) -> CodeRecord | None:
        snapshot = await asyncio.to_thread(self._doc(key).get)
        if not snapshot.exists:
            return None
        data = snapshot.to_dict() or {}
        try:
            return CodeRecord(
                code_hash=str(data["code_hash"]),
                expires_at=float(data["expires_at"]),
                attempts=int(data["attempts"]),
                sent_at=float(data["sent_at"]),
                window_start=float(data["window_start"]),
                sent_in_window=int(data["sent_in_window"]),
            )
        except (KeyError, TypeError, ValueError):
            return None

    async def put(self, key: str, record: CodeRecord) -> None:
        await asyncio.to_thread(self._doc(key).set, asdict(record))

    async def delete(self, key: str) -> None:
        await asyncio.to_thread(self._doc(key).delete)


class EmailCodeService:
    def __init__(
        self,
        store: CodeStore,
        mailer: Mailer,
        *,
        pepper: str,
        ttl_seconds: int = 600,
        max_attempts: int = 5,
        resend_seconds: int = 60,
        hourly_limit: int = 5,
        clock: Callable[[], float] = time.time,
        code_factory: Callable[[], str] | None = None,
    ) -> None:
        self._store = store
        self._mailer = mailer
        self._pepper = pepper.encode("utf-8")
        self._ttl = ttl_seconds
        self._max_attempts = max_attempts
        self._resend = resend_seconds
        self._hourly_limit = hourly_limit
        self._clock = clock
        self._code_factory = code_factory or (lambda: f"{secrets.randbelow(10**6):06d}")

    @staticmethod
    def _key(email: str) -> str:
        return hashlib.sha256(email.encode("utf-8")).hexdigest()

    def _hash(self, email: str, code: str) -> str:
        return hmac.new(self._pepper, f"{email}:{code}".encode("utf-8"), hashlib.sha256).hexdigest()

    async def start(self, raw_email: str) -> dict[str, Any]:
        email = normalize_email(raw_email)
        now = self._clock()
        key = self._key(email)
        previous = await self._store.get(key)

        window_start, sent = now, 0
        if previous is not None:
            since_last = now - previous.sent_at
            if since_last < self._resend:
                wait = math.ceil(self._resend - since_last)
                raise ApiError(
                    429,
                    "resend_too_soon",
                    f"Tunggu {wait} detik sebelum meminta kode lagi.",
                    headers={"Retry-After": str(wait)},
                )
            if now - previous.window_start < HOUR:
                window_start, sent = previous.window_start, previous.sent_in_window
        if sent >= self._hourly_limit:
            raise ApiError(
                429,
                "too_many_codes",
                "Terlalu banyak permintaan kode untuk email ini. Coba lagi dalam satu jam.",
            )

        code = self._code_factory()
        await self._store.put(
            key,
            CodeRecord(
                code_hash=self._hash(email, code),
                expires_at=now + self._ttl,
                attempts=0,
                sent_at=now,
                window_start=window_start,
                sent_in_window=sent + 1,
            ),
        )
        try:
            await self._mailer.send_code(email, code, max(self._ttl // 60, 1))
        except MailNotConfigured as error:
            await self._restore(key, previous)
            raise ApiError(
                503, "email_not_configured", "Pengiriman email belum diatur di server."
            ) from error
        except MailError as error:
            await self._restore(key, previous)
            raise ApiError(
                502, "email_failed", "Email gagal terkirim. Coba lagi beberapa saat lagi."
            ) from error
        return {"ok": True, "expires_in": self._ttl, "resend_in": self._resend}

    async def verify(self, raw_email: str, code: str) -> str:
        """Mengembalikan email ternormalisasi kalau kode benar. Kode hanya berlaku sekali."""
        email = normalize_email(raw_email)
        now = self._clock()
        key = self._key(email)
        record = await self._store.get(key)

        if record is None or now >= record.expires_at:
            if record is not None:
                await self._store.delete(key)
            raise ApiError(
                400,
                "code_expired",
                "Kode sudah kedaluwarsa atau belum diminta. Minta kode baru.",
            )

        if not hmac.compare_digest(record.code_hash, self._hash(email, code)):
            record.attempts += 1
            left = self._max_attempts - record.attempts
            if left <= 0:
                await self._store.delete(key)
                raise ApiError(
                    429, "too_many_attempts", "Terlalu banyak percobaan. Minta kode baru."
                )
            await self._store.put(key, record)
            raise ApiError(400, "code_invalid", f"Kode salah. Sisa percobaan: {left}.")

        await self._store.delete(key)
        return email

    async def _restore(self, key: str, previous: CodeRecord | None) -> None:
        if previous is None:
            await self._store.delete(key)
        else:
            await self._store.put(key, previous)
