"""Membuat custom token Firebase setelah kode email terbukti benar."""

from __future__ import annotations

import asyncio
from typing import Any, Protocol

from .errors import ApiError


class Accounts(Protocol):
    async def custom_token_for_email(self, email: str) -> str: ...


class FirebaseAccounts:
    def __init__(self, app: Any) -> None:
        self._app = app

    async def custom_token_for_email(self, email: str) -> str:
        return await asyncio.to_thread(self._sync, email)

    def _sync(self, email: str) -> str:
        from firebase_admin import auth

        try:
            user = auth.get_user_by_email(email, app=self._app)
            if user.disabled:
                raise ApiError(403, "user_disabled", "Akun ini dinonaktifkan.")
            if not user.email_verified:
                auth.update_user(user.uid, email_verified=True, app=self._app)
        except auth.UserNotFoundError:
            user = auth.create_user(email=email, email_verified=True, app=self._app)

        token = auth.create_custom_token(user.uid, app=self._app)
        return token.decode("utf-8") if isinstance(token, bytes) else str(token)
