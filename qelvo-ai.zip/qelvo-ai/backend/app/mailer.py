"""Pengiriman email kode verifikasi lewat SMTP."""

from __future__ import annotations

import asyncio
import logging
import smtplib
import ssl
from email.message import EmailMessage
from email.utils import parseaddr
from typing import Protocol

from .config import Settings

logger = logging.getLogger("qelvo.mail")


class MailError(Exception):
    """Email gagal terkirim."""


class MailNotConfigured(MailError):
    """SMTP belum diisi di server."""


class Mailer(Protocol):
    async def send_code(self, recipient: str, code: str, minutes: int) -> None: ...


def build_code_message(sender: str, recipient: str, code: str, minutes: int) -> EmailMessage:
    message = EmailMessage()
    message["Subject"] = f"Kode masuk QELVO: {code}"
    message["From"] = sender
    message["To"] = recipient
    message.set_content(
        f"Kode masuk QELVO kamu: {code}\n\n"
        f"Kode berlaku {minutes} menit dan hanya bisa dipakai sekali.\n"
        "Jangan bagikan kode ini ke siapa pun. Jika kamu tidak meminta kode, abaikan email ini.\n"
    )
    message.add_alternative(
        "<div style=\"font-family:Arial,sans-serif;font-size:16px;color:#0b1320\">"
        "<p>Kode masuk QELVO kamu:</p>"
        f"<p style=\"font-size:32px;letter-spacing:8px;font-weight:700\">{code}</p>"
        f"<p>Kode berlaku {minutes} menit dan hanya bisa dipakai sekali.</p>"
        "<p style=\"color:#536278\">Jangan bagikan kode ini ke siapa pun. "
        "Jika kamu tidak meminta kode, abaikan email ini.</p></div>",
        subtype="html",
    )
    return message


class NoMailer:
    async def send_code(self, recipient: str, code: str, minutes: int) -> None:
        raise MailNotConfigured("SMTP belum dikonfigurasi")


class ConsoleMailer:
    """Hanya untuk uji lokal (DEV_PRINT_CODES=true): kode dicetak ke log server."""

    async def send_code(self, recipient: str, code: str, minutes: int) -> None:
        logger.warning("[DEV] Kode untuk %s: %s (berlaku %s menit)", recipient, code, minutes)


class SmtpMailer:
    def __init__(
        self,
        *,
        host: str,
        port: int,
        user: str,
        password: str,
        sender: str,
        security: str = "starttls",
        timeout: float = 20.0,
    ) -> None:
        self._host = host
        self._port = port
        self._user = user
        self._password = password
        self._sender = sender
        self._security = security
        self._timeout = timeout

    async def send_code(self, recipient: str, code: str, minutes: int) -> None:
        message = build_code_message(self._sender, recipient, code, minutes)
        await asyncio.to_thread(self._send, message)

    def _send(self, message: EmailMessage) -> None:
        try:
            if self._security == "ssl":
                with smtplib.SMTP_SSL(
                    self._host, self._port, timeout=self._timeout,
                    context=ssl.create_default_context(),
                ) as smtp:
                    self._deliver(smtp, message)
            else:
                with smtplib.SMTP(self._host, self._port, timeout=self._timeout) as smtp:
                    if self._security == "starttls":
                        smtp.starttls(context=ssl.create_default_context())
                    self._deliver(smtp, message)
        except (smtplib.SMTPException, OSError) as error:
            # Isi pesan (kode) tidak ikut dicatat.
            logger.error("Gagal mengirim email: %s", type(error).__name__)
            raise MailError(type(error).__name__) from error

    def _deliver(self, smtp: smtplib.SMTP, message: EmailMessage) -> None:
        if self._user:
            smtp.login(self._user, self._password)
        smtp.send_message(message, from_addr=parseaddr(self._sender)[1] or self._sender)


def build_mailer(settings: Settings) -> Mailer:
    if settings.smtp_host and settings.smtp_from:
        return SmtpMailer(
            host=settings.smtp_host,
            port=settings.smtp_port,
            user=settings.smtp_user,
            password=settings.smtp_password,
            sender=settings.smtp_from,
            security=settings.smtp_security,
        )
    if settings.dev_print_codes:
        logger.warning("DEV_PRINT_CODES aktif: kode verifikasi dicetak ke log. Jangan dipakai di produksi.")
        return ConsoleMailer()
    return NoMailer()
