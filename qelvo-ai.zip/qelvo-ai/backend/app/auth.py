"""Verifikasi token ID Firebase. Chat hanya bisa dipakai setelah login."""

from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import Mapping
from typing import Any, NamedTuple, Protocol

from .errors import ApiError

logger = logging.getLogger("qelvo.auth")


class AuthenticatedUser(NamedTuple):
    uid: str
    email: str
    is_guest: bool = False


def _is_guest(claims: Mapping[str, Any]) -> bool:
    firebase = claims.get("firebase")
    return isinstance(firebase, Mapping) and firebase.get("sign_in_provider") == "anonymous"


def check_claims(claims: Mapping[str, Any], *, allow_guest: bool = True) -> AuthenticatedUser:
    """Memastikan token punya uid, lalu email terverifikasi atau status tamu.

    Login Google selalu menghasilkan email terverifikasi, begitu juga login
    kode email (server menandainya saat membuat akun). Tamu (Firebase
    Anonymous) tidak punya email; mereka hanya diterima kalau `allow_guest`.
    """
    uid = claims.get("uid") or claims.get("user_id") or claims.get("sub")
    if not uid:
        raise ApiError(401, "invalid_token", "Sesi tidak valid. Masuk lagi.")
    if _is_guest(claims):
        if not allow_guest:
            raise ApiError(
                403, "guest_disabled", "Mode tamu sedang dimatikan. Masuk dengan Google."
            )
        return AuthenticatedUser(uid=str(uid), email="", is_guest=True)
    email = claims.get("email")
    if not email or not claims.get("email_verified"):
        raise ApiError(
            403,
            "email_not_verified",
            "Email akunmu belum terverifikasi. Masuk dengan Google atau kode email.",
        )
    return AuthenticatedUser(uid=str(uid), email=str(email))


class TokenVerifier(Protocol):
    async def verify(self, token: str | None) -> AuthenticatedUser: ...


class OpenVerifier:
    """AUTH_MODE=off: tanpa login. Hanya untuk uji lokal."""

    async def verify(self, token: str | None) -> AuthenticatedUser:
        return AuthenticatedUser(uid="dev-user", email="dev@localhost")


def init_firebase_app(credentials_json: str, credentials_path: str, project_id: str) -> Any:
    """Membuat aplikasi firebase_admin dari akun layanan."""
    import firebase_admin
    from firebase_admin import credentials

    if credentials_json:
        try:
            certificate = credentials.Certificate(json.loads(credentials_json, strict=False))
        except (ValueError, json.JSONDecodeError) as error:
            raise RuntimeError(
                "FIREBASE_CREDENTIALS_JSON bukan JSON akun layanan yang valid."
            ) from error
    elif credentials_path:
        certificate = credentials.Certificate(credentials_path)
    else:
        raise RuntimeError(
            "AUTH_MODE=firebase membutuhkan FIREBASE_CREDENTIALS_JSON atau "
            "GOOGLE_APPLICATION_CREDENTIALS. Lihat docs/SETUP.md."
        )
    options = {"projectId": project_id} if project_id else None
    return firebase_admin.initialize_app(certificate, options)


class FirebaseVerifier:
    def __init__(self, app: Any, *, allow_guest: bool = True) -> None:
        self._app = app
        self._allow_guest = allow_guest

    async def verify(self, token: str | None) -> AuthenticatedUser:
        if not token:
            raise ApiError(401, "unauthorized", "Masuk dulu untuk memakai QELVO.")
        claims = await asyncio.to_thread(self._verify_sync, token)
        return check_claims(claims, allow_guest=self._allow_guest)

    def _verify_sync(self, token: str) -> Mapping[str, Any]:
        from firebase_admin import auth

        fetch_error = getattr(auth, "CertificateFetchError", ())
        try:
            return auth.verify_id_token(token, app=self._app)
        except fetch_error as error:
            raise ApiError(
                503,
                "auth_unavailable",
                "Layanan login sedang tidak terjangkau. Coba lagi sebentar lagi.",
            ) from error
        except Exception as error:  # token rusak, kedaluwarsa, atau dicabut
            logger.info("Token ditolak: %s", type(error).__name__)
            raise ApiError(
                401, "invalid_token", "Sesi tidak valid atau sudah berakhir. Masuk lagi."
            ) from error
