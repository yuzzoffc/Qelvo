# Env lengkap

Konfigurasi QELVO ada di tiga tempat. Nilai rahasia hanya boleh disimpan di sana, bukan di kode atau di repo.

| Tempat | Berkas atau lokasi | Dipakai oleh |
| --- | --- | --- |
| 1. Backend | `backend/.env` (lokal) atau environment variable di hosting | server FastAPI |
| 2. Aplikasi | `app/env.json` (lokal) | `flutter run` |
| 3. GitHub | Variables dan Secrets di repo | workflow **Build APK** |

Ketiganya harus saling cocok. `QELVO_API_URL` di aplikasi menunjuk ke backend, dan backend memakai akun layanan dari proyek Firebase yang sama dengan nilai `FIREBASE_*` di aplikasi. Kalau berbeda proyek, login email gagal dengan pesan "proyek Firebase di aplikasi dan server tidak sama".

## 1. Backend

Paling sedikit supaya login dan chat jalan:

- satu key penyedia AI: `GEMINI_API_KEY` atau `OPENROUTER_API_KEY`
- `FIREBASE_CREDENTIALS_JSON` atau `GOOGLE_APPLICATION_CREDENTIALS`
- untuk login email (disembunyikan di aplikasi sampai `EMAIL_LOGIN=true`): `SMTP_HOST`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM`, dan `CODE_PEPPER`

Isi lengkapnya sama dengan `.env.example`. Salin ke `backend/.env` lalu isi:

```env
# ======================================================================
# QELVO AI, konfigurasi backend (lengkap)
#
# Lokal: salin file ini ke backend/.env lalu isi.
# Hosting: isi tiap baris sebagai environment variable di dashboard.
# JANGAN PERNAH mengunggah .env ke GitHub (sudah ada di .gitignore).
#
# Aturan format: satu baris satu nilai, tanpa komentar di belakang nilai.
# [WAJIB] harus diisi. [OPSIONAL] sudah punya nilai bawaan.
# ======================================================================


# ---------- 1. Penyedia AI ----------
# [WAJIB] Isi minimal salah satu: GEMINI_API_KEY atau OPENROUTER_API_KEY.

# Key dari aistudio.google.com/apikey
GEMINI_API_KEY=

# [OPSIONAL] Format id|Label, dipisah koma. Model pertama jadi bawaan.
# ID model sering berganti. Cek dokumentasi Gemini API untuk nama terbaru.
GEMINI_MODELS=gemini-3.5-flash-lite|Gemini 3.5 Flash-Lite,gemini-3.8-flash|Gemini 3.8 Flash,gemini-3.1-flash-lite|Gemini 3.1 Flash-Lite

# [OPSIONAL] Tingkat berpikir saat chip "Berpikir" menyala dan mati.
# Nilai: low, medium, atau high. Kosongkan untuk tidak mengirim parameternya.
GEMINI_EFFORT_THINKING=medium
GEMINI_EFFORT_FAST=low

# Key dari openrouter.ai (menu Keys)
OPENROUTER_API_KEY=

# [OPSIONAL] Model gratis di OpenRouter berubah-ubah. openrouter/free memilihkan otomatis.
OPENROUTER_MODELS=openrouter/free|OpenRouter Gratis (otomatis)

# [OPSIONAL] gemini atau openrouter. Kosong = penyedia pertama yang punya key.
DEFAULT_PROVIDER=


# ---------- 2. Login Firebase ----------
# firebase = wajib login (disarankan). off = tanpa login, HANYA untuk uji lokal.
AUTH_MODE=firebase

# [OPSIONAL] ID proyek Firebase. Biasanya sudah terbaca dari akun layanan.
FIREBASE_PROJECT_ID=

# [OPSIONAL] true = izinkan masuk sebagai tamu (Firebase Anonymous). Matikan kalau ada penyalahgunaan.
ALLOW_GUEST=true
# [OPSIONAL] Batas chat per menit untuk tamu, dihitung per alamat IP karena akun tamu mudah dibuat ulang. 0 = tanpa batas.
GUEST_RATE_LIMIT_PER_MINUTE=10

# [WAJIB bila AUTH_MODE=firebase] Isi salah satu dari dua baris berikut.
# a) Isi JSON akun layanan (Firebase Console > Project settings > Service accounts >
#    Generate new private key). Di berkas .env harus satu baris (jq -c . akun.json).
#    Di dashboard hosting boleh ditempel apa adanya.
FIREBASE_CREDENTIALS_JSON=
# b) Jalur ke berkas JSON itu di server, misalnya dari fitur "secret file" hosting.
GOOGLE_APPLICATION_CREDENTIALS=


# ---------- 3. Kode verifikasi email ----------
# [WAJIB agar login email jalan] Server SMTP.
# Brevo: smtp-relay.brevo.com, port 587. Gmail: smtp.gmail.com, port 587 dengan app password.
SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=
# Format: Nama <alamat>. Alamatnya harus sudah diverifikasi di penyedia SMTP.
SMTP_FROM=QELVO <alamat-pengirim@contoh.com>
# starttls (port 587), ssl (port 465), atau none.
SMTP_SECURITY=starttls

# [DISARANKAN] Teks acak panjang untuk meng-hash kode, misalnya hasil `openssl rand -hex 32`.
# Kalau kosong, server membuat yang baru tiap start, dan kode yang belum dipakai jadi tidak berlaku.
CODE_PEPPER=

# [OPSIONAL] firestore (tahan restart, disarankan) atau memory (satu proses, hilang saat restart).
EMAIL_CODE_STORE=firestore
EMAIL_CODE_TTL_SECONDS=600
EMAIL_CODE_MAX_ATTEMPTS=5
EMAIL_CODE_RESEND_SECONDS=60
EMAIL_CODE_HOURLY_LIMIT=5

# [OPSIONAL] Hanya uji lokal: cetak kode ke log server bila SMTP kosong. Jangan dipakai di produksi.
DEV_PRINT_CODES=false


# ---------- 4. Batas pemakaian dan server ----------
RATE_LIMIT_PER_MINUTE=20
MAX_MESSAGES=40
MAX_MESSAGE_CHARS=8000
MAX_CONTEXT_CHARS=48000
MAX_OUTPUT_TOKENS=8192
REQUEST_TIMEOUT_SECONDS=90
# Asal yang boleh memanggil API dari browser, dipisah koma. Aplikasi Android tidak membutuhkannya.
CORS_ORIGINS=*
# true bila server di belakang proxy tepercaya (Render, Fly, dan sejenisnya), agar IP klien dibaca dari X-Forwarded-For.
TRUST_PROXY=false
# Diisi otomatis oleh sebagian hosting dan dibaca oleh Dockerfile, bukan oleh kode Python.
# PORT=8000
```

### Penjelasan variabel

| Variabel | Wajib | Bawaan | Keterangan |
| --- | --- | --- | --- |
| `GEMINI_API_KEY` | salah satu key AI | kosong | Penyedia Gemini hanya aktif kalau key ini ada |
| `GEMINI_MODELS` | tidak | tiga model Gemini 3.x | `id\|Label` dipisah koma, model pertama jadi bawaan |
| `GEMINI_EFFORT_THINKING` | tidak | `medium` | Tingkat berpikir saat chip Berpikir menyala. Kosong = tidak dikirim |
| `GEMINI_EFFORT_FAST` | tidak | `low` | Saat chip Berpikir mati |
| `OPENROUTER_API_KEY` | salah satu key AI | kosong | Penyedia OpenRouter hanya aktif kalau key ini ada |
| `OPENROUTER_MODELS` | tidak | `openrouter/free` | Format sama dengan `GEMINI_MODELS` |
| `DEFAULT_PROVIDER` | tidak | kosong | `gemini` atau `openrouter`. Kosong = penyedia pertama yang punya key |
| `AUTH_MODE` | tidak | `firebase` | `off` mematikan login, hanya untuk uji lokal |
| `FIREBASE_PROJECT_ID` | tidak | kosong | Biasanya sudah terbaca dari akun layanan |
| `ALLOW_GUEST` | tidak | `true` | Izinkan masuk sebagai tamu. `false` menolak token tamu dengan kode `guest_disabled` |
| `GUEST_RATE_LIMIT_PER_MINUTE` | tidak | `10` | Permintaan chat per menit untuk tamu, dihitung per IP. `0` = tanpa batas |
| `FIREBASE_CREDENTIALS_JSON` | ya, bila `firebase` | kosong | Isi JSON akun layanan |
| `GOOGLE_APPLICATION_CREDENTIALS` | alternatif | kosong | Jalur ke berkas JSON akun layanan di server |
| `SMTP_HOST` | untuk login email | kosong | Server SMTP |
| `SMTP_PORT` | tidak | `587` | 587 untuk starttls, 465 untuk ssl |
| `SMTP_USER` | sesuai penyedia | kosong | Nama pengguna SMTP |
| `SMTP_PASSWORD` | sesuai penyedia | kosong | Kata sandi SMTP atau app password |
| `SMTP_FROM` | untuk login email | kosong | `Nama <alamat>`, alamat harus terverifikasi |
| `SMTP_SECURITY` | tidak | `starttls` | `starttls`, `ssl`, atau `none` |
| `CODE_PEPPER` | disarankan | acak tiap start | Rahasia untuk meng-hash kode email |
| `EMAIL_CODE_STORE` | tidak | `firestore` | `memory` hanya untuk satu proses |
| `EMAIL_CODE_TTL_SECONDS` | tidak | `600` | Masa berlaku kode |
| `EMAIL_CODE_MAX_ATTEMPTS` | tidak | `5` | Batas salah ketik per kode |
| `EMAIL_CODE_RESEND_SECONDS` | tidak | `60` | Jeda sebelum kode boleh diminta lagi |
| `EMAIL_CODE_HOURLY_LIMIT` | tidak | `5` | Maksimal kode per jam per email |
| `DEV_PRINT_CODES` | tidak | `false` | Cetak kode ke log bila SMTP kosong. Hanya uji lokal |
| `RATE_LIMIT_PER_MINUTE` | tidak | `20` | Permintaan chat per pengguna per menit. `0` = tanpa batas |
| `MAX_MESSAGES` | tidak | `40` | Pesan terakhir yang diteruskan ke model |
| `MAX_MESSAGE_CHARS` | tidak | `8000` | Panjang maksimal satu pesan |
| `MAX_CONTEXT_CHARS` | tidak | `48000` | Panjang maksimal seluruh riwayat yang dikirim |
| `MAX_OUTPUT_TOKENS` | tidak | `8192` | Batas panjang jawaban, termasuk token berpikir |
| `REQUEST_TIMEOUT_SECONDS` | tidak | `90` | Batas tunggu respons penyedia |
| `CORS_ORIGINS` | tidak | `*` | Hanya penting untuk klien web |
| `TRUST_PROXY` | tidak | `false` | `true` bila di belakang proxy tepercaya |
| `PORT` | diisi hosting | `8000` | Dibaca Dockerfile, bukan kode Python |

Variabel di dashboard hosting berlaku sebagai environment variable asli dan mengalahkan isi `.env`.

## 2. Aplikasi (`app/env.json`)

Salin dari `app/env.example.json`, isi, lalu jalankan `flutter run --dart-define-from-file=env.json`. Berkas `env.json` sudah masuk `.gitignore`.

```json
{
  "QELVO_API_URL": "https://alamat-backend-kamu.contoh.id",
  "FIREBASE_API_KEY": "AIzaSy...isi-dari-google-services.json",
  "FIREBASE_APP_ID": "1:123456789012:android:0123456789abcdef",
  "FIREBASE_PROJECT_ID": "nama-proyek-firebase",
  "FIREBASE_SENDER_ID": "123456789012",
  "FIREBASE_STORAGE_BUCKET": "",
  "EMAIL_LOGIN": "false"
}
```

`EMAIL_LOGIN` bersifat opsional. Bawaannya mati, jadi layar masuk hanya memuat Google dan tamu. Isi `"true"` untuk menampilkan login email dengan kode (server harus punya SMTP, lihat bagian 1).

Empat nilai Firebase diambil dari `google-services.json` (Firebase Console, Project settings, aplikasi Android):

| Variabel | Letak di `google-services.json` |
| --- | --- |
| `FIREBASE_API_KEY` | `client[0].api_key[0].current_key` |
| `FIREBASE_APP_ID` | `client[0].client_info.mobilesdk_app_id` |
| `FIREBASE_PROJECT_ID` | `project_info.project_id` |
| `FIREBASE_SENDER_ID` | `project_info.project_number` |
| `FIREBASE_STORAGE_BUCKET` (opsional) | `project_info.storage_bucket` |

`QELVO_API_URL` yang kosong berarti `http://10.0.2.2:8000`, alamat komputer dari dalam emulator Android.

## 3. GitHub Variables dan Secrets

Workflow **Build APK** membaca nilai-nilai ini. Tiap Variable boleh juga disimpan sebagai Secret dengan nama yang sama.

| Nama | Jenis | Wajib | Isi |
| --- | --- | --- | --- |
| `QELVO_API_URL` | Variable | ya | Alamat backend, misalnya `https://qelvo-api.contoh.id` |
| `FIREBASE_API_KEY` | Variable | ya | Lihat tabel di bagian 2 |
| `FIREBASE_APP_ID` | Variable | ya | Lihat tabel di bagian 2 |
| `FIREBASE_PROJECT_ID` | Variable | ya | Lihat tabel di bagian 2 |
| `FIREBASE_SENDER_ID` | Variable | ya | Lihat tabel di bagian 2 |
| `FIREBASE_STORAGE_BUCKET` | Variable | tidak | Boleh kosong |
| `EMAIL_LOGIN` | Variable | tidak | `true` menampilkan login email. Kosong = mati |
| `DEBUG_KEYSTORE_BASE64` | **Secret** | disarankan | Teks base64 dari workflow **Buat keystore debug** |

Cara mengisi dari HP, lewat situs github.com di browser:

1. Buka repo, **Settings**, **Secrets and variables**, **Actions**.
2. Tab **Variables**, **New repository variable**, isi nama dan nilai, simpan. Ulangi untuk tiap variabel.
3. Tab **Secrets**, **New repository secret** untuk `DEBUG_KEYSTORE_BASE64`.

Workflow memeriksa nilai-nilai wajib di awal dan berhenti dengan pesan yang menyebut nama variabel yang kosong atau berbentuk salah.

## 4. Contoh bentuk yang benar

Ini nilai palsu, hanya untuk memeriksa bentuk:

| Variabel | Contoh bentuk |
| --- | --- |
| `FIREBASE_API_KEY` | `AIzaSyA1b2C3d4E5f6G7h8I9j0K1l2M3n4O5p6Q` (diawali `AIza`) |
| `FIREBASE_APP_ID` | `1:123456789012:android:0123456789abcdef` (memuat `:android:`) |
| `FIREBASE_PROJECT_ID` | `qelvo-ai-1a2b3` |
| `FIREBASE_SENDER_ID` | `123456789012` (angka saja) |
| `QELVO_API_URL` | `https://qelvo-api.contoh.id` (tanpa garis miring di akhir) |
| `SMTP_FROM` | `QELVO <no-reply@contoh.id>` |
| `GEMINI_MODELS` | `gemini-3.5-flash-lite\|Gemini 3.5 Flash-Lite,gemini-3.8-flash\|Gemini 3.8 Flash` |

## 5. Membuat nilai acak dan JSON satu baris

- `CODE_PEPPER`: jalankan `openssl rand -hex 32` (Linux, macOS, Codespaces, Termux). Atau pakai pembuat kata sandi dengan panjang 64 karakter.
- JSON akun layanan satu baris untuk berkas `.env`: `jq -c . akun-layanan.json`. Di dashboard hosting, tempel isi JSON apa adanya (boleh banyak baris).
- Kalau muncul error bahwa `FIREBASE_CREDENTIALS_JSON` bukan JSON yang valid, pakai `GOOGLE_APPLICATION_CREDENTIALS` dengan fitur "secret file" dari hosting.

## 6. Urutan dari nol sampai APK terpasang

1. Siapkan Firebase: proyek, login Google, Firestore, dan aturan dari `firestore.rules` (lihat [SETUP.md](SETUP.md)).
2. Jalankan workflow **Buat keystore debug** satu kali. Daftarkan SHA-1 dan SHA-256-nya di Firebase, simpan teks base64 sebagai secret `DEBUG_KEYSTORE_BASE64`.
3. Deploy backend dengan environment variable dari bagian 1, lalu catat alamat HTTPS-nya.
4. Isi Variables di GitHub (bagian 3), termasuk `QELVO_API_URL` dengan alamat dari langkah 3.
5. Actions, **Build APK**, **Run workflow**. Biarkan "Buat GitHub Release" tercentang.
6. Buka tab **Releases** di repo dari HP, unduh APK, izinkan instal dari sumber tidak dikenal, lalu pasang.
7. Cocokkan sidik jari di ringkasan job dengan yang terdaftar di Firebase kalau login Google gagal.

## Keamanan

- `.env`, `env.json`, berkas akun layanan, dan keystore sudah ada di `.gitignore`. Jangan di-commit.
- Yang benar-benar rahasia: key Gemini dan OpenRouter, akun layanan Firebase, `SMTP_PASSWORD`, `CODE_PEPPER`, dan `DEBUG_KEYSTORE_BASE64`. Kalau ada yang bocor, cabut dan buat ulang.
- Nilai `FIREBASE_*` di aplikasi ikut terbungkus di dalam APK, jadi bukan rahasia. Pengamannya adalah login dan `firestore.rules`.
