# Env lengkap

Konfigurasi aplikasi ada di dua tempat. Nilai rahasia hanya boleh disimpan di sana, bukan di kode atau di repo. Env backend ada di proyek terpisah, `qelvo-api` (`docs/ENV.md` di sana).

| Tempat | Berkas atau lokasi | Dipakai oleh |
| --- | --- | --- |
| 1. Aplikasi | `app/env.json` (lokal) | `flutter run` |
| 2. GitHub | Variables dan Secrets di repo | workflow **Build APK** |

Keduanya harus cocok dengan backend: `QELVO_API_URL` menunjuk ke backend, dan backend memakai proyek Firebase yang sama dengan nilai `FIREBASE_*` di sini (`FIREBASE_PROJECT_ID` di sisi backend). Kalau berbeda proyek, login ditolak server (401).

## 1. Aplikasi (`app/env.json`)

Salin dari `app/env.example.json`, isi, lalu jalankan `flutter run --dart-define-from-file=env.json`. Berkas `env.json` sudah masuk `.gitignore`.

```json
{
  "QELVO_API_URL": "https://alamat-backend-kamu.contoh.id",
  "FIREBASE_API_KEY": "AIzaSy...isi-dari-google-services.json",
  "FIREBASE_APP_ID": "1:123456789012:android:0123456789abcdef",
  "FIREBASE_PROJECT_ID": "nama-proyek-firebase",
  "FIREBASE_SENDER_ID": "123456789012",
  "FIREBASE_STORAGE_BUCKET": "",
  "EMAIL_LOGIN": "false"
}
```

`EMAIL_LOGIN` bersifat opsional. Bawaannya mati, jadi layar masuk hanya memuat Google dan tamu. Isi `"true"` untuk menampilkan login email dengan kode (server harus punya SMTP; lihat env backend di proyek `qelvo-api`).

Empat nilai Firebase diambil dari `google-services.json` (Firebase Console, Project settings, aplikasi Android):

| Variabel | Letak di `google-services.json` |
| --- | --- |
| `FIREBASE_API_KEY` | `client[0].api_key[0].current_key` |
| `FIREBASE_APP_ID` | `client[0].client_info.mobilesdk_app_id` |
| `FIREBASE_PROJECT_ID` | `project_info.project_id` |
| `FIREBASE_SENDER_ID` | `project_info.project_number` |
| `FIREBASE_STORAGE_BUCKET` (opsional) | `project_info.storage_bucket` |

Build di GitHub mengambil kelimanya langsung dari `app/google-services.json` kalau berkas itu ada di repo. Variables yang terisi tetap diutamakan, tetapi harus sama dengan isi berkas karena plugin Google Services ikut memasangnya di sisi native.

`QELVO_API_URL` juga boleh ditaruh di berkas yang sama, sebagai kunci tambahan `"qelvo_api_url"` di tingkat atas (plugin Google Services mengabaikannya). Berkas yang diunduh ulang dari Firebase tidak punya kunci ini, jadi tambahkan lagi. Nilai `https://isi-alamat-backend.invalid` hanya contoh: build tetap lolos dengan peringatan, dan alamatnya bisa diganti dari aplikasi.

`QELVO_API_URL` yang kosong berarti `http://10.0.2.2:8000`, alamat komputer dari dalam emulator Android.

## 2. GitHub Variables dan Secrets

Workflow **Build APK** membaca nilai-nilai ini. Tiap Variable boleh juga disimpan sebagai Secret dengan nama yang sama.

| Nama | Jenis | Wajib | Isi |
| --- | --- | --- | --- |
| `QELVO_API_URL` | Variable | ya | Alamat backend, misalnya `https://qelvo-api.contoh.id` |
| `FIREBASE_API_KEY` | Variable | ya | Lihat tabel di bagian 1 |
| `FIREBASE_APP_ID` | Variable | ya | Lihat tabel di bagian 1 |
| `FIREBASE_PROJECT_ID` | Variable | ya | Lihat tabel di bagian 1 |
| `FIREBASE_SENDER_ID` | Variable | ya | Lihat tabel di bagian 1 |
| `FIREBASE_STORAGE_BUCKET` | Variable | tidak | Boleh kosong |
| `EMAIL_LOGIN` | Variable | tidak | `true` menampilkan login email. Kosong = mati |
| `DEBUG_KEYSTORE_BASE64` | **Secret** | disarankan | Teks base64 dari workflow **Buat keystore debug** |

Cara mengisi dari HP, lewat situs github.com di browser:

1. Buka repo, **Settings**, **Secrets and variables**, **Actions**.
2. Tab **Variables**, **New repository variable**, isi nama dan nilai, simpan. Ulangi untuk tiap variabel.
3. Tab **Secrets**, **New repository secret** untuk `DEBUG_KEYSTORE_BASE64`.

Workflow memeriksa nilai-nilai wajib di awal dan berhenti dengan pesan yang menyebut nama variabel yang kosong atau berbentuk salah.

## 3. Contoh bentuk yang benar

Ini nilai palsu, hanya untuk memeriksa bentuk:

| Variabel | Contoh bentuk |
| --- | --- |
| `FIREBASE_API_KEY` | `AIzaSyA1b2C3d4E5f6G7h8I9j0K1l2M3n4O5p6Q` (diawali `AIza`) |
| `FIREBASE_APP_ID` | `1:123456789012:android:0123456789abcdef` (memuat `:android:`) |
| `FIREBASE_PROJECT_ID` | `qelvo-ai-1a2b3` |
| `FIREBASE_SENDER_ID` | `123456789012` (angka saja) |
| `QELVO_API_URL` | `https://qelvo-api.contoh.id` (tanpa garis miring di akhir) |

## 4. Urutan dari nol sampai APK terpasang

1. Siapkan Firebase: proyek, login Google, Firestore, dan aturan dari `firestore.rules` (lihat [SETUP.md](SETUP.md)).
2. Jalankan workflow **Buat keystore debug** satu kali. Daftarkan SHA-1 dan SHA-256-nya di Firebase, simpan teks base64 sebagai secret `DEBUG_KEYSTORE_BASE64`.
3. Deploy backend (proyek `qelvo-api`, ikuti README-nya), lalu catat alamat HTTPS-nya.
4. Isi Variables di GitHub (bagian 2), termasuk `QELVO_API_URL` dengan alamat dari langkah 3. Semua nilai boleh dilewati kalau `app/google-services.json` ada di repo dan memuat `qelvo_api_url`.
5. Actions, **Build APK**, **Run workflow**. Biarkan "Buat GitHub Release" tercentang.
6. Buka tab **Releases** di repo dari HP, unduh APK, izinkan instal dari sumber tidak dikenal, lalu pasang.
7. Cocokkan sidik jari di ringkasan job dengan yang terdaftar di Firebase kalau login Google gagal.

## Keamanan

- `env.json`, berkas akun layanan, dan keystore sudah ada di `.gitignore`. Jangan di-commit.
- Yang benar-benar rahasia di proyek ini: `DEBUG_KEYSTORE_BASE64`. Rahasia backend (key Gemini dan OpenRouter, akun layanan Firebase) ada di proyek `qelvo-api`. Kalau ada yang bocor, cabut dan buat ulang.
- Nilai `FIREBASE_*` di aplikasi ikut terbungkus di dalam APK, jadi bukan rahasia. Pengamannya adalah login dan `firestore.rules`.
