# Cari web

Cari web membuat jawaban memakai hasil pencarian web, lengkap dengan sumbernya.

```
QELVO AI
   |
Deteksi pencarian  (server, untuk mode otomatis)
   |
+--+--------------------+
|                       |
Gemini                  OpenRouter
Google Search           Plugin pencarian
Grounding               web
|                       |
+--+--------------------+
   |
Jawaban AI
   |
Sumber dan tautan
```

## Menyalakan

1. **Perbarui server.** Unggah `qelvo-api.zip` terbaru, jalankan Ekstrak zip, lalu tunggu Vercel selesai deploy. Deploy ini memasang paket `google-genai` dari `requirements.txt`.
2. **Tandai modelnya.** Buka `https://<server>/v1/providers` dan cari `"web_search": true`.
   - **Gemini:** bawaan server menandai Gemini 3.8 Flash. Kalau `GEMINI_MODELS` di Vercel kamu isi sendiri, bawaannya tidak berlaku: tambahkan `|cari` pada model yang mendukung tool `google_search`, misalnya `gemini-3.8-flash|Gemini 3.8 Flash|cari`, lalu Redeploy.
   - **OpenRouter:** tambahkan `|cari` di `OPENROUTER_MODELS`. Pencarian OpenRouter memotong kredit akun (tiap hasil berbiaya), jadi tandai model satu per satu.
   - `WEB_SEARCH_ENABLED=false` mematikan fiturnya untuk semua model sekaligus.
3. **Pasang aplikasi.** Pilih model yang bertanda, buka **+** di kolom tulis, dan nyalakan Cari web.

Urutannya bisa terbalik tanpa merusak apa pun: aplikasi hanya menyalakan sakelar kalau server mengiklankan `web_search: true`, jadi dengan server lama barisnya tetap "Segera hadir" dan kolom baru tidak pernah dikirim.

## Cara kerja

- **Otomatis.** Sakelar yang menyala berarti aplikasi mengirim `web_search: "auto"`. Server menilai pesan terakhir (`app/search_detect.py` di `qelvo-api`) dan mencari hanya kalau perlu: permintaan eksplisit ("cari di web", "sertakan sumber"), topik yang berubah tiap saat (cuaca, kurs, harga emas, skor, berita, versi terbaru), atau pertanyaan dengan kata waktu ("hari ini", "terbaru", "saat ini") atau tahun yang baru berlalu. Terjemahan, kode, dan dokumen panjang tidak memicu pencarian. Aturannya sederhana dan tanpa panggilan model tambahan, jadi tidak menambah waktu tunggu. Kalau terlalu sering atau terlalu jarang mencari, ubah daftar kata di berkas itu.
- **Memaksa.** Menulis "cari di web" di pesan selalu memicu pencarian. API juga menerima `web_search: true` (selalu mencari) untuk klien lain.
- **Penyedia mengikuti model.** Gemini mencari lewat Google Search Grounding (Interactions API, tool `google_search`): pencarian selesai dulu di server, lalu jawaban datang utuh. OpenRouter mencari lewat plugin `web`: hasil pencarian disuntikkan ke prompt di sisi OpenRouter, lalu jawaban mengalir seperti biasa.
- **Foto.** Pesan yang membawa foto (termasuk foto lama yang masih ikut sebagai konteks) melewati pencarian, karena jalur pencarian hanya membaca teks. Foto diutamakan.
- **Sumber.** Tampil sebagai tombol bernomor di dalam kartu jawaban, memakai `title` dari server sebagai label. Judul kutipan Google biasanya berupa nama domain, sedangkan alamatnya bisa berupa alamat pengalih milik Google, jadi alamat tidak dipakai sebagai label. Aturannya sama di aplikasi dan server: hanya `http` atau `https`, tanpa spasi, paling banyak 8, tanpa alamat ganda, `title` paling banyak 120 karakter. Sumber tersimpan di riwayat dan ikut ekspor Markdown.
- **Tanpa penanda "sedang mencari".** Keputusan mencari ada di server, jadi aplikasi tidak tahu sebelum jawabannya datang. Penandanya tetap "QELVO sedang menjawab" atau "sedang berpikir".

## Kontrak

Rinciannya ada di API.md, dan berkas itu sama dengan yang ada di `qelvo-api`. Ringkasnya:

| Bagian | Perubahan |
| --- | --- |
| `GET /v1/providers` | Tiap model punya `web_search` (`true` kalau boleh mencari web) |
| `POST /v1/chat` | `web_search`: `false`, `true` (selalu), atau `"auto"` (server menilai). `true` pada model tanpa dukungan: 422 `model_no_web_search`; `true` bersama foto: 422 `invalid_request`. `"auto"` tidak pernah menolak |
| Respons SSE | `meta` memuat `"web_search": true` kalau pencarian dipakai, lalu teks, lalu satu event `sources`, lalu `done` |
| Respons tanpa streaming | Kolom `sources` |
| Riwayat | Pesan `assistant` boleh membawa `sources` (disimpan dan dibaca) |

## Uji

```bash
curl -N -X POST "$SERVER/v1/chat" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"messages":[{"role":"user","content":"Berita terbaru hari ini?"}],"model":"gemini-3.8-flash","web_search":"auto","stream":true}'
```

Urutan yang diharapkan: `meta` (dengan `"web_search":true`), teks, satu `sources`, lalu `done`. Pertanyaan biasa ("Jelaskan fotosintesis") dengan `"auto"` menjawab tanpa `web_search` di `meta` dan tanpa `sources`. Lalu di aplikasi:

1. Baris Cari web di lembar **+** berubah dari "Segera hadir" jadi sakelar.
2. Pilih model yang tidak bertanda `cari`: barisnya mati dan berbunyi "Model ini belum bisa mencari web."
3. Nyalakan sakelar dan tanyakan sesuatu yang terkini ("Cuaca besok?"): tombol Sumber muncul di bawah jawaban.
4. Tanyakan sesuatu yang tidak butuh pencarian ("Jelaskan rekursi"): jawaban biasa tanpa Sumber.
5. Matikan sakelar: tidak pernah ada Sumber.
6. Buka ulang percakapan dari riwayat: tombol Sumber tetap ada.

## Status pengujian

Bagian yang murni (deteksi, membaca hasil Gemini dan OpenRouter, menyaring sumber, menerjemahkan galat, aliran SSE, penyimpanan riwayat) dites tanpa jaringan di `qelvo-api`. Yang **belum pernah dijalankan** adalah panggilan sungguhan: bentuk hasil Gemini (`steps`, `content`, `annotations`) dan pemanggilan `client.interactions.create` mengikuti contoh resmi yang kamu kirim, sedangkan parameter plugin OpenRouter (`plugins: [{"id": "web", "max_results": 5}]`) dan bentuk `annotations`-nya mengikuti dokumentasi OpenRouter yang saya ketahui; keduanya belum dicocokkan dengan keluaran asli. Pencarian pertama di server adalah ujian sebenarnya; kalau gagal, log Vercel menyebut penyebabnya (`Gemini (Cari web) membalas ...`, `openrouter membalas ...`, atau `Cari web gagal tanpa kode status`).

## Catatan

- **Kuota dan biaya.** Pencarian Google lewat Gemini bisa punya batas dan tarif sendiri, terpisah dari kuota teks. Pencarian OpenRouter memotong kredit akun, dan akun tanpa kredit menerima "Pencarian web di penyedia ini butuh kredit akun". Pakai `WEB_SEARCH_ENABLED=false` untuk menghentikan semuanya cepat.
- **Privasi.** Saat pencarian dipakai, pertanyaan pengguna juga dikirim ke Google Search (Gemini) atau ke penyedia pencarian di balik OpenRouter. Kebijakan Privasi di aplikasi perlu satu kalimat tentang itu sebelum rilis publik; teksnya belum diubah.
- **Kutipan di dalam teks.** Gemini dan OpenRouter memberi `start_index` dan `end_index` untuk tiap kutipan, tapi satuan indeksnya (karakter atau byte) belum terverifikasi, dan indeks yang salah akan merusak jawaban. Karena itu hanya daftar sumber yang ditampilkan. Penanda `[1]`, `[2]` di dalam teks bisa ditambahkan setelah ada keluaran asli untuk diuji; tombol Sumber sudah bernomor, jadi cocok dengannya.
- **Versi SDK.** `requirements.txt` memakai `google-genai>=1.50`. Interactions API masih berkembang; kalau pencarian Gemini mulai gagal setelah SDK naik versi, pasang versi terakhir yang jalan.
- **Percakapan panjang.** Untuk Gemini, riwayat diratakan jadi satu teks, jadi pesan yang sangat panjang memakan konteks.
- **Koneksi putus.** Kalau aplikasi menutup koneksi di tengah pencarian Gemini, panggilannya tetap selesai di server. Itu tidak berbahaya, hanya memakai kuota.
