# Cari web

Cari web membuat jawaban memakai hasil pencarian Google lewat Gemini, lengkap dengan sumbernya. Aplikasi dan server `qelvo-api` sudah mendukungnya; dokumen ini menjelaskan cara menyalakannya, apa yang terjadi di balik layar, dan cara memeriksanya.

## Menyalakan

1. **Perbarui server.** Unggah `qelvo-api.zip` terbaru, jalankan Ekstrak zip, lalu tunggu Vercel selesai deploy. Deploy ini memasang paket `google-genai` dari `requirements.txt`.
2. **Tandai modelnya.** Buka `https://<server>/v1/providers` dan cari `"web_search": true`. Bawaan server menandai Gemini 3.8 Flash. Kalau `GEMINI_MODELS` di Vercel kamu isi sendiri, bawaannya tidak berlaku: tambahkan `|cari` pada model yang mendukung tool `google_search`, misalnya `gemini-3.8-flash|Gemini 3.8 Flash|cari`, lalu Redeploy. `WEB_SEARCH_ENABLED=false` mematikan fiturnya untuk semua model.
3. **Pasang aplikasi.** Pilih model yang bertanda, buka **+** di kolom tulis, dan nyalakan Cari web.

Urutannya bisa terbalik tanpa merusak apa pun: aplikasi hanya menyalakan sakelar kalau server mengiklankan `web_search: true`, jadi dengan server lama barisnya tetap "Segera hadir" dan kolom baru tidak pernah dikirim.

## Kontrak

Rinciannya ada di API.md, dan berkas itu sama dengan yang ada di `qelvo-api`. Ringkasnya:

| Bagian | Perubahan |
| --- | --- |
| `GET /v1/providers` | Tiap model punya `web_search` (`true` kalau boleh mencari web) |
| `POST /v1/chat` | `web_search: true` meminta pencarian. 422 `model_no_web_search` kalau modelnya tidak mendukung, 422 `invalid_request` kalau ada foto |
| Respons SSE | Satu `delta` utuh, lalu satu event `sources`, lalu `done` |
| Respons tanpa streaming | Kolom `sources` |
| Riwayat | Pesan `assistant` boleh membawa `sources` (disimpan dan dibaca) |

## Perilaku

- Pencarian selesai dulu di server, baru jawabannya dikirim sekaligus. Selama menunggu (beberapa detik sampai belasan detik) penanda berbunyi "QELVO sedang mencari di web…", dan tidak ada teks yang mengalir. Kalau penyedia gagal (kuota, key, model menolak pencarian), aplikasi menerima status HTTP yang tepat, sama seperti chat biasa.
- Aplikasi mengirim `web_search: true` hanya kalau sakelarnya menyala, model terpilih `web_search: true`, dan pesannya tidak membawa foto (termasuk foto lama yang masih ikut sebagai konteks). Jalur pencarian hanya membaca teks, jadi foto diutamakan. `thinking` tidak berpengaruh pada pencarian.
- Sumber tampil sebagai tombol bernomor di dalam kartu jawaban, memakai `title` dari server sebagai label. Judul kutipan Google biasanya berupa nama domain, sedangkan alamatnya bisa berupa alamat pengalih milik Google, jadi alamat tidak dipakai sebagai label.
- Sumber yang diterima aplikasi dan server mengikuti aturan yang sama: hanya `http` atau `https`, tanpa spasi, paling banyak 8, tanpa alamat ganda, `title` paling banyak 120 karakter. Server menerapkannya sebelum mengirim, jadi sumber yang diteruskan aplikasi ke riwayat selalu diterima.
- Sumber tersimpan di riwayat dan ikut ekspor Markdown.

## Uji

```bash
curl -N -X POST "$SERVER/v1/chat" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"messages":[{"role":"user","content":"Siapa juara Euro 2024?"}],"model":"gemini-3.8-flash","web_search":true,"stream":true}'
```

Urutan yang diharapkan: `meta`, satu `delta`, satu `sources`, lalu `done`. Lalu di aplikasi:

1. Baris Cari web di lembar **+** berubah dari "Segera hadir" jadi sakelar.
2. Pilih model yang tidak bertanda `cari`: barisnya mati dan berbunyi "Model ini belum bisa mencari web."
3. Nyalakan sakelar dan kirim pertanyaan terkini: penanda berbunyi "QELVO sedang mencari di web…", lalu tombol Sumber muncul di bawah jawaban.
4. Matikan sakelar: jawaban biasa tanpa Sumber.
5. Buka ulang percakapan dari riwayat: tombol Sumber tetap ada.
6. Lampirkan foto dengan sakelar menyala: pencarian dilewati dan fotonya tetap dibaca.

## Status pengujian

Bagian yang murni (membaca hasil Interactions API, menyaring sumber, menerjemahkan galat, penyimpanan riwayat) dites tanpa jaringan di `qelvo-api`. Yang **belum pernah dijalankan** adalah panggilan sungguhan ke Gemini: bentuk hasil (`steps`, `content`, `annotations`) dan pemanggilan `client.interactions.create` mengikuti contoh resmi yang kamu kirim, dan belum dicocokkan dengan keluaran asli. Pencarian pertama di server adalah ujian sebenarnya; kalau gagal, log Vercel menyebut penyebabnya (`Gemini (Cari web) membalas ...` atau `Cari web gagal tanpa kode status`).

## Catatan

- **Kuota dan biaya.** Pencarian Google lewat Gemini bisa punya batas dan tarif sendiri, terpisah dari kuota teks. Cek halaman harga Gemini API sebelum menandai banyak model, dan pakai `WEB_SEARCH_ENABLED=false` untuk menghentikannya cepat.
- **Privasi.** Saat Cari web menyala, pertanyaan pengguna juga dikirim ke Google Search. Kebijakan Privasi di aplikasi perlu satu kalimat tentang itu sebelum rilis publik; teksnya belum diubah.
- **Kutipan di dalam teks.** Interactions API memberi `start_index` dan `end_index` untuk tiap kutipan, tapi satuan indeksnya (karakter atau byte) belum terverifikasi, dan indeks yang salah akan merusak jawaban. Karena itu hanya daftar sumber yang ditampilkan. Penanda `[1]`, `[2]` di dalam teks bisa ditambahkan setelah ada keluaran asli untuk diuji; tombol Sumber sudah bernomor, jadi cocok dengannya.
- **Versi SDK.** `requirements.txt` memakai `google-genai>=1.50`. Interactions API masih berkembang; kalau pencarian mulai gagal setelah SDK naik versi, pasang versi terakhir yang jalan.
- **Percakapan panjang.** Riwayat diratakan jadi satu teks untuk pencarian, jadi pesan yang sangat panjang memakan konteks.
- **Koneksi putus.** Kalau aplikasi menutup koneksi di tengah pencarian, panggilan ke Gemini tetap selesai di server. Itu tidak berbahaya, hanya memakai kuota.
