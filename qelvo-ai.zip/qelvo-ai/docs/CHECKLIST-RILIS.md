# Checklist rilis

Urutannya penting: **backend dulu, baru aplikasi.** Aplikasi baru memanggil endpoint yang belum ada di backend lama (judul otomatis, ganti nama, hapus akun), dan backend baru menolak token akun tamu dari aplikasi lama.

## 1. Firebase Console
- [ ] Authentication, Sign-in method: **Google** aktif, **Anonymous** dimatikan.
- [ ] Project settings, aplikasi Android: sidik jari **SHA-1 dan SHA-256** dari workflow keystore sudah ditambahkan (hapus yang lama).
- [ ] Firestore: `firestore.rules` terpasang (tolak semua akses langsung).
- [ ] Firestore, tab TTL: kebijakan untuk `email_codes`, `app_reports`, dan `usage` pada field `expireAt` (docs/ENV.md di `qelvo-api`).

## 2. Backend (Vercel)
- [ ] `GEMINI_API_KEY` dan/atau `OPENROUTER_API_KEY`.
- [ ] `FIREBASE_PROJECT_ID` dan `FIREBASE_CREDENTIALS_JSON` (akun layanan, JSON satu baris).
- [ ] Login email: `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM`, dan `CODE_PEPPER` (acak, **tetap**, jangan diganti).
- [ ] Opsional: `SUPPORT_EMAIL`, `HEALTH_TOKEN`, `DAILY_LIMIT_PER_USER`.
- [ ] Buka `https://<server>/health`: `status` harus `ok` dan `problems` kosong.
- [ ] Buka `https://<server>/hapus-akun`: halaman tampil.

## 3. GitHub (aplikasi)
- [ ] Keystore tetap: **repo privat** boleh memakai secret `DEBUG_KEYSTORE_BASE64` yang sudah ada (tidak perlu apa-apa lagi). **Repo publik**: secret `KEYSTORE_PASSPHRASE` (tab *Secrets*, bukan Variables) dan `DEBUG_KEYSTORE_ENC` terisi lewat workflow **Buat keystore debug**
- [ ] Variabel/secret `QELVO_API_URL`, `FIREBASE_*` terisi; variabel `EMAIL_LOGIN` kosong atau `true`.
- [ ] Workflow yang berubah **tidak berlaku dari dalam zip**; tempel manual ke `.github/workflows/` (Add file, atau edit berkas yang ada): `build-apk.yml` dan `keystore.yml` di repo aplikasi, `cleanup-guests.yml` di repo `qelvo-api` (dikirim juga sebagai berkas terpisah). Tanpa menempelnya, build lama tetap jalan dengan kunci lama.
- [ ] Rotasi keystore (`KEYSTORE_PASSPHRASE`, `DEBUG_KEYSTORE_ENC`): kalau repo **publik**, lakukan (kunci lama pernah tercetak di ringkasan job). Kalau **privat**, boleh setelah deadline: rotasi mengganti tanda tangan, jadi semua HP harus pasang ulang dan SHA baru harus didaftarkan di Firebase dulu.
- [ ] Build APK hijau. Kalau gagal, kirim lognya.

## 4. Uji di HP (urut)
1. [ ] Pasang APK baru (hapus yang lama kalau tanda tangannya berganti).
2. [ ] Masuk dengan **Google**.
3. [ ] Keluar, masuk dengan **email**: kode 6 digit tiba, diketik, berhasil masuk. Coba kode salah sekali.
4. [ ] Kirim chat biasa: jawaban mengalir. Kirim "berita hari ini": muncul "mencari di web", jawaban punya sumber.
5. [ ] Jawaban pertama: judul percakapan berubah jadi judul AI (bisa beberapa detik).
6. [ ] Riwayat: tekan lama percakapan, ganti nama, sematkan, hapus.
7. [ ] Ubah pesan terakhir (ikon pensil) lalu kirim ulang.
8. [ ] Tekan ikon mikrofon, ucapkan sesuatu: teks masuk ke kolom pesan.
9. [ ] Kirim chat, tekan Home saat jawaban mengalir: ada notifikasi senyap "sedang menjawab", lalu "sudah menjawab".
10. [ ] Pengaturan, Tentang kamu: isi nama dan gaya, tanyakan "siapa namaku?".
11. [ ] Pengaturan, Akun, **Hapus akun** (pakai akun uji!): kode tiba, akun terhapus, kembali ke layar masuk.

## 5. Sebelum rilis publik
- [ ] Isi bagian `[ ... ]` di Ketentuan dan Kebijakan Privasi (`legal_screen.dart`): kontak, alamat halaman `/hapus-akun`.
- [ ] Jalankan workflow **Bersihkan akun tamu** dengan `apply = false`, periksa angkanya, lalu `apply = true`.
- [ ] Kalau rilis lewat Google Play: butuh kunci rilis sendiri, varian tanpa pembaruan OTA (izin `REQUEST_INSTALL_PACKAGES`), dan deklarasi layanan latar depan `dataSync`.
