# Panduan setup

Urutan yang disarankan: Firebase, backend (proyek terpisah), lalu aplikasi. Nama menu di Firebase Console bisa berubah sedikit; cari istilah yang mirip.

## 1. Firebase

1. Buka console.firebase.google.com, buat proyek baru. Paket gratis (Spark) cukup untuk tahap ini.
2. **Tambah aplikasi Android** (Project settings, Your apps). Package name: `com.qelvo.qelvo_ai`.
3. **Sidik jari tanda tangan.** Login Google mencocokkan SHA-1 dan SHA-256 tanda tangan APK dengan yang terdaftar.
   - Di GitHub, buka tab Actions, jalankan workflow **Buat keystore debug** satu kali.
   - Buka ringkasan job. Salin SHA-1 dan SHA-256 ke Firebase (aplikasi Android, Add fingerprint).
   - Salin teks base64 di ringkasan itu ke secret repo `DEBUG_KEYSTORE_BASE64` (Settings, Secrets and variables, Actions).
   - Tanpa langkah ini, tiap build CI memakai kunci baru dan login Google gagal. Login tamu tetap jalan.
4. **Authentication**, tab Sign-in method: aktifkan **Google** dan isi email dukungan, lalu aktifkan **Anonymous** (dipakai login tamu). Login email tidak perlu diaktifkan di sini, karena kodenya dikirim dan diperiksa oleh backend.
5. **Firestore Database**: buat database. Di tab Rules, tempel isi `firestore.rules` dari repo ini lalu publikasikan. Atau dengan Firebase CLI: `firebase deploy --only firestore:rules`. Aturannya tolak-semua: aplikasi tidak boleh menyentuh Firestore, dan riwayat chat lewat backend (langkah 7).
6. **Nilai untuk aplikasi.** Unduh `google-services.json` dari Project settings, buka sebagai teks, lalu ambil empat nilai:

   | Variabel | Letak di `google-services.json` |
   | --- | --- |
   | `FIREBASE_PROJECT_ID` | `project_info.project_id` |
   | `FIREBASE_SENDER_ID` | `project_info.project_number` |
   | `FIREBASE_APP_ID` | `client[0].client_info.mobilesdk_app_id` |
   | `FIREBASE_API_KEY` | `client[0].api_key[0].current_key` |

   Kalau berkas diletakkan di `app/google-services.json`, workflow GitHub mengambil nilai-nilai di atas darinya, jadi tidak perlu diisi manual, dan `setup_android.sh` memasang plugin Google Services. Variables yang terisi tetap diutamakan, tetapi harus sama dengan isi berkas. Berkas itu konfigurasi klien; akun layanan di langkah 7 yang rahasia.
7. **Backend.** Backend ada di proyek terpisah (`qelvo-api`) dan memakai proyek Firebase yang sama: isi `FIREBASE_PROJECT_ID` di sana dengan `project_id` dari langkah 6. Itu cukup untuk memeriksa token login Google dan tamu. Untuk **riwayat chat** backend juga butuh akun layanan (Project settings, Service accounts, Generate new private key), diisi sebagai `FIREBASE_CREDENTIALS_JSON`. Berkas itu rahasia, jangan diunggah ke GitHub. Tanpa akun layanan chat tetap jalan, tetapi riwayat nonaktif.

## 2. Backend

Backend ada di proyek terpisah, `qelvo-api` (zip tersendiri). Cara menjalankan dan deploy gratis ke Vercel dari HP ada di README-nya. Setelah jalan, catat alamat HTTPS-nya (misalnya `https://qelvo-api.vercel.app`) lalu pakai sebagai `QELVO_API_URL`, atau isi dari dalam aplikasi: Pengaturan, Lanjutan, Alamat server.

Agar HP bisa menjangkau backend yang kamu jalankan sendiri:

- **Emulator Android:** alamat bawaan aplikasi `http://10.0.2.2:8000` sudah mengarah ke komputer.
- **GitHub Codespaces:** jalankan uvicorn, buka tab Ports, ubah visibilitas port 8000 menjadi Public, lalu pakai URL `https://...app.github.dev` sebagai alamat server.
- Pakai HTTPS untuk pemakaian sungguhan. Manifest Android di repo mengizinkan `http://` untuk uji coba; hapus atribut `usesCleartextTraffic` di `app/tool/AndroidManifest.xml` setelah backend berjalan di HTTPS.

## 3. Aplikasi

Butuh Flutter (versi stabil terbaru) dan JDK 17.

```bash
cd app
cp env.example.json env.json      # isi empat nilai Firebase dan QELVO_API_URL
bash tool/setup_android.sh        # flutter create, manifest, minSdk 23, plugin Google Services, ikon
flutter run --dart-define-from-file=env.json
```

Skrip `setup_android.sh` membuat folder `android/` (tidak ikut git), memasang manifest dari `app/tool/AndroidManifest.xml` (izin INTERNET dan izin membaca foto untuk lampiran), menaikkan `minSdk` ke 23 (syarat Firebase), memasang plugin Google Services bila `app/google-services.json` ada, dan membuat ikon launcher dari `assets/icon`.

Alamat server juga bisa diubah dari dalam aplikasi: Pengaturan, Lanjutan, Alamat server.

### Build APK lewat GitHub Actions

Repo boleh berisi proyek sebagai folder (`app/`) atau sebagai zip yang diunggah apa adanya: GitHub tidak mengekstrak zip, jadi workflow membukanya sendiri dan memakai zip yang terakhir di-commit. Workflow yang berjalan selalu `.github/workflows/build-apk.yml` di repo; perubahan workflow di dalam zip tidak berlaku, jadi tempel manual kalau berubah.

Daftar lengkap nilai yang harus diisi ada di [ENV.md](ENV.md). Ringkasnya:

1. Settings, Secrets and variables, Actions, tab **Variables**: isi `QELVO_API_URL`, `FIREBASE_API_KEY`, `FIREBASE_APP_ID`, `FIREBASE_PROJECT_ID`, `FIREBASE_SENDER_ID`. Atau lewati langkah ini: semuanya bisa dibaca dari `app/google-services.json` (alamat backend di kunci `qelvo_api_url`).
2. Pastikan secret `DEBUG_KEYSTORE_BASE64` sudah terisi (langkah 1.3).
3. Actions, **Build APK**, **Run workflow**. Pilihannya: arsitektur HP (`universal` untuk semua HP, `arm64` lebih kecil), buat GitHub Release atau tidak, dan versi Flutter (kosong = stabil terbaru).
4. Setelah selesai, APK ada di tab **Releases** (paling mudah diunduh dari HP) dan di bagian Artifacts. Ringkasan job memuat sidik jari tanda tangan APK untuk dicocokkan dengan Firebase.

Workflow juga jalan saat kamu mendorong tag `v*`, misalnya `v0.1.0`, dan hasilnya dilampirkan ke rilis bertag itu. Build tidak jalan otomatis di tiap push supaya menit Actions tidak terbuang. Kalau ada variabel wajib yang kosong, workflow berhenti di langkah pertama dengan pesan yang menyebut namanya.

APK ini ditandatangani dengan kunci debug dan cocok untuk uji coba. Untuk Play Store dibutuhkan keystore rilis sendiri.

## Pemecahan masalah

| Gejala | Penyebab dan langkah |
| --- | --- |
| Layar "Firebase belum disiapkan" | Build tanpa `--dart-define-from-file=env.json`, atau ada nilai yang kosong |
| Login Google: "Gagal masuk" | SHA-1 dan SHA-256 belum ditambahkan di Firebase, atau APK ditandatangani kunci yang berbeda dari yang terdaftar |
| Riwayat: "Riwayat chat belum aktif di server" | Backend belum punya akun layanan. Isi `FIREBASE_CREDENTIALS_JSON` di backend lalu Redeploy. `/health` menampilkan `"history": false` |
| Riwayat: "Database Firestore belum siap" | Database Firestore belum dibuat (Firebase Console, Firestore Database, Create database), atau akun layanan berasal dari proyek lain |
| "Tidak bisa terhubung ke server QELVO" | Alamat server salah, backend mati, atau HTTP diblokir. Periksa di Pengaturan, Alamat server |
| "Sesi tidak valid" (401) | `FIREBASE_PROJECT_ID` di backend berbeda dari proyek Firebase aplikasi |
| "Cara masuk ini belum diaktifkan di Firebase" | Provider Google atau Anonymous belum diaktifkan di Authentication, Sign-in method |
| "Mode tamu sedang dimatikan" | `ALLOW_GUEST=false` di server |
| "Kode diterima, tetapi proyek Firebase di aplikasi dan server tidak sama" | `FIREBASE_PROJECT_ID` aplikasi dan akun layanan backend berasal dari proyek berbeda |
| "Kuota gratis penyedia sedang habis" | Batas harian penyedia tercapai. Pilih model atau penyedia lain, atau tunggu |
| Build APK: "Proyek QELVO ... tidak ada di repo ini" | Repo belum berisi proyek, baik sebagai folder maupun di dalam zip. Unggah zip proyek (tidak perlu diekstrak) atau isinya ke akar repo. Daftar isi repo tercetak di log langkah itu |
| Build APK: "Belum terbaca: ..." padahal sudah diisi | Nilai tersimpan di tempat yang salah. Harus di Settings, Secrets and variables, tab **Actions**, bagian Repository variables, dengan nama persis sama |
| "Gagal masuk (kode)" saat memakai Google | SHA-1 dan SHA-256 aplikasi belum didaftarkan di Firebase (Project settings, aplikasi Android, Add fingerprint), atau Google belum diaktifkan di Authentication. Login tamu tidak butuh SHA |
| Build Gradle gagal soal manifest atau minSdk | Hapus folder `app/android`, jalankan ulang `bash tool/setup_android.sh` |
| Tombol + menjawab "Model ini belum bisa membaca foto" | Model aktif tidak mendukung foto, atau backend belum diperbarui. Buka `/v1/providers` di backend: tiap model harus punya `"vision": true` |
| Pilih foto menampilkan "QELVO belum boleh membuka foto" | Izin foto ditolak. Tekan Buka pengaturan, izinkan akses foto untuk QELVO, lalu Coba lagi |

Penyebab sisi server (kuota, penyedia AI, SMTP) dijelaskan di README `qelvo-api`.
