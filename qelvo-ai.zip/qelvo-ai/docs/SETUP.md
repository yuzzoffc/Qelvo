# Panduan setup

Urutan yang disarankan: Firebase, backend, lalu aplikasi. Nama menu di Firebase Console bisa berubah sedikit; cari istilah yang mirip.

## 1. Firebase

1. Buka console.firebase.google.com, buat proyek baru. Paket gratis (Spark) cukup untuk tahap ini.
2. **Tambah aplikasi Android** (Project settings, Your apps). Package name: `com.qelvo.qelvo_ai`.
3. **Sidik jari tanda tangan.** Login Google mencocokkan SHA-1 dan SHA-256 tanda tangan APK dengan yang terdaftar.
   - Di GitHub, buka tab Actions, jalankan workflow **Buat keystore debug** satu kali.
   - Buka ringkasan job. Salin SHA-1 dan SHA-256 ke Firebase (aplikasi Android, Add fingerprint).
   - Salin teks base64 di ringkasan itu ke secret repo `DEBUG_KEYSTORE_BASE64` (Settings, Secrets and variables, Actions).
   - Tanpa langkah ini, tiap build CI memakai kunci baru dan login Google gagal. Login tamu tetap jalan.
4. **Authentication**, tab Sign-in method: aktifkan **Google** dan isi email dukungan, lalu aktifkan **Anonymous** (dipakai login tamu). Login email tidak perlu diaktifkan di sini, karena kodenya dikirim dan diperiksa oleh backend.
5. **Firestore Database**: buat database. Di tab Rules, tempel isi `firestore.rules` dari repo ini lalu publikasikan. Atau dengan Firebase CLI: `firebase deploy --only firestore:rules`.
6. **Nilai untuk aplikasi.** Unduh `google-services.json` dari Project settings, buka sebagai teks, lalu ambil empat nilai:

   | Variabel | Letak di `google-services.json` |
   | --- | --- |
   | `FIREBASE_PROJECT_ID` | `project_info.project_id` |
   | `FIREBASE_SENDER_ID` | `project_info.project_number` |
   | `FIREBASE_APP_ID` | `client[0].client_info.mobilesdk_app_id` |
   | `FIREBASE_API_KEY` | `client[0].api_key[0].current_key` |

   Kalau berkas diletakkan di `app/google-services.json`, workflow GitHub mengambil nilai-nilai di atas darinya, jadi tidak perlu diisi manual, dan `setup_android.sh` memasang plugin Google Services. Variables yang terisi tetap diutamakan, tetapi harus sama dengan isi berkas. Berkas itu konfigurasi klien; akun layanan di langkah 7 yang rahasia.
7. **Akun layanan untuk backend.** Project settings, Service accounts, Generate new private key. Berkas JSON ini rahasia: jangan diunggah ke GitHub. Isinya dipasang sebagai environment variable `FIREBASE_CREDENTIALS_JSON` di server (di berkas `.env` harus satu baris, misalnya hasil `jq -c . akun.json`).

## 2. Kunci API model

- **Gemini:** buat key di aistudio.google.com/apikey, isi `GEMINI_API_KEY`.
- **OpenRouter:** buat key di openrouter.ai, isi `OPENROUTER_API_KEY`. Model bawaannya `openrouter/free`, yang memilih model gratis yang sedang tersedia.
- ID model dan kuota gratis sering berubah. Daftar model ada di `GEMINI_MODELS` dan `OPENROUTER_MODELS` (format `id|Label`, dipisah koma), jadi bisa diganti tanpa mengubah kode. Cek dokumentasi penyedia untuk nama terbaru.
- Kuota gratis kecil. Saat habis, aplikasi menampilkan pesan "Kuota gratis penyedia sedang habis".

## 3. Email kode verifikasi (SMTP)

Lewati bagian ini selama login email dimatikan (bawaan; lihat `EMAIL_LOGIN` di [ENV.md](ENV.md)). Backend mengirim kode lewat SMTP. Dua pilihan yang tidak butuh domain sendiri:

- **Brevo** (paket gratis): daftarkan dan verifikasi satu alamat pengirim, lalu isi `SMTP_HOST=smtp-relay.brevo.com`, `SMTP_PORT=587`, `SMTP_USER` dan `SMTP_PASSWORD` dari halaman SMTP, `SMTP_FROM` dengan alamat pengirim yang sudah diverifikasi.
- **Gmail:** aktifkan verifikasi 2 langkah, buat app password, lalu `SMTP_HOST=smtp.gmail.com`, `SMTP_PORT=587`, `SMTP_USER` alamat Gmail, `SMTP_PASSWORD` app password.

Isi juga `CODE_PEPPER` dengan teks acak panjang (`openssl rand -hex 32`). Kode disimpan sebagai hash dengan pepper ini, jadi jangan dibagikan.

Aturan kode: 6 digit, berlaku 10 menit, sekali pakai, maksimal 5 salah ketik, jeda 60 detik untuk kirim ulang, maksimal 5 kode per jam per email. Semuanya bisa diatur lewat variabel `EMAIL_CODE_*`.

Untuk uji lokal tanpa SMTP, set `DEV_PRINT_CODES=true`: kode dicetak di log server. Jangan dipakai di produksi.

## 4. Menjalankan backend

```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp ../.env.example .env     # lalu isi
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Cek `http://localhost:8000/health`. Dokumentasi interaktif ada di `/docs`.

Agar HP bisa menjangkau backend:

- **Emulator Android:** alamat bawaan aplikasi `http://10.0.2.2:8000` sudah mengarah ke komputer.
- **GitHub Codespaces:** jalankan uvicorn, buka tab Ports, ubah visibilitas port 8000 menjadi Public, lalu pakai URL `https://...app.github.dev` sebagai alamat server.
- **Server sendiri atau layanan hosting:** build dengan `backend/Dockerfile` (port dibaca dari variabel `PORT`), isi semua environment variable dari `.env.example`, dan set `TRUST_PROXY=true` kalau ada di belakang proxy. Layanan gratis biasanya tidur saat tidak dipakai, jadi permintaan pertama bisa lambat.
- Pakai HTTPS untuk pemakaian sungguhan. Manifest Android di repo mengizinkan `http://` untuk uji coba; hapus atribut `usesCleartextTraffic` di `app/tool/AndroidManifest.xml` setelah backend berjalan di HTTPS.

Batas pemakaian per pengguna disimpan di memori proses (`RATE_LIMIT_PER_MINUTE`). Tamu juga dibatasi per alamat IP (`GUEST_RATE_LIMIT_PER_MINUTE`), karena akun tamu bisa dibuat ulang tanpa batas. Kalau menjalankan lebih dari satu instance, batasnya berlaku per instance.

## 5. Aplikasi

Butuh Flutter (versi stabil terbaru) dan JDK 17.

```bash
cd app
cp env.example.json env.json      # isi empat nilai Firebase dan QELVO_API_URL
bash tool/setup_android.sh        # flutter create, manifest, minSdk 23, plugin Google Services, ikon
flutter run --dart-define-from-file=env.json
```

Skrip `setup_android.sh` membuat folder `android/` (tidak ikut git), memasang manifest dari `app/tool/AndroidManifest.xml`, menaikkan `minSdk` ke 23 (syarat Firebase), memasang plugin Google Services bila `app/google-services.json` ada, dan membuat ikon launcher dari `assets/icon`.

Alamat server juga bisa diubah dari dalam aplikasi: Pengaturan, Lanjutan, Alamat server.

### Build APK lewat GitHub Actions

Daftar lengkap nilai yang harus diisi ada di [ENV.md](ENV.md). Ringkasnya:

1. Settings, Secrets and variables, Actions, tab **Variables**: isi `QELVO_API_URL`, `FIREBASE_API_KEY`, `FIREBASE_APP_ID`, `FIREBASE_PROJECT_ID`, `FIREBASE_SENDER_ID`.
2. Pastikan secret `DEBUG_KEYSTORE_BASE64` sudah terisi (langkah 1.3).
3. Actions, **Build APK**, **Run workflow**. Pilihannya: arsitektur HP (`universal` untuk semua HP, `arm64` lebih kecil), buat GitHub Release atau tidak, dan versi Flutter (kosong = stabil terbaru).
4. Setelah selesai, APK ada di tab **Releases** (paling mudah diunduh dari HP) dan di bagian Artifacts. Ringkasan job memuat sidik jari tanda tangan APK untuk dicocokkan dengan Firebase.

Workflow juga jalan saat kamu mendorong tag `v*`, misalnya `v0.1.0`, dan hasilnya dilampirkan ke rilis bertag itu. Build tidak jalan otomatis di tiap push supaya menit Actions tidak terbuang. Kalau ada variabel wajib yang kosong, workflow berhenti di langkah pertama dengan pesan yang menyebut namanya.

Workflow **Backend test** menjalankan semua tes backend, termasuk tes endpoint FastAPI, dan mencoba membangun image Docker. Ia jalan otomatis saat ada perubahan di folder `backend`.

APK ini ditandatangani dengan kunci debug dan cocok untuk uji coba. Untuk Play Store dibutuhkan keystore rilis sendiri.

## Pemecahan masalah

| Gejala | Penyebab dan langkah |
| --- | --- |
| Layar "Firebase belum disiapkan" | Build tanpa `--dart-define-from-file=env.json`, atau ada nilai yang kosong |
| Login Google: "Gagal masuk" | SHA-1 dan SHA-256 belum ditambahkan di Firebase, atau APK ditandatangani kunci yang berbeda dari yang terdaftar |
| Riwayat: "Akses riwayat ditolak" | `firestore.rules` belum dipasang, atau database Firestore belum dibuat |
| "Tidak bisa terhubung ke server QELVO" | Alamat server salah, backend mati, atau HTTP diblokir. Periksa di Pengaturan, Alamat server |
| "Sesi tidak valid" (401) | Proyek Firebase di backend (akun layanan) berbeda dari yang dipakai aplikasi |
| "Cara masuk ini belum diaktifkan di Firebase" | Provider Google atau Anonymous belum diaktifkan di Authentication, Sign-in method |
| "Mode tamu sedang dimatikan" | `ALLOW_GUEST=false` di server |
| "Pengiriman email belum diatur" | `SMTP_HOST` dan `SMTP_FROM` kosong di server |
| "Email gagal terkirim" | Kredensial SMTP salah, atau alamat pengirim belum diverifikasi di penyedia SMTP |
| "Kode diterima, tetapi proyek Firebase di aplikasi dan server tidak sama" | `FIREBASE_PROJECT_ID` aplikasi dan akun layanan backend berasal dari proyek berbeda |
| "Kuota gratis penyedia sedang habis" | Batas harian penyedia tercapai. Pilih model atau penyedia lain, atau tunggu |
| Build APK: "Proyek QELVO ... tidak ada di repo ini" | Repo belum berisi proyek. Unggah isi zip supaya `.github`, `app`, dan `backend` ada di akar repo. Daftar isi repo tercetak di log langkah itu |
| Build APK: "Belum terbaca: ..." padahal sudah diisi | Nilai tersimpan di tempat yang salah. Harus di Settings, Secrets and variables, tab **Actions**, bagian Repository variables, dengan nama persis sama |
| Build Gradle gagal soal manifest atau minSdk | Hapus folder `app/android`, jalankan ulang `bash tool/setup_android.sh` |
