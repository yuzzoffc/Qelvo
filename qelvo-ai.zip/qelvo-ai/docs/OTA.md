# Pembaruan lewat aplikasi (OTA)

Aplikasi memperbarui dirinya lewat GitHub Releases, tanpa server tambahan dan tanpa Play Store. Sifatnya **semi otomatis**: aplikasi memeriksa sendiri saat dibuka, tapi mengunduh dan memasang hanya setelah kamu setuju, dan Android tetap meminta satu ketukan di pemasang sistemnya (pemasangan diam-diam tidak diizinkan untuk aplikasi biasa). Tidak ada pemberitahuan untuk pembaruan; semuanya tampil di dalam aplikasi.

```
Kamu menjalankan "Build APK" dengan ota dicentang
        |
GitHub Actions: bangun, tandatangani, hitung SHA-256
        |
GitHub Release vX.Y.Z  (APK + berkas .sha256 + catatan rilis)
        |
Aplikasi memeriksa releases/latest saat dibuka
        |
Lembar "Pembaruan tersedia"  ->  kamu ketuk Perbarui
        |
Unduh, cek ukuran dan checksum  ->  pemasang Android  ->  kamu ketuk Pasang
```

## Persiapan satu kali

1. **Repositori harus publik.** Aplikasi membaca rilis lewat API GitHub tanpa token, dan GitHub menjawab 404 untuk repositori privat. Kalau repo aplikasimu privat, buat repo publik khusus rilis (misalnya `qelvo-rilis`), lalu isi Variable `UPDATE_REPO` dengan `pemilik/qelvo-rilis` dan Secret `UPDATE_TOKEN` dengan token yang punya izin tulis Contents ke repo itu. Workflow menerbitkan rilis ke sana, dan aplikasi membacanya dari sana.
2. **Keystore tetap.** Android hanya menerima pembaruan yang ditandatangani kunci yang sama dengan aplikasi terpasang. Pastikan secret `DEBUG_KEYSTORE_BASE64` terisi (workflow **Buat keystore debug**, lihat SETUP.md) dan jangan pernah diganti. Workflow menolak rilis OTA tanpa secret itu.
3. **Pasang APK pertama yang sudah punya fitur ini.** Versi lama tidak bisa memperbarui dirinya. Build biasa (tanpa centang `ota`) cukup untuk itu; unduh dari rilis `build-N` atau dari artifact, pasang sekali, dan seterusnya semuanya lewat OTA.

## Merilis versi baru

1. Buka tab **Actions**, pilih **Build APK**, tekan **Run workflow**.
2. Centang **ota**, isi **version** (misalnya `0.2.0`; kosongkan untuk memakai versi di `pubspec.yaml`), dan isi **notes** kalau perlu. Catatan boleh berbaris-baris: pisahkan dengan `\n`, dan Markdown sederhana (daftar, huruf tebal) ikut tampil.
3. Tunggu selesai. Hasilnya rilis `v0.2.0` bertanda "Latest" berisi `QELVO-v0.2.0.apk` dan `QELVO-v0.2.0.apk.sha256`.

Kalau nomor versinya sudah pernah dirilis, workflow berhenti di awal dengan pesan yang jelas. Nomor harus naik; Android menolak turun versi.

## Di HP

- Saat aplikasi dibuka, ia bertanya ke GitHub apakah ada rilis lebih baru (paling sering sekali per 12 jam). Kalau ada, lembar **Pembaruan tersedia** muncul dengan versi, ukuran, dan catatan rilis.
- **Perbarui** mengunduh APK, memeriksa ukuran dan SHA-256-nya, lalu membuka pemasang Android. Pemasangan pertama meminta izin "pasang aplikasi tak dikenal" untuk QELVO; setelah diizinkan, kembali ke aplikasi dan ketuk **Pasang**.
- **Nanti** menutup lembar sampai pemeriksaan berikutnya. **Lewati versi ini** membuat versi itu tidak ditawarkan lagi oleh pemeriksaan otomatis (pemeriksaan manual tetap menampilkannya).
- **Pengaturan > Pembaruan** punya tombol **Periksa pembaruan** dan sakelar **Periksa otomatis**. Bagian itu hanya ada di build yang punya `UPDATE_REPO`, yaitu build dari workflow.

## Aturan versi

- Nomor versi tiga angka: `major.minor.patch`. Tag rilisnya `v` ditambah nomor itu.
- Kode versi di dalam APK (`versionCode`) diturunkan dari nomor: `major × 1.000.000 + minor × 1.000 + patch`. Angka pertama harus di bawah 2000, kedua dan ketiga di bawah 1000. Karena diturunkan, kode selalu naik bersama versi, dan build uji coba dengan nomor yang sama punya kode yang sama.
- Aplikasi membandingkan nomor versi dari tag rilis dengan `versionName` yang dibaca dari APK terpasang, bukan dengan kode.

## Keamanan

- Alamat unduhan hanya diterima kalau `https://github.com/<UPDATE_REPO>/releases/download/...`. Alamat lain di respons GitHub diabaikan.
- Rilis tanpa checksum tidak dipasang. Checksum dibaca dari kolom `digest` aset, atau dari berkas `.sha256` di rilis yang sama; ukuran juga dicocokkan dengan yang dicatat GitHub.
- Berkas hanya dibuka pemasang lewat penyedia konten sempit (`UpdateFileProvider`): mode baca, hanya `.apk`, hanya dari `cache/updates/`.
- Yang pada akhirnya menjaga keaslian adalah tanda tangan: Android menolak APK yang tidak ditandatangani kunci yang sama dengan aplikasi terpasang.

## Batasan

- Semi otomatis: pemasangan butuh satu ketukan di pemasang Android, dan unduhan butuh persetujuanmu.
- Pemeriksaan hanya saat aplikasi dibuka. Tidak ada pemeriksaan di latar belakang dan tidak ada pemberitahuan, karena satu-satunya pemberitahuan aplikasi adalah "QELVO sudah menjawab".
- API GitHub tanpa token dibatasi 60 permintaan per jam per alamat IP. Pemeriksaan sekali per 12 jam jauh di bawah itu, tapi jaringan bersama yang ramai bisa kena batas ("Batas pemeriksaan GitHub tercapai").
- Play Protect bisa menampilkan peringatan untuk aplikasi yang dipasang di luar Play Store. Itu normal untuk APK yang dipasang manual.
- Tidak ada rollback otomatis. Untuk menarik rilis yang bermasalah, terbitkan rilis dengan nomor lebih tinggi yang berisi perbaikannya.
- Kode Kotlin dan Dart untuk fitur ini belum pernah dikompilasi atau dijalankan di perangkat sungguhan (sandbox tanpa Flutter). Uji dulu satu putaran penuh di HP: pasang APK dari build biasa, terbitkan rilis `ota` dengan nomor lebih tinggi, lalu perbarui dari dalam aplikasi.

## Masalah umum

Tabel pemecahan masalah di [SETUP.md](SETUP.md) memuat gejala pembaruan yang paling sering: "Aplikasi tidak terpasang" (kunci tanda tangan berbeda), baris Pembaruan yang tidak muncul, "Belum ada rilis resmi di GitHub", dan izin pemasangan.
