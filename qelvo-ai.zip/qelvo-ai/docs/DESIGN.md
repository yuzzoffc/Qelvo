# Catatan desain

Sumber arah: PDF **QELVO_AI__Desain_Aplikasi_1_.pdf** (desain terbaru, menggantikan PDF pertama). Dikerjakan dengan aturan antislop, mode *during*.

**Design Read:** aplikasi chat asisten AI untuk pelajar dan developer Indonesia, gaya gelap minimal dengan satu aksen cyan. Dial ENERGY 2, RHYTHM 2, MOTION 1.

## Token

Warna dan gaya teks ada di satu tempat: `app/lib/core/theme.dart`.

| Token | Gelap | Terang | Dipakai untuk |
| --- | --- | --- | --- |
| `bg` | `#040810` | `#F4F7FB` | latar layar |
| `surface` | `#0B1220` | `#FFFFFF` | kartu, komposer, drawer |
| `bubble` | `#131C30` | `#E6EDF6` | gelembung pengguna, chip kode inline |
| `text` / `muted` | `#EEF2FA` / `#8F9BB5` | `#0B1320` / `#536278` | teks |
| `accent` | `#34E0F7` | `#22CBE8` | isi tombol utama |
| `accentText` | `#34E0F7` | `#07697E` | teks dan ikon beraksen |
| `warn` | `#F2B84B` | `#8F5200` | error dan aksi menghapus |

Hanya satu aksen (cyan). Amber hanya untuk keadaan: error dan hapus. Tema terang dirancang sendiri karena PDF hanya memuat tema gelap; pilihannya ada di Pengaturan (Gelap, Terang, Sistem).

**Kontras** (dihitung dengan rumus WCAG): semua pasangan teks dan latar yang dipakai minimal 4.5:1 di kedua tema; tepi kolom isian minimal 3:1. Pasangan yang diperiksa: teks, muted, dan accentText di atas bg, surface, bubble, dan codeBg; onAccent di atas accent; warn dan warna kode di atas latarnya.

**Tipografi** (alasan tiap pilihan):

- Plus Jakarta Sans untuk judul, sapaan, dan wordmark: dirancang studio Indonesia, bentuk huruf lebar dan tegas seperti di PDF.
- Inter untuk isi dan antarmuka padat: terbaca di ukuran kecil di layar HP, mendukung teks Indonesia penuh.
- JetBrains Mono hanya untuk kode: lebar huruf tetap dan pembeda yang jelas antara `l`, `1`, `I`, `0`, `O`.

**Bentuk:** radius berjenjang (10, 16, 22, 28). Bentuk pil hanya untuk chip dan toggle.

## Perubahan dari PDF, dengan alasan

| Perubahan | Alasan |
| --- | --- |
| Tombol **+** dan **mikrofon** di komposer tidak dipasang. Slot kanan jadi tombol kirim atau berhenti. | Belum ada fungsinya. Tombol yang tidak berfungsi lebih buruk daripada tidak ada. Mudah ditambah di fase 2. |
| Chip **Cari web** tampil dengan label "Segera" dan memberi penjelasan saat disentuh. | Gemini gratis tidak menyediakan pencarian web. Placeholder harus berlabel (ada `TODO(web-search)` di `composer.dart`). Kartu "QELVO Intelligence" juga berlabel Segera, seperti di PDF. |
| Ikon "Cari ide" memakai lampu, "Berpikir" memakai ikon pikiran, bukan bintang kilau. | Kilau adalah ikon AI generik; lampu dan pikiran sesuai artinya. Bintang empat sudut dipertahankan di pilihan Gemini karena itu tanda Gemini sendiri. |
| Ikon bagikan per pesan (ikon kelima) tidak dipasang. Ikon bagikan di bilah atas menyalin percakapan sebagai Markdown. | Berbagi lewat share sheet butuh paket tambahan. Salin ke clipboard sudah bisa, dan labelnya menyebut hal itu. |
| Titik di ujung teks saat streaming statis, tanpa denyut. | Titik menandai keadaan nyata (jawaban berjalan) dan teks yang bertambah sudah menunjukkan kemajuan. |
| Splash: titik orbit bergerak satu kali lalu diam. Dilewati bila pengguna mengurangi animasi. | Gerak berulang tanpa fungsi hanya jadi gangguan. Satu gerakan cukup mengarahkan mata ke logo. |
| "Simpan riwayat di perangkat" menjadi "Simpan riwayat". | Riwayat sekarang di Firebase, bukan di perangkat. |
| Menambah layar masuk (Google dan tamu; form kode email disembunyikan sementara lewat `EMAIL_LOGIN`), bagian Akun, Ketentuan, Kebijakan Privasi, dan Alamat server. | Login wajib (permintaan baru), Google dulu dengan opsi tamu. PDF memuat kalimat persetujuan Ketentuan dan Privasi, jadi halamannya harus ada. Alamat server dibutuhkan untuk menghubungkan app ke backend. |

## Keputusan yang dipertahankan dari PDF

- Tombol **Mulai** di splash tetap memakai teks dari PDF. CTA ini tergolong generik; alternatif yang lebih spesifik adalah "Masuk atau daftar". Ubah satu string di `splash_screen.dart` kalau mau.
- Empat kartu saran di beranda tetap seperti di PDF. Kartu mengisi kolom pesan (tidak langsung mengirim) supaya pengguna bisa melengkapinya.
- Garis kiri pada kutipan Markdown memakai warna netral, sebagai penanda kutipan.

## Keadaan tampilan

| Tampilan | Memuat | Kosong | Error |
| --- | --- | --- | --- |
| Percakapan | spinner saat membuka riwayat, titik saat streaming | sapaan dan kartu saran | pemberitahuan dengan tombol Coba lagi |
| Drawer riwayat | spinner | tiga variasi pesan (belum ada, penyimpanan mati, tidak cocok) | pesan dengan Coba lagi, pesan khusus untuk akses ditolak |
| Sheet model | spinner | pesan "server belum punya penyedia" | pesan dengan Coba lagi |
| Login dan kode email | tombol sibuk | n/a | pemberitahuan inline |
| Pengaturan | spinner di Ekspor, status server | n/a | snackbar |

## Aksesibilitas

- Area sentuh minimal 44dp. Semua kontrol dibuat di atas `InkWell` sehingga bisa difokus dan dipakai lewat keyboard atau pembaca layar, dengan label pada tombol yang hanya berisi ikon.
- Ukuran teks mengikuti sistem dan bisa ditambah 0.9x, 1.0x, atau 1.15x dari Pengaturan. Tata letak tidak mengunci tinggi teks.
- Status tidak hanya lewat warna: toggle berubah posisi, segmen terpilih berubah tebal dan terisi, error memakai ikon dan teks.
- Animasi spinner dan splash menghormati pengaturan "kurangi animasi".

## Laporan Delivery Gate

**Diverifikasi:**

- Tidak ada em dash atau en dash di berkas mana pun (pencarian seluruh repo, 0 hasil).
- Kontras: dihitung untuk kedua tema, 0 pasangan teks di bawah 4.5:1.
- Tidak ada data karangan: tidak ada percakapan contoh, jumlah dan daftar riwayat berasal dari Firestore.
- Placeholder berlabel: "Segera" di Cari web dan QELVO Intelligence, `[ ]` di draf hukum.
- Kejujuran soal model: aplikasi dan prompt sistem menyebut bahwa jawaban dibuat model penyedia API. Catatan "kuota gratis dapat berubah" tampil di sheet model.
- Ketentuan dan Kebijakan Privasi ada, berlabel draf.
- Setiap kontrol interaktif punya handler (diperiksa lewat kode). Kontrol yang belum berfungsi dihapus atau berlabel.

**Belum bisa dibuktikan:** aplikasi belum dikompilasi dan belum diklik di perangkat, karena lingkungan pembuatan tidak punya Flutter SDK. Pengganti yang dilakukan: pemeriksaan struktur otomatis pada 41 berkas Dart (kurung, string, impor, 0 kesalahan) dan pembacaan kode per layar. Jalankan `flutter run`, lalu telusuri tiap layar sebelum dianggap selesai.
