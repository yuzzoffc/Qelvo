# Catatan desain

Sumber arah: PDF **QELVOAIDesainAplikasi.pdf** (identitas visual versi 3.0, menggantikan PDF sebelumnya). Versi aplikasi tidak berubah (0.1.0): yang disesuaikan hanya tampilan. Dikerjakan dengan aturan antislop, mode *during*.

**Design Read:** aplikasi chat asisten AI untuk pelajar dan developer Indonesia, gaya gelap minimal dengan satu aksen cyan. Dial ENERGY 2, RHYTHM 2, MOTION 1.

## Token

Warna dan gaya teks ada di satu tempat: `app/lib/core/theme.dart`. Angka tema gelap diambil langsung dari warna isian di PDF, bukan ditebak dari gambar.

| Token | Gelap | Terang | Dipakai untuk |
| --- | --- | --- | --- |
| `bg` | `#060912` (Ink) | `#F5F8FC` | latar layar |
| `surface` | `#0C1220` | `#FFFFFF` | kartu, komposer, sheet |
| `panel` | `#080D19` | `#FFFFFF` | drawer riwayat |
| `bubble` | `#131C30` | `#E6EDF6` | gelembung pengguna, chip kode inline |
| `text` / `muted` | `#E8EDF7` / `#8E9DB5` (Steel) | `#0A1226` / `#53637D` | teks |
| `accent` | `#3DE0F5` (Cyan) | `#22CBE8` | isi tombol utama |
| `accentText` | `#3DE0F5` | `#07697E` | teks dan ikon beraksen |
| `warn` | `#F5B84A` | `#8F5200` | error dan aksi menghapus |
| `logoRing` / `logoTail` | `#F1F5FB` (Mist) / `#3DE0F5` | `#0A1226` / `#0891B2` | logo |

Hanya satu aksen (cyan). Amber hanya untuk keadaan: error dan hapus. Tema terang dirancang sendiri karena PDF hanya memuat layar gelap (halaman logo hanya memberi warna logo untuk latar terang); pilihannya ada di Pengaturan (Gelap, Terang, Sistem).

**Kontras** (dihitung dengan rumus WCAG): semua pasangan teks dan latar yang dipakai minimal 4.5:1 di kedua tema; tepi kolom isian dan kotak kode minimal 3:1. Pasangan yang diperiksa: teks, muted, dan accentText di atas bg, surface, panel, bubble, dan codeBg; onAccent di atas accent; warn dan warna kode di atas latarnya; outline di atas bg, surface, dan bubble.

## Logo

Geometri logo v3.0 **diukur dari vektor di PDF**, bukan digambar ulang: cincin luar berpusat di (50, 50) berjari-jari 50, cincin dalam bergeser 4,17 satuan ke kanan atas (jadi cincin menebal di kiri bawah), dua tepi celah sejajar sisi ekor, ekor bersumbu 45 derajat dan menembus kotak sampai 118,75 satuan. Angkanya ada di `app/lib/ui/widgets/qelvo_logo.dart` dan dijaga oleh `app/test/logo_test.dart`.

- Simbol: `QelvoLogo`. Logotype Q E L V O: `QelvoWordmark`, dengan slogan opsional.
- Ikon aplikasi (`app/assets/icon/`) dan logo README dibuat ulang dari geometri yang sama. Latar adaptif `#060912`.
- Slogan "THINK BEYOND." masih teks hidup (Sora lewat `google_fonts`), sama seperti catatan di PDF. Ubah ke outline sebelum produksi.
- Celah antara ekor dan cincin hilang di bawah sekitar 24 px (catatan uji di PDF). Di ukuran itu simbol tetap terbaca sebagai Q.

**Tipografi** (alasan tiap pilihan):

- Plus Jakarta Sans untuk judul dan sapaan: dirancang studio Indonesia, bentuk huruf lebar dan tegas.
- Inter untuk isi dan antarmuka padat: terbaca di ukuran kecil di layar HP, mendukung teks Indonesia penuh.
- JetBrains Mono hanya untuk kode dan kotak digit: lebar huruf tetap dan pembeda yang jelas antara `l`, `1`, `I`, `0`, `O`.
- Sora hanya untuk slogan logo, sesuai PDF identitas.

**Bentuk:** radius berjenjang (10, 16, 22, 28). Bentuk pil dipakai untuk chip, toggle, tombol, dan bilah model.

## Perubahan dari PDF, dengan alasan

| Perubahan | Alasan |
| --- | --- |
| **Mikrofon** tidak dipasang. Slot kanan komposer jadi tombol kirim atau berhenti. | Mikrofon butuh paket suara dan izin, dan belum dikerjakan. Tombol yang tidak berfungsi lebih buruk daripada tidak ada. |
| Lembar **Pilih foto** memakai folder yang ada di perangkat (Terbaru dulu, lalu Kamera, Screenshot, Unduhan, dan folder lain), bukan daftar tetap. Maksimal 4 foto per pesan; kolom pesan yang masih kosong terisi "Jelaskan isi foto ini" setelah foto dipilih. | Izin galeri diminta saat tombol **+** pertama ditekan. Batas 4 foto dan ukuran foto mengikuti batas server dan batas 4,5 MB badan permintaan di Vercel. |
| Gelembung pesan menampilkan gambar kecil foto di atas teks, dan pesan lama yang dibuka dari riwayat tetap menampilkannya. Tombol **+** menyebut alasannya bila model tidak mendukung foto. | PDF tidak memuat tampilan ini. Foto asli tidak disimpan; riwayat hanya menyimpan gambar kecil (sekitar 256 px). |
| Foto dikecilkan sebelum dikirim (sisi terpendek sekitar 1280 px, JPEG). Foto dari lampiran terbaru ikut dikirim ulang di pesan berikutnya selama aplikasi masih terbuka. | Supaya pertanyaan lanjutan tentang foto yang sama tetap bisa dijawab tanpa menambah foto lagi. Pesan yang dimuat dari riwayat hanya punya gambar kecil, jadi fotonya tidak dikirim ulang. |
| Chip **Cari web** tampil dengan label "Segera" dan memberi penjelasan saat disentuh. | Gemini gratis tidak menyediakan pencarian web. Placeholder harus berlabel (ada `TODO(web-search)` di `composer.dart`). |
| Ikon "Cari ide" memakai lampu, "Berpikir" memakai ikon pikiran, bukan bintang kilau. | Kilau adalah ikon AI generik; lampu dan pikiran sesuai artinya. |
| Ikon bagikan per pesan (ikon kelima) tidak dipasang. Ikon bagikan di bilah atas menyalin percakapan sebagai Markdown. | Berbagi lewat share sheet butuh paket tambahan. Salin ke clipboard sudah bisa, dan labelnya menyebut hal itu. |
| Titik di ujung teks saat streaming statis, tanpa denyut. Kerangka "Berpikir…" berdenyut pelan dan diam bila pengguna mengurangi animasi. | Titik menandai keadaan nyata dan teks yang bertambah sudah menunjukkan kemajuan. Kerangka hanya tampil sebelum potongan pertama tiba. |
| Splash tanpa tombol, hanya muncul perlahan satu kali. Persetujuan Ketentuan Layanan dan Kebijakan Privasi ada di layar masuk, seperti di PDF. | Splash di PDF hanya merek dan penanda memuat. Tombol "Mulai" dari desain lama dihapus. |
| Teks "riwayat hanya tersimpan di perangkat ini" diganti: layar masuk berbunyi "riwayat hanya bisa dibuka di perangkat ini dan hilang saat kamu keluar", pita tamu berbunyi "riwayat hilang saat keluar", dan "Simpan riwayat di perangkat" menjadi "Simpan riwayat". | Riwayat disimpan di Firebase lewat backend, bukan di perangkat. Kalimat di PDF tidak sesuai kenyataan. |
| Tab **Masuk** dan **Daftar** memakai alur yang sama. Pilihan hanya mengubah judul ("Masuk ke QELVO" atau "Buat akun QELVO"). | Akun dibuat otomatis lewat Google, email, maupun tamu, jadi tidak ada alur terpisah. |
| Kolom email dan kode 6 digit tampil hanya bila `EMAIL_LOGIN` aktif. Bila mati, layar masuk berisi Google dan tamu. | Permintaan: Google dulu, email menyusul. Layar kode sudah memakai desain baru dan siap dinyalakan. |
| Layar **Akun** hanya berisi yang bisa dipenuhi: avatar, nama (bisa diubah), email (baca saja), metode masuk, dan Keluar. Tidak dipasang: lencana kamera di avatar, ganti email, "Perangkat yang masuk", "Hapus akun". | Foto profil, ganti email dengan kode, daftar perangkat, dan hapus akun butuh dukungan di backend dan Firebase yang belum ada. |
| Pengaturan memuat bagian tambahan di bawah bagian yang ada di PDF: Ukuran teks, Instruksi sistem, Ekspor percakapan, Ketentuan Layanan, Kebijakan Privasi, Alamat server. | Semua sudah berfungsi di versi sebelumnya. Dua halaman hukum wajib ada karena layar masuk menautkannya. Alamat server dibutuhkan untuk menghubungkan app ke backend. |
| Sheet model berupa satu daftar model; subjudul tiap model memakai tagline penyedia dari server. Kartu "QELVO Intelligence" dihapus. | Desain baru tidak punya kartu itu, dan penyedia memang mengikuti model. Keterangan per model di PDF ("cepat dan hemat kuota") tidak dikirim server. |
| Garis tepi kolom isian dan toggle mati dibuat lebih tegas dari PDF (`#566B88` gelap, `#72849E` terang). | Garis di PDF sekitar 2:1 terhadap latarnya; dinaikkan agar minimal 3:1. |
| Dialog "Masuk dengan akun?" untuk tamu menyebut bahwa riwayat tamu tidak ikut pindah. | Tidak ada migrasi akun tamu ke akun Google, jadi pengguna perlu tahu sebelum menekan Lanjut. |

## Keputusan yang dipertahankan dari PDF

- Empat kartu saran di beranda tetap seperti di PDF. Kartu mengisi kolom pesan (tidak langsung mengirim) supaya pengguna bisa melengkapinya.
- Komposer berbentuk kartu dengan chip di bawah isian, sama di beranda dan di dalam percakapan.
- Bilah model menampilkan nama pendek model ("2.5 Flash"), diturunkan dari label model dengan membuang awalan nama penyedia.
- Garis kiri pada kutipan Markdown memakai warna netral, sebagai penanda kutipan.

## Keadaan tampilan

| Tampilan | Memuat | Kosong | Error |
| --- | --- | --- | --- |
| Percakapan | spinner saat membuka riwayat; kerangka "Berpikir…" sebelum potongan pertama; titik saat streaming | sapaan "Halo, {nama}." dan kartu saran | blok "Tidak dapat memperoleh jawaban" dengan Coba lagi dan Ganti model; tanpa sambungan: pita "Tidak ada koneksi internet" dan "Tidak terkirim, Coba lagi" di bawah pesan |
| Drawer riwayat | spinner | tiga variasi pesan (belum ada, penyimpanan mati, tidak cocok) | pesan dengan Coba lagi, pesan khusus untuk akses ditolak |
| Sheet model | spinner | pesan "server belum punya penyedia" | pesan dengan Coba lagi |
| Login dan kode email | tombol sibuk | n/a | pemberitahuan inline; kotak digit bergaris amber |
| Pengaturan dan Akun | spinner di Ekspor, status server | n/a | snackbar |
| Lembar Pilih foto | spinner saat membuka folder dan saat foto diperkecil | "Tidak ada foto di folder ini." | izin ditolak: penjelasan dengan Buka pengaturan dan Coba lagi; gagal memuat: Coba lagi; foto tidak terbuka: pesan di atas tombol |

## Aksesibilitas

- Area sentuh minimal 44dp. Semua kontrol dibuat di atas `InkWell` sehingga bisa difokus dan dipakai lewat keyboard atau pembaca layar, dengan label pada tombol yang hanya berisi ikon.
- Ukuran teks mengikuti sistem dan bisa ditambah 0.9x, 1.0x, atau 1.15x dari Pengaturan. Tata letak tidak mengunci tinggi teks.
- Status tidak hanya lewat warna: toggle berubah posisi, segmen terpilih berubah tebal dan terisi, error memakai ikon dan teks.
- Enam kotak kode hanyalah tampilan; satu kolom isian transparan di atasnya menerima ketikan, isi otomatis dari SMS, dan tempel, dan dibacakan sebagai "Kode verifikasi 6 digit".
- Animasi spinner, kerangka, dan splash menghormati pengaturan "kurangi animasi".
- Di lembar Pilih foto, tiap foto dibacakan sebagai "Foto" atau "Foto, dipilih nomor 2", jumlah pilihan di judul diumumkan saat berubah, dan foto terlampir di komposer punya tombol hapus bernama "Hapus foto 1" dengan area sentuh 44dp.

## Laporan Delivery Gate

**Diverifikasi:**

- Tidak ada em dash atau en dash di berkas mana pun (pencarian seluruh repo, 0 hasil).
- Kontras: dihitung untuk kedua tema, 0 pasangan di bawah ambang (4.5:1 teks, 3:1 garis tepi).
- Geometri logo: dibandingkan dengan render PDF, cincin dan ekor tumpang tindih 98% (selisih hanya tepi anti-alias). Posisi titik di dalam dan di luar cincin dan ekor diuji di `logo_test.dart` dan dicek terpisah dengan model Python yang sama.
- Warna tema gelap: sama dengan warna isian di PDF.
- Tidak ada data karangan: tidak ada percakapan contoh, jumlah dan daftar riwayat berasal dari Firestore.
- Placeholder berlabel: "Segera" di Cari web, `[ ]` di draf hukum.
- Kejujuran soal model: aplikasi dan prompt sistem menyebut bahwa jawaban dibuat model penyedia API. Catatan "kuota gratis dapat berubah" tampil di sheet model.
- Ketentuan dan Kebijakan Privasi ada, berlabel draf.
- Setiap kontrol interaktif punya handler (diperiksa lewat kode). Kontrol yang belum berfungsi dihapus atau berlabel.

**Belum bisa dibuktikan:** aplikasi belum dikompilasi dan belum diklik di perangkat, karena lingkungan pembuatan tidak punya Flutter SDK. Pengganti yang dilakukan: pemeriksaan struktur otomatis pada 54 berkas Dart (kurung, string, impor, nama kelas, argumen gaya teks, 0 temuan) dan pembacaan kode per layar. Jalankan `flutter test` dan `flutter run`, lalu telusuri tiap layar sebelum dianggap selesai. Khusus lampiran foto: pemakaian paket `photo_manager` (izin galeri, daftar folder, pembuatan gambar kecil) ditulis dari pengetahuan API-nya tanpa compiler, jadi bagian ini yang paling perlu dicoba di perangkat nyata (Android 13 dan 14 punya aturan izin yang berbeda). Hal lain yang belum: slogan logo belum jadi outline, uji rak kompetitor dengan pustaka logo belum dijalankan, dan pencarian merek dagang tetap perlu (semuanya catatan dari PDF identitas).
