# Catatan desain

Sumber arah: PDF **QELVOAIDesainAplikasi.pdf** (identitas visual versi 3.0, menggantikan PDF sebelumnya). Versi aplikasi tidak berubah (0.1.0): yang disesuaikan hanya tampilan. Dikerjakan dengan aturan antislop, mode *during*.

**Design Read:** aplikasi chat asisten AI untuk pelajar dan developer Indonesia, gaya gelap minimal dengan satu aksen cyan. Dial ENERGY 2, RHYTHM 2, MOTION 1.

## Token

Warna dan gaya teks ada di satu tempat: `app/lib/core/theme.dart`. Angka tema gelap diambil langsung dari warna isian di PDF, bukan ditebak dari gambar.

| Token | Gelap | Terang | Dipakai untuk |
| --- | --- | --- | --- |
| `bg` | `#060912` (Ink) | `#F5F8FC` | latar layar |
| `surface` | `#0C1220` | `#FFFFFF` | kartu, komposer, sheet |
| `panel` | `#080D19` | `#FFFFFF` | drawer riwayat |
| `bubble` | `#131C30` | `#E6EDF6` | chip kode inline, kepala tabel, tombol + dan sakelar mati |
| `userBubble` / `userBubbleLine` | `#134556` / `#1F6F7C` | `#C4EAF3` / `#5FA9BD` | gelembung pesan pengguna dan garis tepinya |
| `aiBubbleLine` | `#2B3A5C` | `#B4C2D3` | garis tepi kartu jawaban AI dan kartu di lembar Tambahkan ke chat |
| `text` / `muted` | `#E8EDF7` / `#A8B6CB` | `#0A1226` / `#475770` | teks |
| `accent` | `#3DE0F5` (Cyan) | `#22CBE8` | isi tombol utama |
| `accentText` | `#3DE0F5` | `#07697E` | teks dan ikon beraksen |
| `warn` | `#F5B84A` | `#8F5200` | error dan aksi menghapus |
| `logoRing` / `logoTail` | `#F1F5FB` (Mist) / `#3DE0F5` | `#0A1226` / `#0891B2` | logo |

Hanya satu aksen (cyan). Amber hanya untuk keadaan: error dan hapus. Tema terang dirancang sendiri karena PDF hanya memuat layar gelap (halaman logo hanya memberi warna logo untuk latar terang); pilihannya ada di Pengaturan (Gelap, Terang, Sistem).

**Kontras** (rumus WCAG, dijaga oleh `app/test/theme_contrast_test.dart`): semua pasangan teks dan latar yang dipakai minimal 4.5:1 di kedua tema; tepi kolom isian, tombol +, dan kotak kode minimal 3:1. Pasangan yang diperiksa: teks, muted, dan accentText di atas bg, surface, panel, bubble, dan codeBg; teks dan muted di atas userBubble; accentText dan muted di atas accentSoft (ikon yang menyala); onAccent di atas accent; warn dan warna kode di atas latarnya; outline di atas bg, surface, dan bubble. `muted` dinaikkan dari warna PDF (`#8E9DB5`: 7,2:1 di atas bg dan 6,2:1 di atas bubble) menjadi `#A8B6CB` (9,7:1 dan 8,3:1). Di tema terang dari `#53637D` (5,7:1 di atas bg) menjadi `#475770` (6,9:1). Alasannya: teks sekunder kecil di latar gelap melelahkan mata bagi pengguna dengan penglihatan terbatas.

## Logo

Geometri logo v3.0 **diukur dari vektor di PDF**, bukan digambar ulang: cincin luar berpusat di (50, 50) berjari-jari 50, cincin dalam bergeser 4,17 satuan ke kanan atas (jadi cincin menebal di kiri bawah), dua tepi celah sejajar sisi ekor, ekor bersumbu 45 derajat dan menembus kotak sampai 118,75 satuan. Angkanya ada di `app/lib/ui/widgets/qelvo_logo.dart` dan dijaga oleh `app/test/logo_test.dart`.

- Simbol: `QelvoLogo`. Logotype Q E L V O: `QelvoWordmark`, dengan slogan opsional.
- Ikon aplikasi (`app/assets/icon/`) dan logo README dibuat ulang dari geometri yang sama. Latar adaptif `#060912`.
- Slogan "THINK BEYOND." masih teks hidup (Sora lewat `google_fonts`), sama seperti catatan di PDF. Ubah ke outline sebelum produksi.
- Celah antara ekor dan cincin hilang di bawah sekitar 24 px (catatan uji di PDF). Di ukuran itu simbol tetap terbaca sebagai Q.

**Tipografi** (alasan tiap pilihan):

- Plus Jakarta Sans untuk judul dan sapaan: dirancang studio Indonesia, bentuk huruf lebar dan tegas.
- Inter untuk isi dan antarmuka padat: terbaca di ukuran kecil di layar HP, mendukung teks Indonesia penuh.
- JetBrains Mono hanya untuk kode dan kotak digit: lebar huruf tetap dan pembeda yang jelas antara `l`, `1`, `I`, `0`, `O`.
- Sora hanya untuk slogan logo, sesuai PDF identitas.

**Bentuk:** radius berjenjang (10, 16, 22, 28). Bentuk pil dipakai untuk chip, toggle, tombol, dan bilah model.

## Perubahan dari PDF, dengan alasan

| Perubahan | Alasan |
| --- | --- |
| **Mikrofon** tidak dipasang. Slot kanan komposer jadi tombol kirim atau berhenti. | Mikrofon butuh paket suara dan izin, dan belum dikerjakan. Tombol yang tidak berfungsi lebih buruk daripada tidak ada. |
| **Foto** dipilih lewat pemilih foto bawaan HP (Photo Picker sistem di Android 13 ke atas), bukan lembar buatan aplikasi. Maksimal 4 foto per pesan; kolom pesan yang masih kosong terisi "Jelaskan isi foto ini" setelah foto dipilih. | Permintaan pemilik proyek. Aplikasi tidak lagi meminta izin galeri dan hanya menerima foto yang dipilih pengguna. Batas 4 foto dan ukuran foto mengikuti batas server dan batas 4,5 MB badan permintaan di Vercel. |
| Gelembung pesan menampilkan gambar kecil foto di atas teks, dan pesan lama yang dibuka dari riwayat tetap menampilkannya. Baris Foto di lembar **+** menyebut alasannya bila model tidak mendukung foto. | PDF tidak memuat tampilan ini. Foto asli tidak disimpan; riwayat hanya menyimpan gambar kecil (sisi terpendek sekitar 320 px, paling besar 40 KB). |
| Foto dikecilkan sebelum dikirim (sisi terpanjang 1280 px, JPEG) dan dibersihkan dari metadata: koordinat GPS dan data kamera tidak ikut terkirim ke penyedia AI. Foto dari lampiran terbaru ikut dikirim ulang di pesan berikutnya selama aplikasi masih terbuka. | Supaya pertanyaan lanjutan tentang foto yang sama tetap bisa dijawab tanpa menambah foto lagi, dan supaya lokasi pengguna tidak bocor lewat foto. Pesan yang dimuat dari riwayat hanya punya gambar kecil, jadi fotonya tidak dikirim ulang. |
| Chip **Berpikir** dan **Cari web** di bawah isian dihapus. Keduanya pindah ke lembar **Tambahkan ke chat** yang dibuka tombol **+**, bersama Foto. Isi lembar hanya tiga hal: Foto, Cari web, Berpikir. Tombol File, Kamera, dan Konektor tidak dipasang. | Permintaan pemilik proyek, mengikuti pola lembar di app Claude tetapi dikurangi jadi tiga hal. File, kamera, dan konektor belum punya dukungan di aplikasi maupun backend, dan tombol yang tidak berfungsi lebih buruk daripada tidak ada. |
| Di lembar itu, Cari web berlabel "Segera hadir" dengan sakelar mati yang tidak bisa disentuh. Berpikir berupa baris dengan sakelar: menyala = ikon berlatar cyan, sakelar terisi, keterangan "Menyala. ..."; mati = ikon redup, sakelar kosong, keterangan "Mati. ...". | Gemini gratis tidak menyediakan pencarian web, jadi placeholder harus berlabel (ada `TODO(web-search)` di `add_sheet.dart`). Keadaan Berpikir tidak hanya lewat warna: posisi sakelar dan kata "Menyala" atau "Mati" ikut menyatakannya. |
| Tombol **+** dibuat paling mencolok setelah tombol kirim: isi `bubble`, garis tepi `outline` (3:1), tanda + tebal 28 px berwarna teks utama, area sentuh 46 dp. | Permintaan pemilik proyek: tombol lampiran harus langsung terlihat. Tombol ini sekarang satu-satunya jalan ke Foto, Cari web, dan Berpikir. |
| Penanda menunggu jawaban diganti: tiga titik cyan bergelombang, kalimat "QELVO sedang berpikir..." ("sedang menjawab..." bila Berpikir mati), dan tiga garis kerangka yang disapu cahaya, semuanya di dalam kartu jawaban. Selama jawaban berjalan ada juga garis tipis bergerak di bawah bilah atas. | Permintaan pemilik proyek: pengguna harus langsung tahu aplikasi sedang bekerja dan tidak macet. Gerak hanya ada di dua tempat ini dan berhenti total bila pengguna mengurangi animasi. |
| Pesan pengguna: isi cyan gelap bergaris tepi, rata kanan. Jawaban AI: kartu netral bergaris tepi, rata kiri, sudut kiri atas runcing ke arah logo. Di PDF jawaban AI tanpa gelembung, dan pesan pengguna hanya sedikit lebih terang dari latar. | Permintaan pemilik proyek: hierarki pesan harus lebih tajam. Keduanya dibedakan lewat warna, bentuk, dan posisi sekaligus, jadi tidak bergantung pada satu petunjuk saja. |
| Ikon "Cari ide" memakai lampu, "Berpikir" memakai ikon pikiran, bukan bintang kilau. | Kilau adalah ikon AI generik; lampu dan pikiran sesuai artinya. |
| Ikon bagikan per pesan (ikon kelima) tidak dipasang. Ikon bagikan di bilah atas menyalin percakapan sebagai Markdown. | Berbagi lewat share sheet butuh paket tambahan. Salin ke clipboard sudah bisa, dan labelnya menyebut hal itu. |
| Titik di ujung teks saat streaming statis, tanpa denyut. Penanda berpikir dan garis aktivitas bergerak, dan diam bila pengguna mengurangi animasi. | Titik menandai keadaan nyata dan teks yang bertambah sudah menunjukkan kemajuan. Penanda berpikir hanya tampil sebelum potongan pertama tiba. |
| Splash tanpa tombol, hanya muncul perlahan satu kali. Persetujuan Ketentuan Layanan dan Kebijakan Privasi ada di layar masuk, seperti di PDF. | Splash di PDF hanya merek dan penanda memuat. Tombol "Mulai" dari desain lama dihapus. |
| Teks "riwayat hanya tersimpan di perangkat ini" diganti: layar masuk berbunyi "riwayat hanya bisa dibuka di perangkat ini dan hilang saat kamu keluar", pita tamu berbunyi "riwayat hilang saat keluar", dan "Simpan riwayat di perangkat" menjadi "Simpan riwayat". | Riwayat disimpan di Firebase lewat backend, bukan di perangkat. Kalimat di PDF tidak sesuai kenyataan. |
| Tab **Masuk** dan **Daftar** memakai alur yang sama. Pilihan hanya mengubah judul ("Masuk ke QELVO" atau "Buat akun QELVO"). | Akun dibuat otomatis lewat Google, email, maupun tamu, jadi tidak ada alur terpisah. |
| Kolom email dan kode 6 digit tampil hanya bila `EMAIL_LOGIN` aktif. Bila mati, layar masuk berisi Google dan tamu. | Permintaan: Google dulu, email menyusul. Layar kode sudah memakai desain baru dan siap dinyalakan. |
| Layar **Akun** hanya berisi yang bisa dipenuhi: avatar, nama (bisa diubah), email (baca saja), metode masuk, dan Keluar. Tidak dipasang: lencana kamera di avatar, ganti email, "Perangkat yang masuk", "Hapus akun". | Foto profil, ganti email dengan kode, daftar perangkat, dan hapus akun butuh dukungan di backend dan Firebase yang belum ada. |
| Pengaturan memuat bagian tambahan di bawah bagian yang ada di PDF: Ukuran teks, Instruksi sistem, Ekspor percakapan, Ketentuan Layanan, Kebijakan Privasi, Alamat server. | Semua sudah berfungsi di versi sebelumnya. Dua halaman hukum wajib ada karena layar masuk menautkannya. Alamat server dibutuhkan untuk menghubungkan app ke backend. |
| Sheet model berupa satu daftar model; subjudul tiap model memakai tagline penyedia dari server. Kartu "QELVO Intelligence" dihapus. | Desain baru tidak punya kartu itu, dan penyedia memang mengikuti model. Keterangan per model di PDF ("cepat dan hemat kuota") tidak dikirim server. |
| Garis tepi kolom isian dan toggle mati dibuat lebih tegas dari PDF (`#566B88` gelap, `#72849E` terang). | Garis di PDF sekitar 2:1 terhadap latarnya; dinaikkan agar minimal 3:1. |
| Dialog "Masuk dengan akun?" untuk tamu menyebut bahwa riwayat tamu tidak ikut pindah. | Tidak ada migrasi akun tamu ke akun Google, jadi pengguna perlu tahu sebelum menekan Lanjut. |

## Keputusan yang dipertahankan dari PDF

- Empat kartu saran di beranda tetap seperti di PDF. Kartu mengisi kolom pesan (tidak langsung mengirim) supaya pengguna bisa melengkapinya.
- Komposer berbentuk kartu dengan isian di atas dan tombol di bawahnya (+ di kiri, kirim di kanan), sama di beranda dan di dalam percakapan.
- Bilah model menampilkan nama pendek model ("2.5 Flash"), diturunkan dari label model dengan membuang awalan nama penyedia.
- Garis kiri pada kutipan Markdown memakai warna netral, sebagai penanda kutipan.

## Keadaan tampilan

| Tampilan | Memuat | Kosong | Error |
| --- | --- | --- | --- |
| Percakapan | spinner saat membuka riwayat; penanda berpikir sebelum potongan pertama; garis aktivitas di bawah bilah atas dan titik di ujung teks saat streaming | sapaan "Halo, {nama}." dan kartu saran | blok "Tidak dapat memperoleh jawaban" dengan Coba lagi dan Ganti model; tanpa sambungan: pita "Tidak ada koneksi internet" dan "Tidak terkirim, Coba lagi" di bawah pesan |
| Drawer riwayat | spinner | tiga variasi pesan (belum ada, penyimpanan mati, tidak cocok) | pesan dengan Coba lagi, pesan khusus untuk akses ditolak |
| Sheet model | spinner | pesan "server belum punya penyedia" | pesan dengan Coba lagi |
| Login dan kode email | tombol sibuk | n/a | pemberitahuan inline; kotak digit bergaris amber |
| Pengaturan dan Akun | spinner di Ekspor, status server | n/a | snackbar |
| Lembar Tambahkan ke chat | n/a | n/a | Foto tidak tersedia: alasannya tertulis di baris Foto (model tidak membaca foto, daftar model belum dimuat, jatah foto penuh) |
| Foto (pemilih bawaan HP) | kotak berputar di komposer selama foto diolah, tombol kirim belum aktif | pemilih ditutup tanpa memilih: tidak ada yang berubah | pemilih gagal dibuka atau foto tidak terbaca: pemberitahuan singkat; pilihan melebihi jatah: pemberitahuan, kelebihannya dilewati |

## Aksesibilitas

- Area sentuh minimal 44dp. Semua kontrol dibuat di atas `InkWell` sehingga bisa difokus dan dipakai lewat keyboard atau pembaca layar, dengan label pada tombol yang hanya berisi ikon.
- Ukuran teks mengikuti sistem dan bisa ditambah 0.9x, 1.0x, atau 1.15x dari Pengaturan. Tata letak tidak mengunci tinggi teks.
- Status tidak hanya lewat warna: toggle berubah posisi, keterangan Berpikir menyebut "Menyala" atau "Mati", segmen terpilih berubah tebal dan terisi, error memakai ikon dan teks.
- Enam kotak kode hanyalah tampilan; satu kolom isian transparan di atasnya menerima ketikan, isi otomatis dari SMS, dan tempel, dan dibacakan sebagai "Kode verifikasi 6 digit".
- Animasi spinner, penanda berpikir, garis aktivitas, dan splash menghormati pengaturan "kurangi animasi": titik penanda tetap menyala penuh dan garis aktivitas menjadi garis diam.
- Tombol + dibacakan "Tambahkan ke chat" (ditambah jumlah foto terlampir bila ada). Tiap baris di lembarnya dibacakan lengkap dengan judul, keterangan, dan keadaan sakelar; Cari web dibacakan tidak aktif. Foto yang sedang diolah dibacakan "Foto sedang disiapkan", dan foto terlampir punya tombol hapus bernama "Hapus foto 1" dengan area sentuh 44dp. Pemilih foto itu sendiri milik sistem, jadi aksesibilitasnya mengikuti pengaturan HP.

## Laporan Delivery Gate

**Diverifikasi:**

- Tidak ada em dash atau en dash di berkas mana pun (pencarian seluruh repo, 0 hasil).
- Kontras: dihitung untuk kedua tema dengan palet baru, 0 pasangan di bawah ambang (4.5:1 teks, 3:1 garis tepi), dan dijaga oleh `theme_contrast_test.dart`.
- Geometri logo: dibandingkan dengan render PDF, cincin dan ekor tumpang tindih 98% (selisih hanya tepi anti-alias). Posisi titik di dalam dan di luar cincin dan ekor diuji di `logo_test.dart` dan dicek terpisah dengan model Python yang sama.
- Warna tema gelap: sama dengan warna isian di PDF.
- Tidak ada data karangan: tidak ada percakapan contoh, jumlah dan daftar riwayat berasal dari Firestore.
- Placeholder berlabel: "Segera hadir" di Cari web, `[ ]` di draf hukum.
- Kejujuran soal model: aplikasi dan prompt sistem menyebut bahwa jawaban dibuat model penyedia API. Catatan "kuota gratis dapat berubah" tampil di sheet model.
- Ketentuan dan Kebijakan Privasi ada, berlabel draf.
- Setiap kontrol interaktif punya handler (diperiksa lewat kode). Kontrol yang belum berfungsi dihapus atau berlabel.

**Belum bisa dibuktikan:** aplikasi belum dikompilasi dan belum diklik di perangkat, karena lingkungan pembuatan tidak punya Flutter SDK. Pengganti yang dilakukan: pemeriksaan struktur otomatis pada 58 berkas Dart (kurung, impor yang ada, impor tak terpakai, tanda hubung panjang; tidak ada temuan nyata) dan pembacaan kode per layar. Jalankan `flutter test` dan `flutter run`, lalu telusuri tiap layar sebelum dianggap selesai. Khusus lampiran foto: pemakaian paket `image_picker` (`pickMultiImage` dengan `limit`, `pickImage`, `maxWidth`, `maxHeight`, `imageQuality`) dan paket `image` (`decodeImage`, `bakeOrientation`, `copyResize`, `encodeJpg`) ditulis dari pengetahuan API-nya tanpa compiler, jadi bagian ini yang paling perlu dicoba di perangkat nyata. Kalau build gagal di argumen `limit`, hapus argumen itu di `lib/data/photo_source.dart`: batas 4 foto tetap ditegakkan oleh pemotongan di fungsi yang sama. Di Android 12 ke bawah pemilihnya adalah pemilih gambar bawaan HP (bukan Photo Picker), dan tampilannya berbeda antarmerek. Tes baru (`photo_prep_test.dart` dan `theme_contrast_test.dart`) belum pernah dijalankan. Hal lain yang belum: slogan logo belum jadi outline, uji rak kompetitor dengan pustaka logo belum dijalankan, dan pencarian merek dagang tetap perlu (semuanya catatan dari PDF identitas).
