# API backend

Kontrak yang dipakai aplikasi. Implementasinya ada di proyek terpisah `qelvo-api` (`docs/API.md` di sana sama dengan berkas ini).

Semua endpoint di bawah `/v1` kecuali dua endpoint login email membutuhkan header:

```
Authorization: Bearer <token ID Firebase>
```

Token diverifikasi server dengan Firebase Admin SDK. Token harus punya email yang sudah terverifikasi, atau berasal dari akun tamu (Firebase Anonymous) selama `ALLOW_GUEST=true`. Tamu juga dibatasi per IP (`GUEST_RATE_LIMIT_PER_MINUTE`). Dengan `AUTH_MODE=off` (hanya uji lokal) pemeriksaan ini dilewati.

Semua error berbentuk:

```json
{ "error": { "code": "rate_limited", "message": "Terlalu banyak permintaan. Coba lagi dalam 12 detik." } }
```

`message` berbahasa Indonesia dan aman ditampilkan langsung ke pengguna. `code` untuk logika program.

## GET /health

Tanpa login. Selalu menjawab 200 selama server hidup, bahkan kalau pengaturannya salah.

```json
{
  "status": "ok",
  "version": "0.2.0",
  "providers": ["gemini"],
  "auth": "ready",
  "email_login": false,
  "history": true,
  "problems": []
}
```

`status` bernilai `ok` atau `degraded`. `auth` bernilai `ready` (login Firebase aktif), `off` (`AUTH_MODE=off`), atau `error` (login gagal disiapkan; endpoint berlogin menjawab 503 `server_misconfigured`). `history` bernilai `true` kalau penyimpanan riwayat aktif (butuh akun layanan Firebase di server). `problems` berisi penjelasan singkat tanpa nilai rahasia, misalnya variabel yang belum diisi.

## GET /v1/providers

Penyedia yang punya API key di server.

```json
{
  "default_provider": "gemini",
  "providers": [
    {
      "id": "gemini",
      "name": "Gemini",
      "tagline": "Google AI Studio · ada kuota gratis",
      "default_model": "gemini-3.5-flash-lite",
      "models": [{ "id": "gemini-3.5-flash-lite", "label": "Gemini 3.5 Flash-Lite", "vision": true }]
    }
  ]
}
```

`vision` bernilai `false` untuk model yang hanya membaca teks (ditandai `|teks` di `GEMINI_MODELS` atau `OPENROUTER_MODELS`). Aplikasi memakainya untuk menyembunyikan pilihan lampiran foto, dan server menolak foto untuk model seperti itu.

## POST /v1/chat

```json
{
  "messages": [
    { "role": "user", "content": "Jelaskan fotosintesis dalam dua kalimat." }
  ],
  "provider": "gemini",
  "model": "gemini-3.5-flash-lite",
  "thinking": true,
  "instruction": "standar",
  "stream": true
}
```

| Field | Keterangan |
| --- | --- |
| `messages` | 1 sampai 200 pesan, `role` `user` atau `assistant`. Pesan terakhir harus dari `user`. Server membuang pesan kosong (pesan tanpa teks tetap dipakai kalau membawa foto), menggabungkan peran beruntun beserta fotonya, dan memangkas bagian terlama (`MAX_MESSAGES`, `MAX_CONTEXT_CHARS`). Satu pesan maksimal `MAX_MESSAGE_CHARS`. |
| `messages[].images` | Opsional, hanya untuk pesan `user`. Daftar foto, lihat bagian Foto di bawah. |
| `provider`, `model` | Opsional. Kosong berarti bawaan server. Model harus ada di daftar server. |
| `thinking` | `true` memakai tingkat berpikir lebih tinggi (`GEMINI_EFFORT_THINKING`), `false` yang lebih cepat. |
| `instruction` | `standar`, `ringkas`, `guru`, atau `developer`. Nilai lain jatuh ke `standar`. Klien tidak bisa mengirim prompt sistem sendiri. |
| `stream` | `true` (bawaan) mengembalikan SSE, `false` mengembalikan satu JSON. |

### Foto

Pesan `user` boleh membawa foto:

```json
{
  "messages": [
    {
      "role": "user",
      "content": "Jelaskan isi foto ini.",
      "images": [{ "mime": "image/jpeg", "data": "<base64 polos, tanpa awalan data:>" }]
    }
  ]
}
```

| Aturan | Nilai bawaan | Variabel |
| --- | --- | --- |
| Jenis | `image/jpeg`, `image/png`, `image/webp`. Server memeriksa tanda di awal berkas, bukan hanya `mime` | |
| Jumlah per permintaan | 4 | `MAX_IMAGES_PER_REQUEST` |
| Ukuran satu foto (setelah base64 dibuka) | 1,5 MB | `MAX_IMAGE_BYTES` |
| Total semua foto | 3 MB | `MAX_IMAGES_TOTAL_BYTES` |

Foto dikirim ke penyedia AI sebagai bagian `image_url` berisi data URL, tidak disimpan, dan tidak dicatat di log. Model harus punya `vision: true` di `/v1/providers`. Di Vercel badan permintaan dibatasi 4,5 MB, dan base64 menambah sepertiga ukuran, jadi total 3 MB aman. Kalau batas itu terlewati, Vercel menjawab 413 `FUNCTION_PAYLOAD_TOO_LARGE` sebelum sampai ke aplikasi ini, tanpa badan JSON.

### Respons streaming (`text/event-stream`)

Tiap event satu baris `data:` yang berisi JSON, dipisah baris kosong:

```
data: {"meta":{"provider":"gemini","provider_name":"Gemini","model":"gemini-3.5-flash-lite","model_label":"Gemini 3.5 Flash-Lite"}}

data: {"delta":"Fotosintesis adalah "}

data: {"delta":"proses ..."}

data: {"done":true}
```

Kalau penyedia menolak sebelum ada potongan pertama (kuota, key, model), respons berupa JSON error dengan status HTTP yang sesuai. Kalau gagal di tengah jawaban, event terakhir adalah `data: {"error":{"code":"...","message":"..."}}`.

### Respons tanpa streaming

```json
{ "provider": "gemini", "provider_name": "Gemini", "model": "gemini-3.5-flash-lite", "model_label": "Gemini 3.5 Flash-Lite", "content": "..." }
```

## Riwayat chat

Riwayat disimpan di Firestore (`users/{uid}/conversations/{id}` dan `.../messages/{id}`) lewat Admin SDK. Aturan `firestore.rules` menolak semua akses dari aplikasi, jadi endpoint di bawah satu-satunya jalan. Semuanya butuh login (termasuk tamu), hanya menyentuh data milik pemilik token, dan dibatasi `HISTORY_RATE_LIMIT_PER_MINUTE`. ID percakapan dan pesan: huruf, angka, `_`, atau `-`, maksimal 64 karakter. Cap waktu dalam milidetik sejak epoch (UTC).

| Endpoint | Fungsi |
| --- | --- |
| `GET /v1/conversations?limit=300` | Daftar percakapan, terbaru dulu (`limit` 1 sampai 500) |
| `DELETE /v1/conversations` | Hapus semua percakapan milik akun |
| `GET /v1/conversations/{id}/messages` | Pesan satu percakapan, urut waktu |
| `PUT /v1/conversations/{id}/messages/{mid}` | Simpan satu pesan sekaligus memperbarui data percakapan |
| `PATCH /v1/conversations/{id}/messages/{mid}` | Ubah penilaian: `{"rating": 1}` (`1`, `0`, atau `-1`) |
| `DELETE /v1/conversations/{id}/messages/{mid}` | Hapus satu pesan |
| `DELETE /v1/conversations/{id}` | Hapus satu percakapan beserta semua pesannya |

```json
// PUT /v1/conversations/c1/messages/m1
{
  "conversation": { "title": "Fotosintesis", "model_label": "Gemini 3.5 Flash-Lite", "preview": "", "created_at": 1767225600000 },
  "message": { "role": "user", "content": "Jelaskan fotosintesis.", "created_at": 1767225600000, "rating": 0 }
}
```

`model_label` dan `preview` yang kosong tidak menimpa nilai yang sudah tersimpan. `updated_at` percakapan diisi server saat menyimpan. Respons daftar:

```json
{ "conversations": [{ "id": "c1", "title": "Fotosintesis", "model_label": "Gemini 3.5 Flash-Lite", "preview": "", "created_at": 1767225600000, "updated_at": 1767225660000 }] }
```

Respons pesan: `{ "messages": [{ "id": "m1", "role": "user", "content": "...", "created_at": 1767225600000, "rating": 0 }] }`. Penyimpanan, penghapusan, dan penilaian menjawab `{ "ok": true }`.

Pesan `user` yang membawa foto boleh menyertakan `images` di `message` saat disimpan: gambar kecil (bukan foto aslinya) dengan bentuk yang sama, `{ "mime": "image/jpeg", "data": "<base64>" }`, maksimal 4 gambar dan `MAX_THUMBNAIL_BYTES` (45 KB) per gambar. Pembacaan pesan memuat `images` hanya untuk pesan yang punya gambar.

## POST /v1/auth/email/start

Tanpa login. Mengirim kode 6 digit ke email.

```json
{ "email": "nama@email.com" }
```

Respons: `{ "ok": true, "expires_in": 600, "resend_in": 60 }`.

## POST /v1/auth/email/verify

Tanpa login. Menukar kode dengan custom token Firebase.

```json
{ "email": "nama@email.com", "code": "123456" }
```

Respons: `{ "custom_token": "..." }`. Aplikasi memanggil `signInWithCustomToken` dengan token ini. Akun dibuat otomatis (dengan email terverifikasi) kalau belum ada.

## Kode error

| Status | `code` | Arti |
| --- | --- | --- |
| 400 | `invalid_email` | Format email salah |
| 400 | `code_invalid` | Kode salah (pesan memuat sisa percobaan) |
| 400 | `code_expired` | Kode kedaluwarsa, sudah dipakai, atau belum diminta |
| 400 | `unknown_provider`, `unknown_model` | Pilihan tidak ada di server |
| 401 | `unauthorized`, `invalid_token` | Belum login atau token tidak valid |
| 403 | `email_not_verified`, `user_disabled`, `guest_disabled` | Email belum terverifikasi, akun dinonaktifkan, atau mode tamu dimatikan |
| 422 | `invalid_request`, `message_too_long` | Isi permintaan tidak valid |
| 422 | `invalid_image`, `too_many_images` | Foto bukan JPEG, PNG, atau WebP yang sah, atau jumlahnya melebihi batas |
| 422 | `model_no_vision` | Foto dikirim ke model yang hanya membaca teks |
| 422 | `images_rejected` | Penyedia AI menolak foto (model tanpa dukungan gambar, atau foto tidak terbaca) |
| 413 | `image_too_large`, `images_too_large` | Satu foto atau total foto melebihi batas ukuran |
| 429 | `rate_limited` | Batas permintaan per menit (per pengguna, atau per IP untuk tamu dan login email) |
| 429 | `resend_too_soon`, `too_many_codes`, `too_many_attempts` | Batas kode email |
| 429 | `provider_rate_limited` | Kuota penyedia AI habis |
| 502 | `provider_auth`, `provider_payment`, `provider_rejected`, `provider_unavailable`, `provider_unreachable`, `provider_error`, `empty_response`, `model_not_found` | Masalah di sisi penyedia AI |
| 502 | `email_failed` | SMTP gagal mengirim |
| 404 | `message_not_found` | Pesan yang mau dinilai tidak ada |
| 503 | `no_provider`, `email_disabled`, `email_not_configured`, `auth_unavailable`, `server_misconfigured` | Server belum dikonfigurasi atau layanan login tidak terjangkau |
| 503 | `history_disabled`, `history_not_ready`, `history_unavailable` | Riwayat nonaktif (tanpa akun layanan), database Firestore belum dibuat atau belum boleh diakses, atau Firestore sementara tidak terjangkau |
| 504 | `provider_timeout` | Penyedia AI terlalu lama merespons |

Respons `429` membawa header `Retry-After` (detik).
