# API backend

Kontrak yang dipakai aplikasi. Implementasinya ada di proyek terpisah `qelvo-api` (`docs/API.md` di sana sama dengan berkas ini).

Semua endpoint di bawah `/v1` kecuali dua endpoint login email membutuhkan header:

```
Authorization: Bearer <token ID Firebase>
```

Token diverifikasi server dengan Firebase Admin SDK. Token harus punya email yang sudah terverifikasi, atau berasal dari akun tamu (Firebase Anonymous) selama `ALLOW_GUEST=true`. Tamu juga dibatasi per IP (`GUEST_RATE_LIMIT_PER_MINUTE`). Dengan `AUTH_MODE=off` (hanya uji lokal) pemeriksaan ini dilewati.

Semua error berbentuk:

```json
{ "error": { "code": "rate_limited", "message": "Terlalu banyak permintaan. Coba lagi dalam 12 detik." } }
```

`message` berbahasa Indonesia dan aman ditampilkan langsung ke pengguna. `code` untuk logika program.

## GET /health

Tanpa login.

```json
{ "status": "ok", "version": "0.1.0", "providers": ["gemini"] }
```

## GET /v1/providers

Penyedia yang punya API key di server.

```json
{
  "default_provider": "gemini",
  "providers": [
    {
      "id": "gemini",
      "name": "Gemini",
      "tagline": "Google AI Studio · ada kuota gratis",
      "default_model": "gemini-3.5-flash-lite",
      "models": [{ "id": "gemini-3.5-flash-lite", "label": "Gemini 3.5 Flash-Lite" }]
    }
  ]
}
```

## POST /v1/chat

```json
{
  "messages": [
    { "role": "user", "content": "Jelaskan fotosintesis dalam dua kalimat." }
  ],
  "provider": "gemini",
  "model": "gemini-3.5-flash-lite",
  "thinking": true,
  "instruction": "standar",
  "stream": true
}
```

| Field | Keterangan |
| --- | --- |
| `messages` | 1 sampai 200 pesan, `role` `user` atau `assistant`. Pesan terakhir harus dari `user`. Server membuang pesan kosong, menggabungkan peran beruntun, dan memangkas bagian terlama (`MAX_MESSAGES`, `MAX_CONTEXT_CHARS`). Satu pesan maksimal `MAX_MESSAGE_CHARS`. |
| `provider`, `model` | Opsional. Kosong berarti bawaan server. Model harus ada di daftar server. |
| `thinking` | `true` memakai tingkat berpikir lebih tinggi (`GEMINI_EFFORT_THINKING`), `false` yang lebih cepat. |
| `instruction` | `standar`, `ringkas`, `guru`, atau `developer`. Nilai lain jatuh ke `standar`. Klien tidak bisa mengirim prompt sistem sendiri. |
| `stream` | `true` (bawaan) mengembalikan SSE, `false` mengembalikan satu JSON. |

### Respons streaming (`text/event-stream`)

Tiap event satu baris `data:` yang berisi JSON, dipisah baris kosong:

```
data: {"meta":{"provider":"gemini","provider_name":"Gemini","model":"gemini-3.5-flash-lite","model_label":"Gemini 3.5 Flash-Lite"}}

data: {"delta":"Fotosintesis adalah "}

data: {"delta":"proses ..."}

data: {"done":true}
```

Kalau penyedia menolak sebelum ada potongan pertama (kuota, key, model), respons berupa JSON error dengan status HTTP yang sesuai. Kalau gagal di tengah jawaban, event terakhir adalah `data: {"error":{"code":"...","message":"..."}}`.

### Respons tanpa streaming

```json
{ "provider": "gemini", "provider_name": "Gemini", "model": "gemini-3.5-flash-lite", "model_label": "Gemini 3.5 Flash-Lite", "content": "..." }
```

## POST /v1/auth/email/start

Tanpa login. Mengirim kode 6 digit ke email.

```json
{ "email": "nama@email.com" }
```

Respons: `{ "ok": true, "expires_in": 600, "resend_in": 60 }`.

## POST /v1/auth/email/verify

Tanpa login. Menukar kode dengan custom token Firebase.

```json
{ "email": "nama@email.com", "code": "123456" }
```

Respons: `{ "custom_token": "..." }`. Aplikasi memanggil `signInWithCustomToken` dengan token ini. Akun dibuat otomatis (dengan email terverifikasi) kalau belum ada.

## Kode error

| Status | `code` | Arti |
| --- | --- | --- |
| 400 | `invalid_email` | Format email salah |
| 400 | `code_invalid` | Kode salah (pesan memuat sisa percobaan) |
| 400 | `code_expired` | Kode kedaluwarsa, sudah dipakai, atau belum diminta |
| 400 | `unknown_provider`, `unknown_model` | Pilihan tidak ada di server |
| 401 | `unauthorized`, `invalid_token` | Belum login atau token tidak valid |
| 403 | `email_not_verified`, `user_disabled`, `guest_disabled` | Email belum terverifikasi, akun dinonaktifkan, atau mode tamu dimatikan |
| 422 | `invalid_request`, `message_too_long` | Isi permintaan tidak valid |
| 429 | `rate_limited` | Batas permintaan per menit (per pengguna, atau per IP untuk tamu dan login email) |
| 429 | `resend_too_soon`, `too_many_codes`, `too_many_attempts` | Batas kode email |
| 429 | `provider_rate_limited` | Kuota penyedia AI habis |
| 502 | `provider_auth`, `provider_payment`, `provider_rejected`, `provider_unavailable`, `provider_unreachable`, `provider_error`, `empty_response`, `model_not_found` | Masalah di sisi penyedia AI |
| 502 | `email_failed` | SMTP gagal mengirim |
| 503 | `no_provider`, `email_disabled`, `email_not_configured`, `auth_unavailable` | Server belum dikonfigurasi atau layanan login tidak terjangkau |
| 504 | `provider_timeout` | Penyedia AI terlalu lama merespons |

Respons `429` membawa header `Retry-After` (detik).
