# API backend

Semua endpoint di bawah `/v1` kecuali endpoint login email dan hapus akun lewat kode membutuhkan header:

```
Authorization: Bearer <token ID Firebase>
```

Token diverifikasi server dengan Firebase Admin SDK. Token harus punya email yang sudah terverifikasi: login Google atau login kode email. Akun tamu (Firebase Anonymous) sudah ditiadakan dan ditolak 403 `guest_disabled`. Dengan `AUTH_MODE=off` (hanya uji lokal) pemeriksaan ini dilewati.

Semua error berbentuk:

```json
{ "error": { "code": "rate_limited", "message": "Terlalu banyak permintaan. Coba lagi dalam 12 detik." } }
```

`message` berbahasa Indonesia dan aman ditampilkan langsung ke pengguna. `code` untuk logika program.

## GET /health

Tanpa login. Selalu menjawab 200 selama server hidup, bahkan kalau pengaturannya salah.

```json
{
  "status": "ok",
  "version": "0.2.0",
  "providers": ["gemini"],
  "auth": "ready",
  "email_login": false,
  "history": true,
  "daily_limit": 100,
  "problems": []
}
```

`status` bernilai `ok` atau `degraded`. `auth` bernilai `ready` (login Firebase aktif), `off` (`AUTH_MODE=off`), atau `error` (login gagal disiapkan; endpoint berlogin menjawab 503 `server_misconfigured`). `history` bernilai `true` kalau penyimpanan riwayat aktif (butuh akun layanan Firebase di server). `problems` berisi penjelasan singkat tanpa nilai rahasia, misalnya variabel yang belum diisi. Kalau `HEALTH_TOKEN` diisi, hanya `status` dan `version` yang diberikan kepada permintaan tanpa header `X-Health-Token` yang cocok; selebihnya khusus pemilik server.

## GET /v1/providers

Penyedia yang punya API key di server.

```json
{
  "default_provider": "gemini",
  "providers": [
    {
      "id": "gemini",
      "name": "Gemini",
      "tagline": "Google AI Studio · ada kuota gratis",
      "default_model": "gemini-3.5-flash-lite",
      "models": [{ "id": "gemini-3.5-flash-lite", "label": "Gemini 3.5 Flash-Lite", "vision": true, "web_search": true }]
    }
  ]
}
```

`vision` bernilai `false` untuk model yang hanya membaca teks (ditandai `|teks` di `GEMINI_MODELS` atau `OPENROUTER_MODELS`). Aplikasi memakainya untuk menyembunyikan pilihan lampiran foto, dan server menolak foto untuk model seperti itu.

`web_search` bernilai `true` untuk model yang boleh menjawab dengan pencarian web (ditandai `|cari` di `GEMINI_MODELS` atau `OPENROUTER_MODELS`). Selalu ada di respons server ini; klien boleh menganggap kolom yang tidak ada sebagai `false`. Aplikasi memakainya untuk menyalakan sakelar Cari web: selama tidak ada satu model pun yang `true`, ia menampilkan Cari web sebagai "Segera hadir" dan tidak pernah mengirim kolom baru ke server.

## POST /v1/chat

```json
{
  "messages": [
    { "role": "user", "content": "Jelaskan fotosintesis dalam dua kalimat." }
  ],
  "provider": "gemini",
  "model": "gemini-3.5-flash-lite",
  "thinking": true,
  "instruction": "standar",
  "stream": true
}
```

| Field | Keterangan |
| --- | --- |
| `messages` | 1 sampai 200 pesan, `role` `user` atau `assistant`. Pesan terakhir harus dari `user`. Server membuang pesan kosong (pesan tanpa teks tetap dipakai kalau membawa foto), menggabungkan peran beruntun beserta fotonya, dan memangkas bagian terlama (`MAX_MESSAGES`, `MAX_CONTEXT_CHARS`). Satu pesan maksimal `MAX_MESSAGE_CHARS`. |
| `messages[].images` | Opsional, hanya untuk pesan `user`. Daftar foto, lihat bagian Foto di bawah. |
| `provider`, `model` | Opsional. Kosong berarti bawaan server. Model harus ada di daftar server. |
| `thinking` | `true` memakai tingkat berpikir lebih tinggi (`GEMINI_EFFORT_THINKING`), `false` yang lebih cepat. |
| `instruction` | `standar`, `ringkas`, `guru`, atau `developer`. Nilai lain jatuh ke `standar`. Klien tidak bisa mengirim prompt sistem sendiri. |
| `custom_instruction` | Opsional, catatan pribadi dari pengaturan aplikasi ("panggil aku Mutu, jawab santai"). Server memangkasnya ke `CUSTOM_INSTRUCTION_CHARS` (500), membuang karakter kontrol, lalu menaruhnya di blok tersendiri di prompt sistem sebagai preferensi yang tidak mengalahkan aturan produk. |
| `web_search` | Opsional, bawaan `false`. `true` selalu mencari. `"auto"` menyerahkan penilaian ke server: mencari hanya kalau pesan terakhir butuh informasi terbaru atau memintanya, dan menjawab biasa kalau tidak. Lihat bagian Cari web di bawah. |
| `stream` | `true` (bawaan) mengembalikan SSE, `false` mengembalikan satu JSON. |

### Foto

Pesan `user` boleh membawa foto:

```json
{
  "messages": [
    {
      "role": "user",
      "content": "Jelaskan isi foto ini.",
      "images": [{ "mime": "image/jpeg", "data": "<base64 polos, tanpa awalan data:>" }]
    }
  ]
}
```

| Aturan | Nilai bawaan | Variabel |
| --- | --- | --- |
| Jenis | `image/jpeg`, `image/png`, `image/webp`. Server memeriksa tanda di awal berkas, bukan hanya `mime` | |
| Jumlah per permintaan | 4 | `MAX_IMAGES_PER_REQUEST` |
| Ukuran satu foto (setelah base64 dibuka) | 1,5 MB | `MAX_IMAGE_BYTES` |
| Total semua foto | 3 MB | `MAX_IMAGES_TOTAL_BYTES` |

Foto dikirim ke penyedia AI sebagai bagian `image_url` berisi data URL, tidak disimpan, dan tidak dicatat di log. Model harus punya `vision: true` di `/v1/providers`. Di Vercel badan permintaan dibatasi 4,5 MB, dan base64 menambah sepertiga ukuran, jadi total 3 MB aman. Kalau batas itu terlewati, Vercel menjawab 413 `FUNCTION_PAYLOAD_TOO_LARGE` sebelum sampai ke aplikasi ini, tanpa badan JSON.

### Cari web

```
QELVO AI
   |
Deteksi pencarian  (hanya untuk "auto")
   |
+--+---------------------+
|                        |
Gemini                   OpenRouter
Google Search Grounding  Plugin pencarian web
|                        |
+--+---------------------+
   |
Jawaban AI
   |
Sumber dan tautan
```

`web_search` menentukan apakah jalur pencarian dipakai:

| Nilai | Perilaku |
| --- | --- |
| `false` (bawaan) | Jawaban biasa. |
| `true` | Selalu mencari. Syaratnya: model punya `web_search: true` di `/v1/providers` (kalau tidak, 422 `model_no_web_search`), dan tidak ada foto di pesan yang dikirim, termasuk foto di riwayat (kalau ada, 422 `invalid_request`). |
| `"auto"` | Server menilai pesan terakhir (`app/search_detect.py`). Mencari kalau modelnya mendukung, tidak ada foto, dan pesannya meminta pencarian secara eksplisit ("cari di web", "sertakan sumber"), menyangkut topik yang berubah tiap saat (cuaca, kurs, harga emas, skor, berita, versi terbaru), atau berupa pertanyaan dengan kata waktu ("hari ini", "terbaru", "saat ini") atau tahun yang baru berlalu. Selain itu menjawab biasa. Tidak pernah menolak: model tanpa dukungan atau pesan berisi foto hanya melewati pencarian. Nilai selain `false`, `true`, dan `"auto"` ditolak 422 `invalid_request`. |

Penyedia yang dipakai ikut model yang dipilih:

- **Gemini** mencari lewat Interactions API dengan tool `google_search` (Google Search Grounding). Pencarian selesai dulu di server, baru jawabannya dikirim utuh sebagai satu `delta`. `thinking` tidak dipakai pada jalur ini.
- **OpenRouter** mencari lewat plugin `web` (`plugins: [{"id": "web", "max_results": 5}]`). Hasil pencarian disuntikkan ke prompt di sisi OpenRouter, lalu jawabannya mengalir seperti biasa. Tiap hasil memotong kredit akun OpenRouter, jadi kredit habis dijawab 502 `provider_payment`.

Kalau pencarian dipakai, event `meta` memuat `"web_search": true`, dan jawabannya ditutup dengan event `sources`. Pencarian bisa makan waktu, jadi dengan `stream: true` aliran langsung dibuka dan `meta` dikirim lebih dulu (aplikasi menampilkan "Mencari di web…"), lalu baris komentar `: keep-alive` dikirim tiap beberapa detik selama menunggu. Karena status HTTP sudah terkirim, penyedia yang gagal (kuota, key, model menolak pencarian) datang sebagai event `error`. Dengan `stream: false` kegagalan tetap berupa status HTTP yang tepat.

`sources` berisi paling banyak 8 sumber yang dikutip jawaban: `{ "title": "...", "url": "https://..." }`, tanpa alamat ganda, hanya `http` atau `https`, `title` maksimal 120 karakter (boleh kosong, dan sebaiknya berisi nama situs atau judul halaman, bukan alamat), `url` maksimal 2048 karakter tanpa spasi. Server menerapkan aturan ini sebelum mengirim, jadi sumber yang diteruskan klien ke riwayat selalu diterima.

### Respons streaming (`text/event-stream`)

Tiap event satu baris `data:` yang berisi JSON, dipisah baris kosong:

```
data: {"meta":{"provider":"gemini","provider_name":"Gemini","model":"gemini-3.5-flash-lite","model_label":"Gemini 3.5 Flash-Lite"}}

data: {"delta":"Fotosintesis adalah "}

data: {"delta":"proses ..."}

data: {"sources":[{"title":"kompas.com","url":"https://www.kompas.com/..."}]}

data: {"done":true}
```

Event `sources` hanya ada pada jawaban hasil pencarian web, sekali, setelah potongan teks terakhir dan sebelum `done`. Pada jawaban seperti itu `meta` juga memuat `"web_search": true`.

Kalau penyedia menolak sebelum ada potongan pertama (kuota, key, model) dan tidak ada model cadangan yang bisa menjawab, respons berupa JSON error dengan status HTTP yang sesuai (kecuali jalur pencarian, lihat di atas). Kalau gagal di tengah jawaban, event terakhir adalah `data: {"error":{"code":"...","message":"..."}}`.

Kalau pertanyaan yang sama baru saja dijawab dengan pencarian (`SEARCH_CACHE_TTL_SECONDS`, bawaan 15 menit), hasilnya dikirim ulang dari cache tanpa mencari lagi: `meta` memuat `"cached": true` di samping `"web_search": true`, lalu teks, `sources`, dan `done` seperti biasa. Aplikasi memakai `cached` supaya tidak menampilkan "Mencari di web…". Permintaan dengan `custom_instruction`, foto, atau teks panjang tidak pernah memakai cache.

Jawaban tanpa pencarian juga bisa membuka aliran lebih awal: kalau potongan pertama belum datang dalam `STREAM_GRACE_SECONDS` (bawaan 3 detik, biasanya karena model sedang berpikir), `meta` dikirim lebih dulu dan baris `: keep-alive` menjaga koneksi selama menunggu, sama seperti pada pencarian. Penyedia yang gagal sesudah titik itu datang sebagai event `error`; yang gagal lebih cepat tetap berupa status HTTP.

Bila jawaban datang dari model cadangan di jalur pencarian, event `meta` kedua menyusul dengan `provider`, `model`, dan `model_label` model yang benar-benar menjawab. Klien memakai `meta` terakhir yang diterima.

### Batas harian dan model cadangan

- **Kuota harian** (`DAILY_LIMIT_PER_USER`, bawaan 100): tiap `/v1/chat` dan `/v1/title` memakai satu jatah, dihitung per akun di Firestore (`users/{uid}/usage/{yyyymmdd}`) jadi berlaku untuk semua instance. Hari berganti pukul 00.00 zona `UTC_OFFSET_HOURS` (bawaan 7, WIB). Kalau habis: 429 `daily_limit` dengan `Retry-After` sampai pergantian hari. Jatah dikembalikan bila permintaan gagal sebelum ada jawaban. `0` mematikan kuota. Kalau Firestore tidak terjangkau, kuota dilewati dan dicatat di log.
- **Model cadangan** (`FALLBACK_ENABLED`, `MAX_FALLBACKS`): bila penyedia menolak sebelum ada jawaban karena kuota habis, penyedia bermasalah, model hilang, atau key/kredit ditolak, server mencoba model lain: model lain di penyedia yang sama dulu (kuota tiap model biasanya terpisah), lalu penyedia lain. Hanya model yang memenuhi syarat permintaan (foto, pencarian web) yang dicoba. Kesalahan yang menyangkut isi permintaan (foto ditolak, pesan ditolak) dan waktu tunggu tidak dialihkan. Model yang menjawab tertulis di `meta`.

### Respons tanpa streaming

```json
{ "provider": "gemini", "provider_name": "Gemini", "model": "gemini-3.5-flash-lite", "model_label": "Gemini 3.5 Flash-Lite", "content": "...", "sources": [{ "title": "kompas.com", "url": "https://www.kompas.com/..." }] }
```

`sources` dan `web_search: true` hanya ada untuk jawaban hasil pencarian web.

## Riwayat chat

Riwayat disimpan di Firestore (`users/{uid}/conversations/{id}` dan `.../messages/{id}`) lewat Admin SDK. Aturan `firestore.rules` menolak semua akses dari aplikasi, jadi endpoint di bawah satu-satunya jalan. Semuanya butuh login, hanya menyentuh data milik pemilik token, dan dibatasi `HISTORY_RATE_LIMIT_PER_MINUTE`. ID percakapan dan pesan: huruf, angka, `_`, atau `-`, maksimal 64 karakter. Cap waktu dalam milidetik sejak epoch (UTC).

| Endpoint | Fungsi |
| --- | --- |
| `GET /v1/conversations?limit=300` | Daftar percakapan, terbaru dulu (`limit` 1 sampai 500) |
| `DELETE /v1/conversations` | Hapus semua percakapan milik akun |
| `GET /v1/conversations/{id}/messages` | Pesan satu percakapan, urut waktu |
| `PUT /v1/conversations/{id}/messages/{mid}` | Simpan satu pesan sekaligus memperbarui data percakapan |
| `PATCH /v1/conversations/{id}` | Ganti nama dan/atau sematkan: `{"title": "Nama baru", "pinned": true}` (isi minimal salah satu; `title` 1 sampai 200 karakter). `updated_at` tidak berubah, jadi urutan daftar tetap. 404 `conversation_not_found` kalau tidak ada |
| `PATCH /v1/conversations/{id}/messages/{mid}` | Ubah penilaian: `{"rating": 1}` (`1`, `0`, atau `-1`) |
| `DELETE /v1/conversations/{id}/messages/{mid}` | Hapus satu pesan |
| `DELETE /v1/conversations/{id}` | Hapus satu percakapan beserta semua pesannya |

```json
// PUT /v1/conversations/c1/messages/m1
{
  "conversation": { "title": "Fotosintesis", "model_label": "Gemini 3.5 Flash-Lite", "preview": "", "created_at": 1767225600000 },
  "message": { "role": "user", "content": "Jelaskan fotosintesis.", "created_at": 1767225600000, "rating": 0 }
}
```

`model_label` dan `preview` yang kosong tidak menimpa nilai yang sudah tersimpan. `updated_at` percakapan diisi server saat menyimpan. Respons daftar:

```json
{ "conversations": [{ "id": "c1", "title": "Fotosintesis", "model_label": "Gemini 3.5 Flash-Lite", "preview": "", "created_at": 1767225600000, "updated_at": 1767225660000, "pinned": false }] }
```

Respons pesan: `{ "messages": [{ "id": "m1", "role": "user", "content": "...", "created_at": 1767225600000, "rating": 0 }] }`. Penyimpanan, penghapusan, dan penilaian menjawab `{ "ok": true }`.

Pesan `user` yang membawa foto boleh menyertakan `images` di `message` saat disimpan: gambar kecil (bukan foto aslinya) dengan bentuk yang sama, `{ "mime": "image/jpeg", "data": "<base64>" }`, maksimal 4 gambar dan `MAX_THUMBNAIL_BYTES` (45 KB) per gambar. Pembacaan pesan memuat `images` hanya untuk pesan yang punya gambar.

Pesan `assistant` hasil pencarian web boleh menyertakan `sources` di `message` saat disimpan: daftar `{ "title": "...", "url": "https://..." }` dengan aturan yang sama seperti di bagian Cari web (maksimal 8, `title` maksimal 120 karakter, `url` hanya `http` atau `https`, maksimal 2048 karakter, tanpa spasi). Bentuk yang melanggar aturan ditolak 422 `invalid_request`. Pembacaan pesan memuat `sources` hanya untuk pesan yang punya.

## POST /v1/auth/email/start

Tanpa login. Mengirim kode 6 digit ke email.

```json
{ "email": "nama@email.com" }
```

Respons: `{ "ok": true, "expires_in": 600, "resend_in": 60 }`.

## POST /v1/auth/email/verify

Tanpa login. Menukar kode dengan custom token Firebase.

```json
{ "email": "nama@email.com", "code": "123456" }
```

Respons: `{ "custom_token": "..." }`. Aplikasi memanggil `signInWithCustomToken` dengan token ini. Akun dibuat otomatis (dengan email terverifikasi) kalau belum ada.

## POST /v1/title

Judul pendek (maksimal 5 kata, bahasa yang sama dengan pengguna) untuk percakapan baru. Dipanggil aplikasi sekali, sesudah jawaban pertama.

```json
{ "user": "resep nasi goreng gimana?", "assistant": "Panaskan minyak, ..." }
```

Respons: `{ "title": "Resep nasi goreng" }`. Kalau model gagal atau tidak mengirim judul layak, `title` kosong (tetap 200) dan aplikasi memakai potongan pesan pertama. Memakai satu jatah harian.

## Hapus akun

Dua langkah dengan kode 6 digit yang dikirim ke email akun (berlaku untuk akun Google maupun email, selama emailnya sama). Tanpa login, jadi bisa dipakai dari aplikasi maupun dari halaman web. Butuh SMTP aktif seperti login email. Kode hapus akun terpisah dari kode masuk.

`POST /v1/account/delete/start` dengan `{ "email": "nama@email.com" }`. Isi jawabannya sama (`{ "ok": true, "expires_in": 600, "resend_in": 60 }`) untuk email yang tidak punya akun, dan email hanya dikirim bila akunnya ada, supaya isi jawaban tidak membocorkan siapa yang terdaftar. Lama responsnya masih bisa sedikit berbeda (mengirim email butuh waktu), jadi ini bukan perlindungan mutlak terhadap penebakan lewat waktu respons.

`POST /v1/account/delete/confirm` dengan `{ "email": "nama@email.com", "code": "123456" }`. Menghapus seluruh data akun di Firestore (riwayat dan kuota), lalu akun Firebase. Respons `{ "ok": true }`. Data dihapus lebih dulu: kalau penghapusan akun gagal, pengguna bisa mengulang.

`GET /hapus-akun` menyajikan halaman web yang memakai dua endpoint itu, untuk persyaratan Google Play (jalur hapus akun di luar aplikasi). Isi `SUPPORT_EMAIL` supaya alamat bantuan tampil di halaman.

## POST /v1/report

Laporan crash dari aplikasi (butuh login, dibatasi `REPORT_RATE_LIMIT_PER_HOUR` per akun).

```json
{ "kind": "crash", "message": "Null check operator used on a null value", "stack": "#0 ...", "version": "0.1.0", "platform": "android 15" }
```

`kind` `crash` atau `error`; `message` maksimal 600 karakter, `stack` 6000. Server menyimpannya ke koleksi `app_reports` di Firestore (atau ke log kalau Firestore tidak aktif) tanpa uid maupun email. Respons `{ "ok": true }`.

## Kode error

| Status | `code` | Arti |
| --- | --- | --- |
| 400 | `invalid_email` | Format email salah |
| 400 | `code_invalid` | Kode salah (pesan memuat sisa percobaan) |
| 400 | `code_expired` | Kode kedaluwarsa, sudah dipakai, atau belum diminta |
| 400 | `unknown_provider`, `unknown_model` | Pilihan tidak ada di server |
| 401 | `unauthorized`, `invalid_token` | Belum login, token tidak valid, atau akunnya sudah dihapus atau dicabut tokennya |
| 403 | `email_not_verified`, `user_disabled`, `guest_disabled` | Email belum terverifikasi, akun dinonaktifkan (efektif langsung, lihat `CHECK_REVOKED`), atau token akun tamu (sudah ditiadakan) |
| 422 | `invalid_request`, `message_too_long` | Isi permintaan tidak valid |
| 422 | `invalid_image`, `too_many_images` | Foto bukan JPEG, PNG, atau WebP yang sah, atau jumlahnya melebihi batas |
| 422 | `model_no_vision` | Foto dikirim ke model yang hanya membaca teks |
| 422 | `model_no_web_search` | `web_search: true` dikirim ke model yang tidak mendukung pencarian web |
| 422 | `images_rejected` | Penyedia AI menolak foto (model tanpa dukungan gambar, atau foto tidak terbaca) |
| 413 | `image_too_large`, `images_too_large` | Satu foto atau total foto melebihi batas ukuran |
| 429 | `rate_limited` | Batas permintaan per menit (per pengguna, atau per IP untuk login email dan hapus akun) |
| 429 | `daily_limit` | Kuota harian per akun habis (`DAILY_LIMIT_PER_USER`) |
| 429 | `resend_too_soon`, `too_many_codes`, `too_many_attempts` | Batas kode email |
| 429 | `provider_rate_limited` | Kuota penyedia AI habis |
| 502 | `provider_auth`, `provider_payment`, `provider_rejected`, `provider_unavailable`, `provider_unreachable`, `provider_error`, `empty_response`, `model_not_found`, `web_search_rejected` | Masalah di sisi penyedia AI (`web_search_rejected`: model menolak tool pencarian) |
| 502 | `email_failed` | SMTP gagal mengirim |
| 404 | `message_not_found`, `conversation_not_found` | Pesan yang mau dinilai atau percakapan yang mau diubah tidak ada |
| 503 | `no_provider`, `email_disabled`, `email_not_configured`, `auth_unavailable`, `server_misconfigured` | Server belum dikonfigurasi atau layanan login tidak terjangkau |
| 503 | `history_disabled`, `history_not_ready`, `history_unavailable` | Riwayat nonaktif (tanpa akun layanan), database Firestore belum dibuat atau belum boleh diakses, atau Firestore sementara tidak terjangkau |
| 503 | `web_search_unavailable` | Paket pencarian (`google-genai`) tidak terpasang di server |
| 504 | `provider_timeout` | Penyedia AI terlalu lama merespons |

Respons `429` membawa header `Retry-After` (detik).
