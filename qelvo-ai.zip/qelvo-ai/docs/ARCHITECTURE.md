# Arsitektur

## Komponen

| Bagian | Teknologi | Tugas |
| --- | --- | --- |
| Aplikasi | Flutter, Dart | Tampilan, login, streaming jawaban, tampilan riwayat |
| Login | Firebase Authentication | Google langsung, tamu lewat akun anonim, email lewat custom token (dimatikan sementara) |
| Riwayat | Cloud Firestore | Percakapan dan pesan per akun, hanya diakses backend |
| Backend | Python, FastAPI | Verifikasi token, batas pemakaian, riwayat chat (Admin SDK), kode email, meneruskan pesan ke penyedia AI |
| Penyedia AI | Gemini (Google AI Studio), OpenRouter | Membuat jawaban |

Penyedia AI dipanggil lewat satu adapter bergaya OpenAI (`app/providers/openai_compat.py` di proyek `qelvo-api`). Gemini dan OpenRouter hanya subkelas kecil dengan alamat dan parameter masing-masing. Menambah penyedia lain berarti menambah satu subkelas dan mendaftarkannya di `providers/__init__.py`.

## Alur satu pesan

1. Pengguna menulis pesan. Aplikasi mengirimnya ke backend untuk disimpan (`PUT /v1/conversations/{id}/messages/{mid}`, kalau "Simpan riwayat" menyala) dan mengirim beberapa pesan terakhir ke `POST /v1/chat`, keduanya dengan token ID Firebase. Kalau ada foto terlampir (dipilih lewat pemilih foto bawaan HP, dikecilkan oleh Android, lalu dirapikan dan dibersihkan dari metadata di isolate terpisah), foto itu ikut dikirim sebagai base64 di pesan itu ke `POST /v1/chat`, sedangkan yang disimpan ke riwayat hanya gambar kecilnya.
2. Backend memverifikasi token, memeriksa batas per pengguna, merapikan riwayat, lalu membuat prompt sistem: aturan dasar QELVO, nama penyedia dan model yang sedang menjawab, dan gaya pilihan pengguna dari daftar tetap.
3. Backend memanggil penyedia dengan streaming dan meneruskan potongan teks ke aplikasi sebagai SSE. Potongan pertama diambil dulu supaya penolakan awal (kuota, key) menjadi status HTTP yang benar.
4. Aplikasi menampilkan teks yang masuk. Saat selesai, jawaban disimpan lewat backend (satu kali, bukan per token). Simpan, nilai, dan hapus berjalan berurutan lewat satu antrean di aplikasi, supaya urutannya di server sama dengan di layar. Kalau aliran putus sebelum penanda selesai, aplikasi menganggapnya gagal dan menawarkan "Coba lagi", bukan menyimpan jawaban yang terpotong.

Kalau pengguna menekan berhenti atau meninggalkan layar, koneksi ke backend ditutup, dan backend menutup koneksi ke penyedia. Keluar dari aplikasi lewat tombol Home atau pindah aplikasi tidak termasuk: jawabannya tetap mengalir (bagian berikut).

## Cari web

```
QELVO AI
   |
Deteksi pencarian (server)
   |
+--+--------------------+
|                       |
Gemini                  OpenRouter
Google Search           Plugin pencarian
Grounding               web
|                       |
+--+--------------------+
   |
Jawaban AI
   |
Sumber dan tautan
```

Sakelar Cari web ada di lembar **+** dan tersimpan di perangkat (`SettingsStore.webSearch`, bawaan mati). Kalau menyala dan model terpilih `web_search: true` di `/v1/providers`, `ChatController` mengirim `web_search: "auto"`. Aplikasi tidak menilai sendiri apakah pesannya butuh pencarian; server yang menilai (`app/search_detect.py` di `qelvo-api`): permintaan eksplisit seperti "cari di web", topik yang berubah tiap saat seperti cuaca, kurs, dan berita, atau pertanyaan dengan kata waktu seperti "hari ini" dan "terbaru". Pesan yang tidak butuh pencarian dijawab seperti biasa, dan pesan yang membawa foto selalu melewatinya.

Penyedia yang mencari mengikuti model: Gemini lewat Google Search Grounding, OpenRouter lewat plugin pencarian webnya. Server menjawab seperti biasa ditambah satu event `sources`; aplikasi menyimpannya di `ChatMessage.sources`, menampilkannya sebagai tombol Sumber di dalam kartu jawaban (`SourceChips`), dan ikut menyimpannya di riwayat. `ChatSource.tryParse` hanya menerima tautan `http` dan `https`, jadi skema lain dari server tidak pernah sampai ke tombol yang bisa diketuk.

Aplikasi aman terhadap server lama: tanpa model yang mengiklankan `web_search`, barisnya tetap "Segera hadir" dan kolom baru tidak pernah dikirim. Cara menyalakan, menguji, dan batasannya ada di [WEB_SEARCH.md](WEB_SEARCH.md).

## Jawaban di latar belakang

Jawaban dialirkan oleh isolate Dart utama, jadi selama prosesnya hidup, alirannya tidak peduli aplikasi sedang terlihat atau tidak. Yang berbahaya adalah Android membekukan atau mematikan proses setelah aplikasi ditinggal. `ChatController` memberi tahu `BackgroundRun` (`lib/data/background_run.dart`) saat jawaban mulai dan berakhir:

- **Mulai:** lewat MethodChannel `com.qelvo.qelvo_ai/background` ke `MainActivity`, yang memegang wake lock berbatas 10 menit (`AnswerKeeper`) supaya CPU tidak tidur di tengah jawaban. **Tidak ada pemberitahuan selama jawaban berjalan.** Sengaja tidak memakai layanan latar depan: Android mewajibkan pemberitahuan tetap selama layanan itu hidup, sedangkan satu-satunya pemberitahuan aplikasi harus "QELVO sudah menjawab".
- **Berakhir:** wake lock dilepas. Kalau jawabannya selesai dan aplikasi sedang tidak terlihat (`paused` atau `hidden`), muncul pemberitahuan "QELVO sudah menjawab"; mengetuknya membawa aplikasi ke depan, dan pemberitahuannya hilang sendiri saat aplikasi dibuka. Isi jawaban tidak ikut karena bisa terbaca di layar kunci. Jawaban yang gagal atau dihentikan pengguna tidak memberi pemberitahuan; kegagalannya tampil di chat.
- **Tombol kembali** di layar utama menyembunyikan aplikasi (`moveTaskToBack`) selama jawaban mengalir, bukan menutupnya. Begitu jawaban selesai, tombol kembali menutup aplikasi seperti biasa.
- **Izin pemberitahuan** (Android 13 ke atas) ditanyakan sekali, saat pesan pertama dikirim. Tanpa izin itu jawaban tetap berjalan; hanya pemberitahuan "sudah menjawab" yang tidak tampil.

Kode native ada di `app/tool/android/` dan disalin oleh `setup_android.sh` ke folder `android/` yang dibuat `flutter create`.

## Pembaruan (OTA)

Pembaruan memakai GitHub Releases, tanpa server sendiri, dan semi otomatis: aplikasi memeriksa sendiri, tapi mengunduh dan memasang hanya setelah pengguna setuju. Cara merilis, persiapan, dan masalah umum ada di [OTA.md](OTA.md). Ringkasnya:

- **Sisi GitHub.** Workflow Build APK punya mode `ota`: ia membangun APK dengan nomor versi dari input (kode versinya diturunkan dari nomor itu, jadi selalu naik), menandatanganinya dengan keystore tetap, lalu menerbitkan rilis resmi `vX.Y.Z` berisi APK, berkas `.sha256`, dan catatan rilis.
- **Sisi aplikasi.** `UpdateController` memeriksa `releases/latest` saat aplikasi dibuka (paling sering sekali per 12 jam, bisa dimatikan di Pengaturan) dan membandingkannya dengan versi yang dibaca dari APK. Kalau ada yang lebih baru, lembar pembaruan menawarkannya dengan catatan rilis. Setelah pengguna menekan Perbarui, `UpdateClient` mengunduh APK dan memeriksa ukuran serta SHA-256-nya, lalu `MainActivity` membuka pemasang Android lewat `UpdateFileProvider`.
- **Keamanan.** Alamat unduhan hanya diterima kalau https di github.com milik repositori rilis; rilis tanpa checksum tidak dipasang; Android menolak APK yang tidak ditandatangani kunci yang sama dengan aplikasi terpasang; dan pemasangan tetap butuh ketukan pengguna serta izin "pasang aplikasi tak dikenal" sekali.
- **Tanpa pemberitahuan.** Pembaruan hanya tampil di dalam aplikasi, sebagai lembar. Satu-satunya pemberitahuan aplikasi tetap "QELVO sudah menjawab".

## Login

**Google.** Aplikasi memakai `FirebaseAuth.signInWithProvider(GoogleAuthProvider())`, yang membuka halaman login Google lewat Custom Tab. Tidak ada paket `google_sign_in`. Parameter `prompt=select_account` membuat pilihan akun Google selalu muncul, jadi pengguna bisa ganti akun setelah keluar. Backend menerima token dari login ini karena Google selalu memberi email terverifikasi.

Syarat di Firebase: provider Google aktif, SHA-1 dan SHA-256 tanda tangan APK terdaftar, lalu `google-services.json` diunduh ulang (berkas yang benar memuat entri `oauth_client`). Workflow Build APK memberi peringatan kalau `oauth_client` masih kosong.

**Tamu.** `FirebaseAuth.signInAnonymously()` membuat akun anonim: ada uid dan token ID, tanpa email. Backend menerima token itu (klaim `firebase.sign_in_provider` bernilai `anonymous`) selama `ALLOW_GUEST=true` dan membatasi tamu per IP, karena akun anonim bisa dibuat ulang tanpa batas. Riwayatnya tersimpan di `users/{uid}` seperti akun lain. Akun tamu tidak bisa dimasuki lagi setelah keluar, jadi saat tamu menekan Keluar aplikasi menghapus riwayatnya, lalu akun anonimnya di Firebase.

**Email dengan kode.** Firebase tidak punya kode OTP email bawaan, jadi alurnya dibuat di backend:

1. `POST /v1/auth/email/start`: backend membuat kode 6 digit, menyimpan hash HMAC-nya (dengan `CODE_PEPPER`) di Firestore koleksi `email_codes`, dan mengirim emailnya lewat SMTP.
2. `POST /v1/auth/email/verify`: kalau kode benar (belum kedaluwarsa, belum melewati batas percobaan), backend menghapus kodenya, membuat atau memperbarui akun Firebase dengan email terverifikasi, lalu mengembalikan custom token.
3. Aplikasi memanggil `signInWithCustomToken`. Sesudah itu alurnya sama dengan login Google.

Kalau email yang sama nanti dipakai masuk dengan Google, perilakunya mengikuti pengaturan "satu akun per email" di Firebase Authentication.

## Model data Firestore

```
users/{uid}/conversations/{conversationId}
    title, modelLabel, preview, createdAt, updatedAt
users/{uid}/conversations/{conversationId}/messages/{messageId}
    role ("user" | "assistant"), content, createdAt, rating (-1, 0, 1),
    images (opsional: daftar gambar kecil {mime, data base64} dari foto yang dilampirkan)

email_codes/{sha256(email)}        // hanya diakses backend
    code_hash, expires_at, attempts, sent_at, window_start, sent_in_window
```

`firestore.rules` berisi tolak-semua: tidak ada klien (aplikasi, browser) yang boleh membaca atau menulis Firestore. Semua akses lewat backend dengan Admin SDK, yang tidak terkena aturan itu, dan backend hanya menyentuh `users/{uid}` milik pemilik token. Karena itu backend wajib punya akun layanan Firebase (`FIREBASE_CREDENTIALS_JSON`) agar riwayat jalan.

Aplikasi tidak memakai SQLite dan tidak menyimpan riwayat di perangkat. Daftar percakapan diambil dari backend tiap kali drawer dibuka dan setelah ada perubahan; kalau pemuatan gagal, daftar terakhir tetap tampil.

## Keamanan

- Server memeriksa token di setiap panggilan chat, katalog, dan riwayat. Gerbang login di aplikasi bukan satu-satunya penjaga.
- Firestore tertutup untuk semua klien (`firestore.rules` tolak-semua). Satu-satunya jalan ke data adalah backend, yang membatasi tiap permintaan ke `uid` pemilik token.
- Klien tidak bisa mengirim prompt sistem. Gaya jawaban hanya dipilih dari daftar tetap, dan riwayat chat diperlakukan sebagai konteks, bukan perintah.
- API key penyedia dan akun layanan hanya ada di environment variable server.
- Batas pemakaian: per pengguna untuk chat dan (terpisah) riwayat, per IP untuk tamu dan login email, per email untuk kode. Pembatas ada di memori satu proses.
- Isi pesan tidak dicatat di log server. Penyedia hosting masih bisa mencatat metadata permintaan.
- Kode email: acak kriptografis, disimpan sebagai HMAC, sekali pakai, kedaluwarsa, dan jumlah salah ketik dibatasi.

## Batasan yang diketahui

- Jawaban hanya selamat selama aplikasinya hidup di latar belakang. Tanpa layanan latar depan (pilihan sengaja, supaya tidak ada pemberitahuan selama menjawab), Android bisa memutus aliran jawaban saat layar mati cukup lama, saat penghemat baterai atau penghemat data menyala, atau saat sistem mematikan proses aplikasi. Kalau pengguna menggeser aplikasi dari daftar terbaru, mesin Flutter mati dan aliran jawaban ikut putus; server tidak melanjutkannya.
- Sebagian merek HP membatasi aplikasi di latar belakang lebih keras daripada Android standar. Kalau jawaban sering putus saat layar mati, matikan penghemat baterai untuk QELVO di pengaturan HP. Kalau itu belum cukup, layanan latar depan bisa dipasang kembali, dengan harga satu pemberitahuan kecil selama QELVO menjawab.
- Pembaruan lewat aplikasi hanya membaca repositori publik tanpa token, dan Android tidak mengizinkan pemasangan diam-diam, jadi tiap pembaruan butuh satu ketukan pengguna di pemasang sistem.
- Pembatas di memori tidak dibagi antar instance server.
- Pencarian riwayat hanya di judul dan cuplikan jawaban terakhir.
- Daftar riwayat tidak lagi tersinkron otomatis (tanpa listener Firestore). Perubahan dari perangkat lain muncul saat drawer dibuka lagi. Tanpa koneksi, daftar terakhir yang dimuat tetap tampil, tetapi percakapan lama tidak bisa dibuka.
- Ekspor menyalin ke clipboard (maksimal sekitar 300 ribu karakter), bukan berbagi berkas.
- Foto didukung, tetapi berkas dan suara belum. Foto asli tidak disimpan: percakapan lama yang dibuka dari riwayat hanya menampilkan gambar kecil, dan fotonya tidak dikirim ulang ke model.
