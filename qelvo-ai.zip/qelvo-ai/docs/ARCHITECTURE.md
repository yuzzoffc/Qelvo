# Arsitektur

## Komponen

| Bagian | Teknologi | Tugas |
| --- | --- | --- |
| Aplikasi | Flutter, Dart | Tampilan, login, streaming jawaban, tampilan riwayat |
| Login | Firebase Authentication | Google langsung, tamu lewat akun anonim, email lewat custom token (dimatikan sementara) |
| Riwayat | Cloud Firestore | Percakapan dan pesan per akun, hanya diakses backend |
| Backend | Python, FastAPI | Verifikasi token, batas pemakaian, riwayat chat (Admin SDK), kode email, meneruskan pesan ke penyedia AI |
| Penyedia AI | Gemini (Google AI Studio), OpenRouter | Membuat jawaban |

Penyedia AI dipanggil lewat satu adapter bergaya OpenAI (`app/providers/openai_compat.py` di proyek `qelvo-api`). Gemini dan OpenRouter hanya subkelas kecil dengan alamat dan parameter masing-masing. Menambah penyedia lain berarti menambah satu subkelas dan mendaftarkannya di `providers/__init__.py`.

## Alur satu pesan

1. Pengguna menulis pesan. Aplikasi mengirimnya ke backend untuk disimpan (`PUT /v1/conversations/{id}/messages/{mid}`, kalau "Simpan riwayat" menyala) dan mengirim beberapa pesan terakhir ke `POST /v1/chat`, keduanya dengan token ID Firebase. Kalau ada foto terlampir (dipilih lewat pemilih foto bawaan HP, dikecilkan oleh Android, lalu dirapikan dan dibersihkan dari metadata di isolate terpisah), foto itu ikut dikirim sebagai base64 di pesan itu ke `POST /v1/chat`, sedangkan yang disimpan ke riwayat hanya gambar kecilnya.
2. Backend memverifikasi token, memeriksa batas per pengguna, merapikan riwayat, lalu membuat prompt sistem: aturan dasar QELVO, nama penyedia dan model yang sedang menjawab, dan gaya pilihan pengguna dari daftar tetap.
3. Backend memanggil penyedia dengan streaming dan meneruskan potongan teks ke aplikasi sebagai SSE. Potongan pertama diambil dulu supaya penolakan awal (kuota, key) menjadi status HTTP yang benar.
4. Aplikasi menampilkan teks yang masuk. Saat selesai, jawaban disimpan lewat backend (satu kali, bukan per token). Simpan, nilai, dan hapus berjalan berurutan lewat satu antrean di aplikasi, supaya urutannya di server sama dengan di layar. Kalau aliran putus sebelum penanda selesai, aplikasi menganggapnya gagal dan menawarkan "Coba lagi", bukan menyimpan jawaban yang terpotong.

Kalau pengguna menekan berhenti atau meninggalkan layar, koneksi ke backend ditutup, dan backend menutup koneksi ke penyedia. Keluar dari aplikasi lewat tombol Home atau pindah aplikasi tidak termasuk: jawabannya tetap mengalir (bagian berikut).

## Jawaban di latar belakang

Jawaban dialirkan oleh isolate Dart utama, jadi selama prosesnya hidup, alirannya tidak peduli aplikasi sedang terlihat atau tidak. Yang berbahaya adalah Android membekukan atau mematikan proses setelah aplikasi ditinggal. Karena itu `ChatController` memberi tahu `BackgroundRun` (`lib/data/background_run.dart`) saat jawaban mulai dan berakhir:

- **Mulai:** lewat MethodChannel `com.qelvo.qelvo_ai/background` ke `MainActivity`, yang menyalakan `AnswerService`, layanan latar depan bertipe `dataSync`. Layanan itu menampilkan pemberitahuan "QELVO sedang menjawab" ("sedang berpikir" bila mode Berpikir menyala) dan memegang wake lock berbatas 10 menit. Di Android 12 ke atas pemberitahuannya baru tampil setelah sekitar 10 detik, jadi jawaban singkat tidak berkedip.
- **Berakhir:** layanan dihentikan. Kalau aplikasi sedang tidak terlihat (`paused` atau `hidden`) dan jawabannya selesai atau gagal, muncul pemberitahuan "QELVO sudah menjawab" atau "Jawaban QELVO gagal"; mengetuknya membawa aplikasi ke depan. Isi jawaban tidak ikut di pemberitahuan karena bisa terbaca di layar kunci. Berhenti oleh pengguna tidak memberi pemberitahuan, dan pemberitahuan hilang sendiri saat aplikasi dibuka lagi.
- **Tombol kembali** di layar utama menyembunyikan aplikasi (`moveTaskToBack`) selama jawaban mengalir, bukan menutupnya. Begitu jawaban selesai, tombol kembali menutup aplikasi seperti biasa.
- **Izin pemberitahuan** (Android 13 ke atas) ditanyakan sekali, saat pesan pertama dikirim. Tanpa izin itu layanan tetap melindungi jawaban; hanya pemberitahuan "sudah menjawab" yang tidak tampil.

Kode native ada di `app/tool/android/` dan disalin oleh `setup_android.sh` ke folder `android/` yang dibuat `flutter create`. Menghentikan layanan sengaja tidak lewat `stopService`: menghentikan layanan latar depan sebelum ia memanggil `startForeground` membuat Android menutup aplikasi, dan jawaban yang gagal seketika (misalnya tanpa sesi) bisa berakhir lebih cepat daripada layanannya siap. `AnswerService.stop()` mengingat permintaan berhenti itu dan menjalankannya setelah layanan siap.

## Login

**Google.** Aplikasi memakai `FirebaseAuth.signInWithProvider(GoogleAuthProvider())`, yang membuka halaman login Google lewat Custom Tab. Tidak ada paket `google_sign_in`. Parameter `prompt=select_account` membuat pilihan akun Google selalu muncul, jadi pengguna bisa ganti akun setelah keluar. Backend menerima token dari login ini karena Google selalu memberi email terverifikasi.

Syarat di Firebase: provider Google aktif, SHA-1 dan SHA-256 tanda tangan APK terdaftar, lalu `google-services.json` diunduh ulang (berkas yang benar memuat entri `oauth_client`). Workflow Build APK memberi peringatan kalau `oauth_client` masih kosong.

**Tamu.** `FirebaseAuth.signInAnonymously()` membuat akun anonim: ada uid dan token ID, tanpa email. Backend menerima token itu (klaim `firebase.sign_in_provider` bernilai `anonymous`) selama `ALLOW_GUEST=true` dan membatasi tamu per IP, karena akun anonim bisa dibuat ulang tanpa batas. Riwayatnya tersimpan di `users/{uid}` seperti akun lain. Akun tamu tidak bisa dimasuki lagi setelah keluar, jadi saat tamu menekan Keluar aplikasi menghapus riwayatnya, lalu akun anonimnya di Firebase.

**Email dengan kode.** Firebase tidak punya kode OTP email bawaan, jadi alurnya dibuat di backend:

1. `POST /v1/auth/email/start`: backend membuat kode 6 digit, menyimpan hash HMAC-nya (dengan `CODE_PEPPER`) di Firestore koleksi `email_codes`, dan mengirim emailnya lewat SMTP.
2. `POST /v1/auth/email/verify`: kalau kode benar (belum kedaluwarsa, belum melewati batas percobaan), backend menghapus kodenya, membuat atau memperbarui akun Firebase dengan email terverifikasi, lalu mengembalikan custom token.
3. Aplikasi memanggil `signInWithCustomToken`. Sesudah itu alurnya sama dengan login Google.

Kalau email yang sama nanti dipakai masuk dengan Google, perilakunya mengikuti pengaturan "satu akun per email" di Firebase Authentication.

## Model data Firestore

```
users/{uid}/conversations/{conversationId}
    title, modelLabel, preview, createdAt, updatedAt
users/{uid}/conversations/{conversationId}/messages/{messageId}
    role ("user" | "assistant"), content, createdAt, rating (-1, 0, 1),
    images (opsional: daftar gambar kecil {mime, data base64} dari foto yang dilampirkan)

email_codes/{sha256(email)}        // hanya diakses backend
    code_hash, expires_at, attempts, sent_at, window_start, sent_in_window
```

`firestore.rules` berisi tolak-semua: tidak ada klien (aplikasi, browser) yang boleh membaca atau menulis Firestore. Semua akses lewat backend dengan Admin SDK, yang tidak terkena aturan itu, dan backend hanya menyentuh `users/{uid}` milik pemilik token. Karena itu backend wajib punya akun layanan Firebase (`FIREBASE_CREDENTIALS_JSON`) agar riwayat jalan.

Aplikasi tidak memakai SQLite dan tidak menyimpan riwayat di perangkat. Daftar percakapan diambil dari backend tiap kali drawer dibuka dan setelah ada perubahan; kalau pemuatan gagal, daftar terakhir tetap tampil.

## Keamanan

- Server memeriksa token di setiap panggilan chat, katalog, dan riwayat. Gerbang login di aplikasi bukan satu-satunya penjaga.
- Firestore tertutup untuk semua klien (`firestore.rules` tolak-semua). Satu-satunya jalan ke data adalah backend, yang membatasi tiap permintaan ke `uid` pemilik token.
- Klien tidak bisa mengirim prompt sistem. Gaya jawaban hanya dipilih dari daftar tetap, dan riwayat chat diperlakukan sebagai konteks, bukan perintah.
- API key penyedia dan akun layanan hanya ada di environment variable server.
- Batas pemakaian: per pengguna untuk chat dan (terpisah) riwayat, per IP untuk tamu dan login email, per email untuk kode. Pembatas ada di memori satu proses.
- Isi pesan tidak dicatat di log server. Penyedia hosting masih bisa mencatat metadata permintaan.
- Kode email: acak kriptografis, disimpan sebagai HMAC, sekali pakai, kedaluwarsa, dan jumlah salah ketik dibatasi.

## Batasan yang diketahui

- Jawaban hanya selamat selama aplikasinya hidup di latar belakang. Kalau pengguna menggeser aplikasi dari daftar terbaru atau sistem mematikannya, mesin Flutter mati dan aliran jawaban ikut putus; server tidak melanjutkannya. Pemberitahuan "sedang menjawab" ikut dihapus pada kasus itu.
- Sebagian merek HP membatasi aplikasi di latar belakang lebih keras daripada Android standar, bahkan untuk layanan latar depan. Kalau jawaban sering putus saat layar mati, matikan penghemat baterai untuk QELVO di pengaturan HP.
- Pembatas di memori tidak dibagi antar instance server.
- Pencarian riwayat hanya di judul dan cuplikan jawaban terakhir.
- Daftar riwayat tidak lagi tersinkron otomatis (tanpa listener Firestore). Perubahan dari perangkat lain muncul saat drawer dibuka lagi. Tanpa koneksi, daftar terakhir yang dimuat tetap tampil, tetapi percakapan lama tidak bisa dibuka.
- Ekspor menyalin ke clipboard (maksimal sekitar 300 ribu karakter), bukan berbagi berkas.
- Foto didukung, tetapi berkas dan suara belum. Foto asli tidak disimpan: percakapan lama yang dibuka dari riwayat hanya menampilkan gambar kecil, dan fotonya tidak dikirim ulang ke model.
