# Arsitektur

## Komponen

| Bagian | Teknologi | Tugas |
| --- | --- | --- |
| Aplikasi | Flutter, Dart | Tampilan, login, streaming jawaban, riwayat |
| Login | Firebase Authentication | Google langsung, email lewat custom token |
| Riwayat | Cloud Firestore | Percakapan dan pesan per akun |
| Backend | Python, FastAPI | Verifikasi token, batas pemakaian, kode email, meneruskan pesan ke penyedia AI |
| Penyedia AI | Gemini (Google AI Studio), OpenRouter | Membuat jawaban |

Penyedia AI dipanggil lewat satu adapter bergaya OpenAI (`backend/app/providers/openai_compat.py`). Gemini dan OpenRouter hanya subkelas kecil dengan alamat dan parameter masing-masing. Menambah penyedia lain berarti menambah satu subkelas dan mendaftarkannya di `providers/__init__.py`.

## Alur satu pesan

1. Pengguna menulis pesan. Aplikasi menyimpannya ke Firestore (kalau "Simpan riwayat" menyala) dan mengirim beberapa pesan terakhir ke `POST /v1/chat` dengan token ID Firebase.
2. Backend memverifikasi token, memeriksa batas per pengguna, merapikan riwayat, lalu membuat prompt sistem: aturan dasar QELVO, nama penyedia dan model yang sedang menjawab, dan gaya pilihan pengguna dari daftar tetap.
3. Backend memanggil penyedia dengan streaming dan meneruskan potongan teks ke aplikasi sebagai SSE. Potongan pertama diambil dulu supaya penolakan awal (kuota, key) menjadi status HTTP yang benar.
4. Aplikasi menampilkan teks yang masuk. Saat selesai, jawaban disimpan ke Firestore (satu kali, bukan per token).

Kalau pengguna menekan berhenti atau meninggalkan layar, koneksi ke backend ditutup, dan backend menutup koneksi ke penyedia.

## Login

**Google.** Aplikasi memakai `FirebaseAuth.signInWithProvider(GoogleAuthProvider())`, yang membuka halaman login Google lewat Custom Tab. Tidak ada paket `google_sign_in`.

**Email dengan kode.** Firebase tidak punya kode OTP email bawaan, jadi alurnya dibuat di backend:

1. `POST /v1/auth/email/start`: backend membuat kode 6 digit, menyimpan hash HMAC-nya (dengan `CODE_PEPPER`) di Firestore koleksi `email_codes`, dan mengirim emailnya lewat SMTP.
2. `POST /v1/auth/email/verify`: kalau kode benar (belum kedaluwarsa, belum melewati batas percobaan), backend menghapus kodenya, membuat atau memperbarui akun Firebase dengan email terverifikasi, lalu mengembalikan custom token.
3. Aplikasi memanggil `signInWithCustomToken`. Sesudah itu alurnya sama dengan login Google.

Kalau email yang sama nanti dipakai masuk dengan Google, perilakunya mengikuti pengaturan "satu akun per email" di Firebase Authentication.

## Model data Firestore

```
users/{uid}/conversations/{conversationId}
    title, modelLabel, preview, createdAt, updatedAt
users/{uid}/conversations/{conversationId}/messages/{messageId}
    role ("user" | "assistant"), content, createdAt, rating (-1, 0, 1)

email_codes/{sha256(email)}        // hanya diakses backend
    code_hash, expires_at, attempts, sent_at, window_start, sent_in_window
```

`firestore.rules` mengizinkan akses ke `users/{uid}/**` hanya untuk pengguna dengan `uid` yang sama. Koleksi lain tidak bisa diakses dari aplikasi. Backend memakai Admin SDK yang tidak terkena aturan itu.

Aplikasi tidak memakai SQLite. Firestore di Android juga menyimpan cache lokal, jadi riwayat yang sudah pernah dimuat tetap terbaca saat koneksi buruk.

## Keamanan

- Server memeriksa token di setiap panggilan chat dan katalog. Gerbang login di aplikasi bukan satu-satunya penjaga.
- Klien tidak bisa mengirim prompt sistem. Gaya jawaban hanya dipilih dari daftar tetap, dan riwayat chat diperlakukan sebagai konteks, bukan perintah.
- API key penyedia dan akun layanan hanya ada di environment variable server.
- Batas pemakaian: per pengguna untuk chat, per IP untuk login email, per email untuk kode. Pembatas ada di memori satu proses.
- Isi pesan tidak dicatat di log server. Penyedia hosting masih bisa mencatat metadata permintaan.
- Kode email: acak kriptografis, disimpan sebagai HMAC, sekali pakai, kedaluwarsa, dan jumlah salah ketik dibatasi.

## Batasan yang diketahui

- Pembatas di memori tidak dibagi antar instance server.
- Pencarian riwayat hanya di judul dan cuplikan jawaban terakhir.
- Ekspor menyalin ke clipboard (maksimal sekitar 300 ribu karakter), bukan berbagi berkas.
- Gambar, berkas, dan suara belum didukung.
