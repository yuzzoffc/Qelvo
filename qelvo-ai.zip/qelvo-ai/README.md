<p align="center">
  <img src="docs/assets/qelvo-logo.png" width="96" alt="Logo QELVO">
</p>

# QELVO AI

Asisten AI untuk bertanya, belajar, menulis, dan coding. Aplikasi Android (Flutter) dengan login wajib (Google atau email dengan kode OTP; tanpa akun tamu), riwayat chat di Firebase (Firestore, diakses lewat backend), dan backend FastAPI terpisah (proyek `qelvo-api`) yang meneruskan pesan ke Gemini atau OpenRouter.

Versi 0.1.0, tahap MVP. Jawaban dibuat oleh model milik penyedia API, bukan model buatan QELVO. Aplikasi dan prompt sistem menyatakan hal ini apa adanya.

## Cara kerja

```
Aplikasi Flutter ── login Google / kode email ──> Firebase Authentication
      │                                                   │
      │  token ID Firebase                                │ custom token
      ▼                                                   │ (email, opsional)
Backend FastAPI ── verifikasi token, batas pemakaian ─────┘
      │                 │
      │                 ├─ kirim kode 6 digit lewat SMTP
      │                 └─ riwayat chat <──> Cloud Firestore (users/{uid}/conversations/...)
      ▼
Gemini (Google AI Studio) atau OpenRouter
```

Login email memakai kode 6 digit (OTP) yang dikirim backend lewat SMTP, lalu custom token Firebase. Aplikasi menampilkannya secara bawaan; `EMAIL_LOGIN=false` menyembunyikannya ([docs/ENV.md](docs/ENV.md)).

Aplikasi tidak mengakses Firestore langsung. `firestore.rules` berisi tolak-semua, dan riwayat chat dibaca serta ditulis backend lewat Admin SDK (endpoint `/v1/conversations`), yang membatasi tiap permintaan ke pemilik token.

## Isi repo

| Folder | Isi |
| --- | --- |
| `app/` | Aplikasi Flutter: splash, login, chat streaming, riwayat, akun, pengaturan. Kode native kecil untuk jawaban di latar belakang ada di `app/tool/android/` |
| `docs/` | Panduan setup, env aplikasi ([ENV.md](docs/ENV.md)), kontrak API, panduan Cari web ([WEB_SEARCH.md](docs/WEB_SEARCH.md)), panduan pembaruan OTA ([OTA.md](docs/OTA.md)), arsitektur, catatan desain |
| `firestore.rules` | Aturan keamanan Firestore: tolak semua akses klien |
| `.github/workflows/` | Build APK dan pembuat keystore debug (hasilnya terenkripsi) |

Backend ada di proyek terpisah, `qelvo-api`, supaya bisa di-deploy dan diperbarui sendiri.

## Mulai cepat

Panduan lengkap dengan langkah di Firebase Console ada di [docs/SETUP.md](docs/SETUP.md). Ringkasnya:

1. Buat proyek Firebase, aktifkan login Google dan Firestore, pasang `firestore.rules`, lalu buat akun layanan untuk backend. Login email memakai kode OTP lewat SMTP di backend (docs/SETUP.md).
2. Siapkan backend: proyek terpisah `qelvo-api`. README-nya memuat cara menjalankan dan deploy gratis ke Vercel dari HP, termasuk mengisi `FIREBASE_CREDENTIALS_JSON` agar riwayat jalan. Catat alamat HTTPS-nya.
3. Jalankan aplikasi (butuh Flutter):
   ```bash
   cd app
   cp env.example.json env.json   # isi nilai dari Firebase
   bash tool/setup_android.sh     # membuat folder android/ dan ikon
   flutter run --dart-define-from-file=env.json
   ```
4. Atau biarkan GitHub Actions membuat APK: isi variabel repo ([docs/ENV.md](docs/ENV.md)), lalu jalankan workflow **Build APK**. APK muncul di tab Releases.

## Fitur v0.1.0

- Login Google atau email dengan kode 6 digit (OTP). Chat tidak bisa dipakai sebelum masuk, dan server ikut memeriksa token. Akun tamu sudah ditiadakan; sisa sesi tamu dari versi lama otomatis dikeluarkan.
- Hapus akun dari Pengaturan, Akun (kode 6 digit dikirim ke email akun), atau lewat halaman web `/hapus-akun` di server tanpa membuka aplikasi.
- Kuota harian per akun di server dan model cadangan otomatis kalau kuota atau penyedia bermasalah.
- Judul percakapan otomatis dari AI, ganti nama dan sematkan percakapan (tekan lama di riwayat), ubah pesan terakhir lalu kirim ulang, kolom "Tentang kamu" di Pengaturan (nama dan gaya jawab), dan input suara lewat mikrofon bawaan Android.
- Penanda "QELVO sedang mencari di web" muncul begitu server memutuskan mencari.
- Laporan crash otomatis (teks teknis saja, tanpa isi percakapan, nama, atau email) ke server; bisa dimatikan di Pengaturan.
- Jawaban mengalir per potongan, bisa dihentikan, diulang, disalin, dan dinilai (suka atau tidak suka).
- Markdown, tabel, dan blok kode dengan tombol salin.
- Riwayat per akun di Firestore (lewat backend), pencarian di judul, hapus satu atau semua, ekspor ke Markdown.
- Pilihan model dari server (penyedia mengikuti model), mode berpikir, empat gaya instruksi, tema gelap dan terang, tiga ukuran teks.
- Tombol **+** di kolom pesan membuka lembar Tambahkan ke chat: Foto, Cari web, dan Berpikir (sakelar menyala atau mati). Foto dipilih lewat pemilih foto bawaan HP, sampai 4 foto per pesan, tanpa izin galeri. Foto dikecilkan dan dibersihkan dari metadata (termasuk lokasi) sebelum dikirim, lalu dibaca model yang mendukung gambar. Butuh qelvo-api yang sudah mendukung foto: `/v1/providers` harus memuat `"vision": true`.
- Jawaban tetap mengalir saat aplikasi ditinggal (Home, pindah aplikasi, layar mati) lewat wake lock berbatas waktu, tanpa pemberitahuan selama berjalan. Pemberitahuan "QELVO sudah menjawab" muncul hanya saat jawaban selesai dan aplikasi sedang tidak terlihat; jawaban yang gagal tidak memberi pemberitahuan. Tombol kembali menyembunyikan aplikasi selama ada jawaban yang mengalir. Berpindah ke percakapan lain di dalam aplikasi tidak menghentikan jawaban: percakapan yang ditinggalkan tetap berjalan sampai selesai dan tersimpan (di riwayat tampil pemutar kecil selama berjalan dan titik kecil saat selesai), dan lengkap begitu dibuka lagi. Itu berlaku bila riwayat tersimpan; tanpa riwayat, alirannya dihentikan seperti biasa. Tidak berlaku kalau aplikasi digeser dari daftar terbaru, dan Android masih bisa mematikan proses kalau memorinya habis (docs/ARCHITECTURE.md, Batasan).
- Layar Akun dengan nama yang bisa diubah. Pita "Tidak ada koneksi internet" dan tombol Coba lagi saat pesan gagal terkirim.

## Belum ada

Ditandai "Segera" di aplikasi atau tidak dipasang, supaya tidak ada tombol yang tidak berfungsi:

- Cari web: sakelar di lembar +, otomatis. Server menilai sendiri apakah pertanyaanmu butuh info terbaru (cuaca, kurs, berita, atau diminta langsung), lalu mencari lewat Google Search Grounding (Gemini) atau plugin pencarian web OpenRouter, dan melengkapi jawaban dengan tombol Sumber. Butuh `qelvo-api` versi terbaru dengan model yang bertanda `cari` (docs/WEB_SEARCH.md); sampai itu siap, barisnya berlabel "Segera hadir".
- Pembaruan lewat GitHub (OTA, semi otomatis): aplikasi memeriksa rilis resmi saat dibuka, menawarkannya lewat lembar, lalu mengunduh dan memeriksa checksum-nya setelah kamu setuju dan membuka pemasang Android. Tanpa pemberitahuan. Panduan: docs/OTA.md.
- QELVO Intelligence, pemilihan model otomatis (tidak ada di desain terbaru, tidak dipasang).
- Di layar Akun: foto profil, ganti email, dan daftar perangkat yang masuk.
- Pencarian riwayat hanya menjangkau judul dan cuplikan jawaban terakhir (Firestore tidak punya pencarian teks).

## Status pengujian

- Backend: tesnya ada di proyek `qelvo-api`.
- Aplikasi Flutter: kode ditulis tanpa compiler Dart. Struktur seluruh berkas `.dart` dicek dengan skrip (kurung seimbang, impor, nama kelas), bukan dengan compiler, jadi belum pernah dikompilasi atau dijalankan di sini. Tes `app/test` (termasuk `history_test.dart`, `features_test.dart`, dan `logo_test.dart`) dijalankan workflow Build APK lewat `flutter test`. Kode Kotlin di `app/tool/android/` (wake lock, pemberitahuan, input suara, pemasang pembaruan, dan jembatannya) juga belum pernah dikompilasi di sini, jadi build APK berikutnya yang pertama kali membuktikannya. Kalau `flutter run` atau build menampilkan error, kirim lognya.

## Lisensi

Belum ditentukan. Draf Ketentuan dan Kebijakan Privasi di aplikasi berisi bagian bertanda `[ ]` yang harus diisi pemilik sebelum rilis publik.
