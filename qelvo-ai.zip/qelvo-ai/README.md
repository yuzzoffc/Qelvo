<p align="center">
  <img src="docs/assets/qelvo-logo.png" width="96" alt="Logo QELVO">
</p>

# QELVO AI

Asisten AI untuk bertanya, belajar, menulis, dan coding. Aplikasi Android (Flutter) dengan login wajib (Google atau tamu; login email dengan kode dimatikan sementara), riwayat chat di Firebase (Firestore, diakses lewat backend), dan backend FastAPI terpisah (proyek `qelvo-api`) yang meneruskan pesan ke Gemini atau OpenRouter.

Versi 0.1.0, tahap MVP. Jawaban dibuat oleh model milik penyedia API, bukan model buatan QELVO. Aplikasi dan prompt sistem menyatakan hal ini apa adanya.

## Cara kerja

```
Aplikasi Flutter ── login Google / tamu ────────> Firebase Authentication
      │                                                   │
      │  token ID Firebase                                │ custom token
      ▼                                                   │ (email, opsional)
Backend FastAPI ── verifikasi token, batas pemakaian ─────┘
      │                 │
      │                 ├─ kirim kode 6 digit lewat SMTP
      │                 └─ riwayat chat <──> Cloud Firestore (users/{uid}/conversations/...)
      ▼
Gemini (Google AI Studio) atau OpenRouter
```

Tamu masuk lewat akun anonim Firebase (tanpa email). Alur email dengan kode (custom token dan SMTP) masih ada di kode tetapi dimatikan sementara; nyalakan dengan `EMAIL_LOGIN` ([docs/ENV.md](docs/ENV.md)).

Aplikasi tidak mengakses Firestore langsung. `firestore.rules` berisi tolak-semua, dan riwayat chat dibaca serta ditulis backend lewat Admin SDK (endpoint `/v1/conversations`), yang membatasi tiap permintaan ke pemilik token.

## Isi repo

| Folder | Isi |
| --- | --- |
| `app/` | Aplikasi Flutter: splash, login, chat streaming, riwayat, akun, pengaturan. Kode native kecil untuk jawaban di latar belakang ada di `app/tool/android/` |
| `docs/` | Panduan setup, env aplikasi ([ENV.md](docs/ENV.md)), kontrak API, arsitektur, catatan desain |
| `firestore.rules` | Aturan keamanan Firestore: tolak semua akses klien |
| `.github/workflows/` | Build APK dan pembuat keystore debug |

Backend ada di proyek terpisah, `qelvo-api`, supaya bisa di-deploy dan diperbarui sendiri.

## Mulai cepat

Panduan lengkap dengan langkah di Firebase Console ada di [docs/SETUP.md](docs/SETUP.md). Ringkasnya:

1. Buat proyek Firebase, aktifkan login Google, Anonymous (untuk tamu), dan Firestore, pasang `firestore.rules`, lalu buat akun layanan untuk backend.
2. Siapkan backend: proyek terpisah `qelvo-api`. README-nya memuat cara menjalankan dan deploy gratis ke Vercel dari HP, termasuk mengisi `FIREBASE_CREDENTIALS_JSON` agar riwayat jalan. Catat alamat HTTPS-nya.
3. Jalankan aplikasi (butuh Flutter):
   ```bash
   cd app
   cp env.example.json env.json   # isi nilai dari Firebase
   bash tool/setup_android.sh     # membuat folder android/ dan ikon
   flutter run --dart-define-from-file=env.json
   ```
4. Atau biarkan GitHub Actions membuat APK: isi variabel repo ([docs/ENV.md](docs/ENV.md)), lalu jalankan workflow **Build APK**. APK muncul di tab Releases.

## Fitur v0.1.0

- Login Google atau sebagai tamu (akun anonim Firebase; riwayat tamu dihapus saat keluar). Login email dengan kode 6 digit sudah ada tetapi dimatikan sementara. Chat tidak bisa dipakai sebelum masuk, dan server ikut memeriksa token. Tamu dibatasi per IP.
- Jawaban mengalir per potongan, bisa dihentikan, diulang, disalin, dan dinilai (suka atau tidak suka).
- Markdown, tabel, dan blok kode dengan tombol salin.
- Riwayat per akun di Firestore (lewat backend), pencarian di judul, hapus satu atau semua, ekspor ke Markdown.
- Pilihan model dari server (penyedia mengikuti model), mode berpikir, empat gaya instruksi, tema gelap dan terang, tiga ukuran teks.
- Tombol **+** di kolom pesan membuka lembar Tambahkan ke chat: Foto, Cari web, dan Berpikir (sakelar menyala atau mati). Foto dipilih lewat pemilih foto bawaan HP, sampai 4 foto per pesan, tanpa izin galeri. Foto dikecilkan dan dibersihkan dari metadata (termasuk lokasi) sebelum dikirim, lalu dibaca model yang mendukung gambar. Butuh qelvo-api yang sudah mendukung foto: `/v1/providers` harus memuat `"vision": true`.
- Jawaban tetap mengalir saat aplikasi ditinggal (Home, pindah aplikasi, layar mati): layanan latar depan dengan pemberitahuan "QELVO sedang menjawab", lalu "QELVO sudah menjawab" kalau selesai saat aplikasi tidak terlihat. Tombol kembali menyembunyikan aplikasi selama jawaban mengalir. Tidak berlaku kalau aplikasi digeser dari daftar terbaru (lihat docs/ARCHITECTURE.md, Batasan).
- Layar Akun dengan nama yang bisa diubah. Pita "Tidak ada koneksi internet" dan tombol Coba lagi saat pesan gagal terkirim.

## Belum ada

Ditandai "Segera" di aplikasi atau tidak dipasang, supaya tidak ada tombol yang tidak berfungsi:

- Cari web (baris di lembar + tampil dengan label "Segera hadir" dan sakelar mati).
- QELVO Intelligence, pemilihan model otomatis (tidak ada di desain terbaru, tidak dipasang).
- Input suara (mikrofon) tidak dipasang.
- Di layar Akun: foto profil, ganti email, daftar perangkat yang masuk, dan hapus akun.
- Memindahkan akun tamu ke akun Google. Riwayat tamu tidak ikut pindah.
- Pencarian riwayat hanya menjangkau judul dan cuplikan jawaban terakhir (Firestore tidak punya pencarian teks).

## Status pengujian

- Backend: tesnya ada di proyek `qelvo-api`.
- Aplikasi Flutter: kode ditulis tanpa compiler Dart. Struktur seluruh berkas `.dart` dicek dengan skrip (kurung seimbang, impor, nama kelas), bukan dengan compiler, jadi belum pernah dikompilasi atau dijalankan di sini. Tes `app/test` (termasuk `history_test.dart` dan `logo_test.dart`) dijalankan workflow Build APK lewat `flutter test`. Kode Kotlin di `app/tool/android/` (layanan latar depan dan jembatannya) juga belum pernah dikompilasi di sini, jadi build APK berikutnya yang pertama kali membuktikannya. Kalau `flutter run` atau build menampilkan error, kirim lognya.

## Lisensi

Belum ditentukan. Draf Ketentuan dan Kebijakan Privasi di aplikasi berisi bagian bertanda `[ ]` yang harus diisi pemilik sebelum rilis publik.
