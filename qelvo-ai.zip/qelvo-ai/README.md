<p align="center">
  <img src="docs/assets/qelvo-logo.png" width="96" alt="Logo QELVO">
</p>

# QELVO AI

Asisten AI untuk bertanya, belajar, menulis, dan coding. Aplikasi Android (Flutter) dengan login wajib (Google atau kode verifikasi email), riwayat chat di Firebase, dan backend FastAPI yang meneruskan pesan ke Gemini atau OpenRouter.

Versi 0.1.0, tahap MVP. Jawaban dibuat oleh model milik penyedia API, bukan model buatan QELVO. Aplikasi dan prompt sistem menyatakan hal ini apa adanya.

## Cara kerja

```
Aplikasi Flutter ── login Google / kode email ──> Firebase Authentication
      │                                                   │
      │  token ID Firebase                                │ custom token
      ▼                                                   │ (login email)
Backend FastAPI ── verifikasi token, batas pemakaian ─────┘
      │                 │
      │                 └─ kirim kode 6 digit lewat SMTP
      ▼
Gemini (Google AI Studio) atau OpenRouter

Riwayat chat: aplikasi <──> Cloud Firestore (users/{uid}/conversations/...)
```

Backend tidak menyimpan isi percakapan. Aplikasi membaca dan menulis riwayat langsung ke Firestore, dan aturan keamanan membatasi akses ke pemilik akun.

## Isi repo

| Folder | Isi |
| --- | --- |
| `app/` | Aplikasi Flutter: splash, login, chat streaming, riwayat, pengaturan |
| `backend/` | FastAPI: `/v1/chat` (SSE), `/v1/providers`, `/v1/auth/email/*` |
| `docs/` | Panduan setup, API, arsitektur, catatan desain |
| `firestore.rules` | Aturan keamanan Firestore |
| `.github/workflows/` | Build APK dan pembuat keystore debug |
| `.env.example` | Contoh konfigurasi backend (salin ke `backend/.env`) |

## Mulai cepat

Panduan lengkap dengan langkah di Firebase Console ada di [docs/SETUP.md](docs/SETUP.md). Ringkasnya:

1. Buat proyek Firebase, aktifkan login Google dan Firestore, pasang `firestore.rules`.
2. Jalankan backend:
   ```bash
   cd backend
   python -m venv .venv && source .venv/bin/activate
   pip install -r requirements.txt
   cp ../.env.example .env        # isi API key, kredensial Firebase, dan SMTP
   uvicorn app.main:app --reload
   ```
3. Jalankan aplikasi (butuh Flutter):
   ```bash
   cd app
   cp env.example.json env.json   # isi nilai dari Firebase
   bash tool/setup_android.sh     # membuat folder android/ dan ikon
   flutter run --dart-define-from-file=env.json
   ```
4. Atau biarkan GitHub Actions membuat APK: isi variabel repo, jalankan workflow `Build APK`.

## Fitur v0.1.0

- Login Google, atau email dengan kode 6 digit yang dikirim otomatis. Chat tidak bisa dipakai sebelum login, dan server ikut memeriksa token.
- Jawaban mengalir per potongan, bisa dihentikan, diulang, disalin, dan dinilai (suka atau tidak suka).
- Markdown, tabel, dan blok kode dengan tombol salin.
- Riwayat per akun di Firestore, pencarian di judul, hapus satu atau semua, ekspor ke Markdown.
- Pilihan penyedia dan model dari server, mode berpikir, empat gaya instruksi, tema gelap dan terang, tiga ukuran teks.

## Belum ada

Ditandai "Segera" di aplikasi atau tidak dipasang, supaya tidak ada tombol yang tidak berfungsi:

- Cari web (chip tampil dengan label "Segera").
- QELVO Intelligence, pemilihan model otomatis (kartu "Segera").
- Lampiran (tombol +) dan input suara (mikrofon) tidak dipasang.
- Hapus akun dari dalam aplikasi.
- Pencarian riwayat hanya menjangkau judul dan cuplikan jawaban terakhir (Firestore tidak punya pencarian teks).

## Status pengujian

- Backend: 33 tes untuk modul murni (konteks, pembatas, konfigurasi, kode email, klaim token, parser) lulus. 12 tes endpoint FastAPI sudah ditulis tetapi belum dijalankan karena paket belum terpasang di lingkungan tempat kode ini dibuat. Jalankan `python -m unittest discover -s tests -t .` di folder `backend`.
- Aplikasi Flutter: kode ditulis tanpa compiler Dart. Struktur sudah dicek otomatis (kurung, string, impor), tetapi belum pernah dikompilasi atau dijalankan. Kalau `flutter run` atau build menampilkan error, kirim lognya.

## Lisensi

Belum ditentukan. Draf Ketentuan dan Kebijakan Privasi di aplikasi berisi bagian bertanda `[ ]` yang harus diisi pemilik sebelum rilis publik.
