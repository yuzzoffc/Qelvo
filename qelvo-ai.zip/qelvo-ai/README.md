<p align="center">
  <img src="docs/assets/qelvo-logo.png" width="96" alt="Logo QELVO">
</p>

# QELVO AI

Asisten AI untuk bertanya, belajar, menulis, dan coding. Aplikasi Android (Flutter) dengan login wajib (Google atau tamu; login email dengan kode dimatikan sementara), riwayat chat di Firebase (Firestore, diakses lewat backend), dan backend FastAPI terpisah (proyek `qelvo-api`) yang meneruskan pesan ke Gemini atau OpenRouter.

Versi 0.1.0, tahap MVP. Jawaban dibuat oleh model milik penyedia API, bukan model buatan QELVO. Aplikasi dan prompt sistem menyatakan hal ini apa adanya.

## Cara kerja

```
Aplikasi Flutter ── login Google / tamu ────────> Firebase Authentication
      │                                                   │
      │  token ID Firebase                                │ custom token
      ▼                                                   │ (email, opsional)
Backend FastAPI ── verifikasi token, batas pemakaian ─────┘
      │                 │
      │                 ├─ kirim kode 6 digit lewat SMTP
      │                 └─ riwayat chat <──> Cloud Firestore (users/{uid}/conversations/...)
      ▼
Gemini (Google AI Studio) atau OpenRouter
```

Tamu masuk lewat akun anonim Firebase (tanpa email). Alur email dengan kode (custom token dan SMTP) masih ada di kode tetapi dimatikan sementara; nyalakan dengan `EMAIL_LOGIN` ([docs/ENV.md](docs/ENV.md)).

Aplikasi tidak mengakses Firestore langsung. `firestore.rules` berisi tolak-semua, dan riwayat chat dibaca serta ditulis backend lewat Admin SDK (endpoint `/v1/conversations`), yang membatasi tiap permintaan ke pemilik token.

## Isi repo

| Folder | Isi |
| --- | --- |
| `app/` | Aplikasi Flutter: splash, login, chat streaming, riwayat, pengaturan |
| `docs/` | Panduan setup, env aplikasi ([ENV.md](docs/ENV.md)), kontrak API, arsitektur, catatan desain |
| `firestore.rules` | Aturan keamanan Firestore: tolak semua akses klien |
| `.github/workflows/` | Build APK dan pembuat keystore debug |

Backend ada di proyek terpisah, `qelvo-api`, supaya bisa di-deploy dan diperbarui sendiri.

## Mulai cepat

Panduan lengkap dengan langkah di Firebase Console ada di [docs/SETUP.md](docs/SETUP.md). Ringkasnya:

1. Buat proyek Firebase, aktifkan login Google, Anonymous (untuk tamu), dan Firestore, pasang `firestore.rules`, lalu buat akun layanan untuk backend.
2. Siapkan backend: proyek terpisah `qelvo-api`. README-nya memuat cara menjalankan dan deploy gratis ke Vercel dari HP, termasuk mengisi `FIREBASE_CREDENTIALS_JSON` agar riwayat jalan. Catat alamat HTTPS-nya.
3. Jalankan aplikasi (butuh Flutter):
   ```bash
   cd app
   cp env.example.json env.json   # isi nilai dari Firebase
   bash tool/setup_android.sh     # membuat folder android/ dan ikon
   flutter run --dart-define-from-file=env.json
   ```
4. Atau biarkan GitHub Actions membuat APK: isi variabel repo ([docs/ENV.md](docs/ENV.md)), lalu jalankan workflow **Build APK**. APK muncul di tab Releases.

## Fitur v0.1.0

- Login Google atau sebagai tamu (akun anonim Firebase; riwayat tamu dihapus saat keluar). Login email dengan kode 6 digit sudah ada tetapi dimatikan sementara. Chat tidak bisa dipakai sebelum masuk, dan server ikut memeriksa token. Tamu dibatasi per IP.
- Jawaban mengalir per potongan, bisa dihentikan, diulang, disalin, dan dinilai (suka atau tidak suka).
- Markdown, tabel, dan blok kode dengan tombol salin.
- Riwayat per akun di Firestore (lewat backend), pencarian di judul, hapus satu atau semua, ekspor ke Markdown.
- Pilihan penyedia dan model dari server, mode berpikir, empat gaya instruksi, tema gelap dan terang, tiga ukuran teks.

## Belum ada

Ditandai "Segera" di aplikasi atau tidak dipasang, supaya tidak ada tombol yang tidak berfungsi:

- Cari web (chip tampil dengan label "Segera").
- QELVO Intelligence, pemilihan model otomatis (kartu "Segera").
- Lampiran (tombol +) dan input suara (mikrofon) tidak dipasang.
- Hapus akun dari dalam aplikasi.
- Memindahkan akun tamu ke akun Google. Riwayat tamu tidak ikut pindah.
- Pencarian riwayat hanya menjangkau judul dan cuplikan jawaban terakhir (Firestore tidak punya pencarian teks).

## Status pengujian

- Backend: tesnya ada di proyek `qelvo-api`.
- Aplikasi Flutter: kode ditulis tanpa compiler Dart. Sintaks seluruh berkas `.dart` sudah dicek dengan parser Dart, tetapi belum pernah dikompilasi atau dijalankan di sini. Tes `app/test` (termasuk `history_test.dart`) dijalankan workflow Build APK lewat `flutter test`. Kalau `flutter run` atau build menampilkan error, kirim lognya.

## Lisensi

Belum ditentukan. Draf Ketentuan dan Kebijakan Privasi di aplikasi berisi bagian bertanda `[ ]` yang harus diisi pemilik sebelum rilis publik.
