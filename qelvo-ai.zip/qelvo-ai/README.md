<p align="center">
  <img src="docs/assets/qelvo-logo.png" width="96" alt="Logo QELVO">
</p>

# QELVO AI

Asisten AI untuk bertanya, belajar, menulis, dan coding. Aplikasi Android (Flutter) dengan login wajib (Google atau tamu; login email dengan kode dimatikan sementara), riwayat chat di Firebase, dan backend FastAPI yang meneruskan pesan ke Gemini atau OpenRouter.

Versi 0.1.0, tahap MVP. Jawaban dibuat oleh model milik penyedia API, bukan model buatan QELVO. Aplikasi dan prompt sistem menyatakan hal ini apa adanya.

## Cara kerja

```
Aplikasi Flutter ── login Google / tamu ────────> Firebase Authentication
      │                                                   │
      │  token ID Firebase                                │ custom token
      ▼                                                   │ (email, opsional)
Backend FastAPI ── verifikasi token, batas pemakaian ─────┘
      │                 │
      │                 └─ kirim kode 6 digit lewat SMTP
      ▼
Gemini (Google AI Studio) atau OpenRouter

Riwayat chat: aplikasi <──> Cloud Firestore (users/{uid}/conversations/...)
```

Tamu masuk lewat akun anonim Firebase (tanpa email). Alur email dengan kode (custom token dan SMTP) masih ada di kode tetapi dimatikan sementara; nyalakan dengan `EMAIL_LOGIN` ([docs/ENV.md](docs/ENV.md)).

Backend tidak menyimpan isi percakapan. Aplikasi membaca dan menulis riwayat langsung ke Firestore, dan aturan keamanan membatasi akses ke pemilik akun.

## Isi repo

| Folder | Isi |
| --- | --- |
| `app/` | Aplikasi Flutter: splash, login, chat streaming, riwayat, pengaturan |
| `backend/` | FastAPI: `/v1/chat` (SSE), `/v1/providers`, `/v1/auth/email/*` |
| `docs/` | Panduan setup, daftar env lengkap ([ENV.md](docs/ENV.md)), API, arsitektur, catatan desain |
| `firestore.rules` | Aturan keamanan Firestore |
| `.github/workflows/` | Build APK, tes backend, dan pembuat keystore debug |
| `.env.example` | Contoh konfigurasi backend (salin ke `backend/.env`) |

## Mulai cepat

Panduan lengkap dengan langkah di Firebase Console ada di [docs/SETUP.md](docs/SETUP.md). Ringkasnya:

1. Buat proyek Firebase, aktifkan login Google, Anonymous (untuk tamu), dan Firestore, pasang `firestore.rules`.
2. Jalankan backend:
   ```bash
   cd backend
   python -m venv .venv && source .venv/bin/activate
   pip install -r requirements.txt
   cp ../.env.example .env        # isi API key dan kredensial Firebase (SMTP hanya untuk login email)
   uvicorn app.main:app --reload
   ```
3. Jalankan aplikasi (butuh Flutter):
   ```bash
   cd app
   cp env.example.json env.json   # isi nilai dari Firebase
   bash tool/setup_android.sh     # membuat folder android/ dan ikon
   flutter run --dart-define-from-file=env.json
   ```
4. Atau biarkan GitHub Actions membuat APK: isi variabel repo ([docs/ENV.md](docs/ENV.md)), lalu jalankan workflow **Build APK**. APK muncul di tab Releases.

## Fitur v0.1.0

- Login Google atau sebagai tamu (akun anonim Firebase; riwayat tamu dihapus saat keluar). Login email dengan kode 6 digit sudah ada tetapi dimatikan sementara. Chat tidak bisa dipakai sebelum masuk, dan server ikut memeriksa token. Tamu dibatasi per IP.
- Jawaban mengalir per potongan, bisa dihentikan, diulang, disalin, dan dinilai (suka atau tidak suka).
- Markdown, tabel, dan blok kode dengan tombol salin.
- Riwayat per akun di Firestore, pencarian di judul, hapus satu atau semua, ekspor ke Markdown.
- Pilihan penyedia dan model dari server, mode berpikir, empat gaya instruksi, tema gelap dan terang, tiga ukuran teks.

## Belum ada

Ditandai "Segera" di aplikasi atau tidak dipasang, supaya tidak ada tombol yang tidak berfungsi:

- Cari web (chip tampil dengan label "Segera").
- QELVO Intelligence, pemilihan model otomatis (kartu "Segera").
- Lampiran (tombol +) dan input suara (mikrofon) tidak dipasang.
- Hapus akun dari dalam aplikasi.
- Memindahkan akun tamu ke akun Google. Riwayat tamu tidak ikut pindah.
- Pencarian riwayat hanya menjangkau judul dan cuplikan jawaban terakhir (Firestore tidak punya pencarian teks).

## Status pengujian

- Backend: 37 tes untuk modul murni (konteks, pembatas, konfigurasi, kode email, klaim token, parser) lulus. 14 tes endpoint FastAPI sudah ditulis tetapi belum dijalankan karena paket belum terpasang di lingkungan tempat kode ini dibuat. Workflow **Backend test** menjalankannya di GitHub, atau jalankan `python -m unittest discover -s tests -t .` di folder `backend`.
- Aplikasi Flutter: kode ditulis tanpa compiler Dart. Struktur sudah dicek otomatis (kurung, string, impor), tetapi belum pernah dikompilasi atau dijalankan. Kalau `flutter run` atau build menampilkan error, kirim lognya.

## Lisensi

Belum ditentukan. Draf Ketentuan dan Kebijakan Privasi di aplikasi berisi bagian bertanda `[ ]` yang harus diisi pemilik sebelum rilis publik.
